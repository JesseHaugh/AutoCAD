package tvicore.objects;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.EventObject;
import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;
import tvicore.miscellaneous.Misc;
import tvicore.dao.RegionData;

/**
 * Implements a cell editor that uses a formatted text field to edit integer values.
 */
public final class MinutesEditor extends DefaultCellEditor
{
    JFormattedTextField ftf;
    int previousValue;
    private final int minimum, maximum;
    boolean restrictIncrements;
    boolean useIncrements;
    String incrementMessage = "";
    
    public MinutesEditor(int min, int max, boolean increments)
    {
        super(new JFormattedTextField());
        clickCountToStart = 2;
        ftf = (JFormattedTextField)getComponent();
        minimum = min;
        maximum = max;
        restrictIncrements = increments;
        useIncrements = increments;
        
        // Set up the editor for the double cells.
        NumberFormat nf = NumberFormat.getNumberInstance();
        NumberFormatter numberFormatter = new NumberFormatter(nf);
        numberFormatter.setFormat(nf);
        numberFormatter.setMinimum(minimum);
        numberFormatter.setMaximum(maximum);
        
        ftf.setFormatterFactory(new DefaultFormatterFactory(numberFormatter));
        ftf.setValue(minimum);
        ftf.setHorizontalAlignment(JTextField.TRAILING);
        ftf.setFocusLostBehavior(JFormattedTextField.PERSIST);
        
        //React when the user presses Enter while the editor is active.
        //(Tab is handled as specified by JFormattedTextField's focusLostBehavior property.)
        ftf.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "check");
        ftf.getActionMap().put("check", new AbstractAction()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object obj;
                try
                {
                    obj = ftf.getText();
                }
                catch (NullPointerException ex)
                {
                    obj = "";
                }
                if (obj.equals(""))
                {
                    ftf.setText("0");
                }
                String sapcode = getSapCode();
                useIncrements = restrictIncrements;//need to update this everytime, the table re-uses this editor.
                if (RegionData.getFeeder().equals("CZE") && Arrays.asList("0201", "0210", "0211", "0221", "0222", "0223", "0224").contains(sapcode))
                {
                    useIncrements = false;
                }
                if (RegionData.getFeeder().equals("SVK") && Arrays.asList("0238", "0240", "0252").contains(sapcode))
                {
                    useIncrements = false;
                }
                if (RegionData.getFeeder().equals("POL"))
                {
                    useIncrements = false;
                }
                if (ftf.isEditValid() && Misc.minutesValid(obj, useIncrements))
                {
                    try
                    {
                        ftf.commitEdit(); // The text is valid, so use it.
                        ftf.postActionEvent(); // stop editing
                    }
                    catch (java.text.ParseException ex)
                    {
                        
                    }
                }
                else // text is invalid
                {
                    if (userSaysRevert())
                    {
                        ftf.postActionEvent(); // inform the editor
                    }
                }
            }
        });
    }
    @Override
    public boolean isCellEditable(EventObject e)
    {
        if (e instanceof MouseEvent)
        {
            return ((MouseEvent) e).getClickCount() >= clickCountToStart;
        }
        else
        {
            return !(e instanceof KeyEvent);
        }
    }
    
    // Override to invoke setValue on the formatted text field.
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
    {
        ftf = (JFormattedTextField) super.getTableCellEditorComponent(table, value, isSelected, row, column);
        if (ftf.getText() == null || ftf.getText().equals(""))
        {
            previousValue = 0;
        }
        else
        {
            previousValue = Integer.parseInt(ftf.getText());
        }
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                ftf.selectAll();
            }
        });
        return ftf;
    }
    
    /*  Override to check whether the edit is valid, setting the value if it is
        and complaining if it isn't.  If it's OK for the editor to go away, we
        need to invoke the superclass's version of this method so that
        everything gets cleaned up.
    */
    @Override
    public boolean stopCellEditing()
    {
        ftf = (JFormattedTextField)getComponent();
        Object obj;
        try
        {
            obj = ftf.getText();
        }
        catch (NullPointerException ex)
        {
            obj = "";
        }
        if (obj.equals(""))
        {
            ftf.setText("0");
        }
        String sapcode = getSapCode();
        useIncrements = restrictIncrements;//need to update this everytime, the table re-uses this editor.
        if (RegionData.getFeeder().equals("CZE") && Arrays.asList("0201", "0210", "0211", "0221", "0222", "0223", "0224").contains(sapcode))
        {
            useIncrements = false;
        }
        if (RegionData.getFeeder().equals("SVK") && Arrays.asList("0238", "0240", "0252").contains(sapcode))
        {
            useIncrements = false;
        }
        if (RegionData.getFeeder().equals("POL"))
        {
            useIncrements = false;
        }
        if (ftf.isEditValid() && Misc.minutesValid(obj, useIncrements))
        {
            try
            {
                ftf.commitEdit();
            }
            catch (java.text.ParseException ex)
            {
                
            }
        }
        else // text is invalid
        {
            if (!userSaysRevert()) // user wants to edit
            {
                return false; // continue editting
            }
        }
        return super.stopCellEditing();
    }

    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevert()
    {
        if (useIncrements)
        {
            incrementMessage = ",\nand must be entered in 15 minute increments";
        }
        
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "The value must be an integer between " + minimum + " and " + maximum + incrementMessage + ".",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
	    return true;
        }
	return false;
    }
    
    @SuppressFBWarnings(value="DB_DUPLICATE_SWITCH_CLAUSES", justification="index values are the same for all tables, but may not be in the future.")
    String getSapCode()
    {
        String sapcode = "";
        String tableName = ftf.getParent().getName();
        if (tableName != null)
        {
            JTable table = (JTable)ftf.getParent();
            int selectedRow = table.getSelectedRow();
            switch (tableName)
            {
                case "absencesTable":
                    sapcode = table.getValueAt(selectedRow, Misc.getIndexAbsCode()).toString();
                    break;
                case "attendancesTable":
                    sapcode = table.getValueAt(selectedRow, Misc.getIndexAttCode()).toString();
                    break;
                case "extraPaymentsTable":
                    sapcode = table.getValueAt(selectedRow, Misc.getIndexExtCode()).toString();
                    break;
                default:
                    // do nothing; other tables using MinutesEditor without needing to check sapcode
            }
        }
        return sapcode;
    }
}
