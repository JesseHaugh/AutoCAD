package tvicore.dao;

public class AttendanceCodeRecord
{
    private String sapCodeArec;
    private String descriptionArec;
    private String process1Arec;
    private String process2Arec;
    private String process3Arec;
    private String process4Arec;
    private String unionFlagsArec;
    
    public AttendanceCodeRecord(String sapCodeArec, String descriptionArec, String process1Arec, String process2Arec, String process3Arec, String process4Arec, String unionFlagsArec)
    {
        this.sapCodeArec = sapCodeArec;
        this.descriptionArec = descriptionArec;
        this.process1Arec = process1Arec;
        this.process2Arec = process2Arec;
        this.process3Arec = process3Arec;
        this.process4Arec = process4Arec;
        this.unionFlagsArec = unionFlagsArec;
    }
    
    public String getProcess1Arec()    { return process1Arec; }
    public String getSapCodeArec()     { return sapCodeArec; }
    public String getDescriptionArec() { return descriptionArec; }
    public String getProcess2Arec()    { return process2Arec; }
    public String getProcess3Arec()    { return process3Arec; }
    public String getProcess4Arec()    { return process4Arec; }
    public String getUnionFlagsArec()  { return unionFlagsArec; }
    
    public void setProcess1Arec(String value)    { process1Arec = value; }
    public void setSapCodeArec(String value)     { sapCodeArec = value; }
    public void setDescriptionArec(String value) { descriptionArec = value; }
    public void setProcess2Arec(String value)    { process2Arec = value; }
    public void setProcess3Arec(String value)    { process3Arec = value; }
    public void setProcess4Arec(String value)    { process4Arec = value; }
    public void setUnionFlagsArec(String value)  { unionFlagsArec = value; }
    
    @Override
    public String toString() { return sapCodeArec; }
}
