package tvicore.dao;

public class ExtraPaymentCodeRecord
{
    private String codeErec;
    private String descriptionErec;
    private String process1Erec;
    private String process2Erec;
    private String process3Erec;
    private boolean costAssignmentOkErec;
    private String amountTypeErec;
    private String unionFlagsErec;
    
    public ExtraPaymentCodeRecord(String codeErec, String descriptionErec, String process1Erec, String process2Erec, String process3Erec, boolean costAssignmentOkErec, String amountTypeErec, String unionFlagsErec)
    {
        this.codeErec = codeErec;
        this.descriptionErec = descriptionErec;
        this.process1Erec = process1Erec;
        this.process2Erec = process2Erec;
        this.process3Erec = process3Erec;
        this.costAssignmentOkErec = costAssignmentOkErec;
        this.amountTypeErec = amountTypeErec;
        this.unionFlagsErec = unionFlagsErec;
    }
    
    public String getCodeErec()             { return codeErec; }
    public String getDescriptionErec()      { return descriptionErec; }
    public String getProcess1Erec()         { return process1Erec; }
    public String getProcess2Erec()         { return process2Erec; }
    public String getProcess3Erec()         { return process3Erec; }
    public boolean isCostAssignmentOkErec() { return costAssignmentOkErec; }
    public String getAmountTypeErec()       { return amountTypeErec; }
    public String getUnionFlagsErec()       { return unionFlagsErec; }
    
    public void setCodeErec(String value)              { codeErec = value; }
    public void setDescriptionErec(String value)       { descriptionErec = value; }
    public void setProcess1Erec(String value)          { process1Erec = value; }
    public void setProcess2Erec(String value)          { process2Erec = value; }
    public void setProcess3Erec(String value)          { process3Erec = value; }
    public void setCostAssignmentOkErec(boolean value) { costAssignmentOkErec = value; }
    public void setAmountTypeErec(String value)        { amountTypeErec = value; }
    public void setUnionFlagsErec(String value)        { unionFlagsErec = value; }
    
    @Override
    public String toString() { return codeErec; }
}