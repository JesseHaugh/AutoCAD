package tvicore.reports;

import java.awt.Component;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Semaphore;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

public class ExcelReports
{
    public static final Semaphore openingXLSReportLock = new Semaphore(1, true);
    
    /**
     * Generates the excel report for MEX payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList
     * @param preview
     */
    public static void fillPayrollReportMEX(Component parentFrame, String feeder, String site, String empList, boolean preview)
    {
        // Get results
        ResultSetWrapper resultsAbs = Oracle.getResultsAbsencesMEX(parentFrame, feeder, site, empList);
        ResultSet rsAbs = resultsAbs.getResultSet();
        
        ResultSetWrapper resultsPrem = Oracle.getResultsPremiumMEX(parentFrame, feeder, site, empList);
        ResultSet rsPrem = resultsPrem.getResultSet();
        
        ResultSetWrapper resultsAbsClear = Oracle.getResultsClearAbsencesMEX(parentFrame, feeder, site, empList);
        ResultSet rsAbsClear = resultsAbsClear.getResultSet();
        
        ResultSetWrapper resultsPremClear = Oracle.getResultsClearPremiumMEX(parentFrame, feeder, site, empList);
        ResultSet rsPremClear = resultsPremClear.getResultSet();
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            String filename;
            if (preview)
            {
                filename = "TVI_Payroll.xlsx";
            }
            else
            {
                Date curDate = Misc.dateNoTime(Oracle.getCurTimeLocal(parentFrame));
                Calendar cal = Calendar.getInstance();
                cal.setTime(curDate);
                String payrollNum = Misc.getNameOfMonth(parentFrame, cal.get(Calendar.MONTH)).substring(0, 3).toUpperCase(Locale.ENGLISH);
                int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
                if (dayOfMonth <= 14)
                {
                    payrollNum += "-1";
                }
                else if (dayOfMonth <= 28)
                {
                    payrollNum += "-2";
                }
                else
                {
                    payrollNum += "-3";
                }
                filename = "TVI_Payroll_" + payrollNum + ".xlsx";
            }
            
            if (!Misc.deleteFile(filename))
            {
                Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
                return;
            }
            
            createAbsencesSheetMEX(parentFrame, workbook, workbook.createSheet("LY_PY_IT2001"), rsAbs, preview);              // Absences sheet
            createPremiumsSheetMEX(parentFrame, workbook, workbook.createSheet("LY_PY_IT2010"), rsPrem, preview);             // Premiums sheet
            createAbsencesSheetMEX(parentFrame, workbook, workbook.createSheet("CLEAR LY_PY_IT2001"), rsAbsClear, preview);   // Clear Absences sheet
            createPremiumsSheetMEX(parentFrame, workbook, workbook.createSheet("CLEAR LY_PY_IT2010"), rsPremClear, preview);  // Clear Premiums sheet
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building payroll report.");
        }
        finally
        {
            resultsAbs.close();
            resultsPrem.close();
            resultsAbsClear.close();
            resultsPremClear.close();
        }
    }
    
    /**
     * Generates the absences worksheet for MEX payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param workbook
     * @param sheet
     * @param rs
     * @param preview
     * @throws java.sql.SQLException
     */
    public static void createAbsencesSheetMEX(Component parentFrame, XSSFWorkbook workbook, XSSFSheet sheet, ResultSet rs, boolean preview) throws SQLException
    {
        Font arial_10 = workbook.createFont();
        arial_10.setFontName("Arial");
        arial_10.setFontHeightInPoints((short)10);

        Font arial_10_bold = workbook.createFont();
        arial_10_bold.setFontName("Arial");
        arial_10_bold.setFontHeightInPoints((short)10);
        arial_10_bold.setBold(true);

        Font arial_14_bold = workbook.createFont();
        arial_14_bold.setFontName("Arial");
        arial_14_bold.setFontHeightInPoints((short)14);
        arial_14_bold.setBold(true);

        XSSFCellStyle titleFormat = workbook.createCellStyle();
        titleFormat.setFont(arial_14_bold);
        titleFormat.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        titleFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        XSSFCellStyle headerFormat = workbook.createCellStyle();
        headerFormat.setFont(arial_10_bold);
        headerFormat.setBorderBottom(BorderStyle.MEDIUM);
        headerFormat.setWrapText(true);

        XSSFCellStyle lineFormat = workbook.createCellStyle();
        lineFormat.setFont(arial_10);
        
        XSSFCellStyle lineFormatHours = workbook.createCellStyle();
        lineFormatHours.cloneStyleFrom(lineFormat);
        lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));

        int rownum = 0;

        // set column widths
        int col = 0;
        sheet.setColumnWidth(col++, calculateColWidth(13));
        sheet.setColumnWidth(col++, calculateColWidth(13));
        sheet.setColumnWidth(col++, calculateColWidth(13));
        sheet.setColumnWidth(col++, calculateColWidth(10));
        sheet.setColumnWidth(col++, calculateColWidth(10));
        sheet.setColumnWidth(col++, calculateColWidth(8));
        sheet.setColumnWidth(col++, calculateColWidth(12));
        sheet.setColumnWidth(col++, calculateColWidth(18));
        sheet.setColumnWidth(col++, calculateColWidth(15));
        sheet.setColumnWidth(col++, calculateColWidth(16));
        sheet.setColumnWidth(col++, calculateColWidth(20));
        sheet.setColumnWidth(col++, calculateColWidth(14));

        // preview title
        if (preview)
        {
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "This is a preview document and is not intended to be used for payroll.", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 7));
        }

        // write column headers
        Row row = sheet.createRow(rownum++);
        row.setHeight((short)(45*20));
        col = 0;
        addCell(row, col++, "No Personal", headerFormat);
        addCell(row, col++, "Fecha Inicio Validez", headerFormat);
        addCell(row, col++, "Fecha Fin Validez", headerFormat);
        addCell(row, col++, "Subtipo", headerFormat);
        addCell(row, col++, "Hora de inicio", headerFormat);
        addCell(row, col++, "Hora final", headerFormat);
        addCell(row, col++, "Horas de absentismo", headerFormat);
        addCell(row, col++, "Descripción de la enfermedad", headerFormat);
        addCell(row, col++, "Indicador para enfermedad derivada", headerFormat);
        addCell(row, col++, "Indicador para enfermedades múltiples", headerFormat);
        addCell(row, col++, "Días calculables para continuación del pago del salario", headerFormat);
        addCell(row, col++, "Número de referencia", headerFormat);

        if (rs != null)
        {
            while (rs.next())
            {
                row = sheet.createRow(rownum++);
                row.setHeight((short)(13*20));
                addCell(row, 0, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                addCell(row, 1, Misc.objectToString(rs.getObject("STARTDATE")), lineFormat);
                addCell(row, 2, Misc.objectToString(rs.getObject("ENDDATE")), lineFormat);
                addCell(row, 3, Misc.objectToString(rs.getObject("SAP_CODE_TREC")), lineFormat);
                Object hours = rs.getObject("HOURS");
                if (hours != null)
                {
                    if (hours.toString().contains("."))
                    {
                        addCell(row, 6, Misc.objectToDouble(hours), lineFormatHours);
                    }
                    else
                    {
                        addCell(row, 6, Misc.objectToInt(hours), lineFormatHours);
                    }
                }
                addCell(row, 10, Misc.objectToInt(rs.getObject("PRIOR_DAYS")), lineFormat);
                addCell(row, 11, Misc.objectToString(rs.getObject("MEDICAL_ID")), lineFormat);
            }
        }
    }
    
    /**
     * Generates the premiums worksheet for MEX payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param workbook
     * @param sheet
     * @param rs
     * @param preview
     * @throws java.sql.SQLException
     */
    public static void createPremiumsSheetMEX(Component parentFrame, XSSFWorkbook workbook, XSSFSheet sheet, ResultSet rs, boolean preview) throws SQLException
    {
        Font arial_10 = workbook.createFont();
        arial_10.setFontName("Arial");
        arial_10.setFontHeightInPoints((short)10);

        Font arial_10_bold = workbook.createFont();
        arial_10_bold.setFontName("Arial");
        arial_10_bold.setFontHeightInPoints((short)10);
        arial_10_bold.setBold(true);

        Font arial_14_bold = workbook.createFont();
        arial_14_bold.setFontName("Arial");
        arial_14_bold.setFontHeightInPoints((short)14);
        arial_14_bold.setBold(true);

        XSSFCellStyle titleFormat = workbook.createCellStyle();
        titleFormat.setFont(arial_14_bold);
        titleFormat.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        titleFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        XSSFCellStyle headerFormat = workbook.createCellStyle();
        headerFormat.setFont(arial_10_bold);
        headerFormat.setBorderBottom(BorderStyle.MEDIUM);
        headerFormat.setWrapText(true);

        XSSFCellStyle lineFormat = workbook.createCellStyle();
        lineFormat.setFont(arial_10);
        lineFormat.setAlignment(HorizontalAlignment.CENTER);

        XSSFCellStyle lineFormatHours = workbook.createCellStyle();
        lineFormatHours.cloneStyleFrom(lineFormat);
        lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));

        int rownum = 0;

        // set column widths
        int col = 0;
        sheet.setColumnWidth(col++, calculateColWidth(16));
        sheet.setColumnWidth(col++, calculateColWidth(20));
        sheet.setColumnWidth(col++, calculateColWidth(20));
        sheet.setColumnWidth(col++, calculateColWidth(10));
        sheet.setColumnWidth(col++, calculateColWidth(10));
        sheet.setColumnWidth(col++, calculateColWidth(10));
        sheet.setColumnWidth(col++, calculateColWidth(20));
        sheet.setColumnWidth(col++, calculateColWidth(16));

        // preview title
        if (preview)
        {
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "This is a preview document and is not intended to be used for payroll.", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 7));
        }

        // write column headers
        Row row = sheet.createRow(rownum++);
        row.setHeight((short)(22*20));
        col = 0;
        addCell(row, col++, "No Personal", headerFormat);
        addCell(row, col++, "Fecha Inicio Validez", headerFormat);
        addCell(row, col++, "Fecha Fin Validez", headerFormat);
        addCell(row, col++, "Codigo", headerFormat);
        addCell(row, col++, "Subtipo", headerFormat);
        addCell(row, col++, "Unidad", headerFormat);
        addCell(row, col++, "Unidades de tiempo", headerFormat);
        addCell(row, col++, "Cantidad", headerFormat);

        if (rs != null)
        {
            while (rs.next())
            {
                row = sheet.createRow(rownum++);
                row.setHeight((short)(13*20));
                addCell(row, 0, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                addCell(row, 1, Misc.objectToString(rs.getObject("STARTDATE")), lineFormat);
                addCell(row, 2, Misc.objectToString(rs.getObject("ENDDATE")), lineFormat);
                addCell(row, 3, Misc.objectToString(rs.getObject("SAP_CODE_AREC")), lineFormat);
                Object hours = rs.getObject("HOURS_AREC");
                if (hours != null)
                {
                    if (hours.toString().contains("."))
                    {
                        addCell(row, 5, Misc.objectToDouble(hours), lineFormatHours);
                    }
                    else
                    {
                        addCell(row, 5, Misc.objectToInt(hours), lineFormatHours);
                    }
                }
            }
        }
    }
    
    /**
     * Generates the shift plan file for CZE/SVK payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillShiftPlan(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsShiftPlan(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Shift_Plan.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle headerFormatLeft = workbook.createCellStyle();
            headerFormatLeft.cloneStyleFrom(headerFormat);
            headerFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormatDate = workbook.createCellStyle();
            lineFormatDate.cloneStyleFrom(lineFormat);
            lineFormatDate.setDataFormat(workbook.createDataFormat().getFormat("d/mm"));
            
            XSSFCellStyle lineFormatHideZeroes = workbook.createCellStyle();
            lineFormatHideZeroes.cloneStyleFrom(lineFormat);
            lineFormatHideZeroes.setDataFormat(workbook.createDataFormat().getFormat("0;-0;;@"));
            
            XSSFSheet sheet = workbook.createSheet("Shift Plan");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 0;
            addCell(row, col++, "EMP ID", headerFormatLeft);
            addCell(row, col++, "DATE", headerFormat);
            addCell(row, col++, "SHIFT", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormatLeft);
                    addCell(row, col++, (Date)rs.getObject("DAY"), lineFormatDate);
                    Object shift = rs.getObject("SHIFT");
                    if (shift != null)
                    {
                        if (shift.toString().contains("."))
                        {
                            addCell(row, col++, Misc.objectToDouble(shift), lineFormatHideZeroes);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToInt(shift), lineFormatHideZeroes);
                        }
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building shift plan report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll excel report for CZE payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param preview
     * @param corrections
     */
    public static void fillPayrollReportCZE(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean preview, boolean corrections)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollCZE(parentFrame, feeder, site, startDate, endDate, corrections);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll.xlsx";
        if (corrections)
        {
            filename = "TVI_Payroll_Corrections.xlsx";
        }
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            Font arial_14_bold = workbook.createFont();
            arial_14_bold.setFontName("Arial");
            arial_14_bold.setFontHeightInPoints((short)14);
            arial_14_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_14_bold);
            titleFormat.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            titleFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatInt = workbook.createCellStyle();
            lineFormatInt.cloneStyleFrom(lineFormat);
            lineFormatInt.setDataFormat(workbook.createDataFormat().getFormat("0;-0;;@"));
            
            XSSFCellStyle lineFormatDouble = workbook.createCellStyle();
            lineFormatDouble.cloneStyleFrom(lineFormat);
            lineFormatDouble.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));
            
            XSSFSheet sheet = workbook.createSheet("Sheet1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            
            // preview title
            if (preview)
            {
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "This is a preview document and is not intended to be used for payroll.", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 7));
            }
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(20*20));
            col = 0;
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "PERIOD", headerFormat);
            addCell(row, col++, "CODE", headerFormat);
            addCell(row, col++, "HOURS", headerFormat);
            addCell(row, col++, "DAYS", headerFormat);
            addCell(row, col++, "FROM", headerFormat);
            addCell(row, col++, "TILL", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    addCell(row, 0, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormat);
                    addCell(row, 1, Misc.objectToString(rs.getObject("PERIOD")), lineFormat);
                    addCell(row, 2, Misc.objectToInt(rs.getObject("CODE")), lineFormat);
                    Object hours = rs.getObject("HOURS");
                    if (hours != null)
                    {
                        if (hours.toString().contains("."))
                        {
                            addCell(row, 3, Misc.objectToDouble(hours), lineFormatDouble);
                        }
                        else
                        {
                            addCell(row, 3, Misc.objectToInt(hours), lineFormatInt);
                        }
                    }
                    Object days = rs.getObject("DAYS");
                    if (days != null)
                    {
                        if (days.toString().contains("."))
                        {
                            addCell(row, 4, Misc.objectToDouble(days), lineFormatDouble);
                        }
                        else
                        {
                            addCell(row, 4, Misc.objectToInt(days), lineFormatInt);
                        }
                    }
                    
                    addCell(row, 5, Misc.dateToStringMDY((Date)rs.getObject("STARTDATE")), lineFormat);
                    addCell(row, 6, Misc.dateToStringMDY((Date)rs.getObject("ENDDATE")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building LOA report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the sickness summary excel report for Europe
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param reportType "SICK" or "LOA"
     */
    public static void fillSicknessSummaryReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate, String reportType)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsSicknessSummary(parentFrame, feeder, site, startDate, endDate, reportType);
        ResultSet rs = results.getResultSet();
        
        String filename;
        String sheetname;
        switch (reportType)
        {
            case "SICK":
                filename = "TVI_Sickness_Summary.xlsx";
                sheetname = "Sickness Summary";
                break;
            case "LOA":
                filename = "TVI_LOA_Summary.xlsx";
                sheetname = "LOA Summary";
                break;
            default:
                Misc.msgbox(parentFrame, "Unhandled report type, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                return;
        }
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setBold(true);
            arial_10_bold.setFontHeightInPoints((short)10);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_10_bold);
            titleFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            titleFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatHighlight = workbook.createCellStyle();
            lineFormatHighlight.cloneStyleFrom(lineFormat);
            lineFormatHighlight.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            lineFormatHighlight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFSheet sheet = workbook.createSheet(sheetname);
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(20));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            
            // write title
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, reportType + " REPORT, Feeder: " + feeder + " Site: " + site + " Start Date: " + Misc.dateToStringMDY(startDate) + " End Date: " + Misc.dateToStringMDY(endDate), titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 8));
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col++, "Employee", headerFormat);
            addCell(row, col++, "Attuid", headerFormat);
            addCell(row, col++, "Code", headerFormat);
            addCell(row, col++, "SL start", headerFormat);
            addCell(row, col++, "SL end", headerFormat);
            addCell(row, col++, "Hours", headerFormat);
            addCell(row, col++, "Days", headerFormat);
            addCell(row, col++, "Spans Month", headerFormat);
            addCell(row, col++, "Calendar Days", headerFormat);
            
            // Freeze the top two rows
            sheet.createFreezePane(0, 2);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("CODE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("STARTDATE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("ENDDATE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOURS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("DAYS")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("SPANS_MONTHS")), lineFormat);
                    int calendarDays = Misc.objectToInt(rs.getObject("CALENDAR_DAYS"));
                    if (calendarDays >= 20) // highlight the cell
                    {
                        addCell(row, col++, calendarDays, lineFormatHighlight);
                    }
                    else
                    {
                        addCell(row, col++, calendarDays, lineFormat);
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building " + reportType + " report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll excel report for SVK payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param preview
     */
    public static void fillPayrollReportSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean preview)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollSVK(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_14_bold = workbook.createFont();
            arial_14_bold.setFontName("Arial");
            arial_14_bold.setFontHeightInPoints((short)14);
            arial_14_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormatPreview = workbook.createCellStyle();
            titleFormatPreview.setFont(arial_14_bold);
            titleFormatPreview.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            titleFormatPreview.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(calibri_11);
            
            XSSFCellStyle titleFormatBold = workbook.createCellStyle();
            titleFormatBold.cloneStyleFrom(titleFormat);
            titleFormatBold.setFont(calibri_11_bold);
            
            XSSFCellStyle titleFormatBoldRight = workbook.createCellStyle();
            titleFormatBoldRight.cloneStyleFrom(titleFormatBold);
            titleFormatBoldRight.setAlignment(HorizontalAlignment.RIGHT);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle headerFormatCenter = workbook.createCellStyle();
            headerFormatCenter.cloneStyleFrom(headerFormat);
            headerFormatCenter.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle headerFormatStyle1 = workbook.createCellStyle();
            headerFormatStyle1.setFont(calibri_11_bold);
            headerFormatStyle1.setVerticalAlignment(VerticalAlignment.CENTER);
            headerFormatStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormatStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle1.setWrapText(true);
            
            XSSFCellStyle headerFormatStyle2 = workbook.createCellStyle();
            headerFormatStyle2.setFont(calibri_11_bold);
            headerFormatStyle2.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle2.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormatStyle2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle2.setBorderTop(BorderStyle.MEDIUM);
            headerFormatStyle2.setBorderBottom(BorderStyle.THIN);
            headerFormatStyle2.setBorderLeft(BorderStyle.THIN);
            headerFormatStyle2.setBorderRight(BorderStyle.THIN);
            headerFormatStyle2.setWrapText(true);
            
            XSSFCellStyle headerFormatStyle3 = workbook.createCellStyle();
            headerFormatStyle3.setFont(calibri_11_bold);
            headerFormatStyle3.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle3.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormatStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle3.setBorderTop(BorderStyle.THIN);
            headerFormatStyle3.setBorderBottom(BorderStyle.THIN);
            headerFormatStyle3.setBorderLeft(BorderStyle.THIN);
            headerFormatStyle3.setBorderRight(BorderStyle.THIN);
            headerFormatStyle3.setWrapText(true);
            
            XSSFCellStyle headerFormatStyle4 = workbook.createCellStyle();
            headerFormatStyle4.setFont(calibri_11_bold);
            headerFormatStyle4.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle4.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
            headerFormatStyle4.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle4.setBorderTop(BorderStyle.THIN);
            headerFormatStyle4.setBorderBottom(BorderStyle.THIN);
            headerFormatStyle4.setBorderLeft(BorderStyle.THIN);
            headerFormatStyle4.setBorderRight(BorderStyle.THIN);
            headerFormatStyle4.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            
            XSSFSheet sheet = workbook.createSheet(Misc.dateToString(endDate, "MMyyyy"));
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(26));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            
            // preview title
            if (preview)
            {
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "This is a preview document and is not intended to be used for payroll.", titleFormatPreview, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 8));
            }
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Spoločnosť", titleFormatBold);
            addCell(row, 2, "AT&T", titleFormatBoldRight);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Obdobie", titleFormatBold);
            addCell(row, 2, Misc.objectToInt(Misc.dateToString(endDate, "yyyyMM")), titleFormatBold);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Verzia importu", titleFormat);
            addCell(row, 2, 3, titleFormat);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Typ MZ", headerFormat);
            addCell(row, 5, "M-H-1", headerFormatCenter);
            addCell(row, 6, "M-H-2", headerFormatCenter);
            addCell(row, 8, "M-H-3", headerFormatCenter);
            addCell(row, 9, "M-H-4", headerFormatCenter);
            addCell(row, 10, "M-H-5", headerFormatCenter);
            addCell(row, 11, "M-H-6", headerFormatCenter);
            addCell(row, 12, "M-H-7", headerFormatCenter);
            addCell(row, 14, "M-H-8", headerFormatCenter);
            addCell(row, 15, "M-H-9", headerFormatCenter);
            addCell(row, 16, "M-H-10", headerFormatCenter);
            addCell(row, 19, "M-H-11", headerFormatCenter);
            addCell(row, 20, "M-H-12", headerFormatCenter);
            addCell(row, 21, "M-H-13", headerFormatCenter);
            addCell(row, 22, "M-H-14", headerFormatCenter);
            addCell(row, 23, "M-H-15", headerFormatCenter);
            addCell(row, 24, "M-H-16", headerFormatCenter);
            addCell(row, 25, "M-H-17", headerFormatCenter);
            addCell(row, 26, "M-H-18", headerFormatCenter);
            addCell(row, 27, "M-H-19", headerFormatCenter);
            addCell(row, 28, "M-H-20", headerFormatCenter);
            addCell(row, 29, "M-H-21", headerFormatCenter);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Číslo MZ", headerFormat);
            addCell(row, 5, 238, headerFormatCenter);
            addCell(row, 6, 520, headerFormatCenter);
            addCell(row, 7, 831, headerFormatCenter);
            addCell(row, 8, 536, headerFormatCenter);
            addCell(row, 9, 241, headerFormatCenter);
            addCell(row, 10, 212, headerFormatCenter);
            addCell(row, 11, 219, headerFormatCenter);
            addCell(row, 12, 252, headerFormatCenter);
            addCell(row, 13, 834, headerFormatCenter);
            addCell(row, 14, 524, headerFormatCenter);
            addCell(row, 15, 538, headerFormatCenter);
            addCell(row, 16, 524, headerFormatCenter);
            addCell(row, 17, 531, headerFormatCenter);
            addCell(row, 18, 535, headerFormatCenter);
            addCell(row, 19, 238, headerFormatCenter);
            addCell(row, 20, 208, headerFormatCenter);
            addCell(row, 21, 209, headerFormatCenter);
            addCell(row, 22, 223, headerFormatCenter);
            addCell(row, 23, 537, headerFormatCenter);
            addCell(row, 24, 539, headerFormatCenter);
            addCell(row, 25, 540, headerFormatCenter);
            addCell(row, 26, 541, headerFormatCenter);
            addCell(row, 27, 527, headerFormatCenter);
            addCell(row, 28, 525, headerFormatCenter);
            addCell(row, 29, 851, headerFormatCenter);
            addCell(row, 30, 530, headerFormatCenter);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "Personal number", headerFormatStyle2);
            addCell(row, col++, "Surname&Name", headerFormatStyle1);
            addCell(row, col++, "ATTUID", headerFormatStyle1);
            addCell(row, col++, "HRID", headerFormatStyle1);
            addCell(row, col++, "Poradie PP", headerFormatStyle1);
            addCell(row, col++, "OTY", headerFormatStyle2);
            addCell(row, col++, "HOL", headerFormatStyle2);
            addCell(row, col++, "SIK", headerFormatStyle2);
            addCell(row, col++, "ADV", headerFormatStyle2);
            addCell(row, col++, "SBY", headerFormatStyle2);
            addCell(row, col++, "EVE", headerFormatStyle2);
            addCell(row, col++, "NGT", headerFormatStyle2);
            addCell(row, col++, "OTW", headerFormatStyle2);
            addCell(row, col++, "ABF", headerFormatStyle2);
            addCell(row, col++, "ABP", headerFormatStyle2);
            addCell(row, col++, "ADF", headerFormatStyle2);
            addCell(row, col++, "ADP", headerFormatStyle2);
            addCell(row, col++, "ABU", headerFormatStyle2);
            addCell(row, col++, "UNAB", headerFormatStyle2);
            addCell(row, col++, "FHP", headerFormatStyle2);
            addCell(row, col++, "AWSA", headerFormatStyle2);
            addCell(row, col++, "AWSU", headerFormatStyle2);
            addCell(row, col++, "WDPH", headerFormatStyle2);
            addCell(row, col++, "ADU", headerFormatStyle2);
            addCell(row, col++, "ARU", headerFormatStyle2);
            addCell(row, col++, "AAP", headerFormatStyle2);
            addCell(row, col++, "AAU", headerFormatStyle2);
            addCell(row, col++, "AOE", headerFormatStyle2);
            addCell(row, col++, "", headerFormatStyle2);
            addCell(row, col++, "", headerFormatStyle2);
            addCell(row, col++, "", headerFormatStyle2);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(58*20));
            col = 0;
            while (col < 5)  //merge logic for first 5 columns
            {
                CellRangeAddress region = new CellRangeAddress(rownum - 2, rownum - 1, col, col);
                sheet.addMergedRegion(region);
                RegionUtil.setBorderTop(BorderStyle.MEDIUM, region, sheet);
                RegionUtil.setBorderBottom(BorderStyle.THIN, region, sheet);
                RegionUtil.setBorderLeft(BorderStyle.THIN, region, sheet);
                RegionUtil.setBorderRight(BorderStyle.THIN, region, sheet);
                col++;
            }
            addCell(row, col++, "Overtime - Weekday", headerFormatStyle3);
            addCell(row, col++, "Holiday", headerFormatStyle3);
            addCell(row, col++, "Sickness Leave", headerFormatStyle3);
            addCell(row, col++, "Doctor's visit", headerFormatStyle3);
            addCell(row, col++, "Standby", headerFormatStyle3);
            addCell(row, col++, "Evening Duty (7pm-10pm)", headerFormatStyle3);
            addCell(row, col++, "Night Duty  (10pm-6am)", headerFormatStyle3);
            addCell(row, col++, "Overtime - Weekend", headerFormatStyle3);
            addCell(row, col++, "Care for Sick family member", headerFormatStyle3);
            addCell(row, col++, "Paid Absence - Short Term", headerFormatStyle3);
            addCell(row, col++, "Doctor's visit with relative", headerFormatStyle3);
            addCell(row, col++, "Pregnancy Doctor's visit", headerFormatStyle3);
            addCell(row, col++, "Unpaid Absence", headerFormatStyle3);
            addCell(row, col++, "Unexcused Absence Unpaid", headerFormatStyle3);
            addCell(row, col++, "FlexiHours Paid", headerFormatStyle3);
            addCell(row, col++, "Allowance work on Saturday", headerFormatStyle3);
            addCell(row, col++, "Allowance work on Sunday", headerFormatStyle3);
            addCell(row, col++, "Work during public holidays", headerFormatStyle3);
            addCell(row, col++, "Doctor's visit unpaid", headerFormatStyle3);
            addCell(row, col++, "Doctor's visit with relative unpaid", headerFormatStyle3);
            addCell(row, col++, "Accompanying disabled person", headerFormatStyle3);
            addCell(row, col++, "Accompanying disable person unpaid", headerFormatStyle3);
            addCell(row, col++, "Obstacles on side of employer", headerFormatStyle3);
            addCell(row, col++, "Prekazky COVID-19", headerFormatStyle4);
            addCell(row, col++, "Paternity Leave", headerFormatStyle3);
            addCell(row, col++, "AT&T Extra Day Off", headerFormatStyle3);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ATT_HRID")), lineFormat);
                    addCell(row, col++, "", lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_238")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_520")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_831")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_536")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_241")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_212")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_219")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_252")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_834")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_524A")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_538")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_524B")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_531")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_535")), lineFormat);
                    addCell(row, col++, "", lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_221")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_272")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_223")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_537")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_539")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_540")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_541")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_527")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_525")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_851")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_530")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building payroll report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll corrections excel report for SVK payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param sickness
     * @param preview
     */
    public static void fillPayrollCorrectionsReportSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean sickness, boolean preview)
    {
        // Get results
        ResultSetWrapper results;
        if (sickness)
        {
            results = Oracle.getResultsPayrollSVKSickness(parentFrame, feeder, site, startDate, endDate);
        }
        else
        {
            results = Oracle.getResultsPayrollSVK(parentFrame, feeder, site, startDate, endDate);
        }
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll_Corrections.xlsx";
        if (sickness)
        {
            filename = "TVI_Payroll_SICK.xlsx";
        }
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_14_bold = workbook.createFont();
            arial_14_bold.setFontName("Arial");
            arial_14_bold.setFontHeightInPoints((short)14);
            arial_14_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormatPreview = workbook.createCellStyle();
            titleFormatPreview.setFont(arial_14_bold);
            titleFormatPreview.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            titleFormatPreview.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormatStyle1 = workbook.createCellStyle();
            headerFormatStyle1.setFont(calibri_11_bold);
            headerFormatStyle1.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormatStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle1.setWrapText(true);
            
            XSSFCellStyle headerFormatStyle2 = workbook.createCellStyle();
            headerFormatStyle2.setFont(calibri_11_bold);
            headerFormatStyle2.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle2.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormatStyle2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle2.setBorderTop(BorderStyle.THIN);
            headerFormatStyle2.setBorderBottom(BorderStyle.THIN);
            headerFormatStyle2.setBorderLeft(BorderStyle.THIN);
            headerFormatStyle2.setBorderRight(BorderStyle.THIN);
            headerFormatStyle2.setWrapText(true);
            
            XSSFCellStyle headerFormatStyle3 = workbook.createCellStyle();
            headerFormatStyle3.setFont(calibri_11_bold);
            headerFormatStyle3.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
            headerFormatStyle3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatStyle3.setBorderTop(BorderStyle.THIN);
            headerFormatStyle3.setBorderBottom(BorderStyle.THIN);
            headerFormatStyle3.setBorderLeft(BorderStyle.THIN);
            headerFormatStyle3.setBorderRight(BorderStyle.THIN);
            headerFormatStyle3.setAlignment(HorizontalAlignment.CENTER);
            headerFormatStyle3.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            
            XSSFSheet sheet = workbook.createSheet("Sheet1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(16));
            sheet.setColumnWidth(col++, calculateColWidth(20));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            
            // preview title
            if (preview)
            {
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "This is a preview document and is not intended to be used for payroll.", titleFormatPreview, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 7));
            }
            
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "Personal number", headerFormatStyle2);
            addCell(row, col++, "Surname&Name", headerFormatStyle1);
            addCell(row, col++, "ATTUID", headerFormatStyle1);
            addCell(row, col++, "HRID", headerFormatStyle1);
            addCell(row, col++, "OTY", headerFormatStyle2);
            addCell(row, col++, "HOL", headerFormatStyle2);
            addCell(row, col++, "SIK", headerFormatStyle2);
            addCell(row, col++, "ADV", headerFormatStyle2);
            addCell(row, col++, "SBY", headerFormatStyle2);
            addCell(row, col++, "EVE", headerFormatStyle2);
            addCell(row, col++, "NGT", headerFormatStyle2);
            addCell(row, col++, "OTW", headerFormatStyle2);
            addCell(row, col++, "ABF", headerFormatStyle2);
            addCell(row, col++, "ABP", headerFormatStyle2);
            addCell(row, col++, "ADF", headerFormatStyle2);
            addCell(row, col++, "ADP", headerFormatStyle2);
            addCell(row, col++, "ABU", headerFormatStyle2);
            addCell(row, col++, "UNAB", headerFormatStyle2);
            addCell(row, col++, "FHP", headerFormatStyle2);
            addCell(row, col++, "AWSA", headerFormatStyle2);
            addCell(row, col++, "AWSU", headerFormatStyle2);
            addCell(row, col++, "WDPH", headerFormatStyle2);
            addCell(row, col++, "ADU", headerFormatStyle2);
            addCell(row, col++, "ARU", headerFormatStyle2);
            addCell(row, col++, "AAP", headerFormatStyle2);
            addCell(row, col++, "AAU", headerFormatStyle2);
            addCell(row, col++, "AOE", headerFormatStyle2);
            addCell(row, col++, "", headerFormatStyle2);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(54*20));
            col = 0;
            while (col < 4)  //merge logic for first 4 columns
            {
                CellRangeAddress region = new CellRangeAddress(rownum - 2, rownum - 1, col, col);
                sheet.addMergedRegion(region);
                RegionUtil.setBorderTop(BorderStyle.MEDIUM, region, sheet);
                RegionUtil.setBorderBottom(BorderStyle.THIN, region, sheet);
                RegionUtil.setBorderLeft(BorderStyle.THIN, region, sheet);
                RegionUtil.setBorderRight(BorderStyle.THIN, region, sheet);
                col++;
            }
            addCell(row, col++, "Overtime - Weekday", headerFormatStyle2);
            addCell(row, col++, "Holiday", headerFormatStyle2);
            addCell(row, col++, "Sickness Leave", headerFormatStyle2);
            addCell(row, col++, "Doctor's visit", headerFormatStyle2);
            addCell(row, col++, "Standby", headerFormatStyle2);
            addCell(row, col++, "Evening Duty\n(7pm-10pm)", headerFormatStyle2);
            addCell(row, col++, "Night Duty\n(10pm-6am)", headerFormatStyle2);
            addCell(row, col++, "Overtime - Weekend", headerFormatStyle2);
            addCell(row, col++, "Care for Sick family member", headerFormatStyle2);
            addCell(row, col++, "Paid Absence - Short Term", headerFormatStyle2);
            addCell(row, col++, "Doctor's visit with relative", headerFormatStyle2);
            addCell(row, col++, "Pregnancy Doctor's visit", headerFormatStyle2);
            addCell(row, col++, "Unpaid Absence", headerFormatStyle2);
            addCell(row, col++, "Unexcused Absence Unpaid", headerFormatStyle2);
            addCell(row, col++, "FlexiHours Paid", headerFormatStyle2);
            addCell(row, col++, "Allowance work on Saturday", headerFormatStyle2);
            addCell(row, col++, "Allowance work on Sunday", headerFormatStyle2);
            addCell(row, col++, "Work during public holidays", headerFormatStyle2);
            addCell(row, col++, "Doctor's visit unpaid", headerFormatStyle2);
            addCell(row, col++, "Doctor's visit with relative unpaid", headerFormatStyle2);
            addCell(row, col++, "Accompanying disabled person", headerFormatStyle2);
            addCell(row, col++, "Accompanying disable person unpaid", headerFormatStyle2);
            addCell(row, col++, "Obstacles on side of employer", headerFormatStyle2);
            addCell(row, col++, "Prekazky COVID-19", headerFormatStyle3);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ATT_HRID")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_238")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_520")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_831")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_536")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_241")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_212")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_219")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_252")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_834")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_524A")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_538")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_524B")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_531")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_535")), lineFormat);
                    addCell(row, col++, "", lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_221")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_272")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_223")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_537")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_539")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_540")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_541")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_527")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_525")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building payroll corrections report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the meal vouchers file for SVK payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillMealVouchersSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsMealVouchersSVK(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Meal_Vouchers.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("SVK MealVoucher");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "COMPANY", lineFormat);
            addCell(row, col++, "AT&T", lineFormat);
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "PERIOD_BEGIN_DT", lineFormat);
            addCell(row, col++, Integer.parseInt(Misc.dateToString(endDate, "Myyyy")), lineFormatLeft);
            
            // write column headers
            rownum = 6;
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "Personal number", headerFormat);
            addCell(row, col++, "SurnameName", headerFormat);
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "HRID", headerFormat);
            addCell(row, col++, "BonusVouchers", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("ATT_HRID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MEAL_VOUCHERS")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building meal voucher report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the time data report for MEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillTimeDataReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsTimeData(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Time_Data.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10);
            headerFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatHours = workbook.createCellStyle();
            lineFormatHours.cloneStyleFrom(lineFormat);
            lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00"));
            
            XSSFSheet sheet = workbook.createSheet("Sheet 1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(19));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(29));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(20));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col++, "Time / Wage Type", headerFormat);
            addCell(row, col++, "Time / Wage Type", headerFormat);
            addCell(row, col++, "Calendar Year/Month", headerFormat);
            addCell(row, col++, "Master Cost Center", headerFormat);
            addCell(row, col++, "Employee#", headerFormat);
            addCell(row, col++, "Employee Name", headerFormat);
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "Employee Group", headerFormat);
            addCell(row, col++, "Absence Reason Code", headerFormat);
            addCell(row, col++, "Absence Reason Description", headerFormat);
            addCell(row, col++, "Hours", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("TIME_WAGE_TYPE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("TIME_WAGE_TYPE_DESCRIPTION")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("CALENDAR_YEAR_MONTH")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("COSTCENTER")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE_NAME")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ATTUID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE_GROUP")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ABSENCE_REASON_CODE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ABSENCE_REASON_DESCRIPTION")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOURS")), lineFormatHours);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building time data report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll review report for CZE
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillPayrollReviewReportCZE(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollReview(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll_Review.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_9_bold = workbook.createFont();
            calibri_9_bold.setFontName("Calibri");
            calibri_9_bold.setFontHeightInPoints((short)9);
            calibri_9_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_9_bold);
            headerFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormat1 = workbook.createCellStyle();
            headerFormat1.cloneStyleFrom(headerFormat);
            headerFormat1.setAlignment(HorizontalAlignment.CENTER);
            headerFormat1.setFillForegroundColor(IndexedColors.DARK_YELLOW.getIndex());
            headerFormat1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat1.setBorderTop(BorderStyle.THIN);
            headerFormat1.setBorderBottom(BorderStyle.THIN);
            headerFormat1.setBorderLeft(BorderStyle.THIN);
            headerFormat1.setBorderRight(BorderStyle.THIN);
            
            XSSFCellStyle headerFormat2 = workbook.createCellStyle();
            headerFormat2.cloneStyleFrom(headerFormat);
            headerFormat2.setAlignment(HorizontalAlignment.CENTER);
            headerFormat2.setBorderTop(BorderStyle.THIN);
            headerFormat2.setBorderBottom(BorderStyle.THIN);
            headerFormat2.setBorderLeft(BorderStyle.THIN);
            headerFormat2.setBorderRight(BorderStyle.THIN);
            headerFormat2.setWrapText(true);
            
            XSSFCellStyle headerFormat3 = workbook.createCellStyle();
            headerFormat3.cloneStyleFrom(headerFormat);
            headerFormat3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerFormat3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat3.setAlignment(HorizontalAlignment.LEFT);
            headerFormat3.setBorderTop(BorderStyle.THIN);
            headerFormat3.setBorderBottom(BorderStyle.THIN);
            headerFormat3.setBorderLeft(BorderStyle.THIN);
            headerFormat3.setBorderRight(BorderStyle.THIN);
            headerFormat3.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            
            XSSFSheet sheet = workbook.createSheet("Sheet1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(27));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(6));
            sheet.setColumnWidth(col++, calculateColWidth(6));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(13*20));
            col = 0;
            addCell(row, col++, feeder + ", site " + site, headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~Overtime~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~Uplifts for Hours Worked~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 4;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~~~~~Absences Sent to Payroll~~~~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 10));
            col += 11;
            addCell(row, col, "~~~~~Not Sent to Payroll~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
            col += 3;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(13*20));
            col = 0;
            addCell(row, col++, "Month ending " + Misc.dateToStringMDY(endDate), headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 200, headerFormat2);
            addCell(row, col++, 210, headerFormat2);
            addCell(row, col++, 211, headerFormat2);
            addCell(row, col++, 201, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 221, headerFormat2);
            addCell(row, col++, 222, headerFormat2);
            addCell(row, col++, 223, headerFormat2);
            addCell(row, col++, 224, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 232, headerFormat2);
            addCell(row, col++, "MV", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "200/201", headerFormat2, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            addCell(row, col++, 111, headerFormat2);
            addCell(row, col++, 118, headerFormat2);
            addCell(row, col++, 118, headerFormat2);
            addCell(row, col++, 118, headerFormat2);
            addCell(row, col++, 118, headerFormat2);
            addCell(row, col++, 119, headerFormat2);
            addCell(row, col++, 120, headerFormat2);
            addCell(row, col++, 321, headerFormat2);
            addCell(row, col++, 323, headerFormat2);
            addCell(row, col++, 325, headerFormat2);
            addCell(row, col++, 326, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(38*20));
            col = 0;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "REG", headerFormat2);
            addCell(row, col++, "OTW", headerFormat2);
            addCell(row, col++, "OTWE\nOTBHO", headerFormat2);
            addCell(row, col++, "REG +\nOvertime", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "NGT", headerFormat2);
            addCell(row, col++, "REG WEEKEND", headerFormat2);
            addCell(row, col++, "WEEKEND HOLIDAY", headerFormat2);
            addCell(row, col++, "WEEKDAY HOLIDAY", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "SBY", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Adds to\n200\n201", headerFormat2);
            addCell(row, col++, "Adds to\n200\n201", headerFormat2);
            addCell(row, col++, "VAC", headerFormat2);
            addCell(row, col, "Doctor's Visits", headerFormat2, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
            col += 3;
            addCell(row, col++, "ABS PD", headerFormat2);
            addCell(row, col++, "ABS - Unpd", headerFormat2);
            addCell(row, col++, "ABS", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "OCR", headerFormat2);
            addCell(row, col++, "LOA", headerFormat2);
            addCell(row, col++, "ILL", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "FYI Tardy", headerFormat2, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(50*20));
            col = 0;
            addCell(row, col++, "Name", headerFormat3);
            addCell(row, col++, "ATTUID", headerFormat3);
            addCell(row, col++, "Scheduled Shift Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Shift Hours Worked", headerFormat2);
            addCell(row, col++, "Overtime Weekday", headerFormat2);
            addCell(row, col++, "Overtime Weekend or Holiday", headerFormat2);
            addCell(row, col++, "Total Hours Worked", headerFormat2);
            addCell(row, col++, "Total Overtime Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Night\n(10pm-6am)", headerFormat2);
            addCell(row, col++, "Shift Hours - Weekend", headerFormat2);
            addCell(row, col++, "Shift Hours Bank Holiday", headerFormat2);
            addCell(row, col++, "Shift Hours Bank Holiday", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "CMPE", headerFormat2);
            addCell(row, col++, "CMPP", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Standby", headerFormat2);
            addCell(row, col++, "# of Meal Vouchers", headerFormat2);
            addCell(row, col++, "MV Partially Taxable", headerFormat2);
            addCell(row, col++, "MV Taxable", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Comp Time Taken", headerFormat2);
            addCell(row, col++, "Holiday NOT WORKED", headerFormat2);
            addCell(row, col++, "Vacation", headerFormat2);
            addCell(row, col++, "Self", headerFormat2);
            addCell(row, col++, "Relative", headerFormat2);
            addCell(row, col++, "Pregnancy", headerFormat2);
            addCell(row, col++, "Paid Leave Excused", headerFormat2);
            addCell(row, col++, "Unpaid Leave Excused", headerFormat2);
            addCell(row, col++, "Leave Not Excused", headerFormat2);
            addCell(row, col++, "Caregiver Leave", headerFormat2);
            addCell(row, col++, "Bereavement", headerFormat2);
            addCell(row, col++, "Paid Parental Leave", headerFormat2);
            addCell(row, col++, "Paid Parental Leave ATT", headerFormat2);
            addCell(row, col++, "Care for Family Member", headerFormat2);
            addCell(row, col++, "Leave of Absence", headerFormat2);
            addCell(row, col++, "Sick Leave", headerFormat2);
            addCell(row, col++, "Total Absence Hours", headerFormat2);
            addCell(row, col++, "Total Regular + Absence", headerFormat2);
            addCell(row, col++, "Number of Tardies", headerFormat2);
            addCell(row, col++, "Tardy Minutes", headerFormat2);
            
            // Freeze the header rows
            sheet.createFreezePane(0, 4);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SCH_HRS")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("REG_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT_WKDAY_210")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT_WKEND_OR_HLDY_211")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_HOURS_WORKED")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_OT_WORKED")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("NGT_HRS_221")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("WKEND_222")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOLIDAY_WKEND_223")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOLIDAY_WKDAY_224")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPP")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SBY_232")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MEAL_VOUCHERS_TOTAL")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MEAL_VOUCHERS_PART_TAX")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MEAL_VOUCHERS_FULL_TAX")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("BHO_NOT_WRKED")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("VAC_111")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADV_118_M1")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADV_118_M2")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADV_118_M3")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADV_118_M4_M5")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABU_119")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_120")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_321")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_323")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_325")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_326")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_OCR1")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_LOA1")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_ILL1")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_ABS_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_REG_PLUS_ABS")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TOTAL_TARDIES")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TARDY_MINUTES")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building time data report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll review report for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillPayrollReviewReportPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollReview(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll_Review.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_10_bold = workbook.createFont();
            calibri_10_bold.setFontName("Calibri");
            calibri_10_bold.setFontHeightInPoints((short)10);
            calibri_10_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_10_bold);
            headerFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormat1 = workbook.createCellStyle();
            headerFormat1.cloneStyleFrom(headerFormat);
            headerFormat1.setAlignment(HorizontalAlignment.CENTER);
            headerFormat1.setFillForegroundColor(IndexedColors.DARK_YELLOW.getIndex());
            headerFormat1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat1.setBorderTop(BorderStyle.THIN);
            headerFormat1.setBorderBottom(BorderStyle.THIN);
            headerFormat1.setBorderLeft(BorderStyle.THIN);
            headerFormat1.setBorderRight(BorderStyle.THIN);
            
            XSSFCellStyle headerFormat2 = workbook.createCellStyle();
            headerFormat2.cloneStyleFrom(headerFormat);
            headerFormat2.setAlignment(HorizontalAlignment.CENTER);
            headerFormat2.setBorderTop(BorderStyle.THIN);
            headerFormat2.setBorderBottom(BorderStyle.THIN);
            headerFormat2.setBorderLeft(BorderStyle.THIN);
            headerFormat2.setBorderRight(BorderStyle.THIN);
            headerFormat2.setWrapText(true);
            
            XSSFCellStyle headerFormat3 = workbook.createCellStyle();
            headerFormat3.cloneStyleFrom(headerFormat);
            headerFormat3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerFormat3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat3.setAlignment(HorizontalAlignment.LEFT);
            headerFormat3.setBorderTop(BorderStyle.THIN);
            headerFormat3.setBorderBottom(BorderStyle.THIN);
            headerFormat3.setBorderLeft(BorderStyle.THIN);
            headerFormat3.setBorderRight(BorderStyle.THIN);
            headerFormat3.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            lineFormat.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));
            
            XSSFSheet sheet = workbook.createSheet("Sheet1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(27));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(13*20));
            col = 0;
            addCell(row, col++, feeder + ", site " + site, headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~~~~~~Shift Hours Worked~~~~~~~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 4));
            col += 5;
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~Overtime~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 4;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Absences~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 18));
            col += 19;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(38*20));
            col = 0;
            addCell(row, col++, "Month ending " + Misc.dateToStringMDY(endDate), headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "EVEN", headerFormat2);
            addCell(row, col++, "NITE", headerFormat2);
            addCell(row, col++, "WKND", headerFormat2);
            addCell(row, col++, "HOWK", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "EXTA", headerFormat2);
            addCell(row, col++, "EXTP", headerFormat2);
            addCell(row, col++, "EXTO", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "CMPE", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "CMPT", headerFormat2);
            addCell(row, col++, "HLDY", headerFormat2);
            addCell(row, col++, "VAC1", headerFormat2);
            addCell(row, col++, "SICK", headerFormat2);
            addCell(row, col++, "CARE", headerFormat2);
            addCell(row, col++, "CARE", headerFormat2);
            addCell(row, col++, "KIDS", headerFormat2);
            addCell(row, col++, "MPE0", headerFormat2);
            addCell(row, col++, "MUE0", headerFormat2);
            addCell(row, col++, "MUN0", headerFormat2);
            addCell(row, col++, "DAYW", headerFormat2);
            addCell(row, col++, "SUNW", headerFormat2);
            addCell(row, col++, "WEDD", headerFormat2);
            addCell(row, col++, "LOA", headerFormat2);
            addCell(row, col++, "PLOA", headerFormat2);
            addCell(row, col++, "PLO2", headerFormat2);
            addCell(row, col++, "LEAV", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "FYI - Tardy (Late)", headerFormat2, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(54*20));
            col = 0;
            addCell(row, col++, "Name", headerFormat3);
            addCell(row, col++, "ATTUID", headerFormat3);
            addCell(row, col++, "Scheduled Shift Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Shift Hours Worked", headerFormat2);
            addCell(row, col++, "Evening\n7pm-10pm", headerFormat2);
            addCell(row, col++, "Night\n10pm-6am", headerFormat2);
            addCell(row, col++, "Saturday and Sunday Hours", headerFormat2);
            addCell(row, col++, "Holiday Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Overtime 50%", headerFormat2);
            addCell(row, col++, "Overtime 100%", headerFormat2);
            addCell(row, col++, "Overtime OFF Day", headerFormat2);
            addCell(row, col++, "Total Overtime Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Comp Time Earned", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Comp Time Taken", headerFormat2);
            addCell(row, col++, "Holiday NOT WORKED", headerFormat2);
            addCell(row, col++, "Vacation", headerFormat2);
            addCell(row, col++, "Sickness Leave", headerFormat2);
            addCell(row, col++, "Care for Family Member", headerFormat2);
            addCell(row, col++, "Paid Caregiver Leave", headerFormat2);
            addCell(row, col++, "Child Care Leave", headerFormat2);
            addCell(row, col++, "Payable Excused Absence", headerFormat2);
            addCell(row, col++, "Unpayable Excused Absence", headerFormat2);
            addCell(row, col++, "Unpayable Unexcused Absence", headerFormat2);
            addCell(row, col++, "Day Off EXCH for Off Day Worked", headerFormat2);
            addCell(row, col++, "Day Off EXCH for Sun Worked", headerFormat2);
            addCell(row, col++, "Wedding Leave", headerFormat2);
            addCell(row, col++, "Leave of Absence", headerFormat2);
            addCell(row, col++, "Paternity Leave", headerFormat2);
            addCell(row, col++, "ATT Paid Paternity Leave", headerFormat2);
            addCell(row, col++, "Force Majeure Leave", headerFormat2);
            addCell(row, col++, "Total Absence Hours", headerFormat2);
            addCell(row, col++, "Total Regular + Absence", headerFormat2);
            addCell(row, col++, "Number of Tardies", headerFormat2);
            addCell(row, col++, "Tardy Minutes", headerFormat2);
            
            // Freeze the header rows
            sheet.createFreezePane(0, 3);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SCH_HRS")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("REG_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EVEN_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("NITE_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("WKND_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOWK_HRS")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EXTA_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EXTP_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EXTO_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_OT_WORKED")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPE")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HLDY_NOT_WRKED")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("VAC_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SICK_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CARE_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CAREGIVER_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("KIDS_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MPE0_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MUE0_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("MUN0_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("DAYW_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUNW_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("WEDD_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("LOA_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_PLOA")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_PLO2")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_LEAV")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_ABS_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_REG_PLUS_ABS")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TOTAL_TARDIES")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TARDY_MINUTES")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building time data report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll review report for SVK
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillPayrollReviewReportSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollReview(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll_Review.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_10_bold = workbook.createFont();
            calibri_10_bold.setFontName("Calibri");
            calibri_10_bold.setFontHeightInPoints((short)10);
            calibri_10_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_10_bold);
            headerFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle headerFormat1 = workbook.createCellStyle();
            headerFormat1.cloneStyleFrom(headerFormat);
            headerFormat1.setFillForegroundColor(IndexedColors.DARK_YELLOW.getIndex());
            headerFormat1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat1.setAlignment(HorizontalAlignment.CENTER);
            headerFormat1.setBorderTop(BorderStyle.THIN);
            headerFormat1.setBorderBottom(BorderStyle.THIN);
            headerFormat1.setBorderLeft(BorderStyle.THIN);
            headerFormat1.setBorderRight(BorderStyle.THIN);
            
            XSSFCellStyle headerFormat2 = workbook.createCellStyle();
            headerFormat2.cloneStyleFrom(headerFormat);
            headerFormat2.setAlignment(HorizontalAlignment.CENTER);
            headerFormat2.setBorderTop(BorderStyle.THIN);
            headerFormat2.setBorderBottom(BorderStyle.THIN);
            headerFormat2.setBorderLeft(BorderStyle.THIN);
            headerFormat2.setBorderRight(BorderStyle.THIN);
            headerFormat2.setWrapText(true);
            
            XSSFCellStyle headerFormat3 = workbook.createCellStyle();
            headerFormat3.cloneStyleFrom(headerFormat);
            headerFormat3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerFormat3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormat3.setAlignment(HorizontalAlignment.LEFT);
            headerFormat3.setBorderTop(BorderStyle.THIN);
            headerFormat3.setBorderBottom(BorderStyle.THIN);
            headerFormat3.setBorderLeft(BorderStyle.THIN);
            headerFormat3.setBorderRight(BorderStyle.THIN);
            headerFormat3.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            
            XSSFSheet sheet = workbook.createSheet("Sheet1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(27));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(6));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(6));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(2));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(6));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(13*20));
            col = 0;
            addCell(row, col++, feeder + ", site " + site, headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~~~~~~Shift Hours Worked~~~~~~~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 5));
            col += 6;
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~Overtime~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 4;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Absences~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", headerFormat1, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 22));
            col += 23;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(13*20));
            col = 0;
            addCell(row, col++, "Month ending " + Misc.dateToStringMDY(endDate), headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 212, headerFormat2);
            addCell(row, col++, 219, headerFormat2);
            addCell(row, col++, 221, headerFormat2);
            addCell(row, col++, 227, headerFormat2);
            addCell(row, col++, 223, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 238, headerFormat2);
            addCell(row, col++, 252, headerFormat2);
            addCell(row, col++, 223, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, 241, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "", headerFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
            col += 3;
            addCell(row, col++, 520, headerFormat2);
            addCell(row, col++, 831, headerFormat2);
            addCell(row, col++, 538, headerFormat2);
            addCell(row, col++, 834, headerFormat2);
            addCell(row, col++, 524, headerFormat2);
            addCell(row, col++, 524, headerFormat2);
            addCell(row, col++, 524, headerFormat2);
            addCell(row, col++, 524, headerFormat2);
            addCell(row, col++, 524, headerFormat2);
            addCell(row, col++, 525, headerFormat2);
            addCell(row, col++, 538, headerFormat2);
            addCell(row, col++, 531, headerFormat2);
            addCell(row, col++, 535, headerFormat2);
            addCell(row, col++, 537, headerFormat2);
            addCell(row, col++, 539, headerFormat2);
            addCell(row, col++, 540, headerFormat2);
            addCell(row, col++, 541, headerFormat2);
            addCell(row, col++, 527, headerFormat2);
            addCell(row, col++, 851, headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(38*20));
            col = 0;
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "EVE", headerFormat2);
            addCell(row, col++, "NGT", headerFormat2);
            addCell(row, col++, "AWSA", headerFormat2);
            addCell(row, col++, "AWSU", headerFormat2);
            addCell(row, col++, "WDPH", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "OTY", headerFormat2);
            addCell(row, col++, "OTW", headerFormat2);
            addCell(row, col++, "WDPH", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "SBY", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "CMPT", headerFormat2);
            addCell(row, col++, "CMPT\nHoliday", headerFormat2);
            addCell(row, col++, "HLDY", headerFormat2);
            addCell(row, col++, "HOL", headerFormat2);
            addCell(row, col++, "SIK", headerFormat2);
            addCell(row, col++, "ADV", headerFormat2);
            addCell(row, col++, "ABF", headerFormat2);
            addCell(row, col++, "ABP", headerFormat2);
            addCell(row, col++, "ADP", headerFormat2);
            addCell(row, col++, "FNRL", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "BLOOD", headerFormat2);
            addCell(row, col++, "COV", headerFormat2);
            addCell(row, col++, "ADF", headerFormat2);
            addCell(row, col++, "ABU", headerFormat2);
            addCell(row, col++, "UNAB", headerFormat2);
            addCell(row, col++, "DVUP", headerFormat2);
            addCell(row, col++, "DVRUP", headerFormat2);
            addCell(row, col++, "HCP", headerFormat2);
            addCell(row, col++, "HCUP", headerFormat2);
            addCell(row, col++, "OBS", headerFormat2);
            addCell(row, col++, "", headerFormat2);
            addCell(row, col++, "LOA", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "", headerFormat);
            addCell(row, col, "FYI Tardy", headerFormat2, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(60*20));
            col = 0;
            addCell(row, col++, "Name", headerFormat3);
            addCell(row, col++, "ATTUID", headerFormat3);
            addCell(row, col++, "Scheduled Shift Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Shift Hours Worked", headerFormat2);
            addCell(row, col++, "Evening\n7pm-\n10pm", headerFormat2);
            addCell(row, col++, "Night\n10pm-\n6am", headerFormat2);
            addCell(row, col++, "Saturday Hours", headerFormat2);
            addCell(row, col++, "Sunday Hours", headerFormat2);
            addCell(row, col++, "Bank Holiday Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Overtime Weekday", headerFormat2);
            addCell(row, col++, "Overtime Weekend", headerFormat2);
            addCell(row, col++, "Overtime Bank Holiday", headerFormat2);
            addCell(row, col++, "Total Overtime Hours", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "CMPE", headerFormat2);
            addCell(row, col++, "CMPE Holiday", headerFormat2);
            addCell(row, col++, "CMPP", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Standby", headerFormat2);
            addCell(row, col++, "", headerFormat);
            addCell(row, col++, "Comp Time Taken", headerFormat2);
            addCell(row, col++, "Comp Time Taken Holiday", headerFormat2);
            addCell(row, col++, "Holiday NOT WORKED", headerFormat2);
            addCell(row, col++, "Holiday Vacation", headerFormat2);
            addCell(row, col++, "Sickness Leave", headerFormat2);
            addCell(row, col++, "Doctor's Visit", headerFormat2);
            addCell(row, col++, "Care for Sick Family Member", headerFormat2);
            addCell(row, col++, "Paid Absence Short Term", headerFormat2);
            addCell(row, col++, "Doctor's Visit Pregnancy", headerFormat2);
            addCell(row, col++, "Funeral", headerFormat2);
            addCell(row, col++, "Bereave-\nment", headerFormat2);
            addCell(row, col++, "Blood Drive", headerFormat2);
            addCell(row, col++, "COVID\n-19", headerFormat2);
            addCell(row, col++, "Doctor's Visit With Relative", headerFormat2);
            addCell(row, col++, "Unpaid Absence", headerFormat2);
            addCell(row, col++, "Unexcused Absence", headerFormat2);
            addCell(row, col++, "Doctor's Visit Unpaid", headerFormat2);
            addCell(row, col++, "Doctor's Visit Relative Unpaid", headerFormat2);
            addCell(row, col++, "Doctor's Visit Handicap Child Paid", headerFormat2);
            addCell(row, col++, "Doctor's Visit Handicap Child Unpaid", headerFormat2);
            addCell(row, col++, "Obstacles on side of Employer", headerFormat2);
            addCell(row, col++, "Paternity Leave", headerFormat2);
            addCell(row, col++, "LOA", headerFormat2);
            addCell(row, col++, "Total Absence Hours", headerFormat2);
            addCell(row, col++, "Total Regular + Absence", headerFormat2);
            addCell(row, col++, "Number of Tardies", headerFormat2);
            addCell(row, col++, "Tardy Minutes", headerFormat2);
            
            // Freeze the header rows
            sheet.createFreezePane(0, 4);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SCH_HRS")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("REG_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EVE_HRS_212")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("NGT_HRS_219")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SAT_HRS_221")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUN_HRS_227")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOLIDAY_223_REG")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT_WKDAY_238")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT_WKEND_252")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOLIDAY_223_EXT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_OT_WORKED")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPE_HLDY")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPP")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SBY_241")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPT_HLDY")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("BHO_NOT_WRKED")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("VAC_520")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SIK_831")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADV_536")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABF_834")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABP_PD_LEAVE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADP_PREGNANCY")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADP_FUNERAL")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADP_BEREAVEMENT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADP_BLOOD_DRIVE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("COVID")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ADF_538")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABU_531")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABU_535")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_537")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_539")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_540")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_541")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_527")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_851")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SUM_LOA")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_ABS_HRS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOT_REG_PLUS_ABS")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TOTAL_TARDIES")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("TARDY_MINUTES")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building time data report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the payroll excel report for POL payroll
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param preview
     */
    public static void fillPayrollReportPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean preview)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollPOL(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_9_bold = workbook.createFont();
            arial_9_bold.setFontName("Arial");
            arial_9_bold.setFontHeightInPoints((short)9);
            arial_9_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_9_bold);
            headerFormat.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            headerFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_9_bold);
            titleFormat.setBorderBottom(BorderStyle.THIN);
            titleFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle titleFormatGrey = workbook.createCellStyle();
            titleFormatGrey.cloneStyleFrom(titleFormat);
            titleFormatGrey.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            titleFormatGrey.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle titleFormatBlue = workbook.createCellStyle();
            titleFormatBlue.cloneStyleFrom(titleFormat);
            titleFormatBlue.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
            titleFormatBlue.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            
            XSSFCellStyle titleFormatLeft = workbook.createCellStyle();
            titleFormatLeft.cloneStyleFrom(titleFormat);
            titleFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormatHideZeroes = workbook.createCellStyle();
            lineFormatHideZeroes.cloneStyleFrom(lineFormat);
            lineFormatHideZeroes.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));
            
            XSSFSheet sheet = workbook.createSheet(Misc.dateToString(endDate, "MMyyyy"));
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(7));
            sheet.setColumnWidth(col++, calculateColWidth(35));
            sheet.setColumnWidth(col++, calculateColWidth(20));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(16));
            
            if (preview)
            {
                Row previewRow = sheet.createRow(rownum++);
                addCell(previewRow, 0, "This is a preview document and is not intended to be used for payroll.", headerFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, 0, 5));
            }
            
            // write column titles
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(20*15));
            col = 0;
            addCell(row, col++, "attuid", titleFormatLeft);
            addCell(row, col++, "day of the month", titleFormat);
            addCell(row, col++, "Month", titleFormat);
            addCell(row, col++, "day of the week", titleFormat);
            addCell(row, col++, "days off", titleFormat);
            addCell(row, col++, "days", titleFormatGrey);
            addCell(row, col++, "From", titleFormatGrey);
            addCell(row, col++, "To", titleFormatGrey);
            addCell(row, col++, "From", titleFormatGrey);
            addCell(row, col++, "To", titleFormatGrey);
            addCell(row, col++, "From", titleFormatGrey);
            addCell(row, col++, "To", titleFormatGrey);
            addCell(row, col++, "Total", titleFormatGrey);
            addCell(row, col++, "days", titleFormatBlue);
            addCell(row, col++, "IN", titleFormatBlue);
            addCell(row, col++, "OUT", titleFormatBlue);
            addCell(row, col++, "IN", titleFormatBlue);
            addCell(row, col++, "OUT", titleFormatBlue);
            addCell(row, col++, "IN", titleFormatBlue);
            addCell(row, col++, "OUT", titleFormatBlue);
            addCell(row, col++, "IN", titleFormatBlue);
            addCell(row, col++, "OUT", titleFormatBlue);
            addCell(row, col++, "Total", titleFormatBlue);
            addCell(row, col++, "Type of absence", titleFormatBlue);
            addCell(row, col++, "Additional comments", titleFormatBlue);
            addCell(row, col++, "Hours of absence", titleFormatBlue);
            addCell(row, col++, "Overtime (Day off)", titleFormatBlue);
            addCell(row, col++, "Overtime 50%", titleFormatBlue);
            addCell(row, col++, "Overtime 100%", titleFormatBlue);
            addCell(row, col++, "Overtime COMP TIME", titleFormatBlue);
            addCell(row, col++, "Night 30%", titleFormatBlue);
            addCell(row, col++, "Evening 10%", titleFormatBlue);
            addCell(row, col++, "Weekend 20%", titleFormatBlue);
            addCell(row, col++, "PH Work Premium", titleFormatBlue);
            
            // Freeze the top row(s)
            if (preview)
            {
                sheet.createFreezePane(0, 2);
            }
            else
            {
                sheet.createFreezePane(0, 1);
            }
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(20*15));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("THEDAY")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("THEMONTH")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("DAYOFWEEK")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("OFFDAY")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("DAYS")), lineFormatHideZeroes);
                    addCell(row, col++, rs.getObject("SSTART1"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("SSTOP1"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("SSTART2"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("SSTOP2"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("SSTART3"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("SSTOP3"), lineFormat, "convertToHours");
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SHIFT")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("ADAYS")), lineFormat);
                    addCell(row, col++, rs.getObject("ASTART1"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTOP1"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTART2"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTOP2"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTART3"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTOP3"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTART4"), lineFormat, "convertToHours");
                    addCell(row, col++, rs.getObject("ASTOP4"), lineFormat, "convertToHours");
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOTAL")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ABS_DESCRIPTION")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ABS_COMMENT")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABS_HOURS")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OTO")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OTP")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPE")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("NITE")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EVENING")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("WKND")), lineFormatHideZeroes);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOWK")), lineFormatHideZeroes);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building payroll report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the actual schedule report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     */
    public static void fillActualScheduleReport(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsActualToSchedule(parentFrame, feeder, site, mu, reportingDate);
        ResultSet[] rsArray = results.getResultSetArray();
        ResultSet rsMinutes = rsArray[0];
        ResultSet rsDays = rsArray[1];
        
        String filename = "TVI_Actual_Schedule.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_12_bold = workbook.createFont();
            arial_12_bold.setFontName("Arial");
            arial_12_bold.setFontHeightInPoints((short)12);
            arial_12_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_12_bold);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11_bold);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle headerFormatRight = workbook.createCellStyle();
            headerFormatRight.cloneStyleFrom(headerFormat);
            headerFormatRight.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
            headerFormatRight.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerFormatRight.setAlignment(HorizontalAlignment.RIGHT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            
            XSSFSheet sheetMinutes = workbook.createSheet("Minutes Late and After");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheetMinutes.setColumnWidth(col++, calculateColWidth(9));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(25));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(10));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(12));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(10));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(11));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(11));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(11));
            sheetMinutes.setColumnWidth(col++, calculateColWidth(11));
            
            // write title
            Row row = sheetMinutes.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col, "Feeder: " + feeder + ", Site: " + site, titleFormat);
            row = sheetMinutes.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col, "ACTUAL versus SCHEDULED for MU: " + mu + " - " + Misc.dateToStringMDY(reportingDate), titleFormat);
            
            // write column headers
            row = sheetMinutes.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "AGENT ID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            addCell(row, col++, "SCHEDULE START", headerFormat);
            addCell(row, col++, "ACTUAL START", headerFormat);
            addCell(row, col++, "MINUTES LATE", headerFormatRight);
            col++;
            addCell(row, col++, "SCHEDULE STOP", headerFormat);
            addCell(row, col++, "ACTUAL STOP", headerFormat);
            addCell(row, col++, "MINUTES AFTER", headerFormatRight);
            col++;
            addCell(row, col++, "FIRST SCHD ACTIVITY", headerFormat);
            addCell(row, col++, "FIRST ACT ACTIVITY", headerFormat);
            addCell(row, col++, "LAST SCHD ACTIVITY", headerFormat);
            addCell(row, col++, "LAST ACT ACTIVITY", headerFormat);
            
            if (rsMinutes != null)
            {
                while (rsMinutes.next())
                {
                    row = sheetMinutes.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("EMPID")), lineFormat);
                    addCell(row, col++, rsMinutes.getInt("AGENTID"), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("SCHED_START")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("ACTUAL_START")), lineFormat);
                    addCell(row, col++, rsMinutes.getInt("DIFF_START"), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("SCHED_STOP")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("ACTUAL_STOP")), lineFormat);
                    addCell(row, col++, rsMinutes.getInt("DIFF_STOP"), lineFormat);
                    col++;
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("SCHED_START_CODE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("ACTUAL_START_CODE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("SCHED_STOP_CODE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsMinutes.getObject("ACTUAL_STOP_CODE")), lineFormat);
                }
            }
            
            XSSFSheet sheetDays = workbook.createSheet("Full Day Differences");
            rownum = 0;
            
            // set column widths
            col = 0;
            sheetDays.setColumnWidth(col++, calculateColWidth(9));
            sheetDays.setColumnWidth(col++, calculateColWidth(12));
            sheetDays.setColumnWidth(col++, calculateColWidth(25));
            sheetDays.setColumnWidth(col++, calculateColWidth(14));
            sheetDays.setColumnWidth(col++, calculateColWidth(14));
            sheetDays.setColumnWidth(col++, calculateColWidth(14));
            sheetDays.setColumnWidth(col++, calculateColWidth(14));
            
            // write title
            row = sheetDays.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col, "Feeder: " + feeder + ", Site: " + site, titleFormat);
            row = sheetDays.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col, "ACTUAL versus SCHEDULED for MU: " + mu + " - " + Misc.dateToStringMDY(reportingDate), titleFormat);
            
            // write column headers
            row = sheetDays.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "AGENT ID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            addCell(row, col++, "SCHEDULED", headerFormat);
            addCell(row, col++, "SCHEDULED MINUTES", headerFormat);
            addCell(row, col++, "ACTUAL", headerFormat);
            addCell(row, col++, "ACTUAL MINUTES", headerFormat);
            
            if (rsDays != null)
            {
                while (rsDays.next())
                {
                    row = sheetDays.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rsDays.getObject("EMPID")), lineFormat);
                    addCell(row, col++, rsDays.getInt("AGENTID"), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsDays.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsDays.getObject("PROCESS_SCHED")), lineFormat);
                    addCell(row, col++, rsDays.getInt("SCHED_MINS"), lineFormat);
                    addCell(row, col++, Misc.objectToString(rsDays.getObject("PROCESS_ACTUAL")), lineFormat);
                    addCell(row, col++, rsDays.getInt("ACT_MINS"), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
            String reportType = "ALL"; // actsch for a single mu
            if (mu.equals("ALL"))
            {
                reportType = "ALLMU"; // actsch for all mus
            }
            Oracle.updateActualScheduleStatus(parentFrame, feeder, site, mu, reportType, reportingDate, "Done");
            Oracle.clearActualSchedule(parentFrame, feeder, site, mu, reportingDate);
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building actual schedule report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the hours summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param startDate
     * @param endDate
     * @param colsToShow
     */
    public static void fillHoursSummaryReport(Component parentFrame, String feeder, String site, String mu, String empList, Date startDate, Date endDate, List<String> colsToShow)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsHoursSummary(parentFrame, feeder, site, mu, empList, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Summary_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(calibri_11_bold);
            titleFormat.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            titleFormat.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            titleFormat.setAlignment(HorizontalAlignment.CENTER);
            titleFormat.setBorderTop(BorderStyle.THIN);
            titleFormat.setBorderBottom(BorderStyle.THIN);
            titleFormat.setBorderLeft(BorderStyle.THIN);
            titleFormat.setBorderRight(BorderStyle.THIN);
            titleFormat.setWrapText(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle headerFormatRight = workbook.createCellStyle();
            headerFormatRight.cloneStyleFrom(headerFormat);
            headerFormatRight.setAlignment(HorizontalAlignment.RIGHT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            
            XSSFSheet sheet = workbook.createSheet(Misc.dateToString(startDate, "MM.dd.yyyy") + " - " + Misc.dateToString(endDate, "MM.dd.yyyy"));
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(28));
            int numOfColumns = colsToShow.size();
            for (int i = 0; i < numOfColumns; i++)
            {
                sheet.setColumnWidth(col++, calculateColWidth(13));
            }
            
            // write title
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col, "Feeder: " + feeder + " Site: " + site, titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            addCell(row, col, "From " + Misc.dateToStringMDY(startDate) + " to " + Misc.dateToStringMDY(endDate), titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 4;
            addCell(row, col, "Generated " + Misc.dateToString(Oracle.getCurTimeLocal(parentFrame), "yyyy-MM-dd hh:mm a"), titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 4;
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(40*20));
            col = 0;
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            if (colsToShow.contains("REGULAR"))
            {
                addCell(row, col++, "REGULAR", headerFormatRight);
            }
            if (colsToShow.contains("OVERTIME"))
            {
                addCell(row, col++, "OVERTIME", headerFormatRight);
            }
            if (colsToShow.contains("OT_MINS"))
            {
                addCell(row, col++, "OT MINS", headerFormatRight);
            }
            if (colsToShow.contains("EXTM"))
            {
                addCell(row, col++, "EXTM", headerFormatRight);
            }
            if (colsToShow.contains("EXTV"))
            {
                addCell(row, col++, "EXTV", headerFormatRight);
            }
                if (colsToShow.contains("EXTI"))
            {
                addCell(row, col++, "EXTI", headerFormatRight);
            }
            if (colsToShow.contains("OT_REF"))
            {
                addCell(row, col++, "OVERTIME\nREFUSED", headerFormatRight);
            }
            if (colsToShow.contains("OT_NA"))
            {
                addCell(row, col++, "OVERTIME\nNOT AVAILABLE", headerFormatRight);
            }
            if (colsToShow.contains("CALLOUT"))
            {
                addCell(row, col++, "CALLOUT", headerFormatRight);
            }
            
            // Freeze the top two rows
            sheet.createFreezePane(0, 2);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    for (String field : colsToShow)
                    {
                        addCell(row, col++, Misc.objectToDouble(rs.getObject(field)), lineFormat);
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building hours summary report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the detail excel report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param startDate
     * @param endDate
     * @param absSelected
     * @param attSelected
     * @param extSelected
     * @param absCodeList
     * @param attCodeList
     * @param extCodeList
     * @param clientName
     */
    public static void fillCodeDetailReport(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate, boolean absSelected, boolean attSelected, boolean extSelected, List<String> absCodeList, List<String> attCodeList, List<String> extCodeList, String clientName)
    {
        // Get results
        ResultSetWrapper resultsAbs = null;
        ResultSetWrapper resultsExt = null;
        ResultSetWrapper resultsAtt = null;
        ResultSet rsAbs = null;
        ResultSet rsExt = null;
        ResultSet rsAtt = null;
        
        if (absSelected)
        {
            resultsAbs = Oracle.getAbsencesReportRecords(parentFrame, feeder, site, employeeSelection, absCodeList, startDate, endDate, "DETAIL", clientName);
            rsAbs = resultsAbs.getResultSet();
        }
        
        if (extSelected)
        {
            resultsExt = Oracle.getExtraPaymentsReportRecords(parentFrame, feeder, site, employeeSelection, extCodeList, startDate, endDate, "DETAIL", clientName);
            rsExt = resultsExt.getResultSet();
        }
        
        if (attSelected)
        {
            resultsAtt = Oracle.getAttendancesReportRecords(parentFrame, feeder, site, employeeSelection, attCodeList, startDate, endDate, "DETAIL", clientName);
            rsAtt = resultsAtt.getResultSet();
        }
        
        String filename = "TVI_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.MEDIUM);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
                        
            // Absences sheet
            if (absSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Absences Report");
                
                int rownum = 0;
                
                // set column widths
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(16));
                sheet.setColumnWidth(col++, calculateColWidth(18));
                sheet.setColumnWidth(col++, calculateColWidth(28));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    sheet.setColumnWidth(col++, calculateColWidth(9));
                }
                sheet.setColumnWidth(col++, calculateColWidth(18));
                sheet.setColumnWidth(col++, calculateColWidth(28));
                sheet.setColumnWidth(col++, calculateColWidth(17));
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "ABSENCES DETAIL", lineFormat);
                row = sheet.createRow(rownum++);
                addCell(row, col, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "REPORT DATE", headerFormat);
                addCell(row, col++, "ABSENCE CODE", headerFormat);
                addCell(row, col++, "ABSENCE DESCRIPTION", headerFormat);
                addCell(row, col++, "HOURS", headerFormat);
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    addCell(row, col++, "MINUTES", headerFormat);
                }
                addCell(row, col++, "REASON CODE", headerFormat);
                addCell(row, col++, "REASON DESCRIPTION", headerFormat);
                addCell(row, col++, "COMMENTS", headerFormat);
                
                if (rsAbs != null)
                {
                    while (rsAbs.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsAbs.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsAbs.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.dateToStringMDY((Date)rsAbs.getObject("REPORTING_DATE")), lineFormat);
                        addCell(row, col++, rsAbs.getObject("SAP_CODE_TREC"), lineFormatLeft);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsAbs.getObject("HOURS_TREC")), lineFormat);
                        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                        {
                            addCell(row, col++, Misc.objectToInt(rsAbs.getObject("MINS_TREC")), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("REASON_CODE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("REASON_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("REASON_TEXT")), lineFormat);
                    }
                }
            }
            
            // Extra Payments sheet
            if (extSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Extra Payments Report");
                
                int rownum = 0;
                // set column widths
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(16));
                sheet.setColumnWidth(col++, calculateColWidth(23));
                sheet.setColumnWidth(col++, calculateColWidth(30));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                sheet.setColumnWidth(col++, calculateColWidth(18));
                sheet.setColumnWidth(col++, calculateColWidth(15));
                sheet.setColumnWidth(col++, calculateColWidth(18));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(11));
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "EXTRA PAYMENTS DETAIL", lineFormat);
                row = sheet.createRow(rownum++);
                addCell(row, col, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "REPORT DATE", headerFormat);
                addCell(row, col++, "EXTRA PAYMENT CODE", headerFormat);
                addCell(row, col++, "EXTRA PAYMENT DESCRIPTION", headerFormat);
                addCell(row, col++, "AMOUNT", headerFormat);
                addCell(row, col++, "AMOUNT TYPE", headerFormat);
                addCell(row, col++, "COST CENTER", headerFormat);
                addCell(row, col++, "LOCATION CODE", headerFormat);
                addCell(row, col++, "ACTIVITY", headerFormat);
                addCell(row, col++, "PROJECT #", headerFormat);
                
                if (rsExt != null)
                {
                    while (rsExt.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsExt.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsExt.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.dateToStringMDY((Date)rsExt.getObject("REPORTING_DATE")), lineFormat);
                        addCell(row, col++, rsExt.getObject("SAP_CODE_EREC"), lineFormatLeft);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsExt.getObject("AMOUNT_EREC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("AMOUNT_TYPE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("COST_CENTER")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("LOCATION_CODE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("ACTIVITY")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("PROJECT_NUMBER")), lineFormat);
                    }
                }
            }
            
            // Attendances sheet
            if (attSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Attendances Report");
                
                int rownum = 0;
                
                // set column widthsi
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(16));
                sheet.setColumnWidth(col++, calculateColWidth(20));
                sheet.setColumnWidth(col++, calculateColWidth(31));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    sheet.setColumnWidth(col++, calculateColWidth(9));
                }
                sheet.setColumnWidth(col++, calculateColWidth(15));
                sheet.setColumnWidth(col++, calculateColWidth(20));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(5));
                sheet.setColumnWidth(col++, calculateColWidth(12));
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(11));
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col, "ATTENDANCES DETAIL", lineFormat);
                row = sheet.createRow(rownum++);
                addCell(row, col, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "REPORT DATE", headerFormat);
                addCell(row, col++, "ATTENDANCE CODE", headerFormat);
                addCell(row, col++, "ATTENDANCE DESCRIPTION", headerFormat);
                addCell(row, col++, "HOURS", headerFormat);
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    addCell(row, col++, "MINUTES", headerFormat);
                }
                addCell(row, col++, "COST CENTER", headerFormat);
                addCell(row, col++, "LOCATION CODE", headerFormat);
                addCell(row, col++, "ACTIVITY", headerFormat);
                addCell(row, col++, "EC", headerFormat);
                addCell(row, col++, "PROJECT #", headerFormat);
                addCell(row, col++, "FRC", headerFormat);
                addCell(row, col++, "TAX AREA", headerFormat);
                
                if (rsAtt != null)
                {
                    while (rsAtt.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsAtt.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsAtt.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.dateToStringMDY((Date)rsAtt.getObject("REPORTING_DATE")), lineFormat);
                        addCell(row, col++, rsAtt.getObject("SAP_CODE_AREC"), lineFormatLeft);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsAtt.getObject("HOURS_AREC")), lineFormat);
                        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                        {
                            addCell(row, col++, Misc.objectToInt(rsAtt.getObject("MINS_AREC")), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("COST_CENTER")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("LOCATION_CODE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("ACTIVITY")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("EC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("PROJECT_NUMBER")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("FRC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("TAX_AREA")), lineFormat);
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building detail report.");
        }
        finally
        {
            if (resultsAbs != null)
            {
                resultsAbs.close();
            }
            if (resultsExt != null)
            {
                resultsExt.close();
            }
            if (resultsAtt != null)
            {
                resultsAtt.close();
            }
        }
    }
    
    /**
     * Generates the summary excel report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param startDate
     * @param endDate
     * @param absSelected
     * @param attSelected
     * @param extSelected
     * @param absCodeList
     * @param attCodeList
     * @param extCodeList
     * @param showReasonCodes
     * @param clientName
     */
    public static void fillCodeSummaryReport(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate, boolean absSelected, boolean attSelected, boolean extSelected, List<String> absCodeList, List<String> attCodeList, List<String> extCodeList, boolean showReasonCodes, String clientName)
    {
        // Get results
        ResultSetWrapper resultsAbs = null;
        ResultSetWrapper resultsExt = null;
        ResultSetWrapper resultsAtt = null;
        ResultSet rsAbs = null;
        ResultSet rsExt = null;
        ResultSet rsAtt = null;
        
        if (absSelected)
        {
            String reportType = "SUMMARY";
            if (showReasonCodes)
            {
                reportType = "REASON_CODE";
            }
            resultsAbs = Oracle.getAbsencesReportRecords(parentFrame, feeder, site, employeeSelection, absCodeList, startDate, endDate, reportType, clientName);
            rsAbs = resultsAbs.getResultSet();
        }
        
        if (extSelected)
        {
            resultsExt = Oracle.getExtraPaymentsReportRecords(parentFrame, feeder, site, employeeSelection, extCodeList, startDate, endDate, "SUMMARY", clientName);
            rsExt = resultsExt.getResultSet();
        }
        
        if (attSelected)
        {
            resultsAtt = Oracle.getAttendancesReportRecords(parentFrame, feeder, site, employeeSelection, attCodeList, startDate, endDate, "SUMMARY", clientName);
            rsAtt = resultsAtt.getResultSet();
        }
        
        String filename = "TVI_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.MEDIUM);
            
            XSSFCellStyle headerFormatLeft = workbook.createCellStyle();
            headerFormatLeft.cloneStyleFrom(headerFormat);
            headerFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            // Absences sheet
            if (absSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Absences Report");
                int rownum = 0;
                
                // set column widths
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(20));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(23));
                sheet.setColumnWidth(col++, calculateColWidth(30));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    sheet.setColumnWidth(col++, calculateColWidth(9));
                }
                if (showReasonCodes)
                {
                    sheet.setColumnWidth(col++, calculateColWidth(18));
                    sheet.setColumnWidth(col++, calculateColWidth(28));
                }
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "ABSENCES SUMMARY", lineFormat);
                row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "CODE", headerFormat);
                addCell(row, col++, "DESCRIPTION", headerFormat);
                addCell(row, col++, "HOURS", headerFormat);
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    addCell(row, col++, "MINUTES", headerFormat);
                }
                if (showReasonCodes)
                {
                    addCell(row, col++, "REASON CODE", headerFormat);
                    addCell(row, col++, "DESCRIPTION", headerFormat);
                }
                
                if (rsAbs != null)
                {
                    while (rsAbs.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsAbs.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsAbs.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("SAP_CODE_TREC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAbs.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsAbs.getObject("HOURS_TREC")), lineFormat);
                        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                        {
                            addCell(row, col++, Misc.objectToInt(rsAbs.getObject("MINS_TREC")), lineFormat);
                        }
                        if (showReasonCodes)
                        {
                            addCell(row, col++, Misc.objectToString(rsAbs.getObject("REASON_CODE")), lineFormat);
                            addCell(row, col++, Misc.objectToString(rsAbs.getObject("REASON_DESCRIPTION")), lineFormat);
                        }
                    }
                }
            }
            
            // Extra Payments sheet
            if (extSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Extra Payments Report");
                
                int rownum = 0;
                // set column widths
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(23));
                sheet.setColumnWidth(col++, calculateColWidth(30));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "EXTRA PAYMENTS SUMMARY", lineFormat);
                row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "CODE", headerFormat);
                addCell(row, col++, "DESCRIPTION", headerFormat);
                addCell(row, col++, "AMOUNT", headerFormat);
                
                if (rsExt != null)
                {
                    while (rsExt.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsExt.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsExt.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("SAP_CODE_EREC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsExt.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsExt.getObject("AMOUNT_EREC")), lineFormat);
                    }
                }
            }
            
            // Attendances sheet
            if (attSelected)
            {
                XSSFSheet sheet = workbook.createSheet("Attendances Report");
                
                int rownum = 0;
                
                // set column widthsi
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(8));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(6));
                sheet.setColumnWidth(col++, calculateColWidth(40));
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(26));
                sheet.setColumnWidth(col++, calculateColWidth(23));
                sheet.setColumnWidth(col++, calculateColWidth(30));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    sheet.setColumnWidth(col++, calculateColWidth(9));
                }
                
                // write title rows
                Row row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "ATTENDANCES SUMMARY", lineFormat);
                row = sheet.createRow(rownum++);
                col = 0;
                addCell(row, col++, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
                
                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(22*20));
                col = 0;
                addCell(row, col++, "FEEDER", headerFormat);
                addCell(row, col++, "SITE", headerFormat);
                addCell(row, col++, "MU", headerFormat);
                addCell(row, col++, "SUPERVISOR", headerFormat);
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormat);
                addCell(row, col++, "CODE", headerFormat);
                addCell(row, col++, "DESCRIPTION", headerFormat);
                addCell(row, col++, "HOURS", headerFormat);
                if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                {
                    addCell(row, col++, "MINUTES", headerFormat);
                }
                
                if (rsAtt != null)
                {
                    while (rsAtt.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("FEEDER")), lineFormat);
                        addCell(row, col++, Misc.objectToInt(rsAtt.getObject("SITE")), lineFormat);
                        String mu = Misc.objectToString(rsAtt.getObject("MU"));
                        if (mu.isEmpty() || !Misc.isNumeric(mu))
                        {
                            addCell(row, col++, mu, lineFormat);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                        }
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("COACH")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("EMPLOYEE")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("SAP_CODE_AREC")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rsAtt.getObject("CODE_DESCRIPTION")), lineFormat);
                        addCell(row, col++, Misc.objectToDouble(rsAtt.getObject("HOURS_AREC")), lineFormat);
                        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
                        {
                            addCell(row, col++, Misc.objectToInt(rsAtt.getObject("MINS_AREC")), lineFormat);
                        }
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building summary report.");
        }
        finally
        {
            if (resultsAbs != null)
            {
                resultsAbs.close();
            }
            if (resultsExt != null)
            {
                resultsExt.close();
            }
            if (resultsAtt != null)
            {
                resultsAtt.close();
            }
        }
    }
    
    /**
     * Generates the employee movement report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillEmployeeMovementReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsEmployeeMovement(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Employee_Movement.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11_bold);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.cloneStyleFrom(headerFormat);
            titleFormat.setBorderBottom(BorderStyle.THIN);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            lineFormat.setFont(calibri_11);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Sheet 1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(27));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            
            // write title
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col, "Feeder: " + feeder + " Site: " + site, titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 2;
            addCell(row, col, "From " + Misc.dateToStringMDY(startDate) + " to " + Misc.dateToStringMDY(endDate), titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            col += 5;
            addCell(row, col, "Old MU INFO", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            col += 3;
            addCell(row, col, "Transferred to MU INFO", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
            col += 4;
            addCell(row, col, "Other INFO", titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(45*20));
            col = 0;
            addCell(row, col++, "TYPE", headerFormat);
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            addCell(row, col++, "MU", headerFormat);
            addCell(row, col++, "Schedule Date", headerFormat);
            addCell(row, col++, "MU\nTransferred To", headerFormat);
            col++;
            addCell(row, col++, "Employee Status on MU", headerFormat);
            addCell(row, col++, "Status Effective Date", headerFormat);
            col++;
            addCell(row, col++, "Date on\nNew MU", headerFormat);
            addCell(row, col++, "Status on\nNew MU", headerFormat);
            addCell(row, col++, "Status Effective Date", headerFormat);
            col++;
            addCell(row, col++, "No Record Found", headerFormat);
            addCell(row, col++, "Day of Week", headerFormat);
            
            // Freeze the top two rows
            sheet.createFreezePane(0, 2);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("TYPE")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormatLeft);
                    String mu = Misc.objectToString(rs.getObject("MU"));
                    if (mu.isEmpty() || !Misc.isNumeric(mu))
                    {
                        addCell(row, col++, mu, lineFormat);
                    }
                    else
                    {
                        addCell(row, col++, Misc.objectToDouble(mu), lineFormat);
                    }
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("REPORTING_DATE")), lineFormat);
                    String mu2 = Misc.objectToString(rs.getObject("TRANSFER_TO_MU"));
                    if (mu2.isEmpty() || !Misc.isNumeric(mu2))
                    {
                        addCell(row, col++, mu2, lineFormat);
                    }
                    else
                    {
                        addCell(row, col++, Misc.objectToDouble(mu2), lineFormat);
                    }
                    col++;
                    addCell(row, col++, Misc.objectToString(rs.getObject("STATUS_ON_MU")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("STATUS_EFFECTIVE_DATE")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("DATE_TRANSFERRED")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("STATUS")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("EFFECTIVE")), lineFormat);
                    col++;
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("NO_RECORD_FOUND")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("DAY_IN_WEEK")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building employee movement report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the actual schedule report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     */
    public static void fillMinimumIntervalReport(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsMinimumIntervalReport(parentFrame, feeder, site, payrollEndDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Minimum_Interval_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_12_bold = workbook.createFont();
            arial_12_bold.setFontName("Arial");
            arial_12_bold.setFontHeightInPoints((short)12);
            arial_12_bold.setBold(true);
            
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_12_bold);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11_bold);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            
            XSSFCellStyle lineFormatHours = workbook.createCellStyle();
            lineFormatHours.cloneStyleFrom(lineFormat);
            lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00"));
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Sheet 1");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(16));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(19));
            sheet.setColumnWidth(col++, calculateColWidth(16));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(19));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            
            // write title
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col, "Feeder: " + feeder + ", Site: " + site, titleFormat);
            
            // write column headers
            row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col++, "MU", headerFormat);
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "NAME", headerFormat);
            addCell(row, col++, "PREVIOUS DATE", headerFormat);
            addCell(row, col++, "END CODE", headerFormat);
            addCell(row, col++, "END SCHEDULE", headerFormat);
            addCell(row, col++, "CURRENT DATE", headerFormat);
            addCell(row, col++, "START CODE", headerFormat);
            addCell(row, col++, "START SCHEDULE", headerFormat);
            addCell(row, col++, "TIME LAPSE", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    col = 0;
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MU")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("NAME")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("PREVIOUS_DATE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("END_CODE")), lineFormat);
                    addCell(row, col++, Misc.dateToString((Date)rs.getObject("END_SCHEDULE"), "MM/dd/yyyy HH:mm"), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("CURRENT_DATE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("START_CODE")), lineFormat);
                    addCell(row, col++, Misc.dateToString((Date)rs.getObject("START_SCHEDULE"), "MM/dd/yyyy HH:mm"), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TIME_LAPSE")), lineFormatHours);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building minimum interval report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the Comp Time report for CZE, SVK
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param payrollEndDate
     * @param reportType
     * @param filename
     * @param openReport
     */
    public static void fillCompTimeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date payrollEndDate, String reportType, String filename, boolean openReport)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsCompTimeReport(parentFrame, feeder, site, mu, empList, payrollEndDate, reportType);
        ResultSet[] rsArray = results.getResultSetArray();
        
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11_bold);
            headerFormat.setBorderBottom(BorderStyle.THICK);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle headerFormatLeft = workbook.createCellStyle();
            headerFormatLeft.cloneStyleFrom(headerFormat);
            headerFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle headerFormatWrap = workbook.createCellStyle();
            headerFormatWrap.cloneStyleFrom(headerFormat);
            headerFormatWrap.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatNormal = workbook.createCellStyle();
            lineFormatNormal.setFont(calibri_11);
            lineFormatNormal.setBorderTop(BorderStyle.THIN);
            lineFormatNormal.setBorderBottom(BorderStyle.THIN);
            lineFormatNormal.setBorderLeft(BorderStyle.THIN);
            lineFormatNormal.setBorderRight(BorderStyle.THIN);
            lineFormatNormal.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatBold = workbook.createCellStyle();
            lineFormatBold.cloneStyleFrom(lineFormatNormal);
            lineFormatBold.setBorderBottom(BorderStyle.THICK);
            
            XSSFCellStyle lineFormatValue = workbook.createCellStyle();
            lineFormatValue.cloneStyleFrom(lineFormatNormal);
            
            XSSFCellStyle lineFormatValueNormal = workbook.createCellStyle();
            lineFormatValueNormal.cloneStyleFrom(lineFormatNormal);
            
            XSSFCellStyle lineFormatValueBold = workbook.createCellStyle();
            lineFormatValueBold.cloneStyleFrom(lineFormatNormal);
            lineFormatValueBold.setFont(calibri_11_bold);
            lineFormatValueBold.setBorderBottom(BorderStyle.THICK);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormatNormal);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormatLeftNormal = workbook.createCellStyle();
            lineFormatLeftNormal.cloneStyleFrom(lineFormatNormal);
            lineFormatLeftNormal.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormatLeftBold = workbook.createCellStyle();
            lineFormatLeftBold.cloneStyleFrom(lineFormatLeftNormal);
            lineFormatLeftBold.setBorderBottom(BorderStyle.THICK);
            
            // Build the report with multiple sheets
            String[] sheetName = {"Comp Time Report", "All Employee Data"};
            int i = 0;
            
            for (ResultSet rs : rsArray) {
                XSSFSheet sheet = workbook.createSheet(sheetName[i]);
                i++;
                
                int rownum = 0;

                // set column widths
                int col = 0;
                sheet.setColumnWidth(col++, calculateColWidth(10));
                sheet.setColumnWidth(col++, calculateColWidth(32));
                sheet.setColumnWidth(col++, calculateColWidth(12));
                sheet.setColumnWidth(col++, calculateColWidth(17));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                sheet.setColumnWidth(col++, calculateColWidth(9));
                sheet.setColumnWidth(col++, calculateColWidth(9));

                // write title
                Row row = sheet.createRow(rownum++);
                col = 0;
                if (feeder.equals("SVK"))
                {
                    addCell(row, col, "Feeder: " + feeder, headerFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
                }
                else
                {
                    addCell(row, col, "Feeder: " + feeder + " Site: " + site + " MU: " + mu, headerFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 2));
                }
                col += 3;
                addCell(row, col, "Pay Period Ending: " + Misc.dateToStringMDY(payrollEndDate), headerFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 4));

                // write column headers
                row = sheet.createRow(rownum++);
                row.setHeight((short)(35*20));
                col = 0;
                addCell(row, col++, "EMPID", headerFormat);
                addCell(row, col++, "EMPLOYEE", headerFormatLeft);
                addCell(row, col++, "REPORTING\nDATE", headerFormatWrap);
                addCell(row, col++, "CODE", headerFormat);
                addCell(row, col++, "EARNED", headerFormat);
                addCell(row, col++, "TAKEN", headerFormat);
                addCell(row, col++, "PAID", headerFormat);
                addCell(row, col++, "BALANCE", headerFormat);

                // Freeze the top two rows
                sheet.createFreezePane(0, 2);

                if (rs != null)
                {
                    while (rs.next())
                    {
                        row = sheet.createRow(rownum++);
                        col = 0;
                        
                        // Adjust the formatting based on the SAP_CODE field
                        String sapCode = Misc.objectToString(rs.getObject("SAP_CODE"));
                        
                        if ("FINAL BALANCE".equals(sapCode)) {
                            lineFormat = lineFormatBold;
                            lineFormatLeft = lineFormatLeftBold;
                            lineFormatValue = lineFormatValueBold;
                        }
                        else {
                            lineFormat = lineFormatNormal;
                            lineFormatLeft = lineFormatLeftNormal;
                            lineFormatValue = lineFormatValueNormal;
                        }
                        
                        addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                        addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormatLeft);
                        addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("REPORTING_DATE")), lineFormat);
                        addCell(row, col++, sapCode, lineFormatValue);
                        addCell(row, col++, Misc.objectToDouble(rs.getObject("EARNED")), lineFormatValue);
                        addCell(row, col++, Misc.objectToDouble(rs.getObject("TAKEN")), lineFormatValue);
                        addCell(row, col++, Misc.objectToDouble(rs.getObject("PAID")), lineFormatValue);
                        addCell(row, col++, Misc.objectToDouble(rs.getObject("BALANCE")), lineFormatValue);
                    }
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            if (openReport)
            {
                Desktop.getDesktop().open(new File(filename));
            }
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building Comp Time report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the LOA excel report for MEX.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillLOAReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsLOAReportExcel(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_LOA_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(arial_10_bold);
            titleFormat.setBorderBottom(BorderStyle.MEDIUM);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("LOA Report");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(21));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(19));
            sheet.setColumnWidth(col++, calculateColWidth(24));
            
            // write title
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "LOA REPORT", lineFormat);
            row = sheet.createRow(rownum++);
            addCell(row, col, "FEEDER: " + feeder + ", SITE: " + site, lineFormat);
            row = sheet.createRow(rownum++);
            addCell(row, col, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(22*20));
            col = 0;
            addCell(row, col++, "SITE", titleFormat);
            addCell(row, col++, "MU", titleFormat);
            addCell(row, col++, "EMPID", titleFormat);
            addCell(row, col++, "PAYROLL ID", titleFormat);
            addCell(row, col++, "CODE", titleFormat);
            addCell(row, col++, "START DATE", titleFormat);
            addCell(row, col++, "END DATE", titleFormat);
            addCell(row, col++, "SENT TO PAYROLL", titleFormat);
            addCell(row, col++, "MEDICAL ID", titleFormat);
            addCell(row, col++, "INITIAL MEDICAL ID", titleFormat);
            addCell(row, col++, "DAYS PREVIOUSLY PAID", titleFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    col = 0;
                    addCell(row, col++, Misc.objectToInt(rs.getObject("SITE")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MU")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("PAYROLL_ID")), lineFormat); // String in case of user input error (i.e. extra spaces in payrollid)
                    addCell(row, col++, Misc.objectToInt(rs.getObject("CODE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("START_DATE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("END_DATE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("SEND_TO_PAYROLL")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("MEDICAL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("INITIAL_MEDICAL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("DAYS_PREVIOUSLY_PAID")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building LOA report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates a payroll summary report for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillPayrollSummaryPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsPayrollSummaryPOL(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Payroll_Summary.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11);
            headerFormat.setBorderTop(BorderStyle.THIN);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setBorderLeft(BorderStyle.THIN);
            headerFormat.setBorderRight(BorderStyle.THIN);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatInt = workbook.createCellStyle();
            lineFormatInt.cloneStyleFrom(lineFormat);
            lineFormatInt.setDataFormat(workbook.createDataFormat().getFormat("0;-0;;@"));
            
            XSSFCellStyle lineFormatHours = workbook.createCellStyle();
            lineFormatHours.cloneStyleFrom(lineFormat);
            lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));
            
            XSSFSheet sheet = workbook.createSheet("Payroll Summary");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(16));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(13));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(30*20));
            col = 0;
            addCell(row, col++, "attuid", headerFormat);
            addCell(row, col++, "Month", headerFormat);
            addCell(row, col++, "Scheduled work days", headerFormat);
            addCell(row, col++, "Scheduled days worked", headerFormat);
            addCell(row, col++, "Absent days", headerFormat);
            addCell(row, col++, "Overtime days worked", headerFormat);
            addCell(row, col++, "Extra Absence days for overtime", headerFormat);
            addCell(row, col++, "Hours scheduled", headerFormat);
            addCell(row, col++, "Standard hours worked", headerFormat);
            addCell(row, col++, "Absence hours", headerFormat);
            addCell(row, col++, "Extra absence hours for overtime", headerFormat);
            addCell(row, col++, "Overtime (Day off)", headerFormat);
            addCell(row, col++, "Overtime 50%", headerFormat);
            addCell(row, col++, "Overtime 100%", headerFormat);
            addCell(row, col++, "Overtime COMP TIME", headerFormat);
            addCell(row, col++, "Night 30%", headerFormat);
            addCell(row, col++, "Evening 10%", headerFormat);
            addCell(row, col++, "Weekend 20%", headerFormat);
            addCell(row, col++, "PH Work Premium", headerFormat);
            
            // Freeze the top row
            sheet.createFreezePane(0, 1);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MONTH")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getInt("SCHEDULED_DAYS")), lineFormatInt);
                    addCell(row, col++, Misc.objectToInt(rs.getInt("SCHEDULED_DAYS_WORKED")), lineFormatInt);
                    addCell(row, col++, Misc.objectToInt(rs.getInt("ABSENCE_DAYS")), lineFormatInt);
                    addCell(row, col++, Misc.objectToInt(rs.getInt("OT_DAYS_WORKED")), lineFormatInt);
                    addCell(row, col++, Misc.objectToInt(rs.getInt("DAYS_OFF_6_OR_7")), lineFormatInt);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SCHEDULED_HOURS")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("SCHEDULED_HOURS_WORKED")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABSENCE_HOURS")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("ABSENCE_HOURS_6_OR_7")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OTO")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OT")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("OTP")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("CMPT")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("NITE")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("EVEN")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("WKND")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOWK")), lineFormatHours);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building payroll summary report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates extra off report for CZE, SVKa
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillExtraOffReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsExtraOffReport(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_EXTRA_OFF_DAYS.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFSheet sheet = workbook.createSheet("EXTRA_OFF_DAYS");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(25));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(50));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "AT&T Extra Off Days", lineFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col - 1, col));
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(40*20));
            col = 0;
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "Employee", headerFormat);
            addCell(row, col++, "Hours Eligible", headerFormat);
            addCell(row, col++, "Hours Taken", headerFormat);
            addCell(row, col++, "Hours Available", headerFormat);
            addCell(row, col++, "Days Taken", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("EXTRA_OFF_DAYS")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("OFF_TAKEN")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("OFF_AVAILABLE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("DAYS_TAKEN")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building extra off report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates a payroll summary report for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillMealVouchersReportSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsMealVouchersReportSVK(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Meal_Voucher_Corrections.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("SVK Meal Voucher Corrections");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(25));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(9));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "Bonus Vouchers Corrections", lineFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "COMPANY", lineFormat);
            addCell(row, col++, "AT&T", lineFormat);
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            col = 0;
            addCell(row, col++, "PERIOD_BEGIN_DT", lineFormat);
            addCell(row, col++, Integer.parseInt(Misc.dateToString(endDate, "Myyyy")), lineFormatLeft);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(40*20));
            col = 0;
            addCell(row, col++, "Personal number", headerFormat);
            addCell(row, col++, "SurnameName", headerFormat);
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "HRID", headerFormat);
            addCell(row, col++, "Meal Vouchers total", headerFormat);
            addCell(row, col++, "Correction", headerFormat);
            addCell(row, col++, "Balance", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("OTHER_PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("ATT_HRID")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MEAL_VOUCHERS")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("CORRECTION")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("BALANCE")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building meal voucher orrections report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the Comp Time Remaining by employee report for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param payrollEndDate
     * @param reportType
     */
    public static void fillCompDaysRemainingReport(Component parentFrame, String feeder, String site)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsCompDaysRemaining(parentFrame, feeder, site);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Comp_Days_Remaining.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font calibri_11 = workbook.createFont();
            calibri_11.setFontName("Calibri");
            calibri_11.setFontHeightInPoints((short)11);
            
            Font calibri_11_bold = workbook.createFont();
            calibri_11_bold.setFontName("Calibri");
            calibri_11_bold.setFontHeightInPoints((short)11);
            calibri_11_bold.setBold(true);
            
            XSSFCellStyle titleFormat = workbook.createCellStyle();
            titleFormat.setFont(calibri_11_bold);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(calibri_11_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(calibri_11);
            lineFormat.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Comp Days Remaining");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(27));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(35));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "REPORT OF COMP DAYS EARNED BUT NOT TAKEN AS OF " + Misc.dateToStringMDY(Oracle.getCurTime(parentFrame)), titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 3));
            row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "Feeder: " + feeder + ", Site: " + site, titleFormat, sheet, new CellRangeAddress(rownum - 1, rownum - 1, col, col + 1));
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(25*20));
            col = 0;
            addCell(row, col++, "MU", headerFormat);
            addCell(row, col++, "ATT UUID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            addCell(row, col++, "DATE EARNED", headerFormat);
            addCell(row, col++, "TYPE OF COMP DAY", headerFormat);
            
            // Freeze the top two rows
            sheet.createFreezePane(0, 3);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    col = 0;
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MU")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("REPORTING_DATE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("COMPTYPE")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building Comp Days Remaining report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates a meal contribution report for SVK
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param startDate
     * @param endDate
     */
    public static void fillMealVouchersDetailReportSVK(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsMeaVouchersDetailSVK(parentFrame, feeder, site, employeeSelection, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Meal_Vouchers_Detail.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle titleFormatBold = workbook.createCellStyle();
            titleFormatBold.setFont(arial_10_bold);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.MEDIUM);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormatHideZeroes = workbook.createCellStyle();
            lineFormatHideZeroes.cloneStyleFrom(lineFormat);
            lineFormatHideZeroes.setDataFormat(workbook.createDataFormat().getFormat("0;-0;;@"));
            
            XSSFCellStyle lineFormatHours = workbook.createCellStyle();
            lineFormatHours.cloneStyleFrom(lineFormat);
            lineFormatHours.setDataFormat(workbook.createDataFormat().getFormat("0.00;-0.00;;@"));
            
            XSSFSheet sheet = workbook.createSheet("Shift Plan");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(11));
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            addCell(row, 0, "Firma", titleFormatBold);
            addCell(row, 2, "AT&T", titleFormatBold);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Obdobie", titleFormatBold);
            addCell(row, 2, Misc.objectToInt(Misc.dateToString(endDate, "yyyyMM")), titleFormatBold);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Typ", titleFormatBold);
            addCell(row, 2, "Regular/Correction", titleFormatBold);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 0;
            addCell(row, col++, "Payroll ID", headerFormat);
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "Name", headerFormat);
            addCell(row, col++, "Date", headerFormat);
            addCell(row, col++, "Shift Hours", headerFormat);
            addCell(row, col++, "Absences", headerFormat);
            addCell(row, col++, "Shift Hours Worked", headerFormat);
            addCell(row, col++, "Overtime Hours", headerFormat);
            addCell(row, col++, "Business Trip", headerFormat);
            addCell(row, col++, "Comptime Earned", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(13*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("PAYROLL_ID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormatLeft);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormatLeft);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("REPORTING_DATE")), lineFormat);
                    Object shift = rs.getObject("SHIFT");
                    if (shift != null)
                    {
                        if (shift.toString().contains("."))
                        {
                            addCell(row, col++, Misc.objectToDouble(shift), lineFormatHideZeroes);
                        }
                        else
                        {
                            addCell(row, col++, Misc.objectToInt(shift), lineFormatHideZeroes);
                        }
                    }
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOTAL_ABS")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOTAL_WORKED")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("TOTAL_OT")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("BUSINESS_TRIP")), lineFormatHours);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("COMP_EARNED")), lineFormatHours);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building shift plan report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates a report which summarizes employee activity for EUR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param employeeSelection
     * @param startDate
     * @param endDate
     */
    public static void fillEmployeeActivityReport(Component parentFrame, String feeder, String site, String mu, String employeeSelection, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsEmployeeActivityReport(parentFrame, feeder, site, mu, employeeSelection, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "TVI_Employee_Activity.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle titleFormatBold = workbook.createCellStyle();
            titleFormatBold.setFont(arial_10_bold);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.MEDIUM);
            
            XSSFCellStyle headerFormatCenter = workbook.createCellStyle();
            headerFormatCenter.cloneStyleFrom(headerFormat);
            headerFormatCenter.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Employee Activity");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(8));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(14));
            sheet.setColumnWidth(col++, calculateColWidth(40));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            
            // write title rows
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            addCell(row, 0, "Firma", titleFormatBold);
            addCell(row, 2, "AT&T", titleFormatBold);
            
            row = sheet.createRow(rownum++);
            row.setHeight((short)(15*20));
            addCell(row, 0, "Obdobie", titleFormatBold);
            addCell(row, 2, Misc.objectToInt(Misc.dateToString(endDate, "yyyyMM")), titleFormatBold);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 0;
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "Name", headerFormat);
            addCell(row, col++, "Date", headerFormatCenter);
            addCell(row, col++, "Activity", headerFormatCenter);
            addCell(row, col++, "Start Time", headerFormatCenter);
            addCell(row, col++, "Stop Time", headerFormatCenter);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormatLeft);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormatLeft);
                    addCell(row, col++, Misc.dateToStringMDY((Date)rs.getObject("REPORTING_DATE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("ACTIVITY")), lineFormat);
                    addCell(row, col++, Misc.dateToString((Date)rs.getObject("START_TIME"), "h:mm a"), lineFormat);
                    addCell(row, col++, Misc.dateToString((Date)rs.getObject("STOP_TIME"), "h:mm a"), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building employee activity report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the absence summary report for MEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList
     * @param startDate
     * @param endDate
     */
    public static void fillAbsenceSummaryReportMEX(Component parentFrame, String feeder, String site, String empList, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsAbsenceSummaryReportMEX(parentFrame, feeder, site, empList, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "Absence_Summary.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle headerFormatLeft = workbook.createCellStyle();
            headerFormatLeft.cloneStyleFrom(headerFormat);
            headerFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Absence Summary");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(24));
            sheet.setColumnWidth(col++, calculateColWidth(18));
            sheet.setColumnWidth(col++, calculateColWidth(22));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 2;
            addCell(row, col++, "Date", lineFormat);
            addCell(row, col++, Misc.dateToString(startDate, "dd-MMM"), lineFormat);
            addCell(row, col++, Misc.dateToString(endDate, "dd-MMM"), lineFormat);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 0;
            addCell(row, col++, "Supervisor", headerFormat);
            addCell(row, col++, "Employee ATTUID", headerFormat);
            addCell(row, col++, "Employee Name", headerFormat);
            addCell(row, col++, "Absence Days", headerFormat);
            addCell(row, col++, "Average Population", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(15*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("COACH")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("DAYS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("AVG_POPULATION")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building absence summary report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates Absence Attendance Summary Report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param startDate
     * @param endDate
     */
    public static void fillAbsAttSummaryReport(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getAbsAttSummaryReportRecords(parentFrame, feeder, site, employeeSelection, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        String filename = "ABS_ATT_SUMMARY_Report.xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderBottom(BorderStyle.MEDIUM);
            headerFormat.setWrapText(true);
            
            XSSFCellStyle headerFormatRight = workbook.createCellStyle();
            headerFormatRight.cloneStyleFrom(headerFormat);
            headerFormatRight.setAlignment(HorizontalAlignment.RIGHT);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            
            XSSFCellStyle lineFormatLeft = workbook.createCellStyle();
            lineFormatLeft.cloneStyleFrom(lineFormat);
            lineFormatLeft.setAlignment(HorizontalAlignment.LEFT);
            
            XSSFSheet sheet = workbook.createSheet("Summary Report");
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(12));
            sheet.setColumnWidth(col++, calculateColWidth(30));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            sheet.setColumnWidth(col++, calculateColWidth(15));
            
            // write title
            Row row = sheet.createRow(rownum++);
            col = 0;
            addCell(row, col, "SUMMARY REPORT", lineFormat);
            row = sheet.createRow(rownum++);
            addCell(row, col, "FEEDER: " + feeder + ", SITE: " + site, lineFormat);
            row = sheet.createRow(rownum++);
            addCell(row, col, "DATES: " + Misc.dateToStringMDY(startDate) + " - " + Misc.dateToStringMDY(endDate), lineFormat);
            
            // write column headers
            row = sheet.createRow(rownum++);
            row.setHeight((short)(36*20));
            col = 0;
            addCell(row, col++, "FEEDER", headerFormat);
            addCell(row, col++, "SITE", headerFormat);
            addCell(row, col++, "MU", headerFormat);
            addCell(row, col++, "COACH", headerFormat);
            addCell(row, col++, "EMPID", headerFormat);
            addCell(row, col++, "EMPLOYEE", headerFormat);
            addCell(row, col++, "ABSENCE HOURS", headerFormatRight);
            addCell(row, col++, "ATTENDANCE\nHOURS", headerFormatRight);
            addCell(row, col++, "TOTAL\nHOURS", headerFormatRight);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("FEEDER")), lineFormat);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("SITE")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToInt(rs.getObject("MU")), lineFormatLeft);
                    addCell(row, col++, Misc.objectToString(rs.getObject("COACH")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPLOYEE")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOURS_ABS")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOURS_WORKED")), lineFormat);
                    addCell(row, col++, Misc.objectToDouble(rs.getObject("HOURS_ABS")) + Misc.objectToDouble(rs.getObject("HOURS_WORKED")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building Absence and Attendance Summary report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * Generates the incidental open time report for EUROPE
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     */
    public static void fillIncidentalOTReportEUR(Component parentFrame, String feeder, String site, Date reportingDate)
    {
        // Get results
        ResultSetWrapper results = Oracle.getResultsIncidentalOT(parentFrame, feeder, site, reportingDate);
        ResultSet rs = results.getResultSet();
        
        String dateString = Misc.dateToString(reportingDate, "MM-dd");
        String filename = "TVI_IncidentalOT_" + dateString + ".xlsx";
        if (!Misc.deleteFile(filename))
        {
            Misc.msgbox(parentFrame, "Check if the report file is already open in excel.", "File is locked", 0, 0, 1);
            return;
        }
        
        // Write the report to file
        try (XSSFWorkbook workbook = new XSSFWorkbook())
        {
            Font arial_10 = workbook.createFont();
            arial_10.setFontName("Arial");
            arial_10.setFontHeightInPoints((short)10);
            
            Font arial_10_bold = workbook.createFont();
            arial_10_bold.setFontName("Arial");
            arial_10_bold.setFontHeightInPoints((short)10);
            arial_10_bold.setBold(true);
            
            XSSFCellStyle headerFormat = workbook.createCellStyle();
            headerFormat.setFont(arial_10_bold);
            headerFormat.setBorderTop(BorderStyle.THIN);
            headerFormat.setBorderBottom(BorderStyle.THIN);
            headerFormat.setBorderLeft(BorderStyle.THIN);
            headerFormat.setBorderRight(BorderStyle.THIN);
            headerFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFCellStyle lineFormat = workbook.createCellStyle();
            lineFormat.setFont(arial_10);
            lineFormat.setBorderTop(BorderStyle.THIN);
            lineFormat.setBorderBottom(BorderStyle.THIN);
            lineFormat.setBorderLeft(BorderStyle.THIN);
            lineFormat.setBorderRight(BorderStyle.THIN);
            lineFormat.setAlignment(HorizontalAlignment.CENTER);
            
            XSSFSheet sheet = workbook.createSheet("Incidental OT");
            
            int rownum = 0;
            
            // set column widths
            int col = 0;
            sheet.setColumnWidth(col++, calculateColWidth(10));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(17));
            sheet.setColumnWidth(col++, calculateColWidth(22));
            
            // write column headers
            Row row = sheet.createRow(rownum++);
            row.setHeight((short)(18*20));
            col = 0;
            addCell(row, col++, "ATTUID", headerFormat);
            addCell(row, col++, "SCHEDULE_DATE", headerFormat);
            addCell(row, col++, "START", headerFormat);
            addCell(row, col++, "END", headerFormat);
            addCell(row, col++, "IEX_EXCEPTION_CODE", headerFormat);
            
            if (rs != null)
            {
                while (rs.next())
                {
                    row = sheet.createRow(rownum++);
                    row.setHeight((short)(18*20));
                    col = 0;
                    addCell(row, col++, Misc.objectToString(rs.getObject("EMPID")).toLowerCase(Locale.ENGLISH), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("REPORTING_DATE")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("START_TIME")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("END_TIME")), lineFormat);
                    addCell(row, col++, Misc.objectToString(rs.getObject("CODE")), lineFormat);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(filename))
            {
                workbook.write(fos);
                workbook.close();
            }
            Desktop.getDesktop().open(new File(filename));
            Oracle.updateActualScheduleStatus(parentFrame, feeder, site, "ALL", "INCOT", reportingDate, "Done");
            Oracle.clearActualScheduleIncOT(parentFrame, feeder, site, "ALL", reportingDate);
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Make sure there are no open reports in Excel.");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error building incidental open time report.");
        }
        finally
        {
            results.close();
        }
    }
    
    /**
     * addCell
     * 
     * POI excel helper method; adds a cell to the given row with the specified value and cell style at the given column.
     * 
     * @param row
     * @param col
     * @param value
     * @param style
     */
    public static void addCell(Row row, int col, Object value, XSSFCellStyle style)
    {
        Cell cell = row.createCell(col);
        if (value instanceof Integer)
        {
            cell.setCellValue((Integer)value);
        }
        else if (value instanceof Double)
        {
            cell.setCellValue((Double)value);
        }
        else if (value instanceof Date)
        {
            cell.setCellValue((Date)value);
        }
        else if (value instanceof String)
        {
            cell.setCellValue((String)value);
        }
        else if (value instanceof Boolean)
        {
            cell.setCellValue((Boolean)value);
        }
        else if (value instanceof LocalDate)
        {
            cell.setCellValue((LocalDate)value);
        }
        else if (value instanceof LocalDateTime)
        {
            cell.setCellValue((LocalDateTime)value);
        }
        else if (value instanceof RichTextString)
        {
            cell.setCellValue((RichTextString)value);
        }
        else
        {
            return; // unhandled data type
        }
        cell.setCellStyle(style);
    }
    
    /**
     * addCell
     * 
     * POI excel helper method; adds a cell to the given row with the specified value and cell style at the given column.
     * This version includes an optional String parameter to specify additional custom formatting.
     * 
     * @param row
     * @param col
     * @param value
     * @param style
     * @param customFormat
     */
    public static void addCell(Row row, int col, Object value, XSSFCellStyle style, String customFormat)
    {
        if (Misc.objectEquals(customFormat, "hideZeroes")) //used to replace zero values, use dataformat "0;-0;;@" instead to retain but hide
        {
            if (value != null && (value.toString().equals("0") || value.toString().equals("0.0")))
            {
                value = "";
            }
            addCell(row, col, value, style);
        }
        else if (Misc.objectEquals(customFormat, "convertToHours"))
        {
            String hours = "";
            if (value != null)
            {
                if (value instanceof Integer)
                {
                    //ignore the value
                }
                else if (!value.toString().isEmpty() && value.toString().length() > 1)
                {
                    hours = Misc.dateToString((Date)value, "H:mm");
                }
            }
            addCell(row, col, hours, style);
        }
        else
        {
            Misc.msgbox(null, "Invalid custom cell format: \"" + customFormat + "\"", "addCell", 0, 1, 1);
        }
    }
    
    /**
     * addCell
     * 
     * POI excel helper method; merges the specified cells on the given sheet after writing to the cell, and corrects region borders to match the style.
     * 
     * @param row
     * @param col
     * @param value
     * @param style
     * @param sheet
     * @param region
     */
    public static void addCell(Row row, int col, Object value, XSSFCellStyle style, XSSFSheet sheet, CellRangeAddress region)
    {
        addCell(row, col, value, style);
        sheet.addMergedRegion(region);
        RegionUtil.setBorderTop(style.getBorderTop(), region, sheet);
        RegionUtil.setBorderBottom(style.getBorderBottom(), region, sheet);
        RegionUtil.setBorderLeft(style.getBorderLeft(), region, sheet);
        RegionUtil.setBorderRight(style.getBorderRight(), region, sheet);
    }
    
    /**
     * calculateColWidth
     * 
     * POI excel helper method; converts the given width to the needed excel twip value.
     * 
     * @param width
     * @return excel twip value
     */
    public static int calculateColWidth(int width)
    {
        if (width > 254)
        {
            return 65280; // maximum allowed column width
        }
        if (width > 1)
        {
            int floor = (int)(Math.floor(((double)width)/5));
            int factor = (30 * floor);
            int value = 450 + factor + ((width - 1) * 250);
            return value;
        }
        else
        {
            return 450; // default to minimum column size of 1
        }
    }
}
