package tvicore.dao;

public class ReasonCodeRecord
{
    private String sapCode;
    private String sapReasonCode;
    private String description;
    private String unionFlags;
    
    public ReasonCodeRecord(String sapCode, String sapReasonCode, String description, String unionFlags)
    {
        this.sapCode = sapCode;
        this.sapReasonCode = sapReasonCode;
        this.description = description;
        this.unionFlags = unionFlags;
    }
    
    public String getSapCode()       { return sapCode; }
    public String getSapReasonCode() { return sapReasonCode; }
    public String getDescription()   { return description; }
    public String getUnionFlags()    { return unionFlags; }
    
    public void setSapCode(String value)       { sapCode = value; }
    public void setSapReasonCode(String value) { sapReasonCode = value; }
    public void setDescription(String value)   { description = value; }
    public void setUnionFlags(String value)    { unionFlags = value; }
    
    @Override
    public String toString() { return sapReasonCode; }
}