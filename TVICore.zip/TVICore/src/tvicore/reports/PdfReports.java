package tvicore.reports;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfCopyFields;
import com.lowagie.text.pdf.PdfReader;
import java.awt.Component;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.Semaphore;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.OSRoutines;
import tvicore.miscellaneous.Constants;

public class PdfReports
{
    public static final Semaphore openingPDFReportLock = new Semaphore(1, true);
    
    public static void createScheduleVerificationReport(Component parentFrame, String feeder, String site, String mu, String empid, String sbcid, Date startDate, Date endDate, String editType, String orientation)
    {
        String jasperFileName = "tvicore/reports/scheduleVerificationReportLandscape.jasper";
        if (orientation.equals("PORTRAIT"))
        {
            jasperFileName = "tvicore/reports/scheduleVerificationReportPortrait.jasper";
        }
        String pdfFileName = "TVIReport.pdf";
        HashMap<String, Object> hm = new HashMap<>();
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        String reportingDateout = Misc.dateToStringMDY(startDate);
        if (editType.equals("NORMAL"))
        {
            hm.put("REPORTDATE", reportingDateout);
        }
        else
        {
            hm.put("REPORTDATE", "Multiple");
        }
        
        ResultSetWrapper results = Oracle.getResultsVerificationReport(parentFrame, feeder, site, mu, empid, startDate, endDate, editType, sbcid);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating ScheduleVerificationReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollPeriodSummaryReport(Component parentFrame, String feeder, String site, String mu, Date payrollStartDate, Date payrollCloseDate)
    {
        String payrollPeriod = "Payroll Period: " + Misc.dateToStringMDY(payrollStartDate) + " - " +  Misc.dateToStringMDY(payrollCloseDate);
        String jasperFileName = "tvicore/reports/payrollPeriodSummaryReport.jasper";
        String pdfFileName = "TVIReport.pdf";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("MU", mu);
        hm.put("PAYROLL_PERIOD", payrollPeriod);
        
        ResultSetWrapper results = Oracle.getResultsPayrollSummaryReport(parentFrame, feeder, site, mu, payrollStartDate, payrollCloseDate);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating Payroll Period Summary Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollPeriodSummaryReport2(Component parentFrame, String feeder, String site, String mu, Date payrollStartDate, Date payrollCloseDate)
    {
        String payrollPeriod = "Payroll Period: " + Misc.dateToStringMDY(payrollStartDate) + " - " +  Misc.dateToStringMDY(payrollCloseDate);
        String jasperFileName = "tvicore/reports/payrollPeriodSummaryReport2.jasper";
        String pdfFileName = "TVIReport.pdf";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("MU", mu);
        hm.put("PAYROLL_PERIOD", payrollPeriod);
        
        ResultSetWrapper results = Oracle.getResultsPayrollSummary2Report(parentFrame, feeder, site, mu, payrollStartDate, payrollCloseDate);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating PayrollPeriodSummaryReport2.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollDetailByEmployeeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, boolean isCorrectingTimeSheet, boolean includeSignature, String sortBy, String pdfFileName, boolean openReport)
    {
        String requestType;
        String jasperFileName = "tvicore/reports/payrollPeriodDetailByEmployee.jasper";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("CORRECTING", isCorrectingTimeSheet);
        hm.put("SIGNATURE", includeSignature);
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        ResultSetWrapper results = Oracle.getResultsDetailByEmployeeReport(parentFrame, feeder, site, mu, empList, startDate, endDate, requestType, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating PayrollDetailByEmployeeReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollSummaryByEmployeeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String sortBy, String pdfFileName, boolean openReport)
    {
        String requestType;
        String jasperFileName = "tvicore/reports/payrollPeriodSummaryByEmployee.jasper";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        ResultSetWrapper results = Oracle.getResultsSummaryByEmployeeReport(parentFrame, feeder, site, mu, empList, startDate, endDate, requestType, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating PayrollSummaryByEmployeeReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createComputeNightDiffReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        String jasperFileName = "tvicore/reports/computeNightDiff.jasper";
        String pdfFileName = "TVIReport.pdf";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASKBAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        ResultSetWrapper results = Oracle.getResultsNightDiffReport(parentFrame, feeder, site, startDate, endDate);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating NightDiffReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createApprovalByPayrollPeriod(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, Date hotDay, String sortBy)
    {
        String jasperFileName = "tvicore/reports/approvalsByPayrollPeriod.jasper";
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        String timezone = "U.S. Pacific Time";
        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
        {
            timezone = "UTC Time";
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        hm.put("TIMEZONE", timezone);
        
        ResultSetWrapper results = Oracle.getResultsApprovalReport(parentFrame, feeder, site, mu, empList, hotDay, startDate, endDate, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating ApprovalsByPayrollPeriod Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollStatusReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, Date hotDay, String sortBy) throws JRException
    {
        String jasperFileName = "tvicore/reports/payrollStatus.jasper";
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        String timezone = "U.S. Pacific Time";
        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
        {
            timezone = "UTC Time";
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        hm.put("TIMEZONE", timezone);
        
        ResultSetWrapper results = Oracle.getResultsApprovalReport(parentFrame, feeder, site, mu, empList, hotDay, startDate, endDate, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating Payroll Status Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createInforStatusReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, Date hotDay, String sortBy) throws JRException, SQLException
    {
        String jasperFileName = "tvicore/reports/inforStatus.jasper";        
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        
        String usersTimeZone = ZoneId.systemDefault().toString();
        
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        ResultSetWrapper results = Oracle.getResultsInforReport(parentFrame, feeder, site, mu, empList, hotDay, startDate, endDate, sortBy, usersTimeZone);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating Data Sent to Infor Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    
    public static void createFeederIndicatorReport(Component parentFrame, String feeder, String site) throws JRException, SQLException
    {
        String jasperFileName = "tvicore/reports/feederStatus.jasper";
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        String usersTimeZone = ZoneId.systemDefault().toString();
        
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("FEEDER", feeder);
        hm.put("SITE", site);
        
        ResultSetWrapper results = Oracle.getResultsFeederReport(parentFrame, feeder, site, usersTimeZone);
        ResultSet rs = results.getResultSet();
        
       
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating Feeder Indicator Sent to Infor Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    
    
    public static void createBalancesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList) throws JRException, SQLException
    {
        String jasperFileName = "tvicore/reports/balancesReport.jasper"; 
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("FEEDER", feeder);
        hm.put("SITE", site);
        
        ResultSetWrapper results = Oracle.getResultsBalancesReport(parentFrame, feeder, site, mu, empList);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating Data Sent to Infor Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    
    
    public static void createEmployeeAbsenceDetailReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String sortBy)
    {
        String jasperFileName = "tvicore/reports/employeeAbsenceDetail.jasper";
        String pdfFileName = "TVIReport.pdf";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("FEEDER", feeder);
        hm.put("SITE", site);
        hm.put("MU", mu);
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        String year = Integer.toString(cal.get(Calendar.YEAR));
        hm.put("YEAR", year);
        
        ResultSetWrapper results = Oracle.getResultsAbsenceDetailReport(parentFrame, feeder, site, mu, empList, startDate, endDate, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating EmployeeAbsenceDetailReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createEntitlementsUsedReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate)
    {
        String requestType;
        String jasperFileName = "tvicore/reports/entitlementsUsed.jasper";
        String pdfFileName = "TVIReport.pdf";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open - check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("FEEDER", feeder);
        hm.put("SITE", site);
        hm.put("MU", mu);
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        String year = Integer.toString(cal.get(Calendar.YEAR));
        hm.put("YEAR", year);
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else if (!mu.equals("ALL"))
        {
            requestType = "MU";
        }
        else
        {
            requestType = "ALL";
        }
        
        ResultSetWrapper results = Oracle.getResultsEntitlementsReport(parentFrame, feeder, site, mu, empList, startDate, endDate, requestType);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            OSRoutines.openFileWithJava(parentFrame, pdfFileName);
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating ScheduleVerificationReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createLateEmployeesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String pdfFileName, boolean openReport)
    {
        String requestType;
        String jasperFileName = "tvicore/reports/lateEmployeesReport.jasper";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        ResultSetWrapper results = Oracle.getResultsLateEmployeesReport(parentFrame, feeder, site, mu, empList, startDate, endDate, requestType);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating LateEmployeesReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createLOAReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean showOKUP, String pdfFileName, boolean openReport)
    {
        String jasperFileName = "tvicore/reports/loaReport.jasper";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("SITE", site);
        hm.put("SHOWOKUP", showOKUP);
        
        ResultSetWrapper results = Oracle.getResultsLOAReportPDF(parentFrame, feeder, site, startDate, endDate, showOKUP);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating LOA Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createPayrollPeriodSummaryReportMEX(Component parentFrame, String feeder, String site, String empListCSV)
    {
        String jasperFileNamePRM = "tvicore/reports/payrollPeriodSummaryReportMEXPrm.jasper";
        String jasperFileNameABS = "tvicore/reports/payrollPeriodSummaryReportMEXAbs.jasper";
        String jasperFileNamePRMClear = "tvicore/reports/payrollPeriodSummaryReportMEXClearPrm.jasper";
        String jasperFileNameABSClear = "tvicore/reports/payrollPeriodSummaryReportMEXClearAbs.jasper";
        String pdfFilePRM = "TVIReportPRM.pdf";
        String pdfFileABS = "TVIReportABS.pdf";
        String pdfFilePRMClear = "TVIReportPRMClear.pdf";
        String pdfFileABSClear = "TVIReportABSClear.pdf";
        List<String> pdfFileList = new ArrayList<>();
        String pdfFileName = "TVIReport.pdf";
        
        if (!Misc.deleteFile(pdfFileName) || !Misc.deleteFile(pdfFilePRM) || !Misc.deleteFile(pdfFileABS) || !Misc.deleteFile(pdfFilePRMClear) || !Misc.deleteFile(pdfFileABSClear))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        ResultSetWrapper resultsPrm = Oracle.getResultsPayrollSummaryMEXPrmReport(parentFrame, feeder, site, empListCSV);
        ResultSet rsPrm = resultsPrm.getResultSet();
        
        ResultSetWrapper resultsAbs = Oracle.getResultsPayrollSummaryMEXAbsReport(parentFrame, feeder, site, empListCSV);
        ResultSet rsAbs = resultsAbs.getResultSet();
        
        ResultSetWrapper resultsClearPrm = Oracle.getResultsPayrollSummaryMEXClearPrmReport(parentFrame, feeder, site, empListCSV);
        ResultSet rsClearPrm = resultsClearPrm.getResultSet();
        
        ResultSetWrapper resultsClearAbs = Oracle.getResultsPayrollSummaryMEXClearAbsReport(parentFrame, feeder, site, empListCSV);
        ResultSet rsClearAbs = resultsClearAbs.getResultSet();
        
        JRDataSource myds;
        JasperPrint jp;
        
        try
        {
            //premiums
            if (rsPrm.next())
            {
                pdfFileList.add(pdfFilePRM);
                myds = new JRResultSetDataSource(rsPrm);
                jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileNamePRM), null, myds);
                JasperExportManager.exportReportToPdfFile(jp, pdfFilePRM);
            }
            
            //absences
            if (rsAbs.next())
            {
                pdfFileList.add(pdfFileABS);
                myds = new JRResultSetDataSource(rsAbs);
                jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileNameABS), null, myds);
                JasperExportManager.exportReportToPdfFile(jp, pdfFileABS);
            }
            
            //premium clears
            if (rsClearPrm.next())
            {
                pdfFileList.add(pdfFilePRMClear);
                myds = new JRResultSetDataSource(rsClearPrm);
                jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileNamePRMClear), null, myds);
                JasperExportManager.exportReportToPdfFile(jp, pdfFilePRMClear);
            }
            
            //absences clears
            if (rsClearAbs.next())
            {
                pdfFileList.add(pdfFileABSClear);
                myds = new JRResultSetDataSource(rsClearAbs);
                jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileNameABSClear), null, myds);
                JasperExportManager.exportReportToPdfFile(jp, pdfFileABSClear);
            }
            
            if (pdfFileList.size() > 0)
            {
                concatPDFs(parentFrame, pdfFileList, pdfFileName);
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
            else
            {
                Misc.msgbox(parentFrame, "No results to display, email TVI Support at " + Constants.EMAIL, "Creating Report", 1, 1, 1);
            }
            Misc.deleteFile(pdfFilePRM);
            Misc.deleteFile(pdfFileABS);
            Misc.deleteFile(pdfFilePRMClear);
            Misc.deleteFile(pdfFileABSClear);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating PayrollPeriodSummaryReportMEX.");
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating PayrollPeriodSummaryReportMEX.");
        }
        finally
        {
            resultsPrm.close();
            resultsAbs.close();
            resultsClearPrm.close();
            resultsClearAbs.close();
        }
    }
    
    public static void createPartialAbsencesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String sortBy, String reportType, String pdfFileName, boolean openReport)
    {
        String requestType;
        String jasperFileName;
        if (reportType.equals("DETAIL"))
        {
            jasperFileName = "tvicore/reports/partialAbsencesDetailReport.jasper";
        }
        else
        {
            jasperFileName = "tvicore/reports/partialAbsencesSummaryReport.jasper";
        }
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("PAYROLLENDDATE", Misc.dateToStringMDY(endDate));
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        ResultSetWrapper results = Oracle.getResultsPartialAbsencesReport(parentFrame, feeder, site, mu, empList, startDate, endDate, reportType, requestType, sortBy);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating PartialAbsencesReport.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void createFMLAUpdatesReport(Component parentFrame, String filename, String pdfFileName, boolean openReport)
    {
        String jasperFileName = "tvicore/reports/FMLAUpdatesReport.jasper";
        if (!Misc.deleteFile(pdfFileName))
        {
            Misc.msgbox(parentFrame, "Cannot open report at this time.  It may already be open.  Check your TASK BAR", "Creating Report", 1, 1, 1);
            return;
        }
        
        HashMap<String, Object> hm = new HashMap<>();
        hm.put("FILENAME", filename);
        
        ResultSetWrapper results = Oracle.getResultsFMLAApprovalsReport(parentFrame);
        ResultSet rs = results.getResultSet();
        
        try
        {
            JRDataSource myds = new JRResultSetDataSource(rs);
            JasperPrint jp = JasperFillManager.fillReport(ClassLoader.getSystemResourceAsStream(jasperFileName), hm, myds);
            JasperExportManager.exportReportToPdfFile(jp, pdfFileName);
            if (openReport)
            {
                OSRoutines.openFileWithJava(parentFrame, pdfFileName);
            }
        }
        catch (JRException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Jasper Error creating FMLA Updates Report.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void concatPDFs(Component parentFrame, List<String> inputFiles, String outputFile)
    {
        try
        {
            PdfCopyFields copy = new PdfCopyFields(new FileOutputStream(outputFile));
            for (int i = 0; i < inputFiles.size(); i++)
            {
                copy.addDocument(new PdfReader(inputFiles.get(i)));
            }
            copy.close();
        }
        catch (DocumentException | IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Error Building PDF Report");
        }
    }
}