package tvicore.objects;

import java.awt.Toolkit;
import java.util.Locale;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;

public class CharLimitFilter extends DocumentFilter
{
    int limit;
    boolean toUpper;
    
    public CharLimitFilter(int limit)
    {
        super();
        this.limit = limit;
        this.toUpper = false;
    }
    
    public CharLimitFilter(int limit, boolean toUpper)
    {
        super();
        this.limit = limit;
        this.toUpper = toUpper;
    }
    
    @Override
    public void insertString(FilterBypass fb, int offset, String str, AttributeSet attr) throws BadLocationException
    {
        str = str.replace("\n", "");
        if ((fb.getDocument().getLength() + str.length()) <= limit)
        {
            if (toUpper)
            {
                super.insertString(fb, offset, str.toUpperCase(Locale.ENGLISH), attr);
            }
            else
            {
                super.insertString(fb, offset, str, attr);
            }
        }
        else
        {
            Toolkit.getDefaultToolkit().beep();
        }
    }
    
    @Override
    public void replace(FilterBypass fb, int offset, int length, String str, AttributeSet attr) throws BadLocationException
    {
        str = str.replace("\n", "");
        if ((fb.getDocument().getLength() + str.length() - length) <= limit)
        {
            if (toUpper)
            {
                super.replace(fb, offset, length, str.toUpperCase(Locale.ENGLISH), attr);
            }
            else
            {
                super.replace(fb, offset, length, str, attr);
            }
        }
        else
        {
            Toolkit.getDefaultToolkit().beep();
        }
    }
}