package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.resources.Resources;
import tvicore.dao.AbsenceCodeRecord;
import tvicore.dao.ExtraPaymentCodeRecord;
import tvicore.dao.UserData;

public final class WeeklyTimecodeMinutesCheck extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile WeeklyTimecodeMinutesCheck instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    TableRowSorter<CustomTableModel> sorter;
    
    Dimension loadingPanelDimensions = new Dimension(825, 250);
    
    Date endDate = null;
    String timecodeType = "^(?!TVI/PSL$|DIS-TOTAL).*";
    Double thresholdMins = 0.0;
    int filterColumn = -1;
    boolean filterEnabled = true;
    public Timer timecodeUpdateTimer;
    
    final static int idx_RESEND         = 0;
    final static int idx_EMPID          = 1;
    final static int idx_EMPLOYEE       = 2;
    final static int idx_MU             = 3;
    final static int idx_REPORTING_DATE = 4;
    final static int idx_TVI_CODE       = 5;
    final static int idx_TVI_MINUTES    = 6;
    final static int idx_TVI_PENDING    = 7;
    final static int idx_INFOR_CODE     = 8;
    final static int idx_INFOR_MINUTES  = 9;
    final static int idx_INFOR_PENDING  = 10;
    final static int idx_CHGD_BY        = 11;
    final static int idx_TIMECODE       = 12;
    final static int idx_CODE           = 13;
    final static int idx_THRESHOLD      = 14;
    
    
    public synchronized static WeeklyTimecodeMinutesCheck getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new WeeklyTimecodeMinutesCheck(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        
        return instance;
    }
    
    private WeeklyTimecodeMinutesCheck(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        

        thresholdPanel.setVisible(false);
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Calendar cal = Calendar.getInstance();
        cal.setTime(Misc.dateAddDays(Misc.getNextDayOfWeek(cal.getTime(), RegionData.getLastDayOfWeek(), true), 14));
        for (int i = 0; i < 55; i++)
        {
            pickDate.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, - 7);
        }
        pickDate.setSelectedIndex(2);
        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        
        // Loads the last updated timecode date after page has been loaded
        ActionListener timecodeUpdateDate = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshLastUpdatedLabel()).start();
            }
        };
        timecodeUpdateTimer = new Timer(0, timecodeUpdateDate);
        timecodeUpdateTimer.setRepeats(false);
        timecodeUpdateTimer.setInitialDelay(0);
        timecodeUpdateTimer.start();
        
        
    }
    
    private class RefreshLastUpdatedLabel implements Runnable
    {
        @Override
        public void run()
        {
            
            timecodeLastUpdatedLabel.setText("INFOR Timecodes Last Updated: " + Oracle.getInforTimecodeTimeStamp(getFormComponent()));
        
        }
    }
    

    private void processFilter()
    {
        if (table == null || !worker.isDone())
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> timecodeFilter;
        RowFilter<CustomTableModel, Object> thresholdFilter;
        
        try
        {
            thresholdFilter = RowFilter.numberFilter(RowFilter.ComparisonType.AFTER, thresholdMins, idx_THRESHOLD);
            filters.add(thresholdFilter);
            
            timecodeFilter = RowFilter.regexFilter(timecodeType, idx_CODE);     
            filters.add(timecodeFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), scheduledHoursCheckScrollPane, table);
        }
    }
    
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                                loadingLabel.setVisible(true);
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    loadingLabel.setText("LOADING...");
                    loadingLabel.setVisible(true);
                    scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
                    validate();
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "Resend",                                           // idx_RESEND
                "AT&T ID",                                          // idx_EMPID
                "Employee",                                         // idx_EMPLOYEE
                "MU",                                               // idx_MU
                "Date",                                             // idx_REPORTING_DATE
                "TVI Codes",                                        // idx_TVI_CODE
                Misc.centerHTML("TVI<br> Minutes"),                 // idx_TVI_MINUTES
                Misc.centerHTML("Pending<br> TVI<br> Minutes"),     // idx_TVI_PENDING
                "INFOR Codes",                                      // idx_TIME_CODE
                Misc.centerHTML("INFOR<br> Minutes"),               // idx_INFOR_MINUTES
                Misc.centerHTML("Pending<br> INFOR<br> Minutes"),   // idx_CHGD_BY
                Misc.centerHTML("Changed in<br> INFOR by"),         // idx_CHGD_BY                
                "Timecode",                                         // idx_TIMECODE
                "",                                                 // idx_CODE 
                ""                                                  // idx_THRESHOLD
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsTimecodeCheck(getFormComponent(), feeder, site, endDate, null, null);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getBoolean("RESEND_FLAG"),                      // idx_RESEND
                    rs.getString("EMPID"),                             // idx_EMPID
                    rs.getString("EMPLOYEE"),                          // idx_EMPLOYEE
                    rs.getString("MU"),                                // idx_MU
                    rs.getDate("REPORTING_DATE"),                      // idx_REPORTING_DATE
                    rs.getString("TVI_CODE"),                          // idx_TVI_CODE
                    rs.getBigDecimal("TVI_MINUTES"),                   // idx_TVI_MINUTES
                    rs.getBigDecimal("TVI_PENDING"),                   // idx_TVI_PENDING
                    rs.getString("INFOR_CODE"),                        // idx_INFOR_CODE
                    rs.getBigDecimal("INFOR_MINUTES"),                 // idx_INFOR_MINUTES
                    rs.getBigDecimal("INFOR_PENDING"),                 // idx_INFOR_PENDING
                    rs.getString("CHGD_BY"),                           // idx_CHGD_BY
                    rs.getString("TIMECODE"),                          // idx_TIMECODE
                    rs.getString("CODE"),                              // idx_CODE  
                    rs.getDouble("THRESHOLD")                          // idx_THRESHOLD
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading scheduled hours check data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                if (dataModel.getRowCount() > 0)
                {
                    Misc.scaleScrollPaneToTable(getFormComponent(), scheduledHoursCheckScrollPane, table);
                    scheduledHoursCheckScrollPane.setViewportView(table);
        
                }
                else
                {
                    loadingLabel.setText("NO ERRORS");
                    loadingLabel.setVisible(true);
                    scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
                }
                validate();
            }
            else
            {
                clearTable();
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                
                @Override
                public void paintComponent(Graphics g)
                {
                    super.paintComponent(g);
                    if (table.getRowCount() > 1)
                    {

                        // Only draw week lines when sorting by date ascending
                        if (!table.getRowSorter().getSortKeys().isEmpty())
                        {
                            if (!(table.getRowSorter().getSortKeys().get(0).getColumn() == idx_EMPID &&
                                table.getRowSorter().getSortKeys().get(0).getSortOrder().toString().equals("ASCENDING")))
                            {
                                return;
                            }
                        }
                        //start at second record 
                        for (int i = 1; i < table.getRowCount(); i++)
                        {
                            if(!((Date) table.getValueAt(i-1, idx_REPORTING_DATE)).equals(((Date) table.getValueAt(i, idx_REPORTING_DATE))))
                            {
                                int y = i * table.getRowHeight();
                                g.drawLine(0, y, table.getWidth(), y);
                            }
                            else
                            {
                                if(!table.getValueAt(i-1, idx_EMPID).equals(table.getValueAt(i,idx_EMPID)))
                                {
                                    int y = i * table.getRowHeight();
                                    g.drawLine(0, y, table.getWidth(), y);
                                }          
                            }  
                        }
                    }
                }
                
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_RESEND:
                            return Boolean.class;
                        case idx_INFOR_MINUTES:
                        case idx_TVI_MINUTES:
                        case idx_INFOR_PENDING:
                        case idx_TVI_PENDING:
                            return BigDecimal.class;
                        case idx_THRESHOLD:
                            return Double.class;
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_MU:
                        case idx_TIMECODE:
                        case idx_CHGD_BY:
                        case idx_INFOR_CODE:
                        case idx_TVI_CODE:
                        case idx_CODE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);


            Misc.configureTable(table, true, false, true);
            Misc.setHeaderRenderer(table, true, true, new Color(  255,   255,   255));
            Misc.setColumnSettings(table, idx_EMPID, 80);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 180, Constants.LEFT);
            Misc.setColumnSettings(table, idx_MU, 60);
            Misc.setColumnSettings(table, idx_REPORTING_DATE, 100);
            Misc.setColumnSettings(table, idx_TIMECODE, 0, false);
            Misc.setColumnSettings(table, idx_INFOR_MINUTES, 60);
            Misc.setColumnSettings(table, idx_TVI_MINUTES, 60);
            Misc.setColumnSettings(table, idx_CHGD_BY, 80);
            Misc.setColumnSettings(table, idx_INFOR_PENDING, 60);
            Misc.setColumnSettings(table, idx_RESEND, 60, false);
            Misc.setColumnSettings(table, idx_TVI_CODE, 250);
            Misc.setColumnSettings(table, idx_INFOR_CODE, 250);
            Misc.setColumnSettings(table, idx_CODE, 0, false);
            Misc.setColumnSettings(table, idx_THRESHOLD, 0, false);
            Misc.setColumnSettings(table, idx_TVI_PENDING, 60);
            
            processFilter();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        hoursRadioGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        subtitleLabel = new javax.swing.JLabel();
        weekEndingLabel = new javax.swing.JLabel();
        retrieveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        timecodeLastUpdatedLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        scheduledHoursCheckScrollPane = new javax.swing.JScrollPane();
        loadingPanel = new javax.swing.JPanel();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        optionsPanel = new javax.swing.JPanel();
        timecodeTypePanel = new javax.swing.JPanel();
        timecodeLabel = new javax.swing.JLabel();
        filterTimecodeComboBox = new javax.swing.JComboBox<>();
        thresholdPanel = new javax.swing.JPanel();
        thresholdLabel = new javax.swing.JLabel();
        filterThresholdComboBox = new javax.swing.JComboBox<>();
        buttonPanel = new javax.swing.JPanel();
        resendToInforButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Weekly Timecode Minutes Check");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(841, 500));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setToolTipText("");
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setMinimumSize(new java.awt.Dimension(805, 120));
        titlePanel.setPreferredSize(new java.awt.Dimension(825, 120));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Timecode Minutes Discrepancies Report ");
        titleLabel.setPreferredSize(new java.awt.Dimension(325, 25));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 390, -1));

        pickDate.setPreferredSize(new java.awt.Dimension(150, 25));
        pickDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickDateActionPerformed(evt);
            }
        });
        titlePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, -1, -1));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("The following employees have timecodes or minutes that do not match INFOR for the week!");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(825, 20));
        titlePanel.add(subtitleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 95, -1, -1));

        weekEndingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        weekEndingLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        weekEndingLabel.setText("Pick Week Ending Date:");
        weekEndingLabel.setPreferredSize(new java.awt.Dimension(200, 20));
        titlePanel.add(weekEndingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 60, 220, -1));

        retrieveButton.setBackground(new java.awt.Color(120, 200, 200));
        retrieveButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        retrieveButton.setText("Retrieve");
        retrieveButton.setPreferredSize(new java.awt.Dimension(130, 35));
        retrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retrieveButtonActionPerformed(evt);
            }
        });
        titlePanel.add(retrieveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 55, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(70, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 10, 80, -1));

        timecodeLastUpdatedLabel.setText("INFOR Timecodes Last Updated: Loading...");
        titlePanel.add(timecodeLastUpdatedLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 260, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMaximumSize(new java.awt.Dimension(1280, 1600));
        centerPanel.setPreferredSize(new java.awt.Dimension(1280, 250));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        scheduledHoursCheckScrollPane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        scheduledHoursCheckScrollPane.setAlignmentY(0.0F);
        scheduledHoursCheckScrollPane.setMaximumSize(new java.awt.Dimension(1250, 450));
        scheduledHoursCheckScrollPane.setMinimumSize(new java.awt.Dimension(1250, 23));
        scheduledHoursCheckScrollPane.setName(""); // NOI18N
        scheduledHoursCheckScrollPane.setPreferredSize(new java.awt.Dimension(1250, 250));

        loadingPanel.setPreferredSize(new java.awt.Dimension(820, 248));
        loadingPanel.setRequestFocusEnabled(false);
        loadingPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 100));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingPanel.add(loadingLabel);

        scheduledHoursCheckScrollPane.setViewportView(loadingPanel);

        centerPanel.add(scheduledHoursCheckScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(825, 20));
        bottomPanel.setPreferredSize(new java.awt.Dimension(825, 120));
        bottomPanel.setVerifyInputWhenFocusTarget(false);
        bottomPanel.setLayout(new java.awt.GridBagLayout());

        optionsPanel.setBackground(new java.awt.Color(120, 200, 200));
        optionsPanel.setMinimumSize(new java.awt.Dimension(850, 30));
        optionsPanel.setPreferredSize(new java.awt.Dimension(850, 40));

        timecodeTypePanel.setBackground(new java.awt.Color(120, 200, 200));

        timecodeLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        timecodeLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        timecodeLabel.setText("Timecode Type:");
        timecodeLabel.setMaximumSize(new java.awt.Dimension(162, 17));
        timecodeLabel.setMinimumSize(new java.awt.Dimension(162, 17));
        timecodeLabel.setPreferredSize(new java.awt.Dimension(120, 20));
        timecodeTypePanel.add(timecodeLabel);

        filterTimecodeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show Leave Link", "Show Disability", "Show Timecodes" }));
        filterTimecodeComboBox.setSelectedIndex(3);
        filterTimecodeComboBox.setMinimumSize(new java.awt.Dimension(31, 22));
        filterTimecodeComboBox.setPreferredSize(new java.awt.Dimension(125, 25));
        filterTimecodeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterTimecodeComboBoxActionPerformed(evt);
            }
        });
        timecodeTypePanel.add(filterTimecodeComboBox);

        optionsPanel.add(timecodeTypePanel);

        thresholdPanel.setBackground(new java.awt.Color(120, 200, 200));

        thresholdLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        thresholdLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        thresholdLabel.setText("Threshold:");
        thresholdLabel.setToolTipText("");
        thresholdLabel.setMaximumSize(new java.awt.Dimension(162, 17));
        thresholdLabel.setMinimumSize(new java.awt.Dimension(162, 17));
        thresholdLabel.setPreferredSize(new java.awt.Dimension(100, 20));
        thresholdPanel.add(thresholdLabel);

        filterThresholdComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0 minutes", "1 minute", "5 minutes" }));
        filterThresholdComboBox.setMinimumSize(new java.awt.Dimension(31, 22));
        filterThresholdComboBox.setPreferredSize(new java.awt.Dimension(115, 25));
        filterThresholdComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterThresholdComboBoxActionPerformed(evt);
            }
        });
        thresholdPanel.add(filterThresholdComboBox);

        optionsPanel.add(thresholdPanel);

        bottomPanel.add(optionsPanel, new java.awt.GridBagConstraints());

        buttonPanel.setBackground(new java.awt.Color(120, 200, 200));
        buttonPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        buttonPanel.setPreferredSize(new java.awt.Dimension(850, 40));

        resendToInforButton.setBackground(new java.awt.Color(120, 200, 200));
        resendToInforButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        resendToInforButton.setText("Resend to INFOR");
        resendToInforButton.setMaximumSize(new java.awt.Dimension(63, 25));
        resendToInforButton.setMinimumSize(new java.awt.Dimension(63, 25));
        resendToInforButton.setPreferredSize(new java.awt.Dimension(140, 35));
        resendToInforButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resendToInforButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(resendToInforButton);

        printButton.setBackground(new java.awt.Color(120, 200, 200));
        printButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        printButton.setText("Print");
        printButton.setPreferredSize(new java.awt.Dimension(140, 35));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(printButton);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        bottomPanel.add(buttonPanel, gridBagConstraints);
        buttonPanel.getAccessibleContext().setAccessibleDescription("");

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", "Code Discrepancies");
    }//GEN-LAST:event_printButtonActionPerformed

    private void retrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retrieveButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_retrieveButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void pickDateActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_pickDateActionPerformed
    {//GEN-HEADEREND:event_pickDateActionPerformed
        setCursor(Constants.HOURGLASS);
        if (worker != null)
        {
            worker.cancel(true);
        }
        clearTable();
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_pickDateActionPerformed

    private void resendToInforButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resendToInforButtonActionPerformed
        if (table.getSelectedRow() == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select a record first.", "Resend to INFOR", 1, 1, 1);
            return;
        }
  
        String lockedBy;
        String scheduleStatus;
        boolean foundCode=false;
        int selectedRow = table.getSelectedRow();
        String mu;
        String empid;
        Date reportingDate;
        int totalviewId;
        boolean flagChecked = false;
        mu = Misc.objectToString(table.getValueAt(selectedRow, idx_MU));
        empid = Misc.objectToString(table.getValueAt(selectedRow, idx_EMPID));
        reportingDate = (Date) table.getValueAt(selectedRow, idx_REPORTING_DATE);
        totalviewId = Oracle.getTotalviewID(getFormComponent(), feeder, site, mu);
        
        //checks schedule status and locked records to see if record can be resent
        scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate);
        if(scheduleStatus==null)
        {
            Misc.msgbox(getFormComponent(), "Record does not exist", "Cannot Resend Records", 1, 1, 1);
            refreshData();
            return; 
        }
        if (Arrays.asList("Requesting", "Loading", "Load Failed", "Sent Waiting Results", "Send Failed").contains(scheduleStatus))
        {
            String message = "Cannot resend timecode with a schedule status of \"" + scheduleStatus + "\".";
            if (scheduleStatus.equals("Load Failed") || scheduleStatus.equals("Send Failed"))
            {
                message += "\nEmail TVI Support: " + Constants.EMAIL;
            }
            Misc.msgbox(getFormComponent(), message, "Cannot Resend Records", 1, 1, 1);
            return;
        }
        else if (Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu, reportingDate) != null)
        {
            lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu, reportingDate);
            Misc.msgbox(getFormComponent(), "Cannot resend timecode at this time, it is currently locked by: " + lockedBy, "Cannot Resend Records", 1, 1, 1);
            return;
        }
        if (Oracle.areAnyRecordsLocked(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate))
        {
            Misc.msgbox(getFormComponent(), "Record is locked by another user.", "Cannot Resend Records.", 1, 1, 1);       
            return;
        }
            

        //do not continue if the record selected is not a timecode
        if(Misc.objectToString(table.getValueAt(selectedRow, idx_CODE)).equals("DIS-TOTAL") || Misc.objectToString(table.getValueAt(selectedRow, idx_CODE)).equals("TVI/PSL"))
        {
            Misc.msgbox(getFormComponent(), "Leave Link and Disability codes cannot be resent", "Cannot Resend Records", 1, 1, 1);
            return;
        }
           
        //locks the record for the selected employee and date
        Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate, UserData.getUUID(), "DETAIL");
        Oracle.updateScheduleStatus(getFormComponent(), feeder, site, empid, reportingDate, reportingDate, "DETAIL");

        //Lets users cancel before resending records
        if(!Misc.msgbox(getFormComponent(), "Employee flagged to resend to INFOR.", "TVI : FYI Message", 1, 2, 1))
        {
            Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate, "DETAIL", UserData.getUUID());
            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, empid, reportingDate, reportingDate, "DETAIL");
            return;
        }



        //loops through each timecode listed for the selected empid and date
        for (int j = 0; j < table.getRowCount(); j++)
        {
            foundCode=false;
                  
            //only grab timecodes not TVI/PSL or DIS-TOTAL
            if(!Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("DIS-TOTAL") && !Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("TVI/PSL"))
            {
                if(Misc.objectToString(table.getValueAt(j, idx_RESEND)).equals("true"))
                {
                    //skip code - ALREADY BEING RESENT
                }
                // if record belongs to empid and reporting_date
                else if(empid.equals(Misc.objectToString(table.getValueAt(j, idx_EMPID))) && Misc.objectToString(table.getValueAt(selectedRow, idx_REPORTING_DATE)).equals(Misc.objectToString(table.getValueAt(j, idx_REPORTING_DATE))))
                {
                    //sets flag if there is a tvi record
                    if(table.getValueAt(j, idx_TVI_CODE)!=(null))
                    {
                        if(!flagChecked)
                        {
                            if(!Oracle.setResendFlag(getFormComponent(), feeder, site, mu, empid, reportingDate, UserData.getUUID()))
                            {
                                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate, "DETAIL", UserData.getUUID());
                                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, empid, reportingDate, reportingDate, "DETAIL");
                                return; 
                            }
                            flagChecked=true;
                        }
                    }
                        
                    //if code is in infor but not tvi
                    if(table.getValueAt(j, idx_TVI_MINUTES)==(null) && table.getValueAt(j, idx_INFOR_CODE)!=(null) && table.getValueAt(j, idx_TVI_PENDING)==(null))
                    {
                        //only assigns 0 to records that arent contractual, job, dis-partial, or dept-approved
                        if (!Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("CONTRACTUAL-ILLNESS")
                            && !Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("JOB-ACCOM-ILLNESS")
                            && !Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("DIS-PARTIAL")
                            && !Misc.objectToString(table.getValueAt(j, idx_CODE)).equals("DEPT-APPROVED-ILLNESS"))
                        {
                            //only sets resend flag to true if there is at least one non contractual-illness, job-accom-illness, dis-partial, or dept-approved-illness record
                            if(!flagChecked)
                            {
                                if(!Oracle.setResendFlag(getFormComponent(), feeder, site, mu, empid, reportingDate, UserData.getUUID()))
                                {
                                    Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate, "DETAIL", UserData.getUUID());
                                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, empid, reportingDate, reportingDate, "DETAIL");
                                    return; 
                                }
                                flagChecked=true;
                            }
                            //ADD INFOR CODE WITH 0 MINUTES TO EITHER ABSENCES OR EXTRA_PAYMENTS
                            for (ExtraPaymentCodeRecord extraPayment : RegionData.getExtraPaymentCodes())
                            {
                                if (Misc.checkUnionFlag(feeder, extraPayment.getUnionFlagsErec(), RegionData.getSiteUnion()))
                                {
                                    if(table.getValueAt(j, idx_INFOR_CODE).equals(extraPayment.getDescriptionErec()))
                                    {
                                        //add to extra payments table
                                        int newReckey = Oracle.getNextReckey(getFormComponent(), empid, reportingDate, "EXTRA_PAYMENTS_MASTER");
                                        Oracle.insertExtraPayment(getFormComponent(), // parentFrame
                                            feeder,                                   // feeder
                                            site,                                     // site
                                            totalviewId,                              // totalviewID
                                            mu,                                       // mu
                                            reportingDate,                            // reportingDate
                                            empid,                                    // empid
                                            newReckey,                                // recKey
                                            extraPayment.getCodeErec(),               // sapCodeTrec
                                            extraPayment.getDescriptionErec(),        // codeDescription
                                            0.0,                                      // amountErec
                                            0,                                        // minsErec
                                            extraPayment.getAmountTypeErec(),         // amountType
                                            "",                                       // activity
                                            "",                                       // costCenter
                                            "",                                       // locationCode
                                            "",                                       // deptTrackingCode
                                            "",                                       // projectNumber
                                            "",                                       // ec
                                            UserData.getUUID()                        // changedBy
                                        );
                                                      
                                        foundCode=true;
                                    }
                                }
                            }
                            for (AbsenceCodeRecord absence : RegionData.getAbsenceCodes())
                            {
                                if (Misc.checkUnionFlag(feeder, absence.getUnionFlags(), RegionData.getSiteUnion()))
                                {
                                    if(table.getValueAt(j, idx_INFOR_CODE).equals(absence.getDescription()))
                                    {
                                        //add to absences table
                                        int newReckey = Oracle.getNextReckey(getFormComponent(), empid, reportingDate, "TIME_ABSENCES_MASTER");
                                        Oracle.insertAbsence(getFormComponent(), // parentFrame
                                            feeder,                              // feeder
                                            site,                                // site
                                            totalviewId,                         // totalviewID
                                            mu,                                  // mu
                                            reportingDate,                       // reportingDate
                                            empid,                               // empid
                                            newReckey,                           // recKey
                                            absence.getSapCode(),                // sapCodeTrec
                                            absence.getDescription(),            // codeDescription
                                            0.0,                                 // hoursTrec
                                            "",                                  // reasonCode
                                            "",                                  // reasonText
                                            -1,                                  // readyFlag
                                            "",                                  // reasonDescription
                                            UserData.getUUID(),                  // changedBy
                                            0                                    // minsTrec
                                        );
                                        foundCode=true;
                                    }
                                }
                            }
                            if(!foundCode){
                                Misc.msgbox(getFormComponent(), "Timecode cannot be resent.", "Cannot Resend Records", 1, 1, 1);
                            }
                        }
                    }    
                 }
            }
        }    
        //unlock records
        Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, empid, reportingDate, reportingDate, "DETAIL", UserData.getUUID());
        Oracle.updateScheduleStatus(getFormComponent(), feeder, site, empid, reportingDate, reportingDate, "DETAIL");
            
        refreshData();
    }//GEN-LAST:event_resendToInforButtonActionPerformed

    private void filterTimecodeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterTimecodeComboBoxActionPerformed
        String selection = filterTimecodeComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "Show All":
                timecodeType = ".*";
                thresholdPanel.setVisible(false);
                filterThresholdComboBox.setSelectedIndex(0);
                break;
            case "Show Leave Link":
                timecodeType = "TVI/PSL";
                thresholdPanel.setVisible(true);
                break;
            case "Show Timecodes":
                timecodeType = "^(?!TVI/PSL$|DIS-TOTAL).*";
                thresholdPanel.setVisible(false);
                filterThresholdComboBox.setSelectedIndex(0);
                break;
            case "Show Disability":
                timecodeType = "DIS-TOTAL";
                thresholdPanel.setVisible(true);
                break;
            default:
                timecodeType = "^(?!TVI/PSL$|DIS-TOTAL).*";
                thresholdPanel.setVisible(false);
                filterThresholdComboBox.setSelectedIndex(0);
                break;
        }
        processFilter();
    }//GEN-LAST:event_filterTimecodeComboBoxActionPerformed

    private void filterThresholdComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterThresholdComboBoxActionPerformed
        String selection = filterThresholdComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "0 minutes":
                thresholdMins = 0.0;
                break;
            case "1 minute":
                thresholdMins = 1.0;
                break;
            case "5 minutes":
                thresholdMins = 5.0;
                break;
            default:
                thresholdMins = 0.0;
                break;
        }
        processFilter();
    }//GEN-LAST:event_filterThresholdComboBoxActionPerformed
    
    private void clearTable()
    {
        loadingLabel.setVisible(false);
        scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
        scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
        scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
        validate();
        
        table = null;
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }

        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JComboBox<String> filterThresholdComboBox;
    private javax.swing.JComboBox<String> filterTimecodeComboBox;
    private javax.swing.ButtonGroup hoursRadioGroup;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel loadingPanel;
    private javax.swing.JPanel optionsPanel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JButton printButton;
    private javax.swing.JButton resendToInforButton;
    private javax.swing.JButton retrieveButton;
    private javax.swing.JScrollPane scheduledHoursCheckScrollPane;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JLabel thresholdLabel;
    private javax.swing.JPanel thresholdPanel;
    private javax.swing.JLabel timecodeLabel;
    private javax.swing.JLabel timecodeLastUpdatedLabel;
    private javax.swing.JPanel timecodeTypePanel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JLabel weekEndingLabel;
    // End of variables declaration//GEN-END:variables
}
