package tvi.gui;

import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.dao.UserData;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.resources.Resources;

public final class Configuration extends javax.swing.JFrame
{
    private static volatile Configuration instance;
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private final String feeder;
    private final String site;
    
    JTable table;
    CustomTableModel dataModel;
    TableSwingWorker worker;
    static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    final static int idx_MU                             = 0;
    final static int idx_PAST_MIDNIGHT                  = 1;
    final static int idx_UNION_FLAG                     = 2;
    final static int idx_DIFD                           = 3;
    final static int idx_THREE_HR_RULE                  = 4;
    final static int idx_USE_EC_CODE                    = 5;
    final static int idx_FUTURE_EXCEPTIONS              = 6;
    final static int idx_EXCL_PARTTIME_FROM_NIGHT_SHIFT = 7;
    final static int idx_PROJECT_NUMBER                 = 8;
    final static int idx_PROJECT_NUMBER_OVERRIDE        = 9;
    final static int idx_PROJECT_NUMBER_ADMIN           = 10;
    final static int idx_PROJECT_NUMBER_TRAINING        = 11;
    final static int idx_ACTIVITY_NUMBER_TRAINING       = 12;
    final static int idx_FRC                            = 13;
    final static int idx_LOCATION_CODE                  = 14;
    
    public synchronized static Configuration getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new Configuration(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private Configuration(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        costCentersButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    muScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",                                             // idx_MU
                Misc.centerHTML("PAST<br>MID<br>NIGHT"),          // idx_PAST_MIDNIGHT
                Misc.centerHTML("UNION<br>RULES"),                // idx_UNION_FLAG
                Misc.centerHTML("Give<br>Multi-<br>Lingual"),     // idx_DIFD
                Misc.centerHTML("West<br>3Hr<br>Rule"),           // idx_THREE_HR_RULE
                Misc.centerHTML("West<br>EC<br>Train"),           // idx_USE_EC_CODE
                Misc.centerHTML("Future<br>Exceps"),              // idx_FUTURE_EXCEPTIONS
                Misc.centerHTML("Excl<br>Parttime<br>NightDiff"), // idx_EXCL_PARTTIME_FROM_NIGHT_SHIFT
                "Proj #",                                         // idx_PROJECT_NUMBER
                Misc.centerHTML("Proj #<br>Override"),            // idx_PROJECT_NUMBER_OVERRIDE
                Misc.centerHTML("Proj #<br>Admin"),               // idx_PROJECT_NUMBER_ADMIN
                Misc.centerHTML("Proj #<br>Train"),               // idx_PROJECT_NUMBER_TRAINING
                Misc.centerHTML("Act #<br>Train"),                // idx_ACTIVITY_NUMBER_TRAINING
                "FRC",                                            // idx_FRC
                Misc.centerHTML("Loc<br>Code")                    // idx_LOCATION_CODE
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsConfiguration(getFormComponent(), feeder, site);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU"),                                                    // idx_MU
                    Misc.oracleToBoolean(rs.getObject("PAST_MIDNIGHT")),                   // idx_PAST_MIDNIGHT
                    rs.getString("UNION_FLAG"),                                            // idx_UNION_FLAG
                    Misc.oracleToBoolean(rs.getObject("DIFD")),                            // idx_DIFD
                    rs.getString("THREE_HR_RULE"),                                         // idx_THREE_HR_RULE
                    Misc.oracleToBoolean(rs.getObject("USE_EC_CODE")),                     // idx_USE_EC_CODE
                    Misc.oracleToBoolean(rs.getObject("FUTURE_EXCEPTIONS")),               // idx_FUTURE_EXCEPTIONS
                    Misc.oracleToBoolean(rs.getObject("EXCL_PARTTIME_FROM_NIGHT_SHIFT")),  // idx_EXCL_PARTTIME_FROM_NIGHT_SHIFT
                    rs.getString("PROJECT_NUMBER"),                                        // idx_PROJECT_NUMBER
                    rs.getString("PROJECT_NUMBER_OVERRIDE"),                               // idx_PROJECT_NUMBER_OVERRIDE
                    rs.getString("PROJECT_NUMBER_ADMIN"),                                  // idx_PROJECT_NUMBER_ADMIN
                    rs.getString("PROJECT_NUMBER_TRAINING"),                               // idx_PROJECT_NUMBER_TRAINING
                    rs.getString("ACTIVITY_NUMBER_TRAINING"),                              // idx_ACTIVITY_NUMBER_TRAINING
                    rs.getString("FRC"),                                                   // idx_FRC
                    rs.getString("LOCATION_CODE")                                          // idx_LOCATION_CODE
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Configuration data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                muScrollPane.setViewportView(table);
            }
            refreshTableLock.release();
            if (cancelled)
            {
                closeForm();
            }
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_PAST_MIDNIGHT:
                        case idx_DIFD:
                        case idx_USE_EC_CODE:
                        case idx_FUTURE_EXCEPTIONS:
                        case idx_EXCL_PARTTIME_FROM_NIGHT_SHIFT:
                            return Boolean.class;
                        case idx_MU:
                        case idx_UNION_FLAG:
                        case idx_THREE_HR_RULE:
                        case idx_PROJECT_NUMBER:
                        case idx_PROJECT_NUMBER_OVERRIDE:
                        case idx_PROJECT_NUMBER_ADMIN:
                        case idx_PROJECT_NUMBER_TRAINING:
                        case idx_ACTIVITY_NUMBER_TRAINING:
                        case idx_FRC:
                        case idx_LOCATION_CODE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, true, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_MU, 40);
            Misc.setColumnSettings(table, idx_PAST_MIDNIGHT, 50, false);
            Misc.setColumnSettings(table, idx_UNION_FLAG, 100);
            Misc.setColumnSettings(table, idx_DIFD, 60, false);
            Misc.setColumnSettings(table, idx_THREE_HR_RULE, 60);
            Misc.setColumnSettings(table, idx_USE_EC_CODE, 60, false);
            Misc.setColumnSettings(table, idx_FUTURE_EXCEPTIONS, 60, false);
            Misc.setColumnSettings(table, idx_EXCL_PARTTIME_FROM_NIGHT_SHIFT, 60, false);
            Misc.setColumnSettings(table, idx_PROJECT_NUMBER, 70);
            Misc.setColumnSettings(table, idx_PROJECT_NUMBER_OVERRIDE, 70);
            Misc.setColumnSettings(table, idx_PROJECT_NUMBER_ADMIN, 70);
            Misc.setColumnSettings(table, idx_PROJECT_NUMBER_TRAINING, 70);
            Misc.setColumnSettings(table, idx_ACTIVITY_NUMBER_TRAINING, 70);
            Misc.setColumnSettings(table, idx_FRC, 70);
            Misc.setColumnSettings(table, idx_LOCATION_CODE, 70);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        configurationPanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        subTitleLabel = new javax.swing.JLabel();
        muScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        footerPanel = new javax.swing.JPanel();
        printButton = new javax.swing.JButton();
        costCentersButton = new javax.swing.JButton();
        userInfoButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Configuration");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(1016, 639));
        setPreferredSize(new java.awt.Dimension(1016, 639));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0);
        flowLayout1.setAlignOnBaseline(true);
        getContentPane().setLayout(flowLayout1);

        configurationPanel.setBackground(new java.awt.Color(120, 200, 200));
        configurationPanel.setMinimumSize(new java.awt.Dimension(1000, 600));
        configurationPanel.setPreferredSize(new java.awt.Dimension(1000, 600));
        configurationPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        configurationPanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        headerPanel.setBackground(new java.awt.Color(120, 200, 200));
        java.awt.FlowLayout flowLayout2 = new java.awt.FlowLayout();
        flowLayout2.setAlignOnBaseline(true);
        headerPanel.setLayout(flowLayout2);

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("MU Configurations and Password Changes");
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, -1));

        subTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subTitleLabel.setText("NOTE: Email TVI Support for Questions on Changes on these Configurations");
        titlePanel.add(subTitleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 540, -1));

        headerPanel.add(titlePanel);

        configurationPanel.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 100));

        muScrollPane.setAlignmentX(0.0F);
        muScrollPane.setAlignmentY(0.0F);

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        muScrollPane.setViewportView(loadingLabel);

        configurationPanel.add(muScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1000, 440));

        footerPanel.setBackground(new java.awt.Color(120, 200, 200));
        footerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 25, 5));

        printButton.setBackground(new java.awt.Color(120, 200, 200));
        printButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        printButton.setText("Print");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        footerPanel.add(printButton);

        costCentersButton.setBackground(new java.awt.Color(120, 200, 200));
        costCentersButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        costCentersButton.setText("Cost Centers");
        costCentersButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                costCentersButtonActionPerformed(evt);
            }
        });
        footerPanel.add(costCentersButton);

        userInfoButton.setBackground(new java.awt.Color(120, 200, 200));
        userInfoButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        userInfoButton.setText("Update User Information ");
        userInfoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userInfoButtonActionPerformed(evt);
            }
        });
        footerPanel.add(userInfoButton);

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        footerPanel.add(exitButton);

        configurationPanel.add(footerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 550, 1000, -1));

        getContentPane().add(configurationPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", "MU Configurations");
    }//GEN-LAST:event_printButtonActionPerformed
    
    private void costCentersButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_costCentersButtonActionPerformed
        CostCenterList.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_costCentersButtonActionPerformed
        
    private void userInfoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userInfoButtonActionPerformed
        UpdateUserInfo.getInstance(getFormComponent());
    }//GEN-LAST:event_userInfoButtonActionPerformed
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel configurationPanel;
    private javax.swing.JButton costCentersButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JPanel footerPanel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JScrollPane muScrollPane;
    private javax.swing.JButton printButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subTitleLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JButton userInfoButton;
    // End of variables declaration//GEN-END:variables
}
