package tvicore.dao;

public class DwsRecord
{
    private String DWS;
    private String HRS_PER_DAY;
    private boolean DIFF_NIGHT;
    private boolean CARFARE;
    private boolean DIFF_15_PERCENT;
    private boolean DIFF_NON_PENSION;
    private boolean DIFF_060;
    private boolean DIFF_150;
    private boolean DIFF_185;
    private boolean DIFF_200;
    private boolean DIFF_220;
    private boolean DIFF_250;
    private boolean DIFF_270;
    private boolean DIFF_300;
    private boolean DIFF_400;
    private boolean DIFF_500;
    private boolean DIFF_900;
    private boolean DIFF_600;
    private boolean DIFF_800;
    private boolean DIFF_1_PERCENT;
    private boolean DIFF_1_5_PERCENT;
    private boolean DIFF_2_PERCENT;
    private boolean DIFF_2_5_PERCENT;
    private boolean DIFF_3_PERCENT;
    private boolean GAP;
    private String UNION_FLAG;
    
    public DwsRecord(String DWS,
                     String HRS_PER_DAY,
                     boolean DIFF_NIGHT,
                     boolean CARFARE,
                     boolean DIFF_15_PERCENT,
                     boolean DIFF_NON_PENSION,
                     boolean DIFF_060,
                     boolean DIFF_150,
                     boolean DIFF_185,
                     boolean DIFF_200,
                     boolean DIFF_220,
                     boolean DIFF_250,
                     boolean DIFF_270,
                     boolean DIFF_300,
                     boolean DIFF_400,
                     boolean DIFF_500,
                     boolean DIFF_900,
                     boolean DIFF_600,
                     boolean DIFF_800,
                     boolean DIFF_1_PERCENT,
                     boolean DIFF_1_5_PERCENT,
                     boolean DIFF_2_PERCENT,
                     boolean DIFF_2_5_PERCENT,
                     boolean DIFF_3_PERCENT,
                     boolean GAP,
                     String UNION_FLAG)
    {
        this.DWS = DWS;
        this.HRS_PER_DAY = HRS_PER_DAY;
        this.DIFF_NIGHT = DIFF_NIGHT;
        this.CARFARE = CARFARE;
        this.DIFF_15_PERCENT = DIFF_15_PERCENT;
        this.DIFF_NON_PENSION = DIFF_NON_PENSION;
        this.DIFF_060 = DIFF_060;
        this.DIFF_150 = DIFF_150;
        this.DIFF_185 = DIFF_185;
        this.DIFF_200 = DIFF_200;
        this.DIFF_220 = DIFF_220;
        this.DIFF_250 = DIFF_250;
        this.DIFF_270 = DIFF_270;
        this.DIFF_300 = DIFF_300;
        this.DIFF_400 = DIFF_400;
        this.DIFF_500 = DIFF_500;
        this.DIFF_900 = DIFF_900;
        this.DIFF_600 = DIFF_600;
        this.DIFF_800 = DIFF_800;
        this.DIFF_1_PERCENT = DIFF_1_PERCENT;
        this.DIFF_1_5_PERCENT = DIFF_1_5_PERCENT;
        this.DIFF_2_PERCENT = DIFF_2_PERCENT;
        this.DIFF_2_5_PERCENT = DIFF_2_5_PERCENT;
        this.DIFF_3_PERCENT = DIFF_3_PERCENT;
        this.GAP = GAP;
        this.UNION_FLAG = UNION_FLAG;
    }
    
    public String getDWS()               { return DWS; }
    public String getHRS_PER_DAY()       { return HRS_PER_DAY; }
    public boolean getDIFF_NIGHT()       { return DIFF_NIGHT; }
    public boolean getCARFARE()          { return CARFARE; }
    public boolean getDIFF_15_PERCENT()  { return DIFF_15_PERCENT; }
    public boolean getDIFF_NON_PENSION() { return DIFF_NON_PENSION; }
    public boolean getDIFF_060()         { return DIFF_060; }
    public boolean getDIFF_150()         { return DIFF_150; }
    public boolean getDIFF_185()         { return DIFF_185; }
    public boolean getDIFF_200()         { return DIFF_200; }
    public boolean getDIFF_220()         { return DIFF_220; }
    public boolean getDIFF_250()         { return DIFF_250; }
    public boolean getDIFF_270()         { return DIFF_270; }
    public boolean getDIFF_300()         { return DIFF_300; }
    public boolean getDIFF_400()         { return DIFF_400; }
    public boolean getDIFF_500()         { return DIFF_500; }
    public boolean getDIFF_900()         { return DIFF_900; }
    public boolean getDIFF_600()         { return DIFF_600; }
    public boolean getDIFF_800()         { return DIFF_800; }
    public boolean getDIFF_1_PERCENT()   { return DIFF_1_PERCENT; }
    public boolean getDIFF_1_5_PERCENT() { return DIFF_1_5_PERCENT; }
    public boolean getDIFF_2_PERCENT()   { return DIFF_2_PERCENT; }
    public boolean getDIFF_2_5_PERCENT() { return DIFF_2_5_PERCENT; }
    public boolean getDIFF_3_PERCENT()   { return DIFF_3_PERCENT; }
    public boolean getGAP()              { return GAP; }
    public String getUNION_FLAG()        { return UNION_FLAG; }
    
    public void setDWS(String value)               { DWS = value; }
    public void setHRS_PER_DAY(String value)       { HRS_PER_DAY = value; }
    public void setDIFF_NIGHT(boolean value)       { DIFF_NIGHT = value; }
    public void setCARFARE(boolean value)          { CARFARE = value; }
    public void setDIFF_15_PERCENT(boolean value)  { DIFF_15_PERCENT = value; }
    public void setDIFF_NON_PENSION(boolean value) { DIFF_NON_PENSION = value; }
    public void setDIFF_060(boolean value)         { DIFF_060 = value; }
    public void setDIFF_150(boolean value)         { DIFF_150 = value; }
    public void setDIFF_185(boolean value)         { DIFF_185 = value; }
    public void setDIFF_200(boolean value)         { DIFF_200 = value; }
    public void setDIFF_220(boolean value)         { DIFF_220 = value; }
    public void setDIFF_250(boolean value)         { DIFF_250 = value; }
    public void setDIFF_270(boolean value)         { DIFF_270 = value; }
    public void setDIFF_300(boolean value)         { DIFF_300 = value; }
    public void setDIFF_400(boolean value)         { DIFF_400 = value; }
    public void setDIFF_500(boolean value)         { DIFF_500 = value; }
    public void setDIFF_900(boolean value)         { DIFF_900 = value; }
    public void setDIFF_600(boolean value)         { DIFF_600 = value; }
    public void setDIFF_800(boolean value)         { DIFF_800 = value; }
    public void setDIFF_1_PERCENT(boolean value)   { DIFF_1_PERCENT = value; }
    public void setDIFF_1_5_PERCENT(boolean value) { DIFF_1_5_PERCENT = value; }
    public void setDIFF_2_PERCENT(boolean value)   { DIFF_2_PERCENT = value; }
    public void setDIFF_2_5_PERCENT(boolean value) { DIFF_2_5_PERCENT = value; }
    public void setDIFF_3_PERCENT(boolean value)   { DIFF_3_PERCENT = value; }
    public void setGAP(boolean value)              { GAP = value; }
    public void setUNION_FLAG(String value)        { UNION_FLAG = value; }
    
    @Override
    public String toString() { return DWS; }
}