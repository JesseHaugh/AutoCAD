package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.dao.UserData;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.resources.Resources;

public final class Reconciliations extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile Reconciliations instance;
    
    private final String feeder;
    private final String site;
    private final String mu;
    private final String empid;
    private final Date startDate;
    private final Date endDate;
    private final String union;
    private final String editType;
    private ResultSetWrapper results;
    
    JTable absencesTable = new JTable();
    JTable clockTimesTable = new JTable();
    CustomTableModel absencesData;
    CustomTableModel clockTimesData;
    TableSwingWorker absencesWorker;
    TableSwingWorker clockTimesWorker;
    TableRowSorter<CustomTableModel> clockTimesSorter;
    private static final Semaphore refreshTablesLock = new Semaphore(1, true);
    
    final static int idx_MU                         = 0;
    final static int idx_REPORTING_DATE             = 1;
    final static int idx_EMPID                      = 2;
    final static int idx_EMPLOYEE                   = 3;
    final static int idx_RECKEY                     = 4;
    final static int idx_ABSENCE_CODE               = 5;
    final static int idx_MINS                       = 6;
    final static int idx_MINS_BUTTON                = 7;
    final static int idx_MINS_RECONCILED            = 8;
    final static int idx_MINS_RECONCILED_BUTTON     = 9;
    final static int idx_START_TIME                 = 10;
    final static int idx_STOP_TIME                  = 11;
    final static int idx_LOCKED_BY                  = 12;
    
    final static int idx_ClockTimes_EMPID           = 0;
    final static int idx_ClockTimes_REPORTING_DATE  = 1;
    final static int idx_ClockTimes_START_TIME      = 2;
    final static int idx_ClockTimes_STOP_TIME       = 3;
    final static int idx_ClockTimes_HOURS           = 4;
    final static int idx_ClockTimes_MINS            = 5;
    final static int idx_ClockTimes_TIME_CODE       = 6;
    
    public synchronized static Reconciliations getInstance(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String union, String editType, ResultSetWrapper results)
    {
        if (instance != null)
        {
            instance.toFront();
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new Reconciliations(feeder, site, mu, empid, startDate, endDate, union, editType, results);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private Reconciliations(String feeder, String site, String mu, String empid, Date startDate, Date endDate, String union, String editType, ResultSetWrapper results)
    {
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.empid = empid;
        this.startDate = new Date(startDate.getTime());
        this.endDate = new Date(endDate.getTime());
        this.union = union;
        this.editType = editType;
        this.results = results;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
    }
    
    public static boolean exists()
    {
        return instance != null;
    }
    
    private final Action keepAction = new AbstractAction()
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            JTable table = (JTable)e.getSource();
            if (table.isEditing())
            {
                table.getCellEditor().stopCellEditing();
            }
            int modelRow = Integer.parseInt(e.getActionCommand());
            if (table.getModel().getValueAt(modelRow, idx_LOCKED_BY) != null &&
                !table.getModel().getValueAt(modelRow, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                Misc.msgbox(getFormComponent(), "This record is locked by another user and cannot be modified at this time.", "Record locked", 1, 1, 1);
                return;
            }
            String muSelected = Misc.objectToString(table.getModel().getValueAt(modelRow, idx_MU));
            String empidSelected = Misc.objectToString(table.getModel().getValueAt(modelRow, idx_EMPID));
            Date dateSelected = (Date) table.getModel().getValueAt(modelRow, idx_REPORTING_DATE);
            int recKey = Misc.objectToInt(table.getModel().getValueAt(modelRow, idx_RECKEY));
	    
            setCursor(Constants.HOURGLASS);
            if (Oracle.setAbsenceReconciledFlag(getFormComponent(), feeder, site, muSelected, empidSelected, dateSelected, recKey, UserData.getUUID()))
            {
                ((CustomTableModel)table.getModel()).removeRow(modelRow);
            }
            setCursor(Constants.NORMAL);
        }
    };
    
    private final Action changeAction = new AbstractAction()
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            JTable table = (JTable)e.getSource();
            if (table.isEditing())
            {
                table.getCellEditor().stopCellEditing();
            }
            int modelRow = Integer.parseInt(e.getActionCommand());
            if (table.getModel().getValueAt(modelRow, idx_LOCKED_BY) != null &&
                !table.getModel().getValueAt(modelRow, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                Misc.msgbox(getFormComponent(), "This record is locked by another user and cannot be modified at this time.", "Record locked", 1, 1, 1);
                return;
            }
            String muSelected = Misc.objectToString(table.getModel().getValueAt(modelRow, idx_MU));
            String empidSelected = Misc.objectToString(table.getModel().getValueAt(modelRow, idx_EMPID));
            Date dateSelected = (Date) table.getModel().getValueAt(modelRow, idx_REPORTING_DATE);
            int recKey = Misc.objectToInt(table.getModel().getValueAt(modelRow, idx_RECKEY));
            int minsReconciled = Misc.objectToInt(table.getModel().getValueAt(modelRow, idx_MINS_RECONCILED));
	    
            setCursor(Constants.HOURGLASS);
            if (Oracle.setAbsenceReconciled(getFormComponent(), feeder, site, muSelected, empidSelected, dateSelected, recKey, minsReconciled, UserData.getUUID()))
            {
                ((CustomTableModel)table.getModel()).removeRow(modelRow);
            }
            setCursor(Constants.NORMAL);
        }
    };
    
    private void updateTableSize()
    {
        int maxWidth = 20;
        for (int i = 0; i < absencesTable.getColumnCount(); i++)
        {
            maxWidth += absencesTable.getColumnModel().getColumn(i).getPreferredWidth();
        }
        int maxHeight = absencesTable.getRowHeight() * absencesTable.getRowCount() + absencesTable.getTableHeader().getPreferredSize().height + 20;
        absencesTableScrollPane.setMaximumSize(new Dimension(maxWidth, maxHeight));
        absencesTableScrollPane.revalidate();
        revalidate();
    }
    
    private void closeForm(boolean continueToTimeReporting)
    {
        if (absencesWorker != null)
        {
            absencesWorker.cancel(true);
        }
        if (clockTimesWorker != null)
        {
            clockTimesWorker.cancel(true);
        }
        
        if (continueToTimeReporting)
        {
            if (absencesTable.getRowCount() > 0)
            {
                Misc.msgbox(getFormComponent(), "First you must finish reviewing all reconciliations.", "Reconciliations", 1, 1, 1);
                return;
            }
        }
        
        switch (editType)
        {
            case "NORMAL":
                if (!Misc.objectEquals(Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, startDate), "Imported"))
                {
                    Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, startDate, endDate, "NORMAL", UserData.getUUID());
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, startDate, endDate, "NORMAL");
                }
                break;
            case "UPDATE":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, null, null, "UPDATE", UserData.getUUID());
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, null, null, "UPDATE");
                break;
            case "DETAIL":
            case "BYEMPLOYEE":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, null, empid, startDate, endDate, "DETAIL", UserData.getUUID());
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                break;
            default:
                // do nothing
        }
        
        releaseInstance();
        dispose();
        
        if (continueToTimeReporting)
        {
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, empid, startDate, endDate, union, editType);
        }
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private void refreshData()
    {
        new Thread(new RefreshDataThread()).start();
    }
    
    private class RefreshDataThread implements Runnable
    {
        CountDownLatch latch;
        boolean finishedAbsences = false;
        boolean finishedClockTimes = false;
        
        @Override
        public void run()
        {
            if (refreshTablesLock.tryAcquire())
            {
                try
                {
                    absencesWorker = null;
                    clockTimesWorker = null;
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    absencesData = new CustomTableModel(buildColumnNamesAbsences());
                    clockTimesData = new CustomTableModel(buildColumnNamesClockTimes());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethodAbsences = this::getResultsAbsences;
                    Supplier<ResultSetWrapper> getResultsMethodClockTimes = this::getResultsClockTimes;
                    Function<ResultSet, Object[]> processResultsFuncAbsences = this::processResultsAbsences;
                    Function<ResultSet, Object[]> processResultsFuncClockTimes = this::processResultsClockTimes;
                    Consumer<Boolean> finalizeRefreshMethodAbsences = this::finalizeRefreshAbsences;
                    Consumer<Boolean> finalizeRefreshMethodClockTimes = this::finalizeRefreshClockTimes;
                    
                    // initialize a CountDownLatch with the number of workers to wait for
                    latch = new CountDownLatch(2);
                    
                    // initialize the custom swing worker
                    absencesWorker = new TableSwingWorker(getFormComponent(), absencesData, getResultsMethodAbsences, processResultsFuncAbsences, finalizeRefreshMethodAbsences, latch);
                    clockTimesWorker = new TableSwingWorker(getFormComponent(), clockTimesData, getResultsMethodClockTimes, processResultsFuncClockTimes, finalizeRefreshMethodClockTimes, latch);
                    
                    
                    
                    if (results == null && !absencesWorker.isCancelled() && !clockTimesWorker.isCancelled())
                    {
                        getResults();
                    }
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    absencesWorker.execute();
                    clockTimesWorker.execute();
                }
                finally
                {
                    if (absencesWorker == null || clockTimesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                absencesLoadingLabel.setText("ERROR");
                            }
                        });
                        refreshTablesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            // disable controls & set view during refresh
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    absencesTableScrollPane.setViewportView(absencesLoadingLabel);
                    clockTimesTableScrollPane.setViewportView(clockTimesLoadingLabel);
                    setControlsEnabled(false);
                    
                    // lock the records
                    if (!UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        if (Arrays.asList("DETAIL", "BYEMPLOYEE").contains(editType))
                        {
                            Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, null, empid, startDate, endDate, UserData.getUUID(), "DETAIL");
                            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                        }
                        else if (editType.equals("UPDATE"))
                        {
                            Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, mu, null, null, null, UserData.getUUID(), "UPDATE");
                            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, null, null, "UPDATE");
                        }
                        else if (editType.equals("NORMAL"))
                        {
                            Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, mu, null, startDate, endDate, UserData.getUUID(), "NORMAL");
                            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, startDate, endDate, "NORMAL");
                        }
                    }
                }
            });
        }
        
        /**
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesAbsences()
        {
            return new String[]
            {
                "MU",                // idx_MU
                "Date",              // idx_REPORTING_DATE
                "EMPID",             // idx_EMPID
                "Employee",          // idx_EMPLOYEE
                "",                  // idx_RECKEY
                "Absence Code",      // idx_ABSENCE_CODE
                "Mins from IEX",     // idx_MINS
                "",                  // idx_MINS_BUTTON
                "Mins Reconciled",   // idx_MINS_RECONCILED
                "",                  // idx_MINS_RECONCILED_BUTTON
                "Start Time",        // idx_START_TIME
                "Stop Time",         // idx_STOP_TIME
                "Locked By"          // idx_LOCKED_BY
            };
        }
        
        /**
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesClockTimes()
        {
            return new String[]
            {
                "",           // idx_ClockTimes_EMPID
                "",           // idx_ClockTimes_REPORTING_DATE
                "Start Time", // idx_ClockTimes_START_TIME
                "Stop Time",  // idx_ClockTimes_STOP_TIME
                "Hours",      // idx_ClockTimes_HOURS
                "Minutes",    // idx_ClockTimes_MINS
                "Time Code"   // idx_ClockTimes_TIME_CODE
            };
        }
        
        /**
        * Gets the results for all tables; the individual supplier methods will extract and send the relevant resultsets.
        * The resultsets will be closed in the TableSwingWorkers, but the CallableStatement will be closed once all workers are finished executing.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        */
        private void getResults()
        {
            results = Oracle.getResultsReconciliations(getFormComponent(), feeder, site, mu, empid, startDate, endDate, UserData.getUUID());
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the timeTotals resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsAbsences()
        {
            return new ResultSetWrapper(results.getResultSetArray()[0]);
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the timeTotals resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsClockTimes()
        {
            return new ResultSetWrapper(results.getResultSetArray()[1]);
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the absencesTable from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of absencesTable
        */
        private Object[] processResultsAbsences(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU"),                // idx_MU
                    rs.getDate("REPORTING_DATE"),      // idx_REPORTING_DATE
                    rs.getString("EMPID"),             // idx_EMPID
                    rs.getString("EMPLOYEE"),          // idx_EMPLOYEE
                    rs.getInt("RECKEY"),               // idx_RECKEY
                    rs.getString("ABSENCE_CODE"),      // idx_ABSENCE_CODE
                    rs.getInt("MINS"),                 // idx_MINS
                    "Keep",                            // idx_MINS_BUTTON
                    rs.getInt("MINS_RECONCILED"),      // idx_MINS_RECONCILED
                    "Apply",                           // idx_MINS_RECONCILED_BUTTON
                    rs.getTimestamp("START_TIME"),     // idx_START_TIME
                    rs.getTimestamp("STOP_TIME"),      // idx_STOP_TIME
                    rs.getString("LOCKED_BY")          // idx_LOCKED_BY
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading reconciliations absences data.");
                absencesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the clockTimesTable from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of clockTimesTable
        */
        private Object[] processResultsClockTimes(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("ATTUID"),                              // idx_ClockTimes_EMPID
                    rs.getDate("WORK_DATE"),                             // idx_ClockTimes_REPORTING_DATE
                    Misc.timestampToDate(rs.getTimestamp("START_TIME")), // idx_ClockTimes_START_TIME
                    Misc.timestampToDate(rs.getTimestamp("END_TIME")),   // idx_ClockTimes_STOP_TIME
                    rs.getBigDecimal("HOURS"),                           // idx_ClockTimes_HOURS
                    rs.getInt("MINS"),                                   // idx_ClockTimes_MINS
                    rs.getString("TIME_CODE")                            // idx_ClockTimes_TIME_CODE
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading reconciliations clock times data.");
                clockTimesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshAbsences(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createAbsencesTable();
                configureAbsencesTable();
            }
            
            finishedAbsences = true;
            if (finishedAbsences && finishedClockTimes)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshClockTimes(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createClockTimesTable();
                configureClockTimesTable();
            }
            
            finishedClockTimes = true;
            if (finishedAbsences && finishedClockTimes)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * Called once all table workers are finished executing.
        * This closes the callable statement and releases the semaphore lock.
        * 
        * Once this code is executed, if not cancelled, the tables are finished and displayed, ready for the user.
        */
        private void finalizeRefresh()
        {
            try
            {
                // wait for all of the workers to properly finish and release their latches
                latch.await();
                if (results != null)
                {
                    results.close();
                }
            }
            catch (InterruptedException ex) { }
            
            if (!absencesWorker.isCancelled() && !clockTimesWorker.isCancelled())
            {
                if (absencesTable.getRowCount() > 0)
                {
                    absencesTable.setRowSelectionInterval(0, 0);
                }
                setControlsEnabled(true);
                absencesTableScrollPane.setViewportView(absencesTable);
                clockTimesTableScrollPane.setViewportView(clockTimesTable);
            }
            refreshTablesLock.release();
        }
        
        private void createAbsencesTable()
        {
            absencesTable = new JTable(absencesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    switch (column)
                    {
                        case idx_MINS_BUTTON:
                        case idx_MINS_RECONCILED_BUTTON:
                            return true;
                        default:
                            return false;
                    }
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_RECKEY:
                        case idx_MINS:
                        case idx_MINS_RECONCILED:
                            return Integer.class;
                        case idx_REPORTING_DATE:
                        case idx_START_TIME:
                        case idx_STOP_TIME:
                            return Date.class;
                        case idx_MU:
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_ABSENCE_CODE:
                        case idx_LOCKED_BY:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (absencesTable.getValueAt(row, idx_LOCKED_BY) != null &&
                            !absencesTable.getValueAt(row, idx_LOCKED_BY).equals(UserData.getUUID()))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void createClockTimesTable()
        {
            clockTimesTable = new JTable(clockTimesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_ClockTimes_HOURS:
                            return BigDecimal.class;
                        case idx_ClockTimes_MINS:
                            return Integer.class;
                        case idx_ClockTimes_REPORTING_DATE:
                        case idx_ClockTimes_START_TIME:
                        case idx_ClockTimes_STOP_TIME:
                            return Date.class;
                        case idx_ClockTimes_EMPID:
                        case idx_ClockTimes_TIME_CODE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureAbsencesTable()
        {
            Misc.configureTable(absencesTable, true, false, false);
            Misc.setHeaderRenderer(absencesTable, true, true, null);
            Misc.setColumnSettings(absencesTable, idx_MU, 60);
            Misc.setColumnSettings(absencesTable, idx_REPORTING_DATE, 70);
            Misc.setColumnSettings(absencesTable, idx_EMPID, 60);
            Misc.setColumnSettings(absencesTable, idx_EMPLOYEE, 140);
            Misc.setColumnSettings(absencesTable, idx_RECKEY, 0);
            Misc.setColumnSettings(absencesTable, idx_ABSENCE_CODE, 220);
            Misc.setColumnSettings(absencesTable, idx_MINS, 115);
            Misc.setColumnHeaderRenderer(absencesTable, idx_MINS, true, true, Constants.LTYELLOW);
            Misc.addButtonToTable(absencesTable, keepAction, idx_MINS_BUTTON);
            Misc.setColumnHeaderRenderer(absencesTable, idx_MINS_BUTTON, true, true, Constants.LTYELLOW);
            Misc.setColumnSettings(absencesTable, idx_MINS_RECONCILED, 115);
            Misc.setColumnHeaderRenderer(absencesTable, idx_MINS_RECONCILED, true, true, Constants.LTGREEN);
            Misc.addButtonToTable(absencesTable, changeAction, idx_MINS_RECONCILED_BUTTON);
            Misc.setColumnHeaderRenderer(absencesTable, idx_MINS_RECONCILED_BUTTON, true, true, Constants.LTGREEN);
            Misc.setColumnSettings(absencesTable, idx_START_TIME, 80, "hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(absencesTable, idx_STOP_TIME, 80, "hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(absencesTable, idx_LOCKED_BY, 70);
            absencesTable.setRowHeight(25);
            updateTableSize();
            
            absencesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = absencesTable.getSelectedRow();
                        if (selectedRow != -1)
                        {
                            processFilter();
                        }
                    }
                }
            });
        }
        
        private void configureClockTimesTable()
        {
            Misc.configureTable(clockTimesTable, true, true, false);
            
            clockTimesSorter = new TableRowSorter<>(clockTimesData);
            clockTimesTable.setRowSorter(clockTimesSorter);
            
            Misc.setHeaderRenderer(clockTimesTable, true, true, null);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_EMPID, 0);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_REPORTING_DATE, 0);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_START_TIME, 100, "hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_STOP_TIME, 100, "hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_HOURS, 75);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_MINS, 75);
            Misc.setColumnSettings(clockTimesTable, idx_ClockTimes_TIME_CODE, 120);
            clockTimesTable.setRowHeight(25);
        }
    }
    
    private void processFilter()
    {
        if (clockTimesTable == null || !clockTimesWorker.isDone())
        {
            return;
        }
        
        String empidFilterText = Misc.objectToString(absencesTable.getValueAt(absencesTable.getSelectedRow(), idx_EMPID));
        String reportingDateFilterText = Misc.objectToString(absencesTable.getValueAt(absencesTable.getSelectedRow(), idx_REPORTING_DATE));
        
        // Clock Times Filtering
        List<RowFilter<CustomTableModel, Object>> filtersClockTimes = new ArrayList<>();
        RowFilter<CustomTableModel, Object> empidFilterClockTimes = RowFilter.regexFilter(empidFilterText, idx_ClockTimes_EMPID);
        RowFilter<CustomTableModel, Object> reportingDateFilterClockTimes = RowFilter.regexFilter(reportingDateFilterText, idx_ClockTimes_REPORTING_DATE);
        filtersClockTimes.add(empidFilterClockTimes);
        filtersClockTimes.add(reportingDateFilterClockTimes);
        if (clockTimesSorter != null)
        {
            clockTimesSorter.setRowFilter(RowFilter.andFilter(filtersClockTimes));
        }
    }
    
    private void setControlsEnabled(final boolean enabled)
    {
        absencesTable.setEnabled(enabled);
        keepCurrentButton.setEnabled(enabled);
        applyReconciliationsButton.setEnabled(enabled);
        continueButton.setEnabled(enabled);
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titlePanel = new javax.swing.JPanel();
        nameLabel = new javax.swing.JLabel();
        detailPanel = new javax.swing.JPanel();
        clockTimesPanel = new javax.swing.JPanel();
        clockTimesLabel = new javax.swing.JLabel();
        clockTimesTableScrollPane = new javax.swing.JScrollPane();
        clockTimesLoadingLabel = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();
        centerPanel = new javax.swing.JPanel();
        absencesTableScrollPane = new javax.swing.JScrollPane();
        absencesLoadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        functionButtons = new javax.swing.JPanel();
        keepPanel = new javax.swing.JPanel();
        keepCurrentButton = new javax.swing.JButton();
        changePanel = new javax.swing.JPanel();
        applyReconciliationsButton = new javax.swing.JButton();
        exitButtons = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();
        continueButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Reconciliations");
        setMinimumSize(new java.awt.Dimension(1020, 600));
        setPreferredSize(new java.awt.Dimension(1020, 700));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setMinimumSize(new java.awt.Dimension(100, 40));
        titlePanel.setPreferredSize(new java.awt.Dimension(100, 240));

        nameLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        nameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nameLabel.setText("Reconciliations");
        nameLabel.setToolTipText("");
        nameLabel.setPreferredSize(new java.awt.Dimension(1060, 30));
        titlePanel.add(nameLabel);

        detailPanel.setBackground(new java.awt.Color(120, 200, 200));
        detailPanel.setMinimumSize(new java.awt.Dimension(1060, 200));
        detailPanel.setPreferredSize(new java.awt.Dimension(1060, 200));
        detailPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        clockTimesPanel.setBackground(new java.awt.Color(120, 200, 200));
        clockTimesPanel.setPreferredSize(new java.awt.Dimension(490, 200));
        clockTimesPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        clockTimesLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        clockTimesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        clockTimesLabel.setText("Clock Times from INFOR");
        clockTimesLabel.setPreferredSize(new java.awt.Dimension(490, 25));
        clockTimesPanel.add(clockTimesLabel);

        clockTimesTableScrollPane.setMaximumSize(new java.awt.Dimension(490, 1600));
        clockTimesTableScrollPane.setMinimumSize(new java.awt.Dimension(490, 200));
        clockTimesTableScrollPane.setName(""); // NOI18N
        clockTimesTableScrollPane.setPreferredSize(new java.awt.Dimension(490, 175));

        clockTimesLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        clockTimesLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        clockTimesLoadingLabel.setText("LOADING...");
        clockTimesTableScrollPane.setViewportView(clockTimesLoadingLabel);

        clockTimesPanel.add(clockTimesTableScrollPane);

        detailPanel.add(clockTimesPanel);

        refreshButton.setBackground(new java.awt.Color(120, 200, 200));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        detailPanel.add(refreshButton);

        titlePanel.add(detailPanel);

        getContentPane().add(titlePanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        absencesTableScrollPane.setMaximumSize(new java.awt.Dimension(980, 1600));
        absencesTableScrollPane.setMinimumSize(new java.awt.Dimension(980, 220));
        absencesTableScrollPane.setName(""); // NOI18N
        absencesTableScrollPane.setPreferredSize(new java.awt.Dimension(980, 220));

        absencesLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        absencesLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        absencesLoadingLabel.setText("LOADING...");
        absencesTableScrollPane.setViewportView(absencesLoadingLabel);

        centerPanel.add(absencesTableScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(1060, 160));
        bottomPanel.setPreferredSize(new java.awt.Dimension(1060, 160));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        functionButtons.setBackground(new java.awt.Color(120, 200, 200));
        functionButtons.setPreferredSize(new java.awt.Dimension(1060, 70));
        functionButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 10));

        keepPanel.setBackground(new java.awt.Color(255, 255, 200));
        keepPanel.setPreferredSize(new java.awt.Dimension(220, 60));
        keepPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 10));

        keepCurrentButton.setBackground(new java.awt.Color(255, 255, 200));
        keepCurrentButton.setText("Keep ALL IEX Minutes");
        keepCurrentButton.setPreferredSize(new java.awt.Dimension(180, 40));
        keepCurrentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keepCurrentButtonActionPerformed(evt);
            }
        });
        keepPanel.add(keepCurrentButton);

        functionButtons.add(keepPanel);

        changePanel.setBackground(new java.awt.Color(200, 255, 200));
        changePanel.setPreferredSize(new java.awt.Dimension(220, 60));
        changePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 10));

        applyReconciliationsButton.setBackground(new java.awt.Color(200, 255, 200));
        applyReconciliationsButton.setText("Apply ALL Reconciliations");
        applyReconciliationsButton.setPreferredSize(new java.awt.Dimension(180, 40));
        applyReconciliationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyReconciliationsButtonActionPerformed(evt);
            }
        });
        changePanel.add(applyReconciliationsButton);

        functionButtons.add(changePanel);

        bottomPanel.add(functionButtons);

        exitButtons.setBackground(new java.awt.Color(120, 200, 200));
        exitButtons.setPreferredSize(new java.awt.Dimension(1060, 100));
        exitButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 10));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Cancel / Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(220, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitButtons.add(exitButton);

        continueButton.setBackground(new java.awt.Color(120, 200, 200));
        continueButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        continueButton.setText("Continue to Time Reporting");
        continueButton.setPreferredSize(new java.awt.Dimension(220, 60));
        continueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                continueButtonActionPerformed(evt);
            }
        });
        exitButtons.add(continueButton);

        bottomPanel.add(exitButtons);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void continueButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_continueButtonActionPerformed
        closeForm(true);
    }//GEN-LAST:event_continueButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm(false);
    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm(false);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void keepCurrentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keepCurrentButtonActionPerformed
        setControlsEnabled(false);
        setCursor(Constants.HOURGLASS);
        for (int i = absencesTable.getRowCount() - 1; i >= 0; i--)
        {
            if (absencesTable.getValueAt(i, idx_LOCKED_BY) == null ||
                absencesTable.getValueAt(i, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                String currentMu = Misc.objectToString(absencesTable.getModel().getValueAt(i, idx_MU));
                String currentEmpid = Misc.objectToString(absencesTable.getValueAt(i, idx_EMPID));
                Date currentDate = (Date) absencesTable.getValueAt(i, idx_REPORTING_DATE);
                int currentRecKey = Misc.objectToInt(absencesTable.getValueAt(i, idx_RECKEY));
                if (Oracle.setAbsenceReconciledFlag(getFormComponent(), feeder, site, currentMu, currentEmpid, currentDate, currentRecKey, UserData.getUUID()))
                {
                    ((CustomTableModel)absencesTable.getModel()).removeRow(i);
                }
            }
        }
        updateTableSize();
        setCursor(Constants.NORMAL);
        setControlsEnabled(true);
        if (absencesTable.getRowCount() == 0)
        {
            closeForm(true);
        }
    }//GEN-LAST:event_keepCurrentButtonActionPerformed

    private void applyReconciliationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyReconciliationsButtonActionPerformed
        setControlsEnabled(false);
        setCursor(Constants.HOURGLASS);
        for (int i = absencesTable.getRowCount() - 1; i >= 0; i--)
        {
            if (absencesTable.getValueAt(i, idx_LOCKED_BY) == null ||
                absencesTable.getValueAt(i, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                String currentMu = Misc.objectToString(absencesTable.getModel().getValueAt(i, idx_MU));
                String currentEmpid = Misc.objectToString(absencesTable.getValueAt(i, idx_EMPID));
                Date currentDate = (Date) absencesTable.getValueAt(i, idx_REPORTING_DATE);
                int currentRecKey = Misc.objectToInt(absencesTable.getValueAt(i, idx_RECKEY));
                int currentMins = Misc.objectToInt(absencesTable.getValueAt(i, idx_MINS_RECONCILED));
                if (Oracle.setAbsenceReconciled(getFormComponent(), feeder, site, currentMu, currentEmpid, currentDate, currentRecKey, currentMins, UserData.getUUID()))
                {
                    ((CustomTableModel)absencesTable.getModel()).removeRow(i);
                }
            }
        }
        updateTableSize();
        setCursor(Constants.NORMAL);
        setControlsEnabled(true);
        if (absencesTable.getRowCount() == 0)
        {
            closeForm(true);
        }
    }//GEN-LAST:event_applyReconciliationsButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        results = null;
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel absencesLoadingLabel;
    private javax.swing.JScrollPane absencesTableScrollPane;
    private javax.swing.JButton applyReconciliationsButton;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JPanel changePanel;
    private javax.swing.JLabel clockTimesLabel;
    private javax.swing.JLabel clockTimesLoadingLabel;
    private javax.swing.JPanel clockTimesPanel;
    private javax.swing.JScrollPane clockTimesTableScrollPane;
    private javax.swing.JButton continueButton;
    private javax.swing.JPanel detailPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitButtons;
    private javax.swing.JPanel functionButtons;
    private javax.swing.JButton keepCurrentButton;
    private javax.swing.JPanel keepPanel;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JButton refreshButton;
    private javax.swing.JPanel titlePanel;
    // End of variables declaration//GEN-END:variables
}