package tvi.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.Semaphore;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.objects.CustomTableModel;
import tvicore.objects.TableSwingWorker;
import java.sql.SQLException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import tvi.client_main.Main;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.resources.Resources;

public final class BeginNewPayPeriod extends javax.swing.JFrame
{
    private static volatile BeginNewPayPeriod instance;
    
    private static final Semaphore refreshBeginNewPayPeriodLock = new Semaphore(1, true);
    
    private final static boolean MAXIMIZE_DEFAULT = false;
    private final String feeder;
    private final String site;
    private final Date payStartDate;
    private final Date payClose;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    public static final Semaphore reimportFutureSchedulesLock = new Semaphore(1, true);
    
    final static int idx_MU                  = 0;
    final static int idx_REPORTING_DATE      = 1;
    final static int idx_STATUS              = 2;
    
    public synchronized static BeginNewPayPeriod getInstance(Component parentFrame, String feeder, String site, Date payStartDate, Date payClose)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new BeginNewPayPeriod(feeder, site, payStartDate, payClose);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private BeginNewPayPeriod(String feeder, String site,  Date payStartDate, Date payClose)
    {
        this.feeder = feeder;
        this.site = site;
        this.payStartDate = payStartDate;
        this.payClose = payClose;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        powerUserOverrideButton.setVisible(UserData.getUserType().equals("POWER"));
        
        computePremiumButton.setVisible(feeder.equals("STI") && RegionData.getNightDiff());
        compute3DayRuleButton.setVisible(Oracle.does3DayRule(getFormComponent(), feeder, site));
        
        computeReliefDifferentialButton.setVisible(Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()));
        validateAllocationsButton.setVisible(Oracle.doesCostAllocation(getFormComponent(), feeder, site, null));
        
        if (Oracle.checkFutureSchedulesUpdated(getFormComponent(), feeder, site, payStartDate, payClose))
        {
            readySchedulesPane.setVisible(false);
            reimportFutureSchedulesButton.setVisible(false);
            schedulePanel.setVisible(false);
        }
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingReadyLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    readySchedulesPane.setViewportView(loadingReadyLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",         // idx_MU
                "Date",       // idx_REPORTING_DATE
                "Status"      // idx_STATUS
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getFutureScheduleList(getFormComponent(), feeder, site, payStartDate, payClose);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU"),            // idx_MU
                    rs.getDate("REPORTING_DATE"),  // idx_REPORTING_DATE
                    rs.getString("STATUS")         // idx_STATUS
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading future schedules.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                readySchedulesPane.setViewportView(table);
                if (table.getRowCount() > 0)
                {
                    table.changeSelection(0, 0, false, false);
                }
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:   
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, false, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_MU, 50);
            Misc.setColumnSettings(table, idx_REPORTING_DATE, 75);
            Misc.setColumnSettings(table, idx_STATUS, 75);
            table.setRowHeight(20);
            table.setFocusable(false);
        }
    }
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        if (table != null && table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        payrollPeriodLabel = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();
        noteScrollPane = new javax.swing.JScrollPane();
        noteTextArea = new javax.swing.JTextArea();
        centerPanel = new javax.swing.JPanel();
        schedulePanel = new javax.swing.JPanel();
        titleLabel1 = new javax.swing.JLabel();
        readySchedulesPane = new javax.swing.JScrollPane();
        loadingReadyLabel = new javax.swing.JLabel();
        buttonPanel = new javax.swing.JPanel();
        validateAllocationsButton = new javax.swing.JButton();
        computePremiumButton = new javax.swing.JButton();
        compute3DayRuleButton = new javax.swing.JButton();
        computeReliefDifferentialButton = new javax.swing.JButton();
        reimportFutureSchedulesButton = new javax.swing.JButton();
        exitPanel = new javax.swing.JPanel();
        beginNewPayPeriodButton = new javax.swing.JButton();
        powerUserOverrideButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Begin New Pay Period");
        setMinimumSize(new java.awt.Dimension(600, 630));
        setPreferredSize(new java.awt.Dimension(720, 460));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(100, 110));
        topPanel.setPreferredSize(new java.awt.Dimension(100, 160));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 15));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setPreferredSize(new java.awt.Dimension(600, 40));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setMinimumSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Begin New Payroll Period");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 5, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setMaximumSize(new java.awt.Dimension(107, 23));
        exitButton.setMinimumSize(new java.awt.Dimension(107, 23));
        exitButton.setPreferredSize(new java.awt.Dimension(107, 23));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 10, -1, -1));

        topPanel.add(titlePanel);

        payrollPeriodLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        payrollPeriodLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        payrollPeriodLabel.setText("Current Payroll Period Ends:");
        payrollPeriodLabel.setPreferredSize(new java.awt.Dimension(290, 30));
        topPanel.add(payrollPeriodLabel);

        refreshButton.setBackground(new java.awt.Color(120, 200, 200));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        topPanel.add(refreshButton);

        noteScrollPane.setBorder(null);
        noteScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        noteScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        noteScrollPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        noteScrollPane.setPreferredSize(new java.awt.Dimension(400, 40));

        noteTextArea.setEditable(false);
        noteTextArea.setBackground(new java.awt.Color(120, 200, 200));
        noteTextArea.setColumns(20);
        noteTextArea.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        noteTextArea.setRows(2);
        noteTextArea.setTabSize(4);
        noteTextArea.setText("Unchecked items below require attention.\nYou may begin the new pay period once all items are checked.");
        noteTextArea.setMinimumSize(new java.awt.Dimension(400, 30));
        noteScrollPane.setViewportView(noteTextArea);

        topPanel.add(noteScrollPane);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(485, 200));
        centerPanel.setPreferredSize(new java.awt.Dimension(720, 200));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 10));

        schedulePanel.setBackground(new java.awt.Color(120, 200, 200));
        schedulePanel.setMinimumSize(new java.awt.Dimension(600, 280));
        schedulePanel.setPreferredSize(new java.awt.Dimension(230, 320));
        schedulePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        titleLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        titleLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel1.setText("Future Schedules to Reimport");
        titleLabel1.setToolTipText("");
        titleLabel1.setPreferredSize(new java.awt.Dimension(400, 30));
        schedulePanel.add(titleLabel1);

        readySchedulesPane.setPreferredSize(new java.awt.Dimension(200, 260));

        loadingReadyLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingReadyLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingReadyLabel.setText("LOADING...");
        readySchedulesPane.setViewportView(loadingReadyLabel);

        schedulePanel.add(readySchedulesPane);

        centerPanel.add(schedulePanel);

        buttonPanel.setBackground(new java.awt.Color(120, 200, 200));
        buttonPanel.setMinimumSize(new java.awt.Dimension(600, 280));
        buttonPanel.setPreferredSize(new java.awt.Dimension(420, 320));
        buttonPanel.setRequestFocusEnabled(false);
        buttonPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        validateAllocationsButton.setBackground(new java.awt.Color(120, 200, 200));
        validateAllocationsButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        validateAllocationsButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tvicore/resources/checkbox_unchecked_60px.png"))); // NOI18N
        validateAllocationsButton.setText("Validate Allocations");
        validateAllocationsButton.setEnabled(false);
        validateAllocationsButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        validateAllocationsButton.setIconTextGap(10);
        validateAllocationsButton.setPreferredSize(new java.awt.Dimension(400, 75));
        validateAllocationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                validateAllocationsButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(validateAllocationsButton);

        computePremiumButton.setBackground(new java.awt.Color(120, 200, 200));
        computePremiumButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        computePremiumButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tvicore/resources/checkbox_unchecked_60px.png"))); // NOI18N
        computePremiumButton.setText("Compute Night Diff Future Exceptions");
        computePremiumButton.setEnabled(false);
        computePremiumButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        computePremiumButton.setIconTextGap(10);
        computePremiumButton.setPreferredSize(new java.awt.Dimension(400, 75));
        computePremiumButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                computePremiumButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(computePremiumButton);

        compute3DayRuleButton.setBackground(new java.awt.Color(120, 200, 200));
        compute3DayRuleButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        compute3DayRuleButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tvicore/resources/checkbox_unchecked_60px.png"))); // NOI18N
        compute3DayRuleButton.setText("Compute 3 Day Rule");
        compute3DayRuleButton.setEnabled(false);
        compute3DayRuleButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        compute3DayRuleButton.setIconTextGap(10);
        compute3DayRuleButton.setPreferredSize(new java.awt.Dimension(400, 75));
        compute3DayRuleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compute3DayRuleButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(compute3DayRuleButton);

        computeReliefDifferentialButton.setBackground(new java.awt.Color(120, 200, 200));
        computeReliefDifferentialButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        computeReliefDifferentialButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tvicore/resources/checkbox_unchecked_60px.png"))); // NOI18N
        computeReliefDifferentialButton.setText("Compute Relief Differential");
        computeReliefDifferentialButton.setEnabled(false);
        computeReliefDifferentialButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        computeReliefDifferentialButton.setIconTextGap(10);
        computeReliefDifferentialButton.setPreferredSize(new java.awt.Dimension(400, 75));
        computeReliefDifferentialButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                computeReliefDifferentialButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(computeReliefDifferentialButton);

        reimportFutureSchedulesButton.setBackground(new java.awt.Color(120, 200, 200));
        reimportFutureSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        reimportFutureSchedulesButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tvicore/resources/checkbox_unchecked_60px.png"))); // NOI18N
        reimportFutureSchedulesButton.setText("Reimport All Future Schedules");
        reimportFutureSchedulesButton.setEnabled(false);
        reimportFutureSchedulesButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        reimportFutureSchedulesButton.setIconTextGap(10);
        reimportFutureSchedulesButton.setPreferredSize(new java.awt.Dimension(400, 75));
        reimportFutureSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reimportFutureSchedulesButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(reimportFutureSchedulesButton);

        centerPanel.add(buttonPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setMinimumSize(new java.awt.Dimension(100, 100));
        exitPanel.setPreferredSize(new java.awt.Dimension(100, 100));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 20));

        beginNewPayPeriodButton.setBackground(new java.awt.Color(120, 200, 200));
        beginNewPayPeriodButton.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        beginNewPayPeriodButton.setText("<html><div align='center' width='100%'>Begin New<br>Pay Period</div></html> ");
        beginNewPayPeriodButton.setPreferredSize(new java.awt.Dimension(150, 60));
        beginNewPayPeriodButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beginNewPayPeriodButtonActionPerformed(evt);
            }
        });
        exitPanel.add(beginNewPayPeriodButton);

        powerUserOverrideButton.setBackground(new java.awt.Color(120, 200, 200));
        powerUserOverrideButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        powerUserOverrideButton.setText("<html><div align='center' width='100%'>Power User<br>Manual Override</div></html>");
        powerUserOverrideButton.setPreferredSize(new java.awt.Dimension(140, 60));
        powerUserOverrideButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                powerUserOverrideButtonActionPerformed(evt);
            }
        });
        exitPanel.add(powerUserOverrideButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void beginNewPayPeriodButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beginNewPayPeriodButtonActionPerformed
        String siteLock = RegionData.getSiteLock();
        String payCycle = RegionData.getPayCycle();
        Date   payClose = RegionData.getPayClose();
        Date   hotDay   = RegionData.getHotDay();
        if (Misc.isBeginNewPayPeriodOkay(getFormComponent(), feeder, site, siteLock, payCycle, payClose, hotDay))
        {
            setCursor(Constants.HOURGLASS);
            Date nextPayClose = Oracle.getNextPayrollEndDate(getFormComponent(), payCycle, Misc.dateAddDays(Oracle.getCurTime(getFormComponent()), -1));
            if (Oracle.updatePayClose(getFormComponent(), feeder, site, nextPayClose))
            {
                RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                setCursor(Constants.NORMAL);
                Misc.msgbox(getFormComponent(), "Next Payroll Period has been started", "Begin New Payroll Period", 1, 1, 1);
                refreshData();
                Schedules.refreshInstance();
            }
            setCursor(Constants.NORMAL);
        }
    }//GEN-LAST:event_beginNewPayPeriodButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void computePremiumButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_computePremiumButtonActionPerformed
        ComputeNightDiff.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_computePremiumButtonActionPerformed

    private void powerUserOverrideButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_powerUserOverrideButtonActionPerformed
        if (!UserData.getUserType().equals("POWER"))
        {
            return;
        }
        
        setCursor(Constants.HOURGLASS);
        Date nextPayClose = Oracle.getNextPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), Misc.dateAddDays(Oracle.getCurTime(getFormComponent()), -1));
        if (Oracle.updatePayClose(getFormComponent(), feeder, site, nextPayClose))
        {
            RegionData.updateSiteInfo(getFormComponent(), feeder, site);
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Payroll Period has been updated", "Begin New Payroll Period", 1, 1, 1);
            refreshData();
            Schedules.refreshInstance();
        }
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_powerUserOverrideButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void validateAllocationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_validateAllocationsButtonActionPerformed
        new Thread(new validateAllocationThread()).start();
    }//GEN-LAST:event_validateAllocationsButtonActionPerformed

    private void compute3DayRuleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compute3DayRuleButtonActionPerformed
        Compute3DayRule.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_compute3DayRuleButtonActionPerformed

    private void computeReliefDifferentialButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_computeReliefDifferentialButtonActionPerformed
        ComputeReliefDifferential.getInstance(getFormComponent(), feeder, site, UserData.getUUID());
    }//GEN-LAST:event_computeReliefDifferentialButtonActionPerformed

    private void reimportFutureSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reimportFutureSchedulesButtonActionPerformed
        new Thread(new reimportFutureSchedulesThread()).start();
    }//GEN-LAST:event_reimportFutureSchedulesButtonActionPerformed
    
    public static void refreshInstance()
    {
        if (instance != null)
        {
            instance.refreshData();
        }
    }
    
    private void refreshData()
    {
        new Thread(new RefreshPayCloseThread()).start();
        new Thread(new RefreshTableThread()).start();
    }
    
    private class validateAllocationThread implements Runnable
    {
        @Override
        public void run()
        {
            if (Misc.validateAllocationsLock.tryAcquire())
            {
                try
                {
                    CustomTableModel errorData = Misc.validateAllocations(getFormComponent(), feeder, site);
                    
                    if (errorData != null)
                    {
                        ValidationErrors.getInstance(getFormComponent(), feeder, site, errorData);
                    }
                    
                    validateAllocationsButton.setEnabled(Oracle.checkPendingAllocation(getFormComponent(), feeder, site));
                }
                finally
                {
                    Misc.validateAllocationsLock.release();
                    refreshData();
                    Schedules.refreshInstance();
                }
            }
        }
    }
    
    private class reimportFutureSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (reimportFutureSchedulesLock.tryAcquire())
            {
                try
                {
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    int numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
                    if (Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site))
                    {
                        if (numberOfRosterRequesting > 0 && RegionData.getNewFeature())
                        {
                            setCursor(Constants.NORMAL);
                            Misc.msgbox(getFormComponent(), "Cannot import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
                        }
                        else if (Oracle.getNumLockedFutureSchedules(getFormComponent(), feeder, site, payStartDate, payClose) > 0)
                        {
                            setCursor(Constants.NORMAL);
                            Misc.msgbox(getFormComponent(), "Cannot import while at least one schedule is locked.", "Import Schedules", 1, 1, 1); 
                        }
                        else
                        {
                            Oracle.requestFutureSchedule(getFormComponent(), feeder, site, payStartDate, payClose, UserData.getUUID());
                        }
                    }
                }
                finally
                {
                    reimportFutureSchedulesLock.release();
                    refreshData();
                    Schedules.refreshInstance();
                }
            }
        }
    }
    
    private class RefreshPayCloseThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshBeginNewPayPeriodLock.tryAcquire())
            {
                try
                {
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            setCursor(Constants.HOURGLASS);
                        }
                    });
                    
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    if (Oracle.getCurTimeLocal(getFormComponent()).compareTo(RegionData.getHotDay()) < 0)
                    {
                        closeForm(); //the payroll period has been moved forward to the current, close the form.
                        return;
                    }
                    
                    // Compute Premium
                    Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
                    boolean premiumComputed;
                    switch (feeder)
                    {
                        case "STI":
                            premiumComputed = Oracle.checkFutureExceptions(getFormComponent(), feeder, site, payStartDate, RegionData.getPayClose());
                            break;
                        default:
                            premiumComputed = true;
                    }
                    
                    // Compute 3 Day Rule
                    boolean threeDayRuleComputed;
                    if (Oracle.does3DayRule(getFormComponent(), feeder, site))
                    {
                        threeDayRuleComputed = Oracle.check3DayRule(getFormComponent(), feeder, site, payStartDate, RegionData.getPayClose());
                    }
                    else
                    {
                        threeDayRuleComputed = true;
                    }
                    
                    // Compute Relief Differential
                    boolean reliefDifferentialComputed;
                    if (Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()))
                    {
                        reliefDifferentialComputed = Oracle.checkReliefDifferential(getFormComponent(), feeder, site, payStartDate, RegionData.getPayClose());
                    }
                    else
                    {
                        reliefDifferentialComputed = true;
                    }
                    
                    // Compute 3 Day Rule
                    boolean futureSchedulesReimported;
                    if (Oracle.checkFutureSchedulesUpdated(getFormComponent(), feeder, site, payStartDate, payClose))
                    {
                        futureSchedulesReimported = true;
                    }
                    else
                    {
                        futureSchedulesReimported = false;
                    }   

                    // Validate Allocations
                    boolean allocationsValidated;
                    if (validateAllocationsButton.isVisible())
                    {
                        Date lastValidated = Oracle.getCFASButtonDate(getFormComponent(), feeder, site);
                        allocationsValidated = lastValidated != null && lastValidated.compareTo(payStartDate) >= 0;
                    }
                    else
                    {
                        allocationsValidated = true;                        
                    }
                    
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            // refresh pay period label
                            payrollPeriodLabel.setText("Current Payroll Period Ends: " + Misc.dateToStringMDY(RegionData.getPayClose()));
                            
                            // refresh computeNightDiff button
                            if (computePremiumButton.isVisible())
                            {
                                computePremiumButton.setEnabled(!premiumComputed);
                                if (premiumComputed)
                                {
                                    computePremiumButton.setIcon(Resources.getIconChecked60());
                                }
                                else
                                {
                                    computePremiumButton.setIcon(Resources.getIconUnchecked60());
                                }
                            }
                            
                            // refresh compute3DayRule button
                            if (compute3DayRuleButton.isVisible())
                            {
                                compute3DayRuleButton.setEnabled(!threeDayRuleComputed);
                                if (threeDayRuleComputed)
                                {
                                    compute3DayRuleButton.setIcon(Resources.getIconChecked60());
                                }
                                else
                                {
                                    compute3DayRuleButton.setIcon(Resources.getIconUnchecked60());
                                }
                            }
                            
                            // refresh computeReliefDifferential button
                            if (computeReliefDifferentialButton.isVisible())
                            {
                                computeReliefDifferentialButton.setEnabled(!reliefDifferentialComputed);
                                if (reliefDifferentialComputed)
                                {
                                    computeReliefDifferentialButton.setIcon(Resources.getIconChecked60());
                                }
                                else
                                {
                                    computeReliefDifferentialButton.setIcon(Resources.getIconUnchecked60());
                                }
                            }
                            
                            // refresh validateAllocationsButton
                            if (validateAllocationsButton.isVisible())
                            {
                                validateAllocationsButton.setEnabled(!allocationsValidated);
                                if (allocationsValidated)
                                {
                                    validateAllocationsButton.setIcon(Resources.getIconChecked60());
                                }
                                else
                                {
                                    validateAllocationsButton.setIcon(Resources.getIconUnchecked60());
                                }
                            }
                            // refresh reimportFutureSchedulesButton
                            if (reimportFutureSchedulesButton.isVisible())
                            {
                                reimportFutureSchedulesButton.setEnabled(!futureSchedulesReimported);
                                if (futureSchedulesReimported)
                                {
                                    reimportFutureSchedulesButton.setIcon(Resources.getIconChecked60());
                                }
                                else
                                {
                                    reimportFutureSchedulesButton.setIcon(Resources.getIconUnchecked60());
                                }
                            }
                            
                            // refresh begin new pay period button
                            if (premiumComputed && threeDayRuleComputed && reliefDifferentialComputed && allocationsValidated)
                            {
                                beginNewPayPeriodButton.setEnabled(true);
                            }
                            else
                            {
                                beginNewPayPeriodButton.setEnabled(false);
                            }
                            setCursor(Constants.NORMAL);
                        }
                    });
                }
                finally
                {
                    refreshBeginNewPayPeriodLock.release();
                }
            }
        }
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton beginNewPayPeriodButton;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton compute3DayRuleButton;
    private javax.swing.JButton computePremiumButton;
    private javax.swing.JButton computeReliefDifferentialButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel loadingReadyLabel;
    private javax.swing.JScrollPane noteScrollPane;
    private javax.swing.JTextArea noteTextArea;
    private javax.swing.JLabel payrollPeriodLabel;
    private javax.swing.JButton powerUserOverrideButton;
    private javax.swing.JScrollPane readySchedulesPane;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton reimportFutureSchedulesButton;
    private javax.swing.JPanel schedulePanel;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel titleLabel1;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton validateAllocationsButton;
    // End of variables declaration//GEN-END:variables
}