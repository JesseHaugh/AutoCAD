package tvi.client_main;

import it.sauronsoftware.junique.AlreadyLockedException;
import it.sauronsoftware.junique.JUnique;
import it.sauronsoftware.junique.MessageHandler;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import tvicore.dao.UserData;
import tvi.gui.MainMenu;
import tvi.gui.Startup;
import tvicore.dao.Config;
import tvicore.miscellaneous.Misc;
import java.util.Date;

public class Main
{
    public static final String CLIENTVERSION = "2.2";
    public static final String CLIENTNAME = "INFOR";
    public static final Config config = new Config();
    public static final String APPID = "TVIMainApp";
    
    public static void main(String args[])
    {
        String version = System.getProperty("java.version");
        if (Double.parseDouble(version.substring(0, 3)) < 1.8)
        {
            Misc.msgbox(null, "Your computer is currently using Java " + version + ", which is no longer supported.\nYou must update to Java 1.8 or newer in order to run TVI.", "Invalid Java Version", 2, 1, 1);
            System.exit(0);
        }
        
        boolean alreadyRunning;
        try
        {
            JUnique.acquireLock(APPID, new MessageHandler()
            {
                @Override
                public String handle(String message)
                {
                    if (message.equals("FOCUS"))
                    {
                        if (!MainMenu.focusInstance())
                        {
                            Startup.focusInstance();
                        }
                    }
                    return null;
                }
            });
            alreadyRunning = false;
        }
        catch (AlreadyLockedException ex)
        {
            alreadyRunning = true;
        }
        if (alreadyRunning)
        {
            JUnique.sendMessage(APPID, "FOCUS");
            System.exit(0);
        }
        
        config.readFromFile(); // load config information from disk
        String userid = config.getUserid();
        if (userid.equals("DEFAULT"))
        {
            userid = Misc.getUUID();
        }
        UserData.setUUID(userid);
        UserData.setUserIP(Misc.getNetworkIp());
        
        // Set the look and feel
        try
        {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException ex)
        {
            System.err.println("Unable to load native look and feel");
        }
        
        // Create and display the STARTUP form for password
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                Startup.getInstance();
            }
        });
    }
}
