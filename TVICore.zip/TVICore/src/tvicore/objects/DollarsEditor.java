package tvicore.objects;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.EventObject;
import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;
import tvicore.miscellaneous.Misc;

/**
 * Implements a cell editor that uses a formatted text field to edit Double values.
 */
public final class DollarsEditor extends DefaultCellEditor
{
    JFormattedTextField ftf;
    double previousValue;
    NumberFormat doubleFormat;
    private final Double minimum = 0.0;
    DecimalFormat df = new DecimalFormat("#.##");
    String incrementMessage = "";

    public DollarsEditor()
    {
        super(new JFormattedTextField());
        clickCountToStart = 2;
        ftf = (JFormattedTextField)getComponent();
        
        // Set up the editor for the double cells.
        doubleFormat = NumberFormat.getNumberInstance();
        NumberFormatter dblFormatter = new NumberFormatter(doubleFormat);
        dblFormatter.setFormat(doubleFormat);
        dblFormatter.setMinimum(minimum);
        df.setRoundingMode(RoundingMode.HALF_UP);
        
        ftf.setFormatterFactory(new DefaultFormatterFactory(dblFormatter));
        ftf.setValue(minimum);
        ftf.setHorizontalAlignment(JTextField.TRAILING);
        ftf.setFocusLostBehavior(JFormattedTextField.PERSIST);
        
        //React when the user presses Enter while the editor is active.
        //(Tab is handled as specified by JFormattedTextField's focusLostBehavior property.)
        ftf.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "check");
        ftf.getActionMap().put("check", new AbstractAction()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object obj;
                try
                {
                    obj = ftf.getText();
                }
                catch (NullPointerException ex)
                {
                    obj = "";
                }
                if (obj.equals(""))
                {
                    ftf.setText("0");
                }
                if (ftf.isEditValid() && (obj.toString().isEmpty() || (Misc.isNumeric(obj.toString()) && Double.parseDouble(obj.toString()) >= 0)))
                {
                    try
                    {
                        if (obj.toString().isEmpty())
                        {
                            ftf.setText("0");
                        }
                        else
                        {
                            ftf.setText(df.format(Double.parseDouble(obj.toString())));
                        }
                        ftf.commitEdit(); // The text is valid, so use it.
                        ftf.postActionEvent(); // stop editing
                    }
                    catch (java.text.ParseException ex)
                    {
                        
                    }
                }
                else // text is invalid
                {
                    if (userSaysRevert())
                    {
                        ftf.postActionEvent(); // inform the editor
                    }
                }
            }
        });
    }
    @Override
    public boolean isCellEditable(EventObject e)
    {
        if (e instanceof MouseEvent)
        {
            return ((MouseEvent) e).getClickCount() >= clickCountToStart;
        }
        else
        {
            return !(e instanceof KeyEvent);
        }
    }
    
    // Override to invoke setValue on the formatted text field.
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
    {
        ftf = (JFormattedTextField) super.getTableCellEditorComponent(table, value, isSelected, row, column);
        if (ftf.getText() == null || ftf.getText().equals(""))
        {
            previousValue = 0.0;
        }
        else
        {
            previousValue = Double.parseDouble(ftf.getText());
        }
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                ftf.selectAll();
            }
        });
        return ftf;
    }
    
    // Override to ensure that the value remains a BigDecimal.
    @Override
    public Object getCellEditorValue()
    {
        ftf = (JFormattedTextField)getComponent();
        Object value = ftf.getValue();
        if (value instanceof BigDecimal)
        {
            return value;
        }
        else if (value instanceof Double)
        {
            return Misc.doubleToBigDecimal((Double)value);
        }
        else if (value instanceof Number)
        {
            return new BigDecimal(((Number)value).toString());
        }
        else
        {
            return null;
        }
    }
    
    /*  Override to check whether the edit is valid, setting the value if it is
        and complaining if it isn't.  If it's OK for the editor to go away, we
        need to invoke the superclass's version of this method so that
        everything gets cleaned up.
    */
    @Override
    public boolean stopCellEditing()
    {
        ftf = (JFormattedTextField)getComponent();
        Object obj;
        try
        {
            obj = ftf.getText();
        }
        catch (NullPointerException ex)
        {
            obj = "";
        }
        if (ftf.isEditValid() && (obj.toString().isEmpty() || (Misc.isNumeric(obj.toString()) && Double.parseDouble(obj.toString()) >= 0)))
        {
            try
            {
                ftf.commitEdit();
            }
            catch (java.text.ParseException ex)
            {
                
            }
        }
        else // text is invalid
        {
            if (!userSaysRevert()) // user wants to edit
            {
                return false; // continue editting
            }
        }
        return super.stopCellEditing();
    }

    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevert()
    {
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "Invalid amount, value must be in dollar increments.\n"
            + incrementMessage + "You can either continue editing or revert to the last valid value.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
	    return true;
        }
	return false;
    }
}
