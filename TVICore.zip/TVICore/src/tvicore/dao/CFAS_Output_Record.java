package tvicore.dao;

public class CFAS_Output_Record
{
    Object x_rcc;
    Object x_material_item_code;
    Object x_rco;
    Object x_gl_period_start_date;
    Object x_gl_period_end_date;
    Object x_flex_value_set_id;
    Object x_location_code;
    Object x_company_code;
    Object x_org_context;
    Object x_project_number;
    Object x_category_id;
    Object x_location_id;
    Object x_hrs_quantity;
    Object x_amount;
    Object x_tax_segment;
    Object x_date_placed_in_service;
    Object x_fa_attribute3;
    Object x_serial_tag_number;
    Object x_book_type_code;
    Object x_account;
    Object x_frc;
    Object x_asset_loc_code;
    Object x_year_placed;
    Object x_asset_key_ccid;
    Object x_payables_ccid;
    Object x_expense_ccid;
    Object x_expenditure_ending_date;
    Object x_super_rule;
    Object x_account_code;
    Object x_xc;
    Object x_ffv_attribute1;
    Object x_ffv_attribute5;
    Object x_proj_task_flag;
    Object x_cost_pool_rc;
    Object x_depr_exp_cost_pool_rc;
    Object x_pa_orig_trans_reference;
    Object x_unmatched_negative_flag;
    Object x_cip_account;
    Object x_function_code;
    Object x_activity_code;
    Object x_task_number;
    Object x_project_id;
    Object x_pa_attribute1;
    Object x_pa_attribute10;
    Object x_pa_attribute6;
    Object x_pa_attribute7;
    Object x_pa_attribute8;
    Object x_pa_attribute9;
    Object x_ca_force_group;
    Object x_charged_company_code;
    Object x_ca_legal_entity;
    Object x_clearance_company_code;
    Object x_clearance_legal_entity;
    Object x_sbc_uid;
    Object x_categories;
    Object x_pa_attribute2;
    Object x_code_combination_id;
    Object x_business_unit_dimension;
    Object x_reserved1;
    Object x_ic_code;
    Object x_product_code;
    Object x_charge_code;
    Object x_market_area;
    Object x_attribute4;
    Object x_user_je_category_name;
    Object x_asset_id;
    Object x_property_ownership;
    Object x_expenditure_comment;
    Object x_mic_description;
    Object x_lessee;
    Object x_error_flag;
    Object x_task_id;
    Object x_coa;
    Object x_ledger_id;
    Object x_org_id;
    Object x_stat;
    Object x_local;
    Object x_local2;
    CFAS_Error_Record[] errors;
}

class CFAS_Error_Record
{
    Object super_rule;
    Object business_rule_number;
    Object business_rule_proc;
    Object error_flag;
    Object error_number;
    Object error_message;
    CFAS_Error_Params[] params;
}

class CFAS_Error_Params
{
    Object param_name;
    Object param_value;
}