package tvi.gui;

import java.awt.Component;
import java.awt.Font;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.resources.Resources;

public final class StartStopTimes extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile StartStopTimes instance;
    
    private final String feeder;
    private final String site;
    private final String mu;
    private final String empid;
    private final String employeeName;
    private final Date reportingDate;
    private final String recordType;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    final static int idx_START_TIME = 0;
    final static int idx_STOP_TIME  = 1;
    final static int idx_HOURS      = 2;
    final static int idx_MINUTES    = 3;
    final static int idx_IEX_CODE   = 4;
    final static int idx_TVI_CODE   = 5;
    final static int idx_ICON       = 6;
    
    public synchronized static StartStopTimes getInstance(Component parentFrame, String feeder, String site, String mu, String empid, String employeeName, Date reportingDate, String recordType)
    {
        if (instance != null)
        {
            if (Misc.objectEquals(instance.feeder, feeder) &&
                Misc.objectEquals(instance.site, site) &&
                Misc.objectEquals(instance.mu, mu) &&
                Misc.objectEquals(instance.empid, empid) &&
                Misc.objectEquals(instance.employeeName, employeeName) &&
                Misc.objectEquals(instance.reportingDate, reportingDate) &&
                Misc.objectEquals(instance.recordType, recordType))
            {
                instance.toFront();
            }
            else
            {
                instance.closeForm();
            }
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new StartStopTimes(feeder, site, mu, empid, employeeName, reportingDate, recordType);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private StartStopTimes(String feeder, String site, String mu, String empid, String employeeName, Date reportingDate, String recordType)
    {
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.empid = empid;
        this.employeeName = employeeName;
        this.reportingDate = reportingDate;
        this.recordType = recordType;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        nameLabel.setText(empid + " - " + employeeName);
    }
    
    public static void closeInstance()
    {
        if (instance != null)
        {
            instance.closeForm();
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    startStopTimesScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "Start Time",  // idx_START_TIME
                "Stop Time",   // idx_STOP_TIME
                "Hours",       // idx_HOURS
                "Minutes",     // idx_MINUTES
                "IEX Code",    // idx_IEX_CODE
                "TVI Code",    // idx_TVI_CODE
                "ICON"         // idx_ICON
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsStartStops(getFormComponent(), feeder, site, mu, empid, reportingDate, recordType);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String tviCode = rs.getString("TVI_CODE");
                String replacedCode = rs.getString("REPLACED_CODE");
                if (replacedCode != null)
                {
                    tviCode = replacedCode;
                }
                
                data = new Object[]
                {
                    Misc.timestampToDate(rs.getTimestamp("START_TIME")),  // idx_START_TIME
                    Misc.timestampToDate(rs.getTimestamp("STOP_TIME")),   // idx_STOP_TIME
                    rs.getBigDecimal("HOURS"),                            // idx_HOURS
                    rs.getInt("THE_MINUTES"),                             // idx_MINUTES
                    rs.getString("IEX_CODE"),                             // idx_IEX_CODE
                    tviCode,                                              // idx_TVI_CODE
                    rs.getString("ICON")                                  // idx_ICON
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Start & Stops data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                startStopTimesScrollPane.setViewportView(table);
            }
            refreshTableLock.release();
            if (cancelled)
            {
                closeForm();
            }
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_HOURS:
                            return BigDecimal.class;
                        case idx_MINUTES:
                            return Integer.class;
                        case idx_START_TIME:
                        case idx_STOP_TIME:
                            return Date.class;
                        case idx_IEX_CODE:
                        case idx_TVI_CODE:
                        case idx_ICON: 
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, true, true, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_START_TIME, 200, "MM/dd/yyyy - hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(table, idx_STOP_TIME, 200, "MM/dd/yyyy - hh:mm a", Constants.CENTER);
            Misc.setColumnSettings(table, idx_HOURS, 60);
            Misc.setColumnSettings(table, idx_MINUTES, 60);
            Misc.setColumnSettings(table, idx_IEX_CODE, 190);
            Misc.setColumnSettings(table, idx_TVI_CODE, 80);
            Misc.setColumnSettings(table, idx_ICON, 420);
            Misc.setColumnHeaderRenderer(table, idx_ICON, false, true, table.getTableHeader().getBackground());
            
            table.setFont(new Font("Tahoma", java.awt.Font.PLAIN, 14));
            table.setRowHeight(25);
        }
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titlePanel = new javax.swing.JPanel();
        nameLabel = new javax.swing.JLabel();
        subtitleLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        startStopTimesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        exitPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Start & Stop Times");
        setMinimumSize(new java.awt.Dimension(960, 600));
        setPreferredSize(new java.awt.Dimension(840, 680));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setMinimumSize(new java.awt.Dimension(100, 80));
        titlePanel.setPreferredSize(new java.awt.Dimension(100, 80));
        titlePanel.setLayout(new java.awt.GridLayout(2, 0));

        nameLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        nameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nameLabel.setText("Empid - Name");
        nameLabel.setToolTipText("");
        nameLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        titlePanel.add(nameLabel);

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("IEX Start & Stop Times From Last Load");
        subtitleLabel.setToolTipText("");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        titlePanel.add(subtitleLabel);

        getContentPane().add(titlePanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.PAGE_AXIS));

        startStopTimesScrollPane.setMaximumSize(new java.awt.Dimension(900, 1600));
        startStopTimesScrollPane.setMinimumSize(new java.awt.Dimension(900, 200));
        startStopTimesScrollPane.setName(""); // NOI18N
        startStopTimesScrollPane.setPreferredSize(new java.awt.Dimension(840, 500));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        startStopTimesScrollPane.setViewportView(loadingLabel);

        centerPanel.add(startStopTimesScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(150, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitPanel.add(exitButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JScrollPane startStopTimesScrollPane;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JPanel titlePanel;
    // End of variables declaration//GEN-END:variables
}