package tvicore.dao;

import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

public class RegionData
{
    private static String currentFeeder = "";
    private static String currentSite = "";
    
    // feeder data
    private static int FIRSTDAYOFWEEK;
    private static int LASTDAYOFWEEK;
    
    // site data
    private static String siteLock = null;
    private static String siteUnion = "";
    private static String sitePayCycle = "";
    private static String siteDescription = "";
    private static Date payClose;
    private static Date nextPayClose;
    private static Date hotDay;
    private static boolean siteNightDiff = false;
    private static boolean siteNewFeature = false;
    private static boolean siteNewFeature2 = false;
    private static boolean siteReviewByMU = false;
    
    private static final ArrayList<String>                 muList            = new ArrayList<>();
    private static final ArrayList<String>                 costCenterList    = new ArrayList<>();
    private static final ArrayList<AttendanceCodeRecord>   attendanceCodes   = new ArrayList<>();
    private static final ArrayList<AbsenceCodeRecord>      absenceCodes      = new ArrayList<>();
    private static final ArrayList<ReasonCodeRecord>       reasonCodes       = new ArrayList<>();
    private static final ArrayList<ExtraPaymentCodeRecord> extraPaymentCodes = new ArrayList<>();
    private static final ArrayList<DwsRecord>              dwsCodes          = new ArrayList<>();
    private static final ArrayList<ShiftRecord>            shiftCodes        = new ArrayList<>();
    private static final ArrayList<HolidayRecord>          holidayCodes      = new ArrayList<>();
    private static final ArrayList<PayrollCloseRecord>     payrollCloseDates = new ArrayList<>();
    
    
    public static int getFirstDayOfWeek() { return FIRSTDAYOFWEEK; }
    public static int getLastDayOfWeek()  { return LASTDAYOFWEEK; }
    
    public static String getSiteLock()        { return siteLock; }
    public static String getSiteUnion()       { return siteUnion; }
    public static String getPayCycle()        { return sitePayCycle; }
    public static String getSiteDescription() { return siteDescription; }
    public static Date getPayClose()          { return new Date(payClose.getTime()); }
    public static Date getNextPayClose()      { return new Date(nextPayClose.getTime()); }
    public static Date getHotDay()            { return new Date(hotDay.getTime()); }
    public static boolean getNightDiff()      { return siteNightDiff; }
    public static boolean getNewFeature()     { return siteNewFeature; }
    public static boolean getNewFeature2()    { return siteNewFeature2; }
    public static boolean getReviewByMU()     { return siteReviewByMU; }
    
    public static String getFeeder() { return currentFeeder; }
    public static String getSite()   { return currentSite; }
    public static void setFeeder(String value) { currentFeeder = value; }
    public static void setSite(String value)   { currentSite = value; }
        
    public static ArrayList<String> getMuList()                            { return muList; }
    public static ArrayList<String> getCostCenterList()                    { return costCenterList; }
    public static ArrayList<AttendanceCodeRecord> getAttendanceCodes()     { return attendanceCodes; }
    public static ArrayList<AbsenceCodeRecord> getAbsenceCodes()           { return absenceCodes; }
    public static ArrayList<ReasonCodeRecord> getReasonCodes()             { return reasonCodes; }
    public static ArrayList<ExtraPaymentCodeRecord> getExtraPaymentCodes() { return extraPaymentCodes; }
    public static ArrayList<DwsRecord> getDwsCodes()                       { return dwsCodes; }
    public static ArrayList<ShiftRecord> getShiftCodes()                   { return shiftCodes; }
    public static ArrayList<HolidayRecord> getHolidayCodes()               { return holidayCodes; }
    public static ArrayList<PayrollCloseRecord> getPayrollCloseDates()     { return payrollCloseDates; }
    
    /**
     * changeFeeder
     * 
     * Changes to the specified feeder and the first available site on that feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName
     * @param feeder
     */
    public static void changeFeeder(Component parentFrame, String clientName, String feeder)
    {
        UserData.loadPermissions(parentFrame, clientName, feeder);
        loadAbsenceCodes(parentFrame, clientName, feeder);
        loadAttendanceCodes(parentFrame, clientName, feeder);
        loadExtraPaymentCodes(parentFrame, clientName, feeder);
        loadReasonCodes(parentFrame, feeder);
        loadDWSCodes(parentFrame, feeder);
        loadShiftCodes(parentFrame, feeder);
        loadPayrollCloseDates(parentFrame, feeder);
        loadHolidayCodes(parentFrame, feeder);
        if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
        {
            FIRSTDAYOFWEEK = Calendar.MONDAY;
            LASTDAYOFWEEK = Calendar.SUNDAY;
        }
        else
        {
            FIRSTDAYOFWEEK = Calendar.SUNDAY;
            LASTDAYOFWEEK = Calendar.SATURDAY;
        }
        currentFeeder = feeder;
        changeSite(parentFrame, feeder, currentSite);
    }
    
    /**
     * changeSite
     * 
     * Changes to the specified site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     */
    public static void changeSite(Component parentFrame, String feeder, String site)
    {
        updateSiteInfo(parentFrame, feeder, site);
        loadMUs(parentFrame, feeder, site);
        loadCostCenters(parentFrame, feeder, site);
        UserData.updateUserAccessLevel(site);
        currentSite = site;
    }
    
    public static void loadAttendanceCodes(Component parentFrame, String clientName, String feeder)
    {
        attendanceCodes.clear();
        ResultSetWrapper results = Oracle.getResultsAttendanceCodes(parentFrame, clientName, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                attendanceCodes.add(new AttendanceCodeRecord
                (
                    rs.getString("SAP_CODE_AREC"),
                    rs.getString("DESCRIPTION"),
                    rs.getString("PROCESS1"),
                    rs.getString("PROCESS2"),
                    rs.getString("PROCESS3"),
                    rs.getString("PROCESS4"),
                    Misc.objectToALL(rs.getString("UNION_FLAG"))
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing attendance code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadAbsenceCodes(Component parentFrame, String clientName, String feeder)
    {
        absenceCodes.clear();
        ResultSetWrapper results = Oracle.getResultsAbsenceCodes(parentFrame, clientName, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                absenceCodes.add(new AbsenceCodeRecord
                (
                    rs.getString("SAP_CODE"),
                    rs.getString("DESCRIPTION"),
                    rs.getString("PROCESS1"),
                    rs.getString("PROCESS2"),
                    rs.getString("PROCESS3"),
                    Misc.oracleToBoolean(rs.getObject("REASON_CODE_REQUIRED")),
                    Misc.oracleToBoolean(rs.getObject("ADD2REGPLUSABS")),
                    Misc.objectToALL(rs.getString("UNION_FLAG"))
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing absence code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadReasonCodes(Component parentFrame, String feeder)
    {
        reasonCodes.clear();
        ResultSetWrapper results = Oracle.getResultsReasonCodes(parentFrame, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                reasonCodes.add(new ReasonCodeRecord
                (
                    rs.getString("SAP_CODE"),
                    rs.getString("SAP_REASON_CODE"),
                    rs.getString("DESCRIPTION"),
                    Misc.objectToALL(rs.getString("UNION_FLAG"))
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing reason code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadExtraPaymentCodes(Component parentFrame, String clientName, String feeder)
    {
        extraPaymentCodes.clear();
        ResultSetWrapper results = Oracle.getResultsExtraPaymentCodes(parentFrame, clientName, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                extraPaymentCodes.add(new ExtraPaymentCodeRecord
                (
                    rs.getString("EREC_CODE"),
                    rs.getString("DESCRIPTION"),
                    rs.getString("PROCESS1"),
                    rs.getString("PROCESS2"),
                    rs.getString("PROCESS3"),
                    Misc.oracleToBoolean(rs.getObject("COST_ASSIGNMENT")),
                    rs.getString("AMOUNT_TYPE"),
                    Misc.objectToALL(rs.getString("UNION_FLAG"))
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing extra payment code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadDWSCodes(Component parentFrame, String feeder)
    {
        dwsCodes.clear();
        ResultSetWrapper results = Oracle.getResultsDWSCodes(parentFrame, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                dwsCodes.add(new DwsRecord
                (
                    rs.getString("DWS"),
                    Misc.formatAsHours(rs.getString("HRS_PER_DAY")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_NIGHT")),
                    Misc.oracleToBoolean(rs.getObject("CARFARE")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_15_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_NON_PENSION")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_060")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_150")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_185")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_200")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_220")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_250")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_270")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_300")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_400")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_500")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_900")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_600_CAR")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_800_CAR")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_1_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_1_5_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_2_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_2_5_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("DIFF_3_PERCENT")),
                    Misc.oracleToBoolean(rs.getObject("GAP")),
                    rs.getString("UNION_FLAG")
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing DWS code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadShiftCodes(Component parentFrame, String feeder)
    {
        shiftCodes.clear();
        ResultSetWrapper results = Oracle.getResultsShiftCodes(parentFrame, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                shiftCodes.add(new ShiftRecord
                (
                    Misc.formatAsHours(rs.getString("HRS_PER_DAY")),
                    rs.getString("UNION_FLAG")
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing shift code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadPayrollCloseDates(Component parentFrame, String feeder)
    {
        payrollCloseDates.clear();
        ResultSetWrapper results = Oracle.getResultsPayrollCloseDates(parentFrame);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                payrollCloseDates.add(new PayrollCloseRecord
                (
                    rs.getDate("PAYROLL_CLOSE"),
                    rs.getDate("HOT_DAY"),
                    rs.getString("PAYROLL_GROUP")
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing payroll close dates.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadHolidayCodes(Component parentFrame, String feeder)
    {
        holidayCodes.clear();
        ResultSetWrapper results = Oracle.getResultsHolidayCodes(parentFrame, feeder);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                holidayCodes.add(new HolidayRecord
                (
                    rs.getDate("HOLIDAY"),
                    rs.getString("THE_TYPE"),
                    rs.getString("THE_NAME")
                ));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing holiday code records.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadMUs(Component parentFrame, String feeder, String site)
    {
        muList.clear();
        ResultSetWrapper results = Oracle.getResultsMUs(parentFrame, feeder, site);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                muList.add(rs.getString("MU"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing site mu list.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadCostCenters(Component parentFrame, String feeder, String site)
    {
        costCenterList.clear();
        ResultSetWrapper results = Oracle.getResultsCostCenters(parentFrame, feeder, site);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                costCenterList.add(rs.getString("COST_CENTER"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing site cost center list.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void updateSiteInfo(Component parentFrame, String feeder, String site)
    {
        ResultSetWrapper results = Oracle.getSiteInfo(parentFrame, feeder, site);
        ResultSet rs = results.getResultSet();
        try
        {
            if (rs.next())
            {
                siteUnion = rs.getString("UNION_PROCCESS_FLAG");
                sitePayCycle = rs.getString("PAY_CYCLE");
                siteDescription = rs.getString("DESCRIPTION");
                siteNightDiff = Misc.oracleToBoolean(rs.getObject("NIGHT_DIFF_OFFICE"));
                siteNewFeature = Misc.oracleToBoolean(rs.getObject("NEW_FEATURE_RELEASE"));
                siteNewFeature2 = Misc.oracleToBoolean(rs.getObject("NEW_FEATURE_RELEASE2"));
                siteReviewByMU = Misc.oracleToBoolean(rs.getObject("REVIEW_BY_MU"));
                payClose = Misc.stringToDateMDY(parentFrame, rs.getString("CURRENT_PAY_PERIOD"));
                siteLock = rs.getString("SITE_LOCKED");
                if (siteLock != null && siteLock.equals(""))
                {
                    siteLock = null;
                }
            }
            else
            {
                Misc.msgbox(parentFrame, "Your TVI site may not have gone LIVE for this new Software.  For Access or GO LIVE info email " + Constants.EMAIL, "", 1, 1, 2);
                Misc.exit(parentFrame, "NO ACCESS");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error processing site info.");
        }
        finally
        {
            results.close();
        }
        
        // get Hot Day and Next payroll close
        boolean getNextClose = false;
        for (int i = 0; i < payrollCloseDates.size(); i++)
        {
            if (sitePayCycle.equals(payrollCloseDates.get(i).getPayrollGroup()))
            {
                if (getNextClose)
                {
                    nextPayClose = payrollCloseDates.get(i).getPayrollClose();
                    break;
                }
                if (payClose.equals(payrollCloseDates.get(i).getPayrollClose()))
                {
                    hotDay = payrollCloseDates.get(i).getHotDay();
                    getNextClose = true;
                }
            }
        }
        
        if (nextPayClose == null ||
            payClose == null ||
            hotDay == null)
        {
            Misc.errorMsgCritical(parentFrame, null, "Pay Cycle configuration error, email TVI Support: " + Constants.EMAIL);
        }
        
        // Set site "PAY PERIOD" locked/unlocked
        Date curTime = Misc.dateNoTime(Oracle.getCurTimeLocal(parentFrame));
        if (siteLock == null)
        {
            if (curTime.compareTo(hotDay) > 0)
            {
                setSiteLocked(parentFrame, "PAY PERIOD");
            }
        }
        else if (siteLock.equals("PAY PERIOD") && curTime.compareTo(hotDay) <= 0)
        {
            setSiteUnlocked(parentFrame);
        }
    }
    
    public static void updatePayClose(Component parentFrame)
    {
        payClose = nextPayClose;
        nextPayClose = Oracle.getNextPayrollEndDate(parentFrame, sitePayCycle, payClose);
        for (int i = 0; i < payrollCloseDates.size(); i++)
        {
            if (sitePayCycle.equals(payrollCloseDates.get(i).getPayrollGroup()) && payClose.equals(payrollCloseDates.get(i).getPayrollClose()))
            {
                hotDay = payrollCloseDates.get(i).getHotDay();
            }
        }
    }
    
    public static void setSiteLocked(Component parentFrame, String lockedType)
    {
        if (Oracle.setSiteLocked(parentFrame, currentFeeder, currentSite, lockedType))
        {
            siteLock = lockedType;
        }
    }
    
    public static void setSiteUnlocked(Component parentFrame)
    {
        if (Oracle.setSiteUnlocked(parentFrame, currentFeeder, currentSite))
        {
            siteLock = "";
        }
    }
}
