package tvicore.objects;

import java.util.Calendar;
import javax.swing.table.AbstractTableModel;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

public class CalendarTableModel extends AbstractTableModel
{
    private Object[][] data;
    int FIRSTDAYOFWEEK;
    
    public CalendarTableModel(CalendarCell[][] data, int firstDayOfWeek)
    {
        this.data = data;
        this.FIRSTDAYOFWEEK = firstDayOfWeek;
    }
    
    public void setData(Object[][] data)
    {
        this.data = data;
    }
    
    @Override
    public Class getColumnClass(int col)
    {
        return CalendarCell.class;
    }
    
    @Override
    public String getColumnName(int col)
    {
        String day = "";
        if (FIRSTDAYOFWEEK == Calendar.SUNDAY)
        {
            switch (col)
            {
                case 0:
                    day = "Sunday";
                    break;
                case 1:
                    day = "Monday";
                    break;
                case 2:
                    day = "Tuesday";
                    break;
                case 3:
                    day = "Wednesday";
                    break;
                case 4:
                    day = "Thursday";
                    break;
                case 5:
                    day = "Friday";
                    break;
                case 6:
                    day = "Saturday";
                    break;
                default:
                    Misc.msgbox(null, "Unhandled day column, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
            }
        }
        else // CZE, MEX, SVK
        {
            switch (col)
            {
                case 0:
                    day = "Monday";
                    break;
                case 1:
                    day = "Tuesday";
                    break;
                case 2:
                    day = "Wednesday";
                    break;
                case 3:
                    day = "Thursday";
                    break;
                case 4:
                    day = "Friday";
                    break;
                case 5:
                    day = "Saturday";
                    break;
                case 6:
                    day = "Sunday";
                    break;
                default:
                    Misc.msgbox(null, "Unhandled day column, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
            }
        }
        return day;
    }
    
    @Override
    public int getRowCount()
    {
        return 6;
    }

    @Override
    public int getColumnCount()
    {
        return 7;
    }

    @Override
    public Object getValueAt(int row, int col)
    {
        return data[row][col];
    }
    
    @Override
    public boolean isCellEditable(int col, int row)
    {
        return false;
    }
}
