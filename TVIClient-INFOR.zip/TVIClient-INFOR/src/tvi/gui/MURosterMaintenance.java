/**
 * This form can be opened in several different ways.
 */

package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class MURosterMaintenance extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile MURosterMaintenance instance;
    
    private final String feeder;
    private final String site;
    String attid;
    String editType;
    
    JTable table;
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    boolean formClosing = false;
    boolean changingEmployees = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    boolean employeeUpdated = false;
    int currentRow = -1;
    int employeeCount = 0;
    
    boolean filterEnabled = true;
    int filterColumn = -1;
    String employeeStatusFilterText = "1";
    
    boolean filterCoachDiscrepancies = false;
    TableRowSorter<CustomTableModel> sorter;
    
    final static int idx_FEEDER                 = 0;
    final static int idx_SITE                   = 1;
    final static int idx_MU                     = 2;
    final static int idx_EMPID                  = 3;
    final static int idx_AGENTID                = 4;
    final static int idx_EMPLOYEE               = 5;
    final static int idx_START_DATE             = 6;
    final static int idx_END_DATE               = 7;
    final static int idx_STATUS                 = 8;
    final static int idx_DO_NOT_IMPORT          = 9;
    final static int idx_ERROR_FLAG             = 10;
    final static int idx_ERROR                  = 11;
    final static int idx_MESSAGE                = 12;
    
    public synchronized static MURosterMaintenance getInstance(Component parentFrame, String feeder, String site, String attid)
    {
        if (instance != null)
        {
            if (Misc.objectEquals(instance.attid, attid))
            {
                instance.toFront();
            }
            else
            {
                instance.closeForm();
            }
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new MURosterMaintenance(feeder, site, attid);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private MURosterMaintenance(String feeder, String site, String attid)
    {
        this.feeder = feeder;
        this.site = site;
        this.attid = attid;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        

        if (Oracle.areAnyNewErrorFlag(getFormComponent(), feeder, site))
        {
            filterEmployeeStatusComboBox.setSelectedIndex(4);
            employeeStatusFilterText = "6";
        }
        else
        {
            filterEmployeeStatusComboBox.setSelectedIndex(0);
        }

        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        subtitleLabel2.setText("For new employees, ensure their AT&T IDs are correct, then validate them with either Validate Button");
        
        updateNewEmpButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        updateAllNewEmpButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        
        filterTextField.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override public void insertUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void removeUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void changedUpdate(DocumentEvent e) { processFilter(); }
        });
        
    }
    
    public String getATTID()
    {
        return attid;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        subtitleLabel1 = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        employeesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        gridPanel = new javax.swing.JPanel();
        filterLabelsPanel = new javax.swing.JPanel();
        filterColumnTextLabel = new javax.swing.JLabel();
        filterTextLabel = new javax.swing.JLabel();
        filterEmployeeStatusLabel = new javax.swing.JLabel();
        filterClearLabel = new javax.swing.JLabel();
        filtersPanel = new javax.swing.JPanel();
        filterColumnComboBox = new javax.swing.JComboBox<>();
        filterTextField = new javax.swing.JTextField();
        filterEmployeeStatusComboBox = new javax.swing.JComboBox<>();
        filterClearButton = new javax.swing.JButton();
        controlPanel2 = new javax.swing.JPanel();
        printButton = new javax.swing.JButton();
        employeeHistoryButton = new javax.swing.JButton();
        updateNewEmpButton = new javax.swing.JButton();
        updateAllNewEmpButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("MU Roster Maintenance");
        setBackground(new java.awt.Color(255, 204, 153));
        setMinimumSize(new java.awt.Dimension(850, 610));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(255, 204, 153));
        topPanel.setMinimumSize(new java.awt.Dimension(850, 90));
        topPanel.setPreferredSize(new java.awt.Dimension(850, 90));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(255, 204, 153));
        titlePanel.setMinimumSize(new java.awt.Dimension(850, 90));
        titlePanel.setName(""); // NOI18N
        titlePanel.setPreferredSize(new java.awt.Dimension(850, 90));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(255, 204, 153));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        exitButton.setBackground(new java.awt.Color(255, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(100, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, -1, -1));

        refreshButton.setBackground(new java.awt.Color(255, 204, 153));
        refreshButton.setText("Refresh Screen");
        refreshButton.setMargin(new java.awt.Insets(2, 5, 2, 5));
        refreshButton.setPreferredSize(new java.awt.Dimension(100, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        titlePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("MU Roster Maintenance");
        titleLabel.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 850, -1));

        subtitleLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel1.setText("For employees with issues, checkmark \"Do Not Import\" or correct the issue in IEX.");
        subtitleLabel1.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 850, 20));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("For new employees, ensure their AT&T IDs are correct, then validate them with either Validate Button");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 850, 20));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(255, 204, 153));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        employeesScrollPane.setAlignmentY(0.0F);
        employeesScrollPane.setMaximumSize(new java.awt.Dimension(590, 460));
        employeesScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        employeesScrollPane.setPreferredSize(new java.awt.Dimension(590, 200));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        employeesScrollPane.setViewportView(loadingLabel);

        centerPanel.add(employeesScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(255, 204, 153));
        bottomPanel.setMinimumSize(new java.awt.Dimension(850, 200));
        bottomPanel.setPreferredSize(new java.awt.Dimension(850, 140));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        gridPanel.setBackground(new java.awt.Color(255, 204, 153));
        gridPanel.setMinimumSize(new java.awt.Dimension(850, 120));
        gridPanel.setPreferredSize(new java.awt.Dimension(850, 200));
        gridPanel.setLayout(new java.awt.GridLayout(5, 0));

        filterLabelsPanel.setBackground(new java.awt.Color(255, 204, 153));
        filterLabelsPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        filterColumnTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterColumnTextLabel.setText("Column to search:");
        filterColumnTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterColumnTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterColumnTextLabel);

        filterTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterTextLabel.setText("Filter by text:");
        filterTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterTextLabel);

        filterEmployeeStatusLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeStatusLabel.setText("Employee Status:");
        filterEmployeeStatusLabel.setToolTipText("");
        filterEmployeeStatusLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeStatusLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeStatusLabel);

        filterClearLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterClearLabel);

        gridPanel.add(filterLabelsPanel);

        filtersPanel.setBackground(new java.awt.Color(255, 204, 153));
        filtersPanel.setMinimumSize(new java.awt.Dimension(850, 30));
        filtersPanel.setPreferredSize(new java.awt.Dimension(850, 30));
        filtersPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        filterColumnComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "FEEDER", "SITE", "MU", "AT&T ID", "EMPLOYEE", "AGENTID", "START DATE", "END DATE", "DO NOT IMPORT", "ISSUE", "ACTION REQUIRED" }));
        filterColumnComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterColumnComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterColumnComboBox);

        filterTextField.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextField.setMaximumSize(new java.awt.Dimension(150, 30));
        filterTextField.setMinimumSize(new java.awt.Dimension(150, 30));
        filterTextField.setPreferredSize(new java.awt.Dimension(150, 30));
        filtersPanel.add(filterTextField);

        filterEmployeeStatusComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show New Emps", "Show ID Errors", "Show Date Errors", "Show New Errors" }));
        filterEmployeeStatusComboBox.setToolTipText("");
        filterEmployeeStatusComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterEmployeeStatusComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterEmployeeStatusComboBox);

        filterClearButton.setBackground(new java.awt.Color(255, 204, 153));
        filterClearButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearButton.setText("Clear Filters");
        filterClearButton.setMaximumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setMinimumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setPreferredSize(new java.awt.Dimension(150, 30));
        filterClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterClearButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(filterClearButton);

        gridPanel.add(filtersPanel);

        controlPanel2.setBackground(new java.awt.Color(255, 204, 153));
        controlPanel2.setMinimumSize(new java.awt.Dimension(850, 40));
        controlPanel2.setPreferredSize(new java.awt.Dimension(850, 40));
        controlPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        printButton.setBackground(new java.awt.Color(255, 204, 153));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setMaximumSize(new java.awt.Dimension(150, 30));
        printButton.setMinimumSize(new java.awt.Dimension(150, 30));
        printButton.setPreferredSize(new java.awt.Dimension(150, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(printButton);

        employeeHistoryButton.setBackground(new java.awt.Color(255, 204, 153));
        employeeHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeHistoryButton.setText("Employee History");
        employeeHistoryButton.setMaximumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setMinimumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setPreferredSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeHistoryButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(employeeHistoryButton);

        updateNewEmpButton.setBackground(new java.awt.Color(150, 210, 170));
        updateNewEmpButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        updateNewEmpButton.setText("<html><div align='center' width='100%'>Validate Selected<br>Employees' AT&T IDs</div></html>");
        updateNewEmpButton.setToolTipText("");
        updateNewEmpButton.setMaximumSize(new java.awt.Dimension(150, 40));
        updateNewEmpButton.setMinimumSize(new java.awt.Dimension(150, 40));
        updateNewEmpButton.setPreferredSize(new java.awt.Dimension(150, 40));
        updateNewEmpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateNewEmpButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(updateNewEmpButton);

        updateAllNewEmpButton.setBackground(new java.awt.Color(150, 210, 170));
        updateAllNewEmpButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        updateAllNewEmpButton.setText("<html><div align='center' width='100%'>Validate All New<br>Employees' AT&T IDs</div></html>");
        updateAllNewEmpButton.setMaximumSize(new java.awt.Dimension(150, 40));
        updateAllNewEmpButton.setMinimumSize(new java.awt.Dimension(150, 40));
        updateAllNewEmpButton.setPreferredSize(new java.awt.Dimension(150, 40));
        updateAllNewEmpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAllNewEmpButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(updateAllNewEmpButton);

        gridPanel.add(controlPanel2);

        bottomPanel.add(gridPanel);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
        
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
    
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void filterColumnComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterColumnComboBoxActionPerformed
        String selection = filterColumnComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "ALL":
                filterColumn = -1;
                break;
            case "FEEDER":
                filterColumn = idx_FEEDER;
                break;
            case "SITE":
                filterColumn = idx_SITE;
                break;
            case "MU":
                filterColumn = idx_MU;
                break;
            case "AT&T ID":
                filterColumn = idx_EMPID;
                break;
            case "AGENTID":
                filterColumn = idx_AGENTID;
                break;
            case "EMPLOYEE":
                filterColumn = idx_EMPLOYEE;
                break;
            case "START DATE":
                filterColumn = idx_START_DATE;
                break;
            case "END DATE":
                filterColumn = idx_END_DATE;
                break;
            case "DO NOT IMPORT":
                filterColumn = idx_DO_NOT_IMPORT;
                break;
            case "ISSUE":
                filterColumn = idx_ERROR;
                break;
            case "ACTION REQUIRED":
                filterColumn = idx_MESSAGE;
                break;
            default:
                Misc.msgbox(getFormComponent(), "Unhandled filter selection, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
        }
        processFilter();
    }//GEN-LAST:event_filterColumnComboBoxActionPerformed

    private void filterEmployeeStatusComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterEmployeeStatusComboBoxActionPerformed
        String selection = filterEmployeeStatusComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "Show New Emps":
                employeeStatusFilterText = "1";
                break;
            case "Show ID Errors":
                employeeStatusFilterText = "2";
                break;
            case "Show Date Errors":
                employeeStatusFilterText = "5";
                break;
            case "Show New Errors":
                employeeStatusFilterText = "6";
                break;
            default:
                employeeStatusFilterText = "";
                break;
        }
        processFilter();
    }//GEN-LAST:event_filterEmployeeStatusComboBoxActionPerformed

    private void filterClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterClearButtonActionPerformed
        clearFilter();
        processFilter();
        filterTextField.requestFocusInWindow();
    }//GEN-LAST:event_filterClearButtonActionPerformed
        
    private void employeeHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeHistoryButtonActionPerformed
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "MU Roster Maintenance", 1, 1, 1);
            return;
        }
        else
        {
            String empid = Misc.objectToString(table.getValueAt(selectedRow, idx_EMPID));
            if (empid.equals(""))
            {
                Misc.msgbox(getFormComponent(), "You cannot select an employee with a blank AT&T ID.", "MU Roster Maintenance", 1, 1, 1);
                return; 
            }
            else
            {
                EmployeeHistory.getInstance(getFormComponent(), feeder, site, empid);
            }
        }
    }//GEN-LAST:event_employeeHistoryButtonActionPerformed
                
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", "Employee Maintenance");
    }//GEN-LAST:event_printButtonActionPerformed

    private void updateNewEmpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateNewEmpButtonActionPerformed
        int[] selectedRows = table.getSelectedRows();
        int selectedRow = table.getSelectedRow();
        int errorFlag = Misc.objectToInt(table.getValueAt(selectedRow, idx_ERROR_FLAG));
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "MU Roster Maintenance", 1, 1, 1);
            return;
        }
        else if (errorFlag != 1)
        {
            Misc.msgbox(getFormComponent(), "Only employees without errors can be validated.", "MU Roster Maintenance", 1, 1, 1);
            return;
        }

        if (Misc.msgbox(getFormComponent(), "<html>This will validate all SELECTED new employees' AT&T IDs.<br>Are all selected new employees' AT&T IDs correct?</html>", "Validate Employee AT&T IDs", 2, 2, 1))
        {
            ArrayList<String> empList = new ArrayList<>();
            for (int i = 0; i < selectedRows.length; i++)
            {
                int flag = Misc.objectToInt(table.getValueAt(selectedRows[i], idx_ERROR_FLAG));
                String empid = Misc.objectToString(table.getValueAt(selectedRows[i], idx_EMPID));

                if (flag == 1)
                {
                    empList.add(empid);
                }
            }
            if (Oracle.updateValidNewEmployees(getFormComponent(), feeder, site, empList))
            {
                refreshData();
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Error validating new employees.  Email TVI at " + Constants.EMAIL, "MU Roster Maintenance", 1, 1, 1);
            }
        }
    }//GEN-LAST:event_updateNewEmpButtonActionPerformed

    private void updateAllNewEmpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateAllNewEmpButtonActionPerformed
        if (!Oracle.areAnyNewEmployees(getFormComponent(), feeder, site))
        {
            Misc.msgbox(getFormComponent(), "There are no new employees without errors to validate.", "MU Roster Maintenance", 1, 1, 1);
            return; 
        }
        
        if (Misc.msgbox(getFormComponent(), "<html>This will validate ALL new employees' AT&T IDs.<br>Are all new employees' AT&T IDs correct?</html>", "Update All Coaches", 2, 2, 1))
        {
            if (Oracle.updateValidNewEmployees(getFormComponent(), feeder, site, null))
            {
                refreshData();
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Error validating new employees.  Email TVI at " + Constants.EMAIL, "MU Roster Maintenance", 1, 1, 1);
            }
        }
    }//GEN-LAST:event_updateAllNewEmpButtonActionPerformed
                        
    private void refreshData()
    {
        if (table != null)
        {
            updateDatabase();
        }
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    employeeCount = 0;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (table != null)
                        {
                            if (table.getSelectedRow() != -1)
                            {
                                changeEmployee(0);
                            }
                        }
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    employeesScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "FEEDER",                                    // idx_FEEDER
                "SITE",                                      // idx_SITE
                "MU",                                        // idx_MU
                Misc.centerHTML("AT&T<br>ID"),               // idx_EMPID
                Misc.centerHTML("Agent<br>ID"),              // idx_AGENTID
                "Employee",                                  // idx_EMPLOYEE
                "Start Date",                                // idx_START_DATE
                "End Date",                                  // idx_END_DATE
                "",                                          // idx_STATUS
                Misc.centerHTML("Do Not<br>Import"),         // idx_DO_NOT_IMPORT
                "",                                          // idx_ERROR_FLAG
                "Issue",                                     // idx_ERROR
                "Steps to Correct"                           // idx_MESSAGE
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsMURosterErrorsINFOR(getFormComponent(), feeder, site);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object []
                {
                    rs.getString("FEEDER"),                                       // idx_FEEDER
                    rs.getString("SITE"),                                         // idx_SITE
                    rs.getString("MU"),                                           // idx_MU
                    rs.getString("EMPID"),                                        // idx_EMPID
                    rs.getString("AGENTID"),                                      // idx_AGENTID
                    rs.getString("EMPLOYEE"),                                     // idx_EMPLOYEE
                    rs.getDate("START_DATE"),                                     // idx_START_DATE
                    rs.getDate("END_DATE"),                                       // idx_END_DATE
                    rs.getString("STATUS"),                                       // idx_STATUS
                    Misc.oracleToBoolean(rs.getObject("DO_NOT_IMPORT")),          // idx_DO_NOT_IMPORT
                    rs.getInt("ERROR_FLAG"),                                      // idx_ERROR_FLAG
                    rs.getString("ERROR"),                                        // idx_ERROR
                    rs.getString("MESSAGE")                                       // idx_MESSAGE
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Employee Issues data.");
                worker.cancel(true);
            }
            employeeCount++;
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
                employeesScrollPane.setViewportView(table);
                filterTextField.requestFocusInWindow();
            }
            refreshTableLock.release();
            if (cancelled)
            {
                closeForm();
            }
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (table.convertRowIndexToModel(row) != currentRow ||
                        table.getSelectedRows().length > 1)
                    {
                        return false;
                    }
                    else if (UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_DO_NOT_IMPORT:
                                return true;
                            default:
                                return false;
                        }
                    }
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_DO_NOT_IMPORT:
                            return Boolean.class;
                        case idx_START_DATE:
                        case idx_END_DATE:
                            return Date.class;
                        case idx_ERROR_FLAG:
                            return Integer.class;
                        case idx_FEEDER:
                        case idx_SITE:
                        case idx_MU:
                        case idx_AGENTID:
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_STATUS:
                        case idx_ERROR:
                        case idx_MESSAGE:
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (UserData.getUserAccessLevel().equals("READONLY") ||
                            !table.getValueAt(row, idx_FEEDER).toString().equals(feeder) ||
                            !table.getValueAt(row, idx_SITE).toString().equals(site))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else if (!table.getValueAt(row, idx_ERROR_FLAG).toString().equals("1"))
                        {
                            c.setBackground(Color.YELLOW);
                        }
                    }
                    return c;
                }
            };
        }

        private void configureTable()
        {
            Action employeeTableAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    int selectedRow = table.getSelectedRow();

                    employeeUpdated = true;
                    currentRow = table.convertRowIndexToModel(selectedRow);
                }
            };
            table.addPropertyChangeListener(new TableCellListener(table, employeeTableAction));

            Misc.configureTable(table, false, true, false);

            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);

            Misc.setTableSorterNumeralComparator(table);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_FEEDER, 60);
            Misc.setColumnSettings(table, idx_SITE, 40);
            Misc.setColumnSettings(table, idx_MU, 40);
            Misc.setColumnSettings(table, idx_EMPID, 60);
            Misc.setColumnSettings(table, idx_AGENTID, 60);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 150, Constants.LEFT);
            Misc.setColumnSettings(table, idx_START_DATE, 80);
            Misc.setColumnSettings(table, idx_END_DATE, 80);
            Misc.setColumnSettings(table, idx_STATUS, 0, false);
            Misc.setColumnSettings(table, idx_DO_NOT_IMPORT, 60, false);
            Misc.setColumnSettings(table, idx_ERROR_FLAG, 0);
            Misc.setColumnSettings(table, idx_ERROR, 200, Constants.LEFT);
            Misc.setColumnSettings(table, idx_MESSAGE, 320, Constants.LEFT);
       
            table.setRowHeight(20);

            if (employeeCount > 0)
            {
                currentRow = 0;
                table.setRowSelectionInterval(0, 0);
                changingEmployees = true;
                changeEmployee(0);
                changingEmployees = false;
            }

            table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = table.getSelectedRow();
                        if (selectedRow != -1 && table.convertRowIndexToModel(selectedRow) != currentRow)
                        {
                            if (!changingEmployees)
                            {
                                changingEmployees = true;
                                changeEmployee(selectedRow);
                                changingEmployees = false;
                            }
                        }
                    }
                }
            });
            processFilter();
        }
    }
    
    public void changeEmployee(int selectedRow)
    {
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        updateDatabase();
        currentRow = table.convertRowIndexToModel(selectedRow);
    }
    
    private void clearFilter()
    {
        filterEnabled = false;
        filterColumnComboBox.setSelectedIndex(0);
        filterTextField.setText("");
        filterEnabled = true;
    }
    
    private void processFilter()
    {
        if (table == null || !worker.isDone() || !filterEnabled)
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> textFilter;
        RowFilter<CustomTableModel, Object> dateFilter = null;
        RowFilter<CustomTableModel, Object> inputFilter;
        RowFilter<CustomTableModel, Object> employeeStatusFilter;
        
        try
        {
            if (filterColumn == -1)
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
                }
            }
            else
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText(), filterColumn);
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()), filterColumn);
                }
            }

            employeeStatusFilter = RowFilter.regexFilter(employeeStatusFilterText, idx_ERROR_FLAG);
            
            inputFilters.add(textFilter);
            if (dateFilter != null)
            {
                inputFilters.add(dateFilter);
            }
            inputFilter = RowFilter.orFilter(inputFilters);
            
            filters.add(inputFilter);
            filters.add(employeeStatusFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
        }
    }
    
    private void updateDatabase()
    {
        if (table == null)
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        int selectedRow = table.getSelectedRow();
        if (employeeUpdated)
        {
            setCursor(Constants.HOURGLASS);
            Oracle.updateMURosterIssuesINFOR(getFormComponent(),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_FEEDER)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_SITE)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_MU)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPID)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_AGENTID)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPLOYEE)),
                (Date)dataModel.getValueAt(currentRow, idx_START_DATE),
                (Date)dataModel.getValueAt(currentRow, idx_END_DATE),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_STATUS)),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_DO_NOT_IMPORT)),
                Misc.objectToInt(dataModel.getValueAt(currentRow, idx_ERROR_FLAG)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_ERROR)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_MESSAGE))
            );
            setCursor(Constants.NORMAL);
            employeeUpdated = false;
            currentRow = table.convertRowIndexToModel(selectedRow);
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        formClosing = true;
        if (table != null && table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        updateDatabase();
        Oracle.updateNewErrorFlag(getFormComponent(), feeder, site);
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JPanel controlPanel2;
    private javax.swing.JButton employeeHistoryButton;
    private javax.swing.JScrollPane employeesScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JButton filterClearButton;
    private javax.swing.JLabel filterClearLabel;
    private javax.swing.JComboBox<String> filterColumnComboBox;
    private javax.swing.JLabel filterColumnTextLabel;
    private javax.swing.JComboBox<String> filterEmployeeStatusComboBox;
    private javax.swing.JLabel filterEmployeeStatusLabel;
    private javax.swing.JPanel filterLabelsPanel;
    private javax.swing.JTextField filterTextField;
    private javax.swing.JLabel filterTextLabel;
    private javax.swing.JPanel filtersPanel;
    private javax.swing.JPanel gridPanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JButton printButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel1;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton updateAllNewEmpButton;
    private javax.swing.JButton updateNewEmpButton;
    // End of variables declaration//GEN-END:variables
}
