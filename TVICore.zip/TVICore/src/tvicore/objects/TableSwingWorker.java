package tvicore.objects;

import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.SwingWorker;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;

/**
 * Used to create a JTable with minimal interruption on the GUI.
 * Lengthy tasks are run on a background worker thread, and only necessary code is run on the EDT.
 * 
 * ---
 * To check if worker is currently running, call worker.isDone() - Returns true if completed. Completion may be due to normal termination, an exception, or cancellation.
 * --- Cancelling ---
 * To cancel call worker.cancel(true) - if the worker is cancelled and has not been executed yet, it will never run.
 * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefreshMethod on the EDT
 * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefreshMethod in-line.  If you want it to instead be enqueued to the EDT, put it in an invokeLater block.
 */
public class TableSwingWorker extends SwingWorker<CustomTableModel, Object[]>
{
    Component parentFrame;
    private final CustomTableModel tableModel;
    private final Supplier<ResultSetWrapper> getResultsMethod;
    private final Function<ResultSet, Object[]> processResultsFunc;
    private final Consumer<Boolean> finalizeRefreshMethod;
    private final CountDownLatch latch;
    private boolean latchReleased = false;
    private boolean isWorking = false;
    
    public TableSwingWorker(Component parentFrame, CustomTableModel tableModel, Supplier<ResultSetWrapper> getResultsMethod, Function<ResultSet, Object[]> processResultsFunc, Consumer<Boolean> finalizeRefreshMethod)
    {
        this.parentFrame = parentFrame;
        this.tableModel = tableModel;
        this.getResultsMethod = getResultsMethod;
        this.processResultsFunc = processResultsFunc;
        this.finalizeRefreshMethod = finalizeRefreshMethod;
        this.latch = null;
    }
    
    // constructor that accepts an optional additional parameter, latch
    public TableSwingWorker(Component parentFrame, CustomTableModel tableModel, Supplier<ResultSetWrapper> getResultsMethod, Function<ResultSet, Object[]> processResultsFunc, Consumer<Boolean> finalizeRefreshMethod, CountDownLatch latch)
    {
        this.parentFrame = parentFrame;
        this.tableModel = tableModel;
        this.getResultsMethod = getResultsMethod;
        this.processResultsFunc = processResultsFunc;
        this.finalizeRefreshMethod = finalizeRefreshMethod;
        this.latch = latch;
    }
    
    /**
    * Background task to run on worker thread (not on the EDT)
    * Calls getResultsMethod to get the results from the database
    * Then iterates through the ResultSet, calling processResultsFunc(rs) to publish one row at a time (as an Object[] array)
    * Once done, closes the ResultSet and CallableStatement.
    * 
    * @return CustomTableModel
    * @throws Exception
    */
    @Override
    protected CustomTableModel doInBackground()
    {
        ResultSetWrapper results = null;
        
        try
        {
            isWorking = true;
            results = getResultsMethod.get();
            ResultSet rs = results.getResultSet();
            try
            {
                while (!isCancelled() && rs.next())
                {
                    Object[] data = processResultsFunc.apply(rs);
                    publish(data);
                }
            }
            catch (SQLException ex)
            {
                this.cancel(true);
                Misc.errorMsgDatabase(parentFrame, ex, true, "A database access error has occurred");
            }
        }
        finally
        {
            if (results != null)
            {
                results.close();
            }
            isWorking = false;
            releaseLatch();
        }
        return tableModel;
    }
    
    /**
    * Receives data chunks from the publish method asynchronously on the Event Dispatch Thread.
    * Because this method is invoked asynchronously, publish() may have been called multiple times.
    * Adds the published rows to the tableModel.
    * 
    * @param chunks
    */
    @Override
    protected void process(List<Object[]> chunks)
    {
        tableModel.addRows(chunks);
    }
    
    /**
    * Executes on the Event Dispatch Thread after the doInBackground method is finished, or if the worker is cancelled before finishing.
    * Calls finalizeRefreshMethod(isCancelled).
    */
    @Override
    protected void done()
    {
        if (isCancelled())
        {
            releaseLatch();
        }
        finalizeRefreshMethod.accept(isCancelled());
    }
    
    /**
     * If a latch exists and still needs to be released, and doInBackground() isn't currently running, then releases the latch
     */
    private void releaseLatch()
    {
        if (latch != null && !latchReleased && !isWorking)
        {
            latch.countDown();
            latchReleased = true;
        }
    }
}