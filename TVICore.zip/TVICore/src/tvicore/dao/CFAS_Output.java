package tvicore.dao;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tvicore.miscellaneous.Misc;
import tvicore.objects.CustomTableModel;

public class CFAS_Output
{
    private final List<CFAS_Output_Record_Container> results;
    
    public CFAS_Output()
    {
        results = new ArrayList<>();
    }
    
    public CustomTableModel processResults(Component parentFrame, String feeder, String site, String sbcid)
    {
        CustomTableModel errorData = new CustomTableModel(new String[]{"EMPID", "Month", "Error Message"});
        List<String> errorList = new ArrayList<>();
        
        for (int i = 0; i < results.size(); i++)
        {
            CFAS_Output_Record result = results.get(i).getRecord();
            if (Misc.objectEquals(result.x_error_flag, "Y"))
            {
                String empid = result.x_sbc_uid.toString();
                String err_msg = result.errors[0].error_message.toString();
                Date endDate = Misc.stringToDate(parentFrame, result.x_gl_period_end_date.toString(), "dd-MMM-yy");
                if (!errorList.contains(empid))
                {
                    errorList.add(empid);
                    errorData.addRow(new Object[]{empid, endDate, err_msg});
                }
            }
        }
        
        String errorListCSV = Misc.listToStringCSV(errorList);
        Oracle.validateAllocations(parentFrame, feeder, site, errorListCSV, sbcid);
        
        return errorData;
    }
}

class CFAS_Output_Record_Container
{
    public final CFAS_Output_Record rec;
    
    public CFAS_Output_Record getRecord() { return rec; }
    
    public CFAS_Output_Record_Container(CFAS_Output_Record rec)
    {
        this.rec = rec;
    }
}
