package tvi.gui;

import java.awt.Component;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultListModel;
import tvi.client_main.Main;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportSchedulesUpdateMonthly extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ImportSchedulesUpdateMonthly instance;
    
    private final String feeder;
    private final String site;
    
    Date firstPriorStartDate;
    Date secondPriorStartDate;
    Date firstCurrentStartDate;
    Date secondCurrentStartDate;
    
    Date firstPriorEndDate;
    Date secondPriorEndDate;
    Date firstCurrentEndDate;
    Date secondCurrentEndDate;
    
    Date startDate;
    Date endDate;
    
    public synchronized static ImportSchedulesUpdateMonthly getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportSchedulesUpdateMonthly(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportSchedulesUpdateMonthly(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        updateSelection();
        
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            if (!Misc.isAlpha(s.substring(0, 1)))
            {
                modelr.addElement(s);
            }
        }
        importSchedules.setModel(modelr);
        if (importSchedules.getModel().getSize() > 0)
        {
            importSchedules.setSelectionInterval(0, importSchedules.getModel().getSize() - 1);
        }
        
        /***********************************************************************
        * Initialize dates & labels
        ***********************************************************************/
        firstPriorStartDate = Oracle.getPreviousPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        firstPriorEndDate = Misc.dateAddDays(firstPriorStartDate, 14);
        secondPriorStartDate = Misc.dateAddDays(firstPriorEndDate, 1);
        secondPriorEndDate = Oracle.getPreviousPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        firstCurrentStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        firstCurrentEndDate = Misc.dateAddDays(firstCurrentStartDate, 14);
        secondCurrentStartDate = Misc.dateAddDays(firstCurrentEndDate, 1);
        secondCurrentEndDate = RegionData.getPayClose();
        
        startDate = firstPriorStartDate;
        endDate = firstPriorEndDate;
        
        firstPriorLabel.setText("(" + Misc.dateToStringMDY(firstPriorStartDate) + " - " + Misc.dateToStringMDY(firstPriorEndDate) + ")");
        secondPriorLabel.setText("(" + Misc.dateToStringMDY(secondPriorStartDate) + " - " + Misc.dateToStringMDY(secondPriorEndDate) + ")");
        firstCurrentLabel.setText("(" + Misc.dateToStringMDY(firstCurrentStartDate) + " - " + Misc.dateToStringMDY(firstCurrentEndDate) + ")");
        secondCurrentLabel.setText("(" + Misc.dateToStringMDY(secondCurrentStartDate) + " - " + Misc.dateToStringMDY(secondCurrentEndDate) + ")");
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Date curDate = Misc.dateAddCustom(Misc.dateNoTime(RegionData.getPayClose()), Calendar.MONTH, 1);
        for (int i = 0; i < 70; i++)
        {
            pickDateStart.addItem(Misc.dateToStringMDY(curDate));
            pickDateEnd.addItem(Misc.dateToStringMDY(curDate));
            curDate = Misc.dateAddDays(curDate, -1);
        }
        
        Date startDateCurrent = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
        
        pickDateStart.setSelectedItem(Misc.dateToStringMDY(startDateCurrent));
        pickDateEnd.setSelectedItem(Misc.dateToStringMDY(endDate));
        pickDateStart.setEditable(true);
        pickDateEnd.setEditable(true);
    }
    
    private void closeForm()
    {
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        reportSelectionGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        subtitltePanel = new javax.swing.JPanel();
        subtitleLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        muSelectionPanel = new javax.swing.JPanel();
        muSelectionLabel = new javax.swing.JLabel();
        importSchedulesPane = new javax.swing.JScrollPane();
        importSchedules = new javax.swing.JList<>();
        datePanel = new javax.swing.JPanel();
        selectionPanel = new javax.swing.JPanel();
        importSelectionPanel = new javax.swing.JPanel();
        firstPriorRadial = new javax.swing.JRadioButton();
        secondPriorRadial = new javax.swing.JRadioButton();
        firstCurrentRadial = new javax.swing.JRadioButton();
        secondCurrentRadial = new javax.swing.JRadioButton();
        customDateRadial = new javax.swing.JRadioButton();
        importLabelPanel = new javax.swing.JPanel();
        firstPriorLabel = new javax.swing.JLabel();
        secondPriorLabel = new javax.swing.JLabel();
        firstCurrentLabel = new javax.swing.JLabel();
        secondCurrentLabel = new javax.swing.JLabel();
        customDateLabel = new javax.swing.JLabel();
        customDatePanel = new javax.swing.JPanel();
        pickDateStart = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        pickDateEnd = new javax.swing.JComboBox<>();
        exitPanel = new javax.swing.JPanel();
        importSchedulesButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Import Recent Changes");
        setMinimumSize(new java.awt.Dimension(600, 500));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(100, 80));
        topPanel.setPreferredSize(new java.awt.Dimension(100, 120));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Import IEX Updates");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        topPanel.add(titleLabel);

        subtitltePanel.setBackground(new java.awt.Color(120, 200, 200));
        subtitltePanel.setPreferredSize(new java.awt.Dimension(600, 50));
        subtitltePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 10));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("This will import only the updates in IEX for the selected schedules.");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(400, 15));
        subtitltePanel.add(subtitleLabel);

        topPanel.add(subtitltePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(485, 180));
        centerPanel.setPreferredSize(new java.awt.Dimension(520, 180));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 0));

        muSelectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        muSelectionPanel.setPreferredSize(new java.awt.Dimension(60, 240));
        muSelectionPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        muSelectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        muSelectionLabel.setText("MU:");
        muSelectionLabel.setPreferredSize(new java.awt.Dimension(60, 20));
        muSelectionPanel.add(muSelectionLabel);

        importSchedulesPane.setPreferredSize(new java.awt.Dimension(60, 150));

        importSchedulesPane.setViewportView(importSchedules);

        muSelectionPanel.add(importSchedulesPane);

        centerPanel.add(muSelectionPanel);

        datePanel.setBackground(new java.awt.Color(120, 200, 200));
        datePanel.setPreferredSize(new java.awt.Dimension(400, 240));
        datePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        selectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        selectionPanel.setPreferredSize(new java.awt.Dimension(400, 170));
        selectionPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        importSelectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        importSelectionPanel.setPreferredSize(new java.awt.Dimension(240, 200));
        importSelectionPanel.setLayout(new java.awt.GridLayout(6, 0));

        firstPriorRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(firstPriorRadial);
        firstPriorRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        firstPriorRadial.setSelected(true);
        firstPriorRadial.setText("1st Half of Prior Payroll");
        firstPriorRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        firstPriorRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        firstPriorRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        firstPriorRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstPriorRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(firstPriorRadial);

        secondPriorRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(secondPriorRadial);
        secondPriorRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        secondPriorRadial.setText("2nd Half of Prior Payroll");
        secondPriorRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        secondPriorRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        secondPriorRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        secondPriorRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondPriorRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(secondPriorRadial);

        firstCurrentRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(firstCurrentRadial);
        firstCurrentRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        firstCurrentRadial.setText("1st Half of Current Payroll");
        firstCurrentRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        firstCurrentRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        firstCurrentRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        firstCurrentRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstCurrentRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(firstCurrentRadial);

        secondCurrentRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(secondCurrentRadial);
        secondCurrentRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        secondCurrentRadial.setText("2nd Half of Current Payroll");
        secondCurrentRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        secondCurrentRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        secondCurrentRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        secondCurrentRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondCurrentRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(secondCurrentRadial);

        customDateRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(customDateRadial);
        customDateRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        customDateRadial.setText("Custom Date Range:");
        customDateRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        customDateRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        customDateRadial.setPreferredSize(new java.awt.Dimension(160, 30));
        customDateRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customDateRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(customDateRadial);

        selectionPanel.add(importSelectionPanel);

        importLabelPanel.setBackground(new java.awt.Color(120, 200, 200));
        importLabelPanel.setPreferredSize(new java.awt.Dimension(160, 200));
        importLabelPanel.setLayout(new java.awt.GridLayout(6, 0));

        firstPriorLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        firstPriorLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        firstPriorLabel.setText("(01/01/2015 - 01/15/2015)");
        importLabelPanel.add(firstPriorLabel);

        secondPriorLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        secondPriorLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        secondPriorLabel.setText("(01/16/2015 - 01/31/2015)");
        importLabelPanel.add(secondPriorLabel);

        firstCurrentLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        firstCurrentLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        firstCurrentLabel.setText("(02/01/2015 - 02/15/2015)");
        importLabelPanel.add(firstCurrentLabel);

        secondCurrentLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        secondCurrentLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        secondCurrentLabel.setText("(02/16/2015 - 02/28/2015)");
        importLabelPanel.add(secondCurrentLabel);

        customDateLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        customDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        customDateLabel.setText("(Must be 15 days or less)");
        importLabelPanel.add(customDateLabel);

        selectionPanel.add(importLabelPanel);

        datePanel.add(selectionPanel);

        customDatePanel.setBackground(new java.awt.Color(120, 200, 200));
        customDatePanel.setPreferredSize(new java.awt.Dimension(400, 40));

        pickDateStart.setPreferredSize(new java.awt.Dimension(110, 25));
        customDatePanel.add(pickDateStart);

        jLabel2.setText("-");
        customDatePanel.add(jLabel2);

        pickDateEnd.setPreferredSize(new java.awt.Dimension(110, 25));
        customDatePanel.add(pickDateEnd);

        datePanel.add(customDatePanel);

        centerPanel.add(datePanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setMinimumSize(new java.awt.Dimension(100, 100));
        exitPanel.setPreferredSize(new java.awt.Dimension(100, 100));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 20));

        importSchedulesButton.setBackground(new java.awt.Color(120, 200, 200));
        importSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        importSchedulesButton.setText("Import Updates");
        importSchedulesButton.setPreferredSize(new java.awt.Dimension(150, 60));
        importSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importSchedulesButtonActionPerformed(evt);
            }
        });
        exitPanel.add(importSchedulesButton);

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(150, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitPanel.add(exitButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void importSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importSchedulesButtonActionPerformed
        List<String> muList = importSchedules.getSelectedValuesList();
        if (muList.size() < 1)
        {
            Misc.msgbox(getFormComponent(), "You must select an MU from the list!", "Import Schedules", 1, 1, 1);
            return;
        }
        else if (muList.size() >= 1)
        {
            if (firstPriorRadial.isSelected())
            {
                startDate = firstPriorStartDate;
                endDate = firstPriorEndDate;
            }
            else if (secondPriorRadial.isSelected())
            {
                startDate = secondPriorStartDate;
                endDate = secondPriorEndDate;
            }
            else if (firstCurrentRadial.isSelected())
            {
                startDate = firstCurrentStartDate;
                endDate = firstCurrentEndDate;
            }
            else if (secondCurrentRadial.isSelected())
            {
                startDate = secondCurrentStartDate;
                endDate = secondCurrentEndDate;
            }
            else if (customDateRadial.isSelected())
            {
                startDate = Misc.stringToDateMDY(getFormComponent(), pickDateStart.getSelectedItem().toString());
                endDate = Misc.stringToDateMDY(getFormComponent(), pickDateEnd.getSelectedItem().toString());
                if (startDate == null || endDate == null)
                {
                    return;
                }
                if (endDate.getTime() - startDate.getTime() > (14 * 24 * 60 * 60 * 1000))
                {
                    Misc.msgbox(getFormComponent(), "Cannot import changes, date range must be 15 days or less.", "Cannot retrieve records.", 1, 1, 1);
                    return;
                }
            }
            
            Calendar cal = Calendar.getInstance();
            cal.setTime(Misc.dateNoTime(Oracle.getCurTimeLocal(this)));
            cal.add(Calendar.YEAR, -1);
            Date lastYear = cal.getTime();
            if (startDate.compareTo(lastYear) < 0)
            {
                Misc.msgbox(getFormComponent(), "Cannot import changes, start date is more than a year old.", "Cannot retrieve records.", 1, 1, 1);
                return;
            }
            
            for (String mu : importSchedules.getSelectedValuesList())
            {
                boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
                if (okToImport)
                {
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
                }
                if (!okToImport)
                {
                    return;
                }
                
                if (Oracle.areAnySchedulesRestricted(getFormComponent(), feeder, site, mu, startDate, endDate))
                {
                    Misc.msgbox(getFormComponent(), "Cannot import changes, at least one of the schedules in the current or previous pay period for mu " + mu + " has locked records.", "Cannot retrieve all records.", 1, 1, 1);
                    return;
                }
                else if (Oracle.areAnyRecordsLocked(getFormComponent(), feeder, site, mu, "ALL", startDate, endDate))
                {
                    Misc.msgbox(getFormComponent(), "Cannot import changes, at least one of the records in the current or previous pay period for mu " + mu + " is currently in use.", "Cannot retrieve all records.", 1, 1, 1);
                    return;
                }
                
                Oracle.requestSchedule(getFormComponent(), feeder, site, mu, startDate, endDate, "UPDATE", UserData.getUUID());
            }
        }
        
        Schedules.refreshInstance();
        closeForm();
    }//GEN-LAST:event_importSchedulesButtonActionPerformed

    private void firstPriorRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstPriorRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_firstPriorRadialActionPerformed

    private void secondPriorRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondPriorRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_secondPriorRadialActionPerformed

    private void firstCurrentRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstCurrentRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_firstCurrentRadialActionPerformed

    private void secondCurrentRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondCurrentRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_secondCurrentRadialActionPerformed

    private void customDateRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customDateRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_customDateRadialActionPerformed
    
    private void updateSelection()
    {
        pickDateStart.setEnabled(customDateRadial.isSelected());
        pickDateEnd.setEnabled(customDateRadial.isSelected());
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel centerPanel;
    private javax.swing.JLabel customDateLabel;
    private javax.swing.JPanel customDatePanel;
    private javax.swing.JRadioButton customDateRadial;
    private javax.swing.JPanel datePanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JLabel firstCurrentLabel;
    private javax.swing.JRadioButton firstCurrentRadial;
    private javax.swing.JLabel firstPriorLabel;
    private javax.swing.JRadioButton firstPriorRadial;
    private javax.swing.JPanel importLabelPanel;
    private javax.swing.JList<String> importSchedules;
    private javax.swing.JButton importSchedulesButton;
    private javax.swing.JScrollPane importSchedulesPane;
    private javax.swing.JPanel importSelectionPanel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel muSelectionLabel;
    private javax.swing.JPanel muSelectionPanel;
    private javax.swing.JComboBox<String> pickDateEnd;
    private javax.swing.JComboBox<String> pickDateStart;
    private javax.swing.ButtonGroup reportSelectionGroup;
    private javax.swing.JLabel secondCurrentLabel;
    private javax.swing.JRadioButton secondCurrentRadial;
    private javax.swing.JLabel secondPriorLabel;
    private javax.swing.JRadioButton secondPriorRadial;
    private javax.swing.JPanel selectionPanel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JPanel subtitltePanel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}