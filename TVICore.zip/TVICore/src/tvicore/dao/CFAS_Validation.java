package tvicore.dao;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import tvicore.miscellaneous.Misc;
import tvicore.objects.CustomTableModel;

public class CFAS_Validation
{
    public static CustomTableModel validate(Component parentFrame, String feeder, String site, String sbcid)
    {
        CustomTableModel errorData = null;
        CFAS_Input cfasInput = new CFAS_Input();
        ResultSetWrapper results = Oracle.getCFASValidationRecords(parentFrame, feeder, site);
        ResultSet rs = results.getResultSet();
        
        try
        {
            if (!rs.next())
            {
                return errorData; // if the resultset is empty, there is nothing to validate
            }
            else
            {
                do
                {
                    cfasInput.addRecord(new CFAS_Input_Record
                    (
                        rs.getString("TRANSACTION_DATE"),
                        rs.getString("ACCOUNTING_PERIOD"),
                        rs.getString("LOCATION_CODE"),
                        rs.getString("RCO"),
                        rs.getString("RCC"),
                        rs.getString("FRC"),
                        rs.getString("FUNCTION_CODE"),
                        rs.getString("CA_ACTIVITY_CODE"),
                        rs.getString("PROJECT_NUMBER"),
                        rs.getString("EXPENDITURE_ITEM_DATE"),
                        rs.getString("HRS_QUANTITY"),
                        rs.getString("SBC_UID")
                    ));
                }
                while (rs.next());
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error validating allocations - creating input data.");
            return errorData;
        }
        finally
        {
            results.close();
        }
        
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String inputJSON = gson.toJson(cfasInput);
        
        String outputJSON = executePost(parentFrame, "https://clph529.sldc.sbc.com:8080/ords/apps/swcs_rest_wrapper/swcs_common_edit", inputJSON);
        //String outputJSON = executePost(parentFrame, "https://cldh036.sldc.sbc.com:8443/ords/apps/swcs_rest_wrapper/swcs_common_edit", inputJSON);
        if (outputJSON != null)
        {
            try
            {
                CFAS_Output response = gson.fromJson(outputJSON, CFAS_Output.class);
                errorData = response.processResults(parentFrame, feeder, site, sbcid);
            }
            catch (JsonSyntaxException ex)
            {
                Misc.errorMsgDefault(parentFrame, ex, "Error validating allocations - processing ICE API response.");
            }
        }
        return errorData;
    }
    
    public static String executePost(Component parentFrame, String targetURL, String requestJSON)
    {
        HttpURLConnection connection = null;
        InputStream is = null;
        
        try
        {
            // Create connection
            URL url = new URL(targetURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setConnectTimeout(30000);// 30 seconds
            connection.setReadTimeout(600000); // 600 seconds
            //connection.setRequestProperty("Authorization", APIKEY);
            //connection.setRequestProperty("Content-Length", Integer.toString(requestJSON.getBytes().length));
            //connection.setRequestProperty("Content-Language", "en-US");
            connection.setUseCaches(false);
            connection.setDoOutput(true);
            
            // Send request
            try (DataOutputStream wr = new DataOutputStream(connection.getOutputStream()))
            {
                wr.write(requestJSON.getBytes());
                //wr.writeBytes(requestJSON);
                
                Integer responseCode = connection.getResponseCode();
                //System.out.println(responseCode);
            }
            catch (IOException ex)
            {
                throw ex;
            }
            
            // Get Response
            try
            {
                is = connection.getInputStream();
            }
            catch (IOException ex)
            {
                if (connection instanceof HttpURLConnection)
                {
                    HttpURLConnection httpConn = (HttpURLConnection) connection;
                    int statusCode = httpConn.getResponseCode();
                    if (statusCode != 200)
                    {
                        is = httpConn.getErrorStream();
                    }
                }
            }
            
            StringBuilder response;
            try (BufferedReader rd = new BufferedReader(new InputStreamReader(is)))
            {
                response = new StringBuilder();
                String line;
                while ((line = rd.readLine()) != null)
                {
                    response.append(line);
                    response.append('\r');
                }
            }
            catch (IOException ex)
            {
                throw ex;
            }
            return response.toString();
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(parentFrame, ex, "Error executing ICE API call.");
            return null;
        }
        finally
        {
            if (connection != null)
            {
                connection.disconnect();
            }
        }
    }
}
