package tvi.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import tvi.client_main.Main;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportSchedulesFuture extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ImportSchedulesFuture instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    final static int idx_MU = 0;
    
    ArrayList<Integer> musChanged = new ArrayList<>();
    
    Calendar cal = Calendar.getInstance();
    
    Date lastStartDate;
    Date thisStartDate;
    Date nextStartDate;
    Date afterNextStartDate;
    
    Date lastEndDate;
    Date thisEndDate;
    Date nextEndDate;
    Date afterNextEndDate;
    
    public synchronized static ImportSchedulesFuture getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportSchedulesFuture(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportSchedulesFuture(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        musChanged.clear();
        /***********************************************************************
        * Initialize dates & labels
        ***********************************************************************/
        Date today = Misc.dateNoTime(Oracle.getCurTimeLocal(getFormComponent()));
        nextStartDate = Misc.getNextDayOfWeek(today, RegionData.getFirstDayOfWeek(), false);
        thisStartDate = Misc.dateAddDays(nextStartDate, -7);
        lastStartDate = Misc.dateAddDays(thisStartDate, -7);
        lastEndDate = Misc.dateAddDays(thisStartDate, -1);
        thisEndDate = Misc.dateAddDays(thisStartDate, 6);
        nextEndDate = Misc.dateAddDays(thisStartDate, 13);
        afterNextStartDate = Misc.dateAddDays(thisStartDate, 14);
        afterNextEndDate = Misc.dateAddDays(thisStartDate, 20);
        
        lastWeekLabel.setText("(" + Misc.dateToStringMDY(lastStartDate) + " - " + Misc.dateToStringMDY(lastEndDate) + ")");
        thisWeekLabel.setText("(" + Misc.dateToStringMDY(thisStartDate) + " - " + Misc.dateToStringMDY(thisEndDate) + ")");
        nextWeekLabel.setText("(" + Misc.dateToStringMDY(nextStartDate) + " - " + Misc.dateToStringMDY(nextEndDate) + ")");
        afterNextWeeksLabel.setText("(" + Misc.dateToStringMDY(afterNextStartDate) + " - " + Misc.dateToStringMDY(afterNextEndDate) + ")");
        
        thisWeekRadial.setSelected(true);
        thisWeekRadial.requestFocus();
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    muScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",                                    // idx_MU
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsFutureImportSettings(getFormComponent(), feeder, site);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU")                                             // idx_MU
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading future import settings.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                muScrollPane.setViewportView(table);
                if (table.getRowCount() > 0)
                {
                    table.changeSelection(0, 0, false, false);
                }
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_MU:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Action muAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    updateStartEndDates();
                    if (!musChanged.contains(table.getSelectedRow()))
                    {
                        musChanged.add(table.getSelectedRow());
                    }
                }
            };
            table.addPropertyChangeListener(new TableCellListener(table, muAction));
            Misc.configureTable(table, false, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_MU, 140);
            table.setRowHeight(20);
            table.setFocusable(false);
            
            table.getSelectionModel().addListSelectionListener (new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        updateStartEndDates();
                    }
                }
            });
        }
    }
    
    private void updateStartEndDates()
    {
        Date today = Misc.dateNoTime(Oracle.getCurTimeLocal(getFormComponent()));
        nextStartDate = Misc.getNextDayOfWeek(today, RegionData.getFirstDayOfWeek(), false);
        thisStartDate = Misc.dateAddDays(nextStartDate, -7);
        lastStartDate = Misc.dateAddDays(thisStartDate, -7);
        lastEndDate = Misc.dateAddDays(thisStartDate, -1);
        thisEndDate = Misc.dateAddDays(thisStartDate, 6);
        nextEndDate = Misc.dateAddDays(thisStartDate, 13);
        afterNextStartDate = Misc.dateAddDays(thisStartDate, 14);
        afterNextEndDate = Misc.dateAddDays(thisStartDate, 20);
        
        lastWeekLabel.setText("(" + Misc.dateToStringMDY(lastStartDate) + " - " + Misc.dateToStringMDY(lastEndDate) + ")");
        thisWeekLabel.setText("(" + Misc.dateToStringMDY(thisStartDate) + " - " + Misc.dateToStringMDY(thisEndDate) + ")");
        nextWeekLabel.setText("(" + Misc.dateToStringMDY(nextStartDate) + " - " + Misc.dateToStringMDY(nextEndDate) + ")");
        afterNextWeeksLabel.setText("(" + Misc.dateToStringMDY(afterNextStartDate) + " - " + Misc.dateToStringMDY(afterNextEndDate) + ")");
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        reportSelectionGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        subtitltePanel = new javax.swing.JPanel();
        subtitleLabel = new javax.swing.JLabel();
        subtitleLabel3 = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        muPanel = new javax.swing.JPanel();
        muScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        importSelectionPanel = new javax.swing.JPanel();
        lastWeekRadial = new javax.swing.JRadioButton();
        thisWeekRadial = new javax.swing.JRadioButton();
        nextWeekRadial = new javax.swing.JRadioButton();
        nextTwoWeeksRadial = new javax.swing.JRadioButton();
        importLabelPanel = new javax.swing.JPanel();
        lastWeekLabel = new javax.swing.JLabel();
        thisWeekLabel = new javax.swing.JLabel();
        nextWeekLabel = new javax.swing.JLabel();
        afterNextWeeksLabel = new javax.swing.JLabel();
        exitPanel = new javax.swing.JPanel();
        importSchedulesButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Import Future Schedules");
        setMinimumSize(new java.awt.Dimension(700, 450));
        setPreferredSize(new java.awt.Dimension(700, 540));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(100, 80));
        topPanel.setPreferredSize(new java.awt.Dimension(100, 150));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Import Future Schedules");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        topPanel.add(titleLabel);

        subtitltePanel.setBackground(new java.awt.Color(120, 200, 200));
        subtitltePanel.setMinimumSize(new java.awt.Dimension(1200, 80));
        subtitltePanel.setPreferredSize(new java.awt.Dimension(600, 80));
        subtitltePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 10));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("WARNING: Do NOT select a week where IEX schedules do not exist!");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(460, 15));
        subtitltePanel.add(subtitleLabel);

        subtitleLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel3.setText("Future imports will be flagged on the green screen with a dot (●) in a column marked 'F' for Future");
        subtitleLabel3.setPreferredSize(new java.awt.Dimension(550, 15));
        subtitltePanel.add(subtitleLabel3);

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("Note: This will not re-import a previously imported future schedule.");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(400, 15));
        subtitltePanel.add(subtitleLabel2);

        topPanel.add(subtitltePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(600, 240));
        centerPanel.setPreferredSize(new java.awt.Dimension(600, 240));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 10));

        muPanel.setBackground(new java.awt.Color(120, 200, 200));
        muPanel.setMinimumSize(new java.awt.Dimension(220, 250));
        muPanel.setPreferredSize(new java.awt.Dimension(220, 250));
        muPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        muScrollPane.setFocusable(false);
        muScrollPane.setMinimumSize(new java.awt.Dimension(160, 250));
        muScrollPane.setPreferredSize(new java.awt.Dimension(160, 250));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        muScrollPane.setViewportView(loadingLabel);

        muPanel.add(muScrollPane);

        centerPanel.add(muPanel);

        importSelectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        importSelectionPanel.setPreferredSize(new java.awt.Dimension(170, 180));
        importSelectionPanel.setLayout(new java.awt.GridLayout(4, 0));

        lastWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(lastWeekRadial);
        lastWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lastWeekRadial.setSelected(true);
        lastWeekRadial.setText("Import Last Week");
        lastWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        lastWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        lastWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        importSelectionPanel.add(lastWeekRadial);

        thisWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(thisWeekRadial);
        thisWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        thisWeekRadial.setText("Import Current Week");
        thisWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        thisWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        thisWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        importSelectionPanel.add(thisWeekRadial);

        nextWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(nextWeekRadial);
        nextWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nextWeekRadial.setText("Import Next Week");
        nextWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        nextWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        nextWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        importSelectionPanel.add(nextWeekRadial);

        nextTwoWeeksRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(nextTwoWeeksRadial);
        nextTwoWeeksRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nextTwoWeeksRadial.setText("Import Week After Next");
        nextTwoWeeksRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        nextTwoWeeksRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        nextTwoWeeksRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        importSelectionPanel.add(nextTwoWeeksRadial);

        centerPanel.add(importSelectionPanel);

        importLabelPanel.setBackground(new java.awt.Color(120, 200, 200));
        importLabelPanel.setPreferredSize(new java.awt.Dimension(160, 180));
        importLabelPanel.setLayout(new java.awt.GridLayout(4, 0));

        lastWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lastWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lastWeekLabel.setText("(01/25/2015 - 01/31/2015)");
        importLabelPanel.add(lastWeekLabel);

        thisWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        thisWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        thisWeekLabel.setText("(02/01/2015 - 02/07/2015)");
        importLabelPanel.add(thisWeekLabel);

        nextWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nextWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nextWeekLabel.setText("(02/08/2015 - 02/14/2015)");
        importLabelPanel.add(nextWeekLabel);

        afterNextWeeksLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        afterNextWeeksLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        afterNextWeeksLabel.setText("(02/15/2015 - 02/21/2015)");
        importLabelPanel.add(afterNextWeeksLabel);

        centerPanel.add(importLabelPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setMinimumSize(new java.awt.Dimension(100, 100));
        exitPanel.setPreferredSize(new java.awt.Dimension(100, 100));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 20));

        importSchedulesButton.setBackground(new java.awt.Color(120, 200, 200));
        importSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        importSchedulesButton.setText("Import Schedules");
        importSchedulesButton.setPreferredSize(new java.awt.Dimension(150, 60));
        importSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importSchedulesButtonActionPerformed(evt);
            }
        });
        exitPanel.add(importSchedulesButton);

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(150, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitPanel.add(exitButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void importSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importSchedulesButtonActionPerformed
        String mu = table.getValueAt(table.getSelectedRow(), idx_MU).toString();
        boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
        if (okToImport)
        {
            RegionData.updateSiteInfo(getFormComponent(), feeder, site);
            okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
        }
        if (!okToImport)
        {
            return;
        }
        if (Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site) != 0 && RegionData.getNewFeature())
        {
            Misc.msgbox(getFormComponent(), "Cannot import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
            return;
        }
        
        String sbcid = UserData.getUUID();
        if (lastWeekRadial.isSelected())
        {
            if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, lastStartDate, lastEndDate))
            {
                return;
            }
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu, lastStartDate, lastEndDate, "FUTURE", sbcid);
        }
        else if (thisWeekRadial.isSelected())
        {
            if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, thisStartDate, thisEndDate))
            {
                return;
            }
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu, thisStartDate, thisEndDate, "FUTURE", sbcid);
        }
        else if (nextWeekRadial.isSelected())
        {
            if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, nextStartDate, nextEndDate))
            {
                return;
            }
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu, nextStartDate, nextEndDate, "FUTURE", sbcid);
        }
        else if (nextTwoWeeksRadial.isSelected())
        {
            if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, afterNextStartDate, afterNextEndDate))
            {
                return;
            }
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu, afterNextStartDate, afterNextEndDate, "FUTURE", sbcid);
        }
        
        Schedules.refreshInstance();
        closeForm();
    }//GEN-LAST:event_importSchedulesButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel afterNextWeeksLabel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JPanel importLabelPanel;
    private javax.swing.JButton importSchedulesButton;
    private javax.swing.JPanel importSelectionPanel;
    private javax.swing.JLabel lastWeekLabel;
    private javax.swing.JRadioButton lastWeekRadial;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel muPanel;
    private javax.swing.JScrollPane muScrollPane;
    private javax.swing.JRadioButton nextTwoWeeksRadial;
    private javax.swing.JLabel nextWeekLabel;
    private javax.swing.JRadioButton nextWeekRadial;
    private javax.swing.ButtonGroup reportSelectionGroup;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel subtitleLabel3;
    private javax.swing.JPanel subtitltePanel;
    private javax.swing.JLabel thisWeekLabel;
    private javax.swing.JRadioButton thisWeekRadial;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}