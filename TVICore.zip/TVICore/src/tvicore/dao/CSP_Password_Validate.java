package tvicore.dao;

import java.net.*;
import java.util.*;
import java.io.*;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import tvicore.miscellaneous.Misc;

public class CSP_Password_Validate
{
    //PRIVATE CONSTANTS
    private static final String sPROTOCOL = "https";
    //private static final String sHOSTNAME = "webtest.csp.att.com";    //CSP DEVELOPMENT
    //private static final String sHOSTNAME = "webtest.stage.att.com";  //CSP DEVELOPMENT
    private static final String sHOSTNAME = "www.e-access.att.com";     //CSP PRODUCTION
    private static final String sPAGENAME = "/cspapiver3/";
    
    private static final int nFAILURE = 0;
    private static final int nSUCCESS = 1;
    private static final boolean bDEBUG = false;
    
    //PUBLIC CONSTANTS
    public static final String MALFORMED_URL_ERROR_STR = "MALFORMED URL ERROR ";
    public static final int    MALFORMED_URL_ERROR     = -20;
    public static final String IO_EXCEPTION_STR        = "IO EXCEPTION ";
    public static final int    IO_EXCEPTION            = -21;
    public static final String GENERAL_ERROR_STR       = "GENERAL EXCEPTION ";
    public static final int    GENERAL_ERROR           = -30;
    
    //PRIVATE VARIABLES
    private static final String sAppID       = "MOTS_8133_CCTATTTVI";
    private static final String sAppPassword = "cBKDsu5XrSvM8479";
    
    /**
     * makeXML
     * 
     * Returns an XML string that incorporates the provided parameters into a properly formatted CSP authenticate request.
     * @param sbcid the User ID requiring authentication
     * @param password the password that corresponds with the User ID requiring authentication
     * @param validateType type of validation to attempt, PASSCODE or PASSWORD
     * @return the properly formatted XML request for CSP validation
     */
    private String makeXML_OLD(String sbcid, String password, String validateType)
    {
        StringBuilder xml = new StringBuilder();
        xml.append("<?xml version=\"1.0\"?>");
        xml.append("<cspinput appID=\"");
        xml.append(sAppID);
        xml.append("\" appPassword=\"");
        xml.append(sAppPassword);
        xml.append("\"><account userid=\"");
        xml.append(sbcid);
        xml.append("\" action=\"authenticate\">");
        if (validateType.equals("PASSCODE")) //passcode
        {
            xml.append("<tokenPasscode>");
            xml.append(password);
            xml.append("</tokenPasscode>");
        }
        else //validateType.equals("PASSWORD")
        {
            xml.append("<password>");
            xml.append(password);
            xml.append("</password>");
        }
        xml.append("</account></cspinput>");

        return xml.toString();
    }
    
    /**
     * makeXML
     * 
     * Returns an XML string that incorporates the provided parameters into a properly formatted CSP authenticate request.
     * @param sbcid the User ID requiring authentication
     * @param password the password that corresponds with the User ID requiring authentication
     * @param validateType type of validation to attempt, PASSCODE or PASSWORD
     * @return the properly formatted XML request for CSP validation
     */
    private String makeXML(String sbcid, String password, String validateType)
    {
        Document document = DocumentHelper.createDocument();
        
        Element root = document.addElement("cspinput");
        root.addAttribute("appID", sAppID);
        root.addAttribute("appPassword", sAppPassword);
        
        Element account = root.addElement("account");
        account.addAttribute("userid", sbcid);
        account.addAttribute("action", "authenticate");
        
        if (validateType.equals("PASSCODE"))
        {
            account.addElement("tokenPasscode").addText(password);
        }
        else //validateType.equals("PASSWORD")
        {
            account.addElement("password").addText(password);
        }
        
        return document.asXML();
    }
    
    /**
    * Returns 1 if the User ID and password are validated by the CSP authentication system, 0 if not,
    * and negative numbers for various errors.  If bDEBUG is set to true this method will send output to the console.
    * @param sbcid the User ID requiring authentication
    * @param password the password that corresponds with the User ID requiring authentication
    * @param validateType type of validation to attempt, PASSCODE or PASSWORD
    * @return true if authenticated, false otherwise
    **/
    public int validate(String sbcid, String password, String validateType)
    {
        if (!checkParameters(sAppID, sAppPassword, sbcid, password))
        {
            return nFAILURE;
        }
        
        try
        {
            URL url = new URL(sPROTOCOL, sHOSTNAME, sPAGENAME);
            URLConnection url_con = url.openConnection();
            url_con.setDoInput(true);
            url_con.setDoOutput(true);
            url_con.setUseCaches(false);
            url_con.setRequestProperty("content-type", "application/x-www-form-urlencoded");
            
            String input_xml = makeXML(sbcid, password, validateType);
            
            if (bDEBUG)
            {
                System.out.println("\nINPUT XML------------------\n" + input_xml);
                System.out.println("\nEND INPUT XML--------------\n");
            }
            
            try (BufferedWriter writebuf = new BufferedWriter(new OutputStreamWriter(url_con.getOutputStream())))// relying on default encoding
            {
                writebuf.write("XMLData=");
                writebuf.write(URLEncoder.encode(input_xml, "UTF-8"));
                writebuf.flush();
            }
            
            HashMap<String, String> hm = parseResponse(url_con);
            
            if (bDEBUG)
            {
                System.out.println("CSP RETURN CODE      = " + hm.get("returnCode"));
                System.out.println("CSP VALIDATION VALUE = " + hm.get("returnValue"));
                System.out.println("CSP ERROR CODE       = " + hm.get("errorNumber"));
            }
            
            if (Misc.objectToString(hm.get("returnValue")).equals("T"))
            {
                return nSUCCESS;
            }
            else
            {
                return nFAILURE;
            }
        }
        
        catch (MalformedURLException e)
        {
            if (bDEBUG)
            {
                System.out.println(MALFORMED_URL_ERROR_STR + e.getMessage());
            }
            return MALFORMED_URL_ERROR;
        }
        catch (IOException e)
        {
            if (bDEBUG)
            {
                System.out.println(IO_EXCEPTION_STR + e.getMessage());
            }
            return IO_EXCEPTION;
        }
    }
    
    // Checks input parameters to validate method.
    private static boolean checkParameters(String sAppID, String sAppPassword, String sUserID, String sPassword)
    {
        boolean output = true;
        if ("".equals(sAppID.trim()))
        {
            if (bDEBUG)
            {
                System.out.println("Application ID is blank\n");
            }
            output = false;
        }
        if ("".equals(sAppPassword.trim()))
        {
            if (bDEBUG)
            {
                System.out.println("Application password is blank\n");
            }
            output = false;
        }
        if ("".equals(sUserID.trim()))
        {
            if (bDEBUG)
            {
                System.out.println("User ID is blank\n");
            }
            output = false;
        }
        if ("".equals(sPassword.trim()))
        {
            if (bDEBUG)
            {
                System.out.println("User password is blank\n");
            }
            output = false;
        }
        return output;
    }
    
    private static HashMap<String, String> parseResponse(URLConnection url_con) throws IOException
    {
        HashMap<String, String> hm = new HashMap<>();
        try (BufferedReader readbuf = new BufferedReader(new InputStreamReader(url_con.getInputStream())))// relying on default encoding
        {
            String line;
            boolean foundReturnCode = false;
            String returnCode = "";
            
            if (bDEBUG)
            {
                System.out.println("RESPONSE XML------------------");
            }
            while ((line = readbuf.readLine()) != null)
            {
                if (bDEBUG)
                {
                    System.out.println(line);
                }
                
                if (!foundReturnCode)
                {
                    // Get Return Code
                    int i = line.indexOf("returnCode=");
                    if (i > -1) // ReturnCode found
                    {
                        foundReturnCode = true;
                        returnCode = line.substring(i + 12, i + 13);
                        hm.put("returnCode", returnCode);
                        continue;
                    }
                }
                
                if (returnCode.equals("0")) // Return Code of Zero, get Answer
                {
                    int i = line.indexOf("returnValue");
                    if (i > -1) // Answer found
                    {
                        hm.put("returnValue", line.substring(i + 12, i + 13));
                        break;
                    }
                }
                else // Return Code is non-zero. look for error
                {
                    int i = line.indexOf("error code=");
                    if (i > -1) // Error Code found
                    {
                        hm.put("errorNumber", line.substring(i + 12, i + 18));
                        break;
                    }
                }
            }
        }
        
        if (bDEBUG)
        {
            System.out.println("END RESPONSE XML--------------\n");
        }
        return hm;
    }
}