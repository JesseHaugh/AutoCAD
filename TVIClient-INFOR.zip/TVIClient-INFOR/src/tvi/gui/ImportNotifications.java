package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportNotifications extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile ImportNotifications instance;
    
    private final String feeder;
    private final String site;
    private final String mu;
    private final Date reportingDate;
    private final String union;
    
    JTable transferredEmployeesTable = new JTable();
    JTable offDaysTable = new JTable();
    JTable duplicateEmployeesTable = new JTable();
    JTable inactiveEmployeesTable = new JTable();
    CustomTableModel transferredEmployeesDataModel;
    CustomTableModel offDaysDataModel;
    CustomTableModel duplicateEmployeesDataModel;
    CustomTableModel inactiveEmployeesDataModel;
    TableSwingWorker transferredEmployeesWorker;
    TableSwingWorker offDaysWorker;
    TableSwingWorker duplicateEmployeesWorker;
    TableSwingWorker inactiveEmployeesWorker;
    private static final Semaphore refreshImportTransferEmployeesLock = new Semaphore(1, true);
    private static final Semaphore refreshImportOffDaysLock = new Semaphore(1, true);
    private static final Semaphore refreshImportDuplicateEmployeesLock = new Semaphore(1, true);
    private static final Semaphore refreshImportInactiveEmployeesLock = new Semaphore(1, true);
    
    final static int idx_transferred_EMPLOYEE  = 0;
    final static int idx_transferred_EMPID     = 1;
    final static int idx_transferred_OLDMU     = 2;
    final static int idx_transferred_OLDSTATUS = 3;
    final static int idx_transferred_NEWMU     = 4;
    final static int idx_transferred_NEWSTATUS = 5;
    final static int idx_transferred_EFFDATE   = 6;
    final static int idx_transferred_PAYROLLID = 7;
    
    final static int idx_offdays_EMPLOYEE = 0;
    final static int idx_offdays_EMPID    = 1;
    final static int idx_offdays_AGENTID  = 2;
    final static int idx_offdays_NUMOFF   = 3;
    
    final static int idx_duplicate_EMPLOYEE = 0;
    final static int idx_duplicate_EMPID    = 1;
    
    final static int idx_inactive_AGENTID      = 0;
    final static int idx_inactive_EMPLOYEE     = 1;
    final static int idx_inactive_PROCESS_INFO = 2;
    
    private int numberOfTransferEmployees = 0;
    private int numberOfOffDays = 0;
    private int numberOfDuplicateEmployees = 0;
    private int numberOfInactiveEmployees = 0;
    
    private boolean transferredEmployeesChecked = true;
    private boolean offDaysChecked = true;
    private boolean duplicateEmployeesChecked = true;
    private boolean inactiveEmployeesChecked = true;
    
    public static boolean focusInstance()
    {
        if (instance != null)
        {
            instance.toFront();
        }
        return instance != null;
    }
    
    public synchronized static ImportNotifications getInstance(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String union, int numberOfTransferEmps, int numberOfOffDays, int numberOfDuplicateEmps, int numberOfInactiveEmps)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportNotifications(feeder, site, mu, reportingDate, union, numberOfTransferEmps, numberOfOffDays, numberOfDuplicateEmps, numberOfInactiveEmps);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportNotifications(String feeder, String site, String mu, Date reportingDate, String union, int numberOfTransferEmps, int numberOfOffDays, int numberOfDuplicateEmps, int numberOfInactiveEmps)
    {
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.reportingDate = reportingDate;
        this.union = union;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        feederSiteMuLabel.setText("Feeder: " + feeder + "    Site: " + site + "    MU: " + mu);
        reportingDateLabel.setText("Reporting Date: " + Misc.dateToStringMDY(reportingDate));
        
        this.numberOfTransferEmployees = numberOfTransferEmps;
        this.numberOfOffDays = numberOfOffDays;
        this.numberOfDuplicateEmployees = numberOfDuplicateEmps;
        this.numberOfInactiveEmployees = numberOfInactiveEmps;
        
        if (numberOfTransferEmps > 0)
        {
            transferredEmployeesChecked = false;
            transferredEmployeesButton.setEnabled(true);
        }
        if (numberOfOffDays > 0)
        {
            offDaysChecked = false;
            offDaysButton.setEnabled(true);
        }
        if (numberOfDuplicateEmps > 0)
        {
            duplicateEmployeesChecked = false;
            duplicateEmployeesButton.setEnabled(true);
        }
        if (numberOfInactiveEmps > 0)
        {
            inactiveEmployeesChecked = false;
            inactiveEmployeesButton.setEnabled(true);
        }
        
        // set initial screen to show
        transferredEmployeesPanel.setVisible(false);
        offDaysPanel.setVisible(false);
        duplicateEmployeesPanel.setVisible(false);
        inactiveEmployeesPanel.setVisible(false);
        if (numberOfTransferEmps > 0)
        {
            transferredEmployeesPanel.setVisible(true);
            transferredEmployeesChecked = true;
        }
        else if (numberOfOffDays > 0)
        {
            offDaysPanel.setVisible(true);
            offDaysChecked = true;
        }
        else if (numberOfDuplicateEmps > 0)
        {
            duplicateEmployeesPanel.setVisible(true);
            duplicateEmployeesChecked = true;
        }
        else if (numberOfInactiveEmps > 0)
        {
            inactiveEmployeesPanel.setVisible(true);
            inactiveEmployeesChecked = true;
        }
        
        hotlineLabel.setText("<html><center>If you need assistance, Email<br>TVI Support: " + Constants.EMAIL);
    }
    
    public static boolean exists()
    {
        return instance != null;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leftPanel = new javax.swing.JPanel();
        importNotificationsLabel = new javax.swing.JLabel();
        feederSitePanel = new javax.swing.JPanel();
        feederSiteMuLabel = new javax.swing.JLabel();
        reportingDateLabel = new javax.swing.JLabel();
        hotlineLabel = new javax.swing.JLabel();
        separator = new javax.swing.JSeparator();
        selectionLabel = new javax.swing.JLabel();
        buttonGridPanel = new javax.swing.JPanel();
        transferredEmployeesButton = new javax.swing.JButton();
        offDaysButton = new javax.swing.JButton();
        duplicateEmployeesButton = new javax.swing.JButton();
        inactiveEmployeesButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        rightPanel = new javax.swing.JPanel();
        workAreaPane = new javax.swing.JLayeredPane();
        transferredEmployeesPanel = new javax.swing.JPanel();
        transferredTopPanel = new javax.swing.JPanel();
        transferredTitleLabel = new javax.swing.JLabel();
        transferredNotesScrollPane = new javax.swing.JScrollPane();
        transferredNotesTextArea = new javax.swing.JTextArea();
        transferredCenterPanel = new javax.swing.JPanel();
        transferredTableScrollPane = new javax.swing.JScrollPane();
        transferredLoadingLabel = new javax.swing.JLabel();
        transferredBottomPanel = new javax.swing.JPanel();
        transferEmployeeButton = new javax.swing.JButton();
        transferAllEmployeesButton = new javax.swing.JButton();
        transferredPrintButton = new javax.swing.JButton();
        offDaysPanel = new javax.swing.JPanel();
        offDaysTopPanel = new javax.swing.JPanel();
        offDaysTitleLabel = new javax.swing.JLabel();
        offDaysNotesScrollPane = new javax.swing.JScrollPane();
        offDaysNotesTextArea = new javax.swing.JTextArea();
        offDaysCenterPanel = new javax.swing.JPanel();
        offDaysTableScrollPane = new javax.swing.JScrollPane();
        offDaysLoadingLabel = new javax.swing.JLabel();
        offDaysBottomPanel = new javax.swing.JPanel();
        offDaysInactivateEmployeeButton = new javax.swing.JButton();
        offDaysPrintButton = new javax.swing.JButton();
        duplicateEmployeesPanel = new javax.swing.JPanel();
        duplicateTopPanel = new javax.swing.JPanel();
        duplicateTitleLabel = new javax.swing.JLabel();
        duplicateNotesScrollPane = new javax.swing.JScrollPane();
        duplicateNotesTextArea = new javax.swing.JTextArea();
        duplicateCenterPanel = new javax.swing.JPanel();
        duplicateTableScrollPane = new javax.swing.JScrollPane();
        duplicateLoadingLabel = new javax.swing.JLabel();
        duplicateBottomPanel = new javax.swing.JPanel();
        duplicatePrintButton = new javax.swing.JButton();
        inactiveEmployeesPanel = new javax.swing.JPanel();
        inactiveTopPanel = new javax.swing.JPanel();
        inactiveTitleLabel = new javax.swing.JLabel();
        inactiveNotesScrollPane = new javax.swing.JScrollPane();
        inactiveNotesTextArea = new javax.swing.JTextArea();
        inactiveCenterPanel = new javax.swing.JPanel();
        inactiveTableScrollPane = new javax.swing.JScrollPane();
        inactiveLoadingLabel = new javax.swing.JLabel();
        inactiveBottomPanel = new javax.swing.JPanel();
        inactiveEmployeeMaintenanceButton = new javax.swing.JButton();
        inactivePrintButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("ImportNotifications");
        setMinimumSize(new java.awt.Dimension(1000, 720));
        setPreferredSize(new java.awt.Dimension(1000, 720));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        leftPanel.setBackground(new java.awt.Color(255, 255, 128));
        leftPanel.setPreferredSize(new java.awt.Dimension(260, 100));
        leftPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 15));

        importNotificationsLabel.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        importNotificationsLabel.setText("Import Notifications");
        leftPanel.add(importNotificationsLabel);

        feederSitePanel.setBackground(new java.awt.Color(255, 255, 128));
        feederSitePanel.setMaximumSize(new java.awt.Dimension(230, 60));
        feederSitePanel.setMinimumSize(new java.awt.Dimension(230, 60));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(230, 50));
        feederSitePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        feederSiteMuLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederSiteMuLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        feederSiteMuLabel.setText("Feeder, Site, MU");
        feederSiteMuLabel.setPreferredSize(new java.awt.Dimension(230, 20));
        feederSitePanel.add(feederSiteMuLabel);

        reportingDateLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        reportingDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reportingDateLabel.setText("Reporting Date:");
        reportingDateLabel.setPreferredSize(new java.awt.Dimension(230, 20));
        feederSitePanel.add(reportingDateLabel);

        leftPanel.add(feederSitePanel);

        hotlineLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        hotlineLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        hotlineLabel.setText("<html><center>If you need assistance,<br>email TVI Support [EMAIL]");
        leftPanel.add(hotlineLabel);

        separator.setBackground(new java.awt.Color(255, 255, 128));
        separator.setToolTipText("");
        separator.setPreferredSize(new java.awt.Dimension(240, 5));
        leftPanel.add(separator);

        selectionLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        selectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        selectionLabel.setText("Please review the following items:");
        selectionLabel.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        selectionLabel.setPreferredSize(new java.awt.Dimension(220, 20));
        leftPanel.add(selectionLabel);

        buttonGridPanel.setBackground(new java.awt.Color(255, 255, 128));
        buttonGridPanel.setPreferredSize(new java.awt.Dimension(240, 360));
        buttonGridPanel.setLayout(new java.awt.GridLayout(5, 0, 0, 10));

        transferredEmployeesButton.setBackground(new java.awt.Color(255, 255, 128));
        transferredEmployeesButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        transferredEmployeesButton.setText("Transferring Employees");
        transferredEmployeesButton.setEnabled(false);
        transferredEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferredEmployeesButtonActionPerformed(evt);
            }
        });
        buttonGridPanel.add(transferredEmployeesButton);

        offDaysButton.setBackground(new java.awt.Color(255, 255, 128));
        offDaysButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        offDaysButton.setText("Off Days");
        offDaysButton.setEnabled(false);
        offDaysButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offDaysButtonActionPerformed(evt);
            }
        });
        buttonGridPanel.add(offDaysButton);

        duplicateEmployeesButton.setBackground(new java.awt.Color(255, 255, 128));
        duplicateEmployeesButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        duplicateEmployeesButton.setText("Duplicate Employees");
        duplicateEmployeesButton.setEnabled(false);
        duplicateEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                duplicateEmployeesButtonActionPerformed(evt);
            }
        });
        buttonGridPanel.add(duplicateEmployeesButton);

        inactiveEmployeesButton.setBackground(new java.awt.Color(255, 255, 128));
        inactiveEmployeesButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        inactiveEmployeesButton.setText("Inactive Employees");
        inactiveEmployeesButton.setEnabled(false);
        inactiveEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inactiveEmployeesButtonActionPerformed(evt);
            }
        });
        buttonGridPanel.add(inactiveEmployeesButton);

        leftPanel.add(buttonGridPanel);

        exitButton.setBackground(new java.awt.Color(255, 255, 128));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("<html><center>Continue to<br>Time Reporting</html>");
        exitButton.setPreferredSize(new java.awt.Dimension(240, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        leftPanel.add(exitButton);

        getContentPane().add(leftPanel, java.awt.BorderLayout.WEST);

        rightPanel.setBackground(new java.awt.Color(0, 204, 153));
        rightPanel.setMinimumSize(new java.awt.Dimension(3500, 500));
        rightPanel.setPreferredSize(new java.awt.Dimension(700, 700));
        rightPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        workAreaPane.setMinimumSize(new java.awt.Dimension(3500, 500));
        workAreaPane.setPreferredSize(new java.awt.Dimension(700, 680));
        workAreaPane.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        transferredEmployeesPanel.setBackground(new java.awt.Color(0, 204, 153));
        transferredEmployeesPanel.setMinimumSize(new java.awt.Dimension(700, 500));
        transferredEmployeesPanel.setPreferredSize(new java.awt.Dimension(700, 680));
        transferredEmployeesPanel.setLayout(new java.awt.BorderLayout());

        transferredTopPanel.setBackground(new java.awt.Color(0, 204, 153));
        transferredTopPanel.setMaximumSize(new java.awt.Dimension(700, 180));
        transferredTopPanel.setMinimumSize(new java.awt.Dimension(700, 180));
        transferredTopPanel.setPreferredSize(new java.awt.Dimension(700, 180));
        transferredTopPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        transferredTitleLabel.setBackground(new java.awt.Color(0, 204, 153));
        transferredTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        transferredTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        transferredTitleLabel.setText("Possible Transferred Employees");
        transferredTitleLabel.setMaximumSize(new java.awt.Dimension(440, 30));
        transferredTitleLabel.setMinimumSize(new java.awt.Dimension(240, 30));
        transferredTitleLabel.setOpaque(true);
        transferredTitleLabel.setPreferredSize(new java.awt.Dimension(680, 30));
        transferredTopPanel.add(transferredTitleLabel);

        transferredNotesScrollPane.setMaximumSize(new java.awt.Dimension(680, 100));
        transferredNotesScrollPane.setMinimumSize(new java.awt.Dimension(680, 100));
        transferredNotesScrollPane.setPreferredSize(new java.awt.Dimension(680, 100));

        transferredNotesTextArea.setEditable(false);
        transferredNotesTextArea.setBackground(new java.awt.Color(255, 255, 102));
        transferredNotesTextArea.setColumns(20);
        transferredNotesTextArea.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        transferredNotesTextArea.setRows(4);
        transferredNotesTextArea.setText("These employees are ACTIVE on a different MU in this site.\n\nIf you want to transfer an employee to this MU on the Effective Date indicated:\n  • Highlight the employee and click on Transfer Employee\n  • You can also click on Transfer All Employees if all employees should be transferred");
        transferredNotesTextArea.setFocusable(false);
        transferredNotesTextArea.setMaximumSize(new java.awt.Dimension(678, 98));
        transferredNotesTextArea.setMinimumSize(new java.awt.Dimension(678, 98));
        transferredNotesTextArea.setPreferredSize(new java.awt.Dimension(678, 98));
        transferredNotesScrollPane.setViewportView(transferredNotesTextArea);

        transferredTopPanel.add(transferredNotesScrollPane);

        transferredEmployeesPanel.add(transferredTopPanel, java.awt.BorderLayout.PAGE_START);

        transferredCenterPanel.setBackground(new java.awt.Color(0, 204, 153));
        transferredCenterPanel.setAlignmentY(0.0F);
        transferredCenterPanel.setLayout(new javax.swing.BoxLayout(transferredCenterPanel, javax.swing.BoxLayout.Y_AXIS));

        transferredTableScrollPane.setAlignmentY(0.0F);
        transferredTableScrollPane.setMaximumSize(new java.awt.Dimension(680, 1600));
        transferredTableScrollPane.setMinimumSize(new java.awt.Dimension(680, 20));
        transferredTableScrollPane.setName(""); // NOI18N
        transferredTableScrollPane.setPreferredSize(new java.awt.Dimension(680, 300));

        transferredLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        transferredLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        transferredLoadingLabel.setText("LOADING...");
        transferredTableScrollPane.setViewportView(transferredLoadingLabel);

        transferredCenterPanel.add(transferredTableScrollPane);

        transferredEmployeesPanel.add(transferredCenterPanel, java.awt.BorderLayout.CENTER);

        transferredBottomPanel.setBackground(new java.awt.Color(0, 204, 153));
        transferredBottomPanel.setMaximumSize(new java.awt.Dimension(700, 60));
        transferredBottomPanel.setMinimumSize(new java.awt.Dimension(700, 60));
        transferredBottomPanel.setPreferredSize(new java.awt.Dimension(700, 60));
        transferredBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 15));

        transferEmployeeButton.setBackground(new java.awt.Color(0, 204, 153));
        transferEmployeeButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        transferEmployeeButton.setText("Transfer Selected Employee ");
        transferEmployeeButton.setPreferredSize(new java.awt.Dimension(217, 30));
        transferEmployeeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferEmployeeButtonActionPerformed(evt);
            }
        });
        transferredBottomPanel.add(transferEmployeeButton);

        transferAllEmployeesButton.setBackground(new java.awt.Color(0, 204, 153));
        transferAllEmployeesButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        transferAllEmployeesButton.setText("Transfer All Employees");
        transferAllEmployeesButton.setPreferredSize(new java.awt.Dimension(179, 30));
        transferAllEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferAllEmployeesButtonActionPerformed(evt);
            }
        });
        transferredBottomPanel.add(transferAllEmployeesButton);

        transferredPrintButton.setBackground(new java.awt.Color(0, 204, 153));
        transferredPrintButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        transferredPrintButton.setText("Print");
        transferredPrintButton.setPreferredSize(new java.awt.Dimension(90, 30));
        transferredPrintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferredPrintButtonActionPerformed(evt);
            }
        });
        transferredBottomPanel.add(transferredPrintButton);

        transferredEmployeesPanel.add(transferredBottomPanel, java.awt.BorderLayout.PAGE_END);

        workAreaPane.add(transferredEmployeesPanel);

        offDaysPanel.setBackground(new java.awt.Color(0, 204, 153));
        offDaysPanel.setMinimumSize(new java.awt.Dimension(700, 500));
        offDaysPanel.setPreferredSize(new java.awt.Dimension(700, 680));
        offDaysPanel.setLayout(new java.awt.BorderLayout());

        offDaysTopPanel.setBackground(new java.awt.Color(0, 204, 153));
        offDaysTopPanel.setMaximumSize(new java.awt.Dimension(700, 170));
        offDaysTopPanel.setMinimumSize(new java.awt.Dimension(700, 170));
        offDaysTopPanel.setPreferredSize(new java.awt.Dimension(700, 170));
        offDaysTopPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        offDaysTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        offDaysTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        offDaysTitleLabel.setText("OFF days TVI has created for Employees NOT on a Schedule ");
        offDaysTitleLabel.setMaximumSize(new java.awt.Dimension(680, 30));
        offDaysTitleLabel.setMinimumSize(new java.awt.Dimension(680, 30));
        offDaysTitleLabel.setPreferredSize(new java.awt.Dimension(680, 30));
        offDaysTopPanel.add(offDaysTitleLabel);

        offDaysNotesScrollPane.setMaximumSize(new java.awt.Dimension(680, 90));
        offDaysNotesScrollPane.setMinimumSize(new java.awt.Dimension(680, 90));
        offDaysNotesScrollPane.setPreferredSize(new java.awt.Dimension(680, 90));

        offDaysNotesTextArea.setEditable(false);
        offDaysNotesTextArea.setBackground(new java.awt.Color(255, 255, 102));
        offDaysNotesTextArea.setColumns(20);
        offDaysNotesTextArea.setRows(3);
        offDaysNotesTextArea.setText("If Employee SHOULD have an OFF day on this MU for this date:\n\t• Take NO Action.\nIf Employee has left this MU (transfered, retired etc.):\n\t• Click on Inactivate & Remove OFF day!");
        offDaysNotesTextArea.setMaximumSize(new java.awt.Dimension(678, 88));
        offDaysNotesTextArea.setMinimumSize(new java.awt.Dimension(678, 88));
        offDaysNotesTextArea.setPreferredSize(new java.awt.Dimension(678, 88));
        offDaysNotesScrollPane.setViewportView(offDaysNotesTextArea);

        offDaysTopPanel.add(offDaysNotesScrollPane);

        offDaysPanel.add(offDaysTopPanel, java.awt.BorderLayout.PAGE_START);

        offDaysCenterPanel.setBackground(new java.awt.Color(0, 204, 153));
        offDaysCenterPanel.setAlignmentY(0.0F);
        offDaysCenterPanel.setLayout(new javax.swing.BoxLayout(offDaysCenterPanel, javax.swing.BoxLayout.Y_AXIS));

        offDaysTableScrollPane.setAlignmentY(0.0F);
        offDaysTableScrollPane.setMaximumSize(new java.awt.Dimension(520, 1600));
        offDaysTableScrollPane.setMinimumSize(new java.awt.Dimension(520, 20));

        offDaysLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        offDaysLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        offDaysLoadingLabel.setText("LOADING...");
        offDaysTableScrollPane.setViewportView(offDaysLoadingLabel);

        offDaysCenterPanel.add(offDaysTableScrollPane);

        offDaysPanel.add(offDaysCenterPanel, java.awt.BorderLayout.CENTER);

        offDaysBottomPanel.setBackground(new java.awt.Color(0, 204, 153));
        offDaysBottomPanel.setMaximumSize(new java.awt.Dimension(700, 60));
        offDaysBottomPanel.setMinimumSize(new java.awt.Dimension(700, 60));
        offDaysBottomPanel.setPreferredSize(new java.awt.Dimension(700, 60));
        offDaysBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 15));

        offDaysInactivateEmployeeButton.setBackground(new java.awt.Color(0, 204, 153));
        offDaysInactivateEmployeeButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        offDaysInactivateEmployeeButton.setText("Inactivate & Remove OFF day");
        offDaysInactivateEmployeeButton.setPreferredSize(new java.awt.Dimension(260, 30));
        offDaysInactivateEmployeeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offDaysInactivateEmployeeButtonActionPerformed(evt);
            }
        });
        offDaysBottomPanel.add(offDaysInactivateEmployeeButton);

        offDaysPrintButton.setBackground(new java.awt.Color(0, 204, 153));
        offDaysPrintButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        offDaysPrintButton.setText("Print");
        offDaysPrintButton.setPreferredSize(new java.awt.Dimension(120, 30));
        offDaysPrintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offDaysPrintButtonActionPerformed(evt);
            }
        });
        offDaysBottomPanel.add(offDaysPrintButton);

        offDaysPanel.add(offDaysBottomPanel, java.awt.BorderLayout.PAGE_END);

        workAreaPane.add(offDaysPanel);

        duplicateEmployeesPanel.setBackground(new java.awt.Color(0, 204, 153));
        duplicateEmployeesPanel.setMinimumSize(new java.awt.Dimension(700, 500));
        duplicateEmployeesPanel.setPreferredSize(new java.awt.Dimension(700, 680));
        duplicateEmployeesPanel.setLayout(new java.awt.BorderLayout());

        duplicateTopPanel.setBackground(new java.awt.Color(0, 204, 153));
        duplicateTopPanel.setMaximumSize(new java.awt.Dimension(700, 200));
        duplicateTopPanel.setMinimumSize(new java.awt.Dimension(700, 200));
        duplicateTopPanel.setPreferredSize(new java.awt.Dimension(700, 200));
        duplicateTopPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        duplicateTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        duplicateTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        duplicateTitleLabel.setText("Duplicate Employees");
        duplicateTitleLabel.setMaximumSize(new java.awt.Dimension(700, 30));
        duplicateTitleLabel.setMinimumSize(new java.awt.Dimension(700, 30));
        duplicateTitleLabel.setPreferredSize(new java.awt.Dimension(700, 30));
        duplicateTopPanel.add(duplicateTitleLabel);

        duplicateNotesScrollPane.setMaximumSize(new java.awt.Dimension(680, 120));
        duplicateNotesScrollPane.setMinimumSize(new java.awt.Dimension(680, 120));
        duplicateNotesScrollPane.setPreferredSize(new java.awt.Dimension(680, 120));

        duplicateNotesTextArea.setEditable(false);
        duplicateNotesTextArea.setBackground(new java.awt.Color(255, 255, 102));
        duplicateNotesTextArea.setColumns(20);
        duplicateNotesTextArea.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        duplicateNotesTextArea.setRows(6);
        duplicateNotesTextArea.setText("These employees already exist in TVI for this date! You have two options:\n   1) If the employee SHOULD NOT be on this schedule.\n      Once the schedule opens - highlight the employee and delete with the Del Emp button.\n   2) If the employee SHOULD BE on this schedule:\n      Open the other schedule - highlight the employee and delete with the Del Emp button.\n      Then go back to this schedule and correct the employee's ATT UUID.");
        duplicateNotesTextArea.setMaximumSize(new java.awt.Dimension(678, 118));
        duplicateNotesTextArea.setMinimumSize(new java.awt.Dimension(678, 118));
        duplicateNotesTextArea.setPreferredSize(new java.awt.Dimension(678, 118));
        duplicateNotesScrollPane.setViewportView(duplicateNotesTextArea);

        duplicateTopPanel.add(duplicateNotesScrollPane);

        duplicateEmployeesPanel.add(duplicateTopPanel, java.awt.BorderLayout.PAGE_START);

        duplicateCenterPanel.setBackground(new java.awt.Color(0, 204, 153));
        duplicateCenterPanel.setAlignmentY(0.0F);
        duplicateCenterPanel.setLayout(new javax.swing.BoxLayout(duplicateCenterPanel, javax.swing.BoxLayout.Y_AXIS));

        duplicateTableScrollPane.setAlignmentY(0.0F);
        duplicateTableScrollPane.setMaximumSize(new java.awt.Dimension(320, 1600));
        duplicateTableScrollPane.setMinimumSize(new java.awt.Dimension(320, 20));
        duplicateTableScrollPane.setName(""); // NOI18N
        duplicateTableScrollPane.setPreferredSize(new java.awt.Dimension(320, 100));

        duplicateLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        duplicateLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        duplicateLoadingLabel.setText("LOADING...");
        duplicateTableScrollPane.setViewportView(duplicateLoadingLabel);

        duplicateCenterPanel.add(duplicateTableScrollPane);

        duplicateEmployeesPanel.add(duplicateCenterPanel, java.awt.BorderLayout.CENTER);

        duplicateBottomPanel.setBackground(new java.awt.Color(0, 204, 153));
        duplicateBottomPanel.setMaximumSize(new java.awt.Dimension(700, 60));
        duplicateBottomPanel.setMinimumSize(new java.awt.Dimension(700, 60));
        duplicateBottomPanel.setPreferredSize(new java.awt.Dimension(700, 60));
        duplicateBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 15));

        duplicatePrintButton.setBackground(new java.awt.Color(0, 204, 153));
        duplicatePrintButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        duplicatePrintButton.setText("Print");
        duplicatePrintButton.setPreferredSize(new java.awt.Dimension(90, 30));
        duplicatePrintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                duplicatePrintButtonActionPerformed(evt);
            }
        });
        duplicateBottomPanel.add(duplicatePrintButton);

        duplicateEmployeesPanel.add(duplicateBottomPanel, java.awt.BorderLayout.PAGE_END);

        workAreaPane.add(duplicateEmployeesPanel);

        inactiveEmployeesPanel.setBackground(new java.awt.Color(0, 204, 153));
        inactiveEmployeesPanel.setMinimumSize(new java.awt.Dimension(700, 500));
        inactiveEmployeesPanel.setPreferredSize(new java.awt.Dimension(700, 680));
        inactiveEmployeesPanel.setLayout(new java.awt.BorderLayout());

        inactiveTopPanel.setBackground(new java.awt.Color(0, 204, 153));
        inactiveTopPanel.setMaximumSize(new java.awt.Dimension(700, 220));
        inactiveTopPanel.setMinimumSize(new java.awt.Dimension(700, 220));
        inactiveTopPanel.setPreferredSize(new java.awt.Dimension(700, 220));
        inactiveTopPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        inactiveTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        inactiveTitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inactiveTitleLabel.setText("EMPLOYEES with NICE/IEX Schedules WHO DID NOT IMPORT");
        inactiveTitleLabel.setMaximumSize(new java.awt.Dimension(700, 30));
        inactiveTitleLabel.setMinimumSize(new java.awt.Dimension(700, 30));
        inactiveTitleLabel.setPreferredSize(new java.awt.Dimension(700, 30));
        inactiveTopPanel.add(inactiveTitleLabel);

        inactiveNotesScrollPane.setMaximumSize(new java.awt.Dimension(680, 140));
        inactiveNotesScrollPane.setMinimumSize(new java.awt.Dimension(680, 140));
        inactiveNotesScrollPane.setPreferredSize(new java.awt.Dimension(680, 140));

        inactiveNotesTextArea.setEditable(false);
        inactiveNotesTextArea.setBackground(new java.awt.Color(255, 255, 102));
        inactiveNotesTextArea.setColumns(20);
        inactiveNotesTextArea.setRows(4);
        inactiveNotesTextArea.setText("These employee(s) are INACTIVE on this MU.\nTVI did NOT import or update with NICE/IEX data.\n   1) InActive - If employee is Active on this MU:\n      • Change status to Active using the Employee Maintenance Screen\n\tYOU MUST RE-IMPORT FOR THE EMPLOYEE TO APPEAR IN TVI!\n   2) Employee left this MU:\n      • Leave as is - TVI will no longer import or send payroll data.");
        inactiveNotesTextArea.setMaximumSize(new java.awt.Dimension(678, 138));
        inactiveNotesTextArea.setMinimumSize(new java.awt.Dimension(678, 138));
        inactiveNotesTextArea.setPreferredSize(new java.awt.Dimension(678, 138));
        inactiveNotesScrollPane.setViewportView(inactiveNotesTextArea);

        inactiveTopPanel.add(inactiveNotesScrollPane);

        inactiveEmployeesPanel.add(inactiveTopPanel, java.awt.BorderLayout.PAGE_START);

        inactiveCenterPanel.setBackground(new java.awt.Color(0, 204, 153));
        inactiveCenterPanel.setLayout(new javax.swing.BoxLayout(inactiveCenterPanel, javax.swing.BoxLayout.Y_AXIS));

        inactiveTableScrollPane.setMaximumSize(new java.awt.Dimension(850, 1600));
        inactiveTableScrollPane.setMinimumSize(new java.awt.Dimension(850, 20));
        inactiveTableScrollPane.setPreferredSize(new java.awt.Dimension(850, 400));

        inactiveLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        inactiveLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inactiveLoadingLabel.setText("LOADING...");
        inactiveTableScrollPane.setViewportView(inactiveLoadingLabel);

        inactiveCenterPanel.add(inactiveTableScrollPane);

        inactiveEmployeesPanel.add(inactiveCenterPanel, java.awt.BorderLayout.CENTER);

        inactiveBottomPanel.setBackground(new java.awt.Color(0, 204, 153));
        inactiveBottomPanel.setMaximumSize(new java.awt.Dimension(700, 60));
        inactiveBottomPanel.setMinimumSize(new java.awt.Dimension(700, 60));
        inactiveBottomPanel.setPreferredSize(new java.awt.Dimension(700, 60));
        inactiveBottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 15));

        inactiveEmployeeMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        inactiveEmployeeMaintenanceButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        inactiveEmployeeMaintenanceButton.setText("Employee Maintenance");
        inactiveEmployeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(180, 30));
        inactiveEmployeeMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inactiveEmployeeMaintenanceButtonActionPerformed(evt);
            }
        });
        inactiveBottomPanel.add(inactiveEmployeeMaintenanceButton);

        inactivePrintButton.setBackground(new java.awt.Color(0, 204, 153));
        inactivePrintButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        inactivePrintButton.setText("Print");
        inactivePrintButton.setPreferredSize(new java.awt.Dimension(90, 30));
        inactivePrintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inactivePrintButtonActionPerformed(evt);
            }
        });
        inactiveBottomPanel.add(inactivePrintButton);

        inactiveEmployeesPanel.add(inactiveBottomPanel, java.awt.BorderLayout.PAGE_END);

        workAreaPane.add(inactiveEmployeesPanel);

        rightPanel.add(workAreaPane);

        getContentPane().add(rightPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void offDaysPrintButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offDaysPrintButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, offDaysTable, "PORTRAIT", "OFF Days Given by TVI");
    }//GEN-LAST:event_offDaysPrintButtonActionPerformed

    private void offDaysInactivateEmployeeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offDaysInactivateEmployeeButtonActionPerformed
        int selectedRow = offDaysTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select an employee.", "Inactivating Employee", 1, 1, 1);
            offDaysTable.requestFocusInWindow();
            return;
        }
        
        String empid = offDaysTable.getValueAt(selectedRow, idx_offdays_EMPID).toString();
        if (!Oracle.isEmployeeInactiveOn(getFormComponent(), feeder, site, mu, empid))
        {
            Date effectiveDate = Misc.getInactiveEffectiveDate(getFormComponent(), reportingDate);
            if (effectiveDate == null)
            {
                offDaysTable.requestFocusInWindow();
                return;
            }
            if (!Oracle.inactivateEmployee(getFormComponent(), feeder, site, mu, empid, effectiveDate, UserData.getUUID()))
            {
                offDaysTable.requestFocusInWindow();
                return;
            }
        }
        
        // remove the off day
        setCursor(Constants.HOURGLASS);
        if (Oracle.deleteEmployee(getFormComponent(), feeder, site, mu, reportingDate, empid, UserData.getUUID()))
        {
            Oracle.updateEmployeeRecordsBeginLastDates(getFormComponent(), feeder, site, mu, empid, "TTDELETE");
            offDaysDataModel.removeRow(offDaysTable.convertRowIndexToModel(selectedRow));
            Misc.scaleScrollPaneToTable(getFormComponent(), offDaysTableScrollPane, offDaysTable);
        }
        setCursor(Constants.NORMAL);
        offDaysTable.requestFocusInWindow();
    }//GEN-LAST:event_offDaysInactivateEmployeeButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void inactiveEmployeeMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_inactiveEmployeeMaintenanceButtonActionPerformed
    {//GEN-HEADEREND:event_inactiveEmployeeMaintenanceButtonActionPerformed
        EmployeeMaintenance.getInstance(getFormComponent(), feeder, site, null);//DYADD pass empid? change procedure to add empid to table
    }//GEN-LAST:event_inactiveEmployeeMaintenanceButtonActionPerformed

    private void inactivePrintButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_inactivePrintButtonActionPerformed
    {//GEN-HEADEREND:event_inactivePrintButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, inactiveEmployeesTable, "PORTRAIT", "Inactive Employees " + "MU: " + mu);
    }//GEN-LAST:event_inactivePrintButtonActionPerformed

    private void duplicatePrintButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_duplicatePrintButtonActionPerformed
    {//GEN-HEADEREND:event_duplicatePrintButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, duplicateEmployeesTable, "PORTRAIT", "Duplicate Employees");
    }//GEN-LAST:event_duplicatePrintButtonActionPerformed

    private void transferredPrintButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_transferredPrintButtonActionPerformed
    {//GEN-HEADEREND:event_transferredPrintButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, transferredEmployeesTable, "PORTRAIT", "Employees that might be transferring");
    }//GEN-LAST:event_transferredPrintButtonActionPerformed

    private void transferEmployeeButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_transferEmployeeButtonActionPerformed
    {//GEN-HEADEREND:event_transferEmployeeButtonActionPerformed
        int selectedRow = transferredEmployeesTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select an employee.", "", 1, 1, 1);
        }
        else
        {
            Date scheduleDate = Misc.stringToDateMDY(getFormComponent(), transferredEmployeesTable.getValueAt(selectedRow, idx_transferred_EFFDATE).toString());
            String empid =  transferredEmployeesTable.getValueAt(selectedRow, idx_transferred_EMPID).toString();
            String oldMU =  transferredEmployeesTable.getValueAt(selectedRow, idx_transferred_OLDMU).toString();
            String newMU =  transferredEmployeesTable.getValueAt(selectedRow, idx_transferred_NEWMU).toString();
            Oracle.transferEmployee(getFormComponent(), feeder, site, empid, oldMU, newMU, scheduleDate);
            
        }
    }//GEN-LAST:event_transferEmployeeButtonActionPerformed

    private void transferAllEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_transferAllEmployeesButtonActionPerformed
    {//GEN-HEADEREND:event_transferAllEmployeesButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        Oracle.transferEmployee(getFormComponent(), feeder, site, "ALL", "ALL", mu, reportingDate);
        new Thread(new RefreshTransferredEmployeesTableThread()).start();
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_transferAllEmployeesButtonActionPerformed

    private void transferredEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_transferredEmployeesButtonActionPerformed
    {//GEN-HEADEREND:event_transferredEmployeesButtonActionPerformed
        transferredEmployeesChecked = true;
        
        transferredEmployeesPanel.setVisible(true);
        offDaysPanel.setVisible(false);
        duplicateEmployeesPanel.setVisible(false);
        inactiveEmployeesPanel.setVisible(false);
        
        resizeWorkPane();
    }//GEN-LAST:event_transferredEmployeesButtonActionPerformed

    private void offDaysButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_offDaysButtonActionPerformed
    {//GEN-HEADEREND:event_offDaysButtonActionPerformed
        offDaysChecked = true;
        
        transferredEmployeesPanel.setVisible(false);
        offDaysPanel.setVisible(true);
        duplicateEmployeesPanel.setVisible(false);
        inactiveEmployeesPanel.setVisible(false);
        
        resizeWorkPane();
    }//GEN-LAST:event_offDaysButtonActionPerformed

    private void duplicateEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_duplicateEmployeesButtonActionPerformed
    {//GEN-HEADEREND:event_duplicateEmployeesButtonActionPerformed
        duplicateEmployeesChecked = true;
        
        transferredEmployeesPanel.setVisible(false);
        offDaysPanel.setVisible(false);
        duplicateEmployeesPanel.setVisible(true);
        inactiveEmployeesPanel.setVisible(false);
        
        resizeWorkPane();
    }//GEN-LAST:event_duplicateEmployeesButtonActionPerformed

    private void inactiveEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_inactiveEmployeesButtonActionPerformed
    {//GEN-HEADEREND:event_inactiveEmployeesButtonActionPerformed
        inactiveEmployeesChecked = true;
        
        transferredEmployeesPanel.setVisible(false);
        offDaysPanel.setVisible(false);
        duplicateEmployeesPanel.setVisible(false);
        inactiveEmployeesPanel.setVisible(true);
        
        resizeWorkPane();
    }//GEN-LAST:event_inactiveEmployeesButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitButtonActionPerformed
    {//GEN-HEADEREND:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt)//GEN-FIRST:event_formComponentResized
    {//GEN-HEADEREND:event_formComponentResized
        resizeWorkPane();
    }//GEN-LAST:event_formComponentResized
    
    private void resizeWorkPane()
    {
        int maxWidth = rightPanel.getWidth();
        if (maxWidth > 1350)
        {
            maxWidth = 1350;
        }
        int maxHeight = rightPanel.getHeight();
        workAreaPane.setPreferredSize(new Dimension(maxWidth, maxHeight));
        workAreaPane.revalidate();
        
        if (transferredEmployeesPanel.isVisible())
        {
            transferredEmployeesPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            transferredEmployeesPanel.revalidate();
            
            maxHeight = maxHeight - transferredTopPanel.getHeight() - transferredBottomPanel.getHeight();
            transferredCenterPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            transferredCenterPanel.revalidate();
        }
        else if (offDaysPanel.isVisible())
        {
            offDaysPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            offDaysPanel.revalidate();
            
            maxHeight = maxHeight - offDaysTopPanel.getHeight() - offDaysBottomPanel.getHeight();
            offDaysCenterPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            offDaysCenterPanel.revalidate();
        }
        else if (duplicateEmployeesPanel.isVisible())
        {
            duplicateEmployeesPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            duplicateEmployeesPanel.revalidate();
            
            maxHeight = maxHeight - duplicateTopPanel.getHeight() - duplicateBottomPanel.getHeight();
            duplicateCenterPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            duplicateCenterPanel.revalidate();
        }
        else if (inactiveEmployeesPanel.isVisible())
        {
            inactiveEmployeesPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            inactiveEmployeesPanel.revalidate();
            
            maxHeight = maxHeight - inactiveTopPanel.getHeight() - inactiveBottomPanel.getHeight();
            inactiveCenterPanel.setPreferredSize(new Dimension(maxWidth, maxHeight));
            inactiveCenterPanel.revalidate();
        }
    }
    
    private void closeForm()
    {
        if (!transferredEmployeesChecked ||
            !offDaysChecked ||
            !duplicateEmployeesChecked ||
            !inactiveEmployeesChecked)
        {
            Misc.msgbox(getFormComponent(), "First you must finish reviewing all import notifications.", "Import Notifications", 1, 1, 1);
            return;
        }
        
        if (transferredEmployeesWorker != null)
        {
            transferredEmployeesWorker.cancel(true);
        }
        if (offDaysWorker != null)
        {
            offDaysWorker.cancel(true);
        }
        if (duplicateEmployeesWorker != null)
        {
            duplicateEmployeesWorker.cancel(true);
        }
        if (inactiveEmployeesWorker != null)
        {
            inactiveEmployeesWorker.cancel(true);
        }
        
        releaseInstance();
        dispose();
        
        Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, "NORMAL", "TVI");
        Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, "NORMAL");
        TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private void refreshData()
    {
        if (numberOfTransferEmployees > 0)
        {
            new Thread(new RefreshTransferredEmployeesTableThread()).start();
        }
        if (numberOfOffDays > 0)
        {
            new Thread(new RefreshOffDaysTableThread()).start();
        }
        if (numberOfDuplicateEmployees > 0)
        {
            new Thread(new RefreshDuplicateEmployeesTableThread()).start();
        }
        if (numberOfInactiveEmployees > 0)
        {
            new Thread(new RefreshInactiveEmployeesTableThread()).start();
        }
    }
    
    private class RefreshTransferredEmployeesTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshImportTransferEmployeesLock.tryAcquire())
            {
                try
                {
                    transferredEmployeesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    transferredEmployeesDataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    transferredEmployeesWorker = new TableSwingWorker(getFormComponent(), transferredEmployeesDataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    transferredEmployeesWorker.execute();
                }
                finally
                {
                    if (transferredEmployeesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                transferredLoadingLabel.setText("ERROR");
                            }
                        });
                        refreshImportTransferEmployeesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    transferredTableScrollPane.setViewportView(transferredLoadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "Employee",        // idx_transferred_EMPLOYEE
                "AT&T ID",         // idx_transferred_EMPID
                "Currnt MU",       // idx_transferred_OLDMU
                "Status",          // idx_transferred_OLDSTATUS
                "Imported MU",     // idx_transferred_NEWMU
                "Status",          // idx_transferred_NEWSTATUS
                "Effective Date",  // idx_transferred_EFFDATE
                "Payroll ID"       // idx_transferred_PAYROLLID
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsTransferEmployees(getFormComponent(), feeder, site, mu, reportingDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("EMPLOYEE"),            // idx_transferred_EMPLOYEE
                    rs.getString("EMPID"),               // idx_transferred_EMPID
                    rs.getString("OLDMU"),               // idx_transferred_OLDMU
                    rs.getString("TVI_STATUS"),          // idx_transferred_OLDSTATUS
                    rs.getString("NEWMU"),               // idx_transferred_NEWMU
                    rs.getString("NEWSTATUS"),           // idx_transferred_NEWSTATUS
                    Misc.dateToStringMDY(reportingDate), // idx_transferred_EFFDATE
                    rs.getString("OTHER_PAYROLL_ID")     // idx_transferred_PAYROLLID
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading transfer employee data.");
                transferredEmployeesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), transferredTableScrollPane, transferredEmployeesTable);
                transferredTableScrollPane.setVisible(true);
                transferredTableScrollPane.setViewportView(transferredEmployeesTable);
                getFormComponent().validate();
            }
            refreshImportTransferEmployeesLock.release();
        }
        
        private void createTable()
        {
            transferredEmployeesTable = new JTable(transferredEmployeesDataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_transferred_EMPLOYEE:
                        case idx_transferred_EMPID:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(transferredEmployeesTable, true, false, false);
            Misc.setHeaderRenderer(transferredEmployeesTable, true, true, null);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_EMPLOYEE, 200, Constants.LEFT);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_EMPID, 60);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_OLDMU, 80);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_OLDSTATUS, 70);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_NEWMU, 90);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_NEWSTATUS, 70);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_EFFDATE, 90);
            Misc.setColumnSettings(transferredEmployeesTable, idx_transferred_PAYROLLID, 0);
            
            resizeWorkPane();
        }
    }
    
    private class RefreshOffDaysTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshImportOffDaysLock.tryAcquire())
            {
                try
                {
                    offDaysWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    offDaysDataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    offDaysWorker = new TableSwingWorker(getFormComponent(), offDaysDataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    offDaysWorker.execute();
                }
                finally
                {
                    if (offDaysWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                offDaysLoadingLabel.setText("ERROR");
                            }
                        });
                        refreshImportOffDaysLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    offDaysTableScrollPane.setViewportView(offDaysLoadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("Employee<br>Given OFF Day"),   // idx_offdays_EMPLOYEE
                "AT&T ID",                                      // idx_offdays_EMPID
                "Agent ID",                                     // idx_offdays_AGENTID
                Misc.centerHTML("Off Days<br>Already in Week")  // idx_offdays_NUMOFF
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            Date weekEndDate = Misc.getNextDayOfWeek(reportingDate, RegionData.getLastDayOfWeek(), true);
            Date weekStartDate = Misc.dateAddDays(weekEndDate, -6);
            return Oracle.getResultsImportOffDays(getFormComponent(), feeder, site, mu, weekStartDate, weekEndDate, reportingDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("EMPLOYEE"),     // idx_offdays_EMPLOYEE
                    rs.getString("EMPID"),        // idx_offdays_EMPID
                    rs.getString("AGENTID"),      // idx_offdays_AGENTID
                    rs.getInt("NUMOFF")           // idx_offdays_NUMOFF
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading OFF day data.");
                offDaysWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), offDaysTableScrollPane, offDaysTable);
                offDaysTableScrollPane.setViewportView(offDaysTable);
                offDaysTableScrollPane.setVisible(true);
                getFormComponent().validate();
            }
            refreshImportOffDaysLock.release();
        }
        
        private void createTable()
        {
            offDaysTable = new JTable(offDaysDataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_offdays_NUMOFF:
                            return Integer.class;
                        case idx_offdays_EMPLOYEE:
                        case idx_offdays_EMPID:
                        case idx_offdays_AGENTID:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(offDaysTable, true, false, false);
            Misc.setHeaderRenderer(offDaysTable, true, true, null);
            Misc.setColumnSettings(offDaysTable, idx_offdays_EMPLOYEE, 200, Constants.LEFT);
            Misc.setColumnSettings(offDaysTable, idx_offdays_EMPID, 70);
            Misc.setColumnSettings(offDaysTable, idx_offdays_AGENTID, 80);
            Misc.setColumnSettings(offDaysTable, idx_offdays_NUMOFF, 150, false);
            
            resizeWorkPane();
            
            DefaultTableCellRenderer highlightOffDaysRenderer = new DefaultTableCellRenderer()
            {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
                {
                    DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    renderer.setHorizontalAlignment(Constants.CENTER);
                    if (table.getSelectedRow() != row)
                    {
                        if ((Integer)value >= 2)
                        {
                            renderer.setBackground(Color.yellow);
                        }
                        else
                        {
                            renderer.setBackground(Color.white);
                        }
                    }
                    return renderer;
                }
            };
            offDaysTable.getColumnModel().getColumn(idx_offdays_NUMOFF).setCellRenderer(highlightOffDaysRenderer);
        }
    }
    
    private class RefreshDuplicateEmployeesTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshImportDuplicateEmployeesLock.tryAcquire())
            {
                try
                {
                    duplicateEmployeesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    duplicateEmployeesDataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    duplicateEmployeesWorker = new TableSwingWorker(getFormComponent(), duplicateEmployeesDataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    duplicateEmployeesWorker.execute();
                }
                finally
                {
                    if (duplicateEmployeesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                duplicateLoadingLabel.setText("ERROR");
                            }
                        });
                        refreshImportDuplicateEmployeesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    duplicateTableScrollPane.setViewportView(duplicateLoadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "Employee",  // idx_duplicate_EMPLOYEE
                "AT&T ID"    // idx_duplicate_EMPID
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsImportDuplicateEmployees(getFormComponent(), feeder, site, mu, reportingDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("EMPLOYEE"),   // idx_duplicate_EMPLOYEE
                    rs.getString("EMPID")       // idx_duplicate_EMPID
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading duplicate employee data.");
                duplicateEmployeesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), duplicateTableScrollPane, duplicateEmployeesTable);
                duplicateTableScrollPane.setVisible(true);
                duplicateTableScrollPane.setViewportView(duplicateEmployeesTable);
                getFormComponent().validate();
            }
            refreshImportDuplicateEmployeesLock.release();
        }
        
        private void createTable()
        {
            duplicateEmployeesTable = new JTable(duplicateEmployeesDataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_duplicate_EMPLOYEE:
                        case idx_duplicate_EMPID:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(duplicateEmployeesTable, true, false, false);
            Misc.setHeaderRenderer(duplicateEmployeesTable, true, true, null);
            Misc.setColumnSettings(duplicateEmployeesTable, idx_duplicate_EMPLOYEE, 200, Constants.LEFT);
            Misc.setColumnSettings(duplicateEmployeesTable, idx_duplicate_EMPID, 100);
            
            resizeWorkPane();
        }
    }
    
    private class RefreshInactiveEmployeesTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshImportInactiveEmployeesLock.tryAcquire())
            {
                try
                {
                    inactiveEmployeesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    inactiveEmployeesDataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    inactiveEmployeesWorker = new TableSwingWorker(getFormComponent(), inactiveEmployeesDataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    inactiveEmployeesWorker.execute();
                }
                finally
                {
                    if (inactiveEmployeesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                inactiveLoadingLabel.setText("ERROR");
                            }
                        });
                        refreshImportInactiveEmployeesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    inactiveTableScrollPane.setViewportView(inactiveLoadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "Agent ID",          // idx_inactive_AGENTID
                "Employee",          // idx_inactive_EMPLOYEE
                "Load Message"       // idx_inactive_PROCESS_INFO
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsImportInactiveEmployees(getFormComponent(), feeder, site, mu, reportingDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("AGENTID"),     // idx_inactive_AGENTID
                    rs.getString("EMPLOYEE"),    // idx_inactive_EMPLOYEE
                    rs.getString("PROCESS_INFO") // idx_inactive_PROCESS_INFO
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading inactive employee data.");
                inactiveEmployeesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), inactiveTableScrollPane, inactiveEmployeesTable);
                inactiveTableScrollPane.setVisible(true);
                inactiveTableScrollPane.setViewportView(inactiveEmployeesTable);
                getFormComponent().validate();
            }
            refreshImportInactiveEmployeesLock.release();
        }
        
        private void createTable()
        {
            inactiveEmployeesTable = new JTable(inactiveEmployeesDataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_inactive_AGENTID:
                        case idx_inactive_EMPLOYEE:
                        case idx_inactive_PROCESS_INFO:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(inactiveEmployeesTable, true, false, false);
            Misc.setHeaderRenderer(inactiveEmployeesTable, true, true, null);
            Misc.setColumnSettings(inactiveEmployeesTable, idx_inactive_AGENTID, 70);
            Misc.setColumnSettings(inactiveEmployeesTable, idx_inactive_EMPLOYEE, 200, Constants.LEFT);
            Misc.setColumnSettings(inactiveEmployeesTable, idx_inactive_PROCESS_INFO, 560, Constants.LEFT);
            
            resizeWorkPane();
        }
    }
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel buttonGridPanel;
    private javax.swing.JPanel duplicateBottomPanel;
    private javax.swing.JPanel duplicateCenterPanel;
    private javax.swing.JButton duplicateEmployeesButton;
    private javax.swing.JPanel duplicateEmployeesPanel;
    private javax.swing.JLabel duplicateLoadingLabel;
    private javax.swing.JScrollPane duplicateNotesScrollPane;
    private javax.swing.JTextArea duplicateNotesTextArea;
    private javax.swing.JButton duplicatePrintButton;
    private javax.swing.JScrollPane duplicateTableScrollPane;
    private javax.swing.JLabel duplicateTitleLabel;
    private javax.swing.JPanel duplicateTopPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederSiteMuLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel hotlineLabel;
    private javax.swing.JLabel importNotificationsLabel;
    private javax.swing.JPanel inactiveBottomPanel;
    private javax.swing.JPanel inactiveCenterPanel;
    private javax.swing.JButton inactiveEmployeeMaintenanceButton;
    private javax.swing.JButton inactiveEmployeesButton;
    private javax.swing.JPanel inactiveEmployeesPanel;
    private javax.swing.JLabel inactiveLoadingLabel;
    private javax.swing.JScrollPane inactiveNotesScrollPane;
    private javax.swing.JTextArea inactiveNotesTextArea;
    private javax.swing.JButton inactivePrintButton;
    private javax.swing.JScrollPane inactiveTableScrollPane;
    private javax.swing.JLabel inactiveTitleLabel;
    private javax.swing.JPanel inactiveTopPanel;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel offDaysBottomPanel;
    private javax.swing.JButton offDaysButton;
    private javax.swing.JPanel offDaysCenterPanel;
    private javax.swing.JButton offDaysInactivateEmployeeButton;
    private javax.swing.JLabel offDaysLoadingLabel;
    private javax.swing.JScrollPane offDaysNotesScrollPane;
    private javax.swing.JTextArea offDaysNotesTextArea;
    private javax.swing.JPanel offDaysPanel;
    private javax.swing.JButton offDaysPrintButton;
    private javax.swing.JScrollPane offDaysTableScrollPane;
    private javax.swing.JLabel offDaysTitleLabel;
    private javax.swing.JPanel offDaysTopPanel;
    private javax.swing.JLabel reportingDateLabel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JLabel selectionLabel;
    private javax.swing.JSeparator separator;
    private javax.swing.JButton transferAllEmployeesButton;
    private javax.swing.JButton transferEmployeeButton;
    private javax.swing.JPanel transferredBottomPanel;
    private javax.swing.JPanel transferredCenterPanel;
    private javax.swing.JButton transferredEmployeesButton;
    private javax.swing.JPanel transferredEmployeesPanel;
    private javax.swing.JLabel transferredLoadingLabel;
    private javax.swing.JScrollPane transferredNotesScrollPane;
    private javax.swing.JTextArea transferredNotesTextArea;
    private javax.swing.JButton transferredPrintButton;
    private javax.swing.JScrollPane transferredTableScrollPane;
    private javax.swing.JLabel transferredTitleLabel;
    private javax.swing.JPanel transferredTopPanel;
    private javax.swing.JLayeredPane workAreaPane;
    // End of variables declaration//GEN-END:variables
}
