package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.ProgressMonitor;
import javax.swing.RowSorter.SortKey;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.TableCellRenderer;
import tvi.client_main.Main;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class Schedules extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile Schedules instance;
    
    private final String feeder;
    private final String site;
    
    private static final Semaphore openingScheduleLock = new Semaphore(1, true);
    private static final Semaphore refreshWorkingSchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshReadySchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshCompletedSchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshPayCloseLock = new Semaphore(1, true);
    private static final Semaphore refreshMURosterLock = new Semaphore(1, true);
    
    JTable workingSchedulesTable;
    JTable readySchedulesTable;
    JTable completedSchedulesTable;
    CustomTableModel workingSchedulesData;
    CustomTableModel readySchedulesData;
    CustomTableModel completedSchedulesData;
    TableSwingWorker workingSchedulesWorker;
    TableSwingWorker readySchedulesWorker;
    TableSwingWorker completedSchedulesWorker;
    
    public Timer paycloseTimer;
    public Timer workingTimer;
    public Timer readyTimer;
    public Timer completedTimer;
    public Timer muRosterTimer;
    
    Date todaysDate = Misc.dateNoTime(Oracle.getCurTimeLocal(this));
    int numberOfOffDays = 0;
    int numberOfInactiveEmps = 0;
    int numberOfDuplicateEmps = 0;
    int numberOf3DayNightDiffEmps = 0;
    int numberOfTransferEmps = 0;
    int numberOfRosterRequesting = 0;
    
    private int workingSelectedRow;
    private int completedSelectedRow;
    private int readySelectedRow;
    private int workingRowCount;
    private int completedRowCount;
    private int readyRowCount;
    private int workingScrollPosition = 0;
    private int readyScrollPosition = 0;
    private int completedScrollPosition = 0;
    private String workingSelectedMu;
    private String workingSelectedDate;
    private String readySelectedMu;
    private String readySelectedDate;
    private String completedSelectedMu;
    private String completedSelectedDate;
    private List<? extends SortKey> workingSortKeys = null;
    private List<? extends SortKey> readySortKeys = null;
    private List<? extends SortKey> completedSortKeys = null;
    
    boolean refreshingPayClose = false;
    boolean disableRefreshing = false;//DYADD change thread to swing worker?
    boolean gotImporting = false;
    boolean updatingMuRoster = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    final static int idx_MU             = 0;
    final static int idx_REPORTING_DATE = 1;
    final static int idx_STATUS         = 2;
    final static int idx_TOTALVIEWID    = 3;
    final static int idx_UNION_FLAG     = 4;
    final static int idx_FUTURE_LOAD    = 5;
    final static int idx_IMPORT_LOCKED  = 6;
    
    public synchronized static Schedules getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new Schedules(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private Schedules(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            testDBLabel.setVisible(true);
        }
        else
        {
            testDBLabel.setVisible(false);
        }
        WeeklyTimecodeMinutesButton.setVisible(UserData.getUserType().equals("POWER") || RegionData.getNewFeature2());
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            if (!Misc.isAlpha(s.substring(0, 1)))
            {
                modelr.addElement(s);
            }
        }
        importSchedules.setModel(modelr);
        if (importSchedules.getModel().getSize() > 0)
        {
            importSchedules.setSelectedIndex(0);
        }
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Calendar cal = Calendar.getInstance();
        Date curDate = Misc.dateNoTime(cal.getTime());
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, 20);
        for (int i = 0; i < 60; i++)
        {
            pickDate.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, +1);
        pickDate.setSelectedItem(Misc.dateToStringMDY(cal.getTime()));
        
        /***********************************************************************
        * setup Timers for refreshing data
        ***********************************************************************/
        ActionListener paycloseRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshPayCloseThread()).start();
            }
        };
        ActionListener workingRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshWorkingSchedulesThread()).start();
            }
        };
        ActionListener readyRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshReadySchedulesThread()).start();
            }
        };
        ActionListener completedRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshCompletedSchedulesThread()).start();
            }
        };
        if (RegionData.getNewFeature())
        {
            ActionListener muRosterRefresh = new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    new Thread(new RefreshMURosterThread()).start();
                }
            };
            muRosterTimer = new Timer(60*1000, muRosterRefresh);
            muRosterTimer.setRepeats(true);
            muRosterTimer.setInitialDelay(60*1000);
            muRosterTimer.start();
        }
        paycloseTimer = new Timer(60*1000, paycloseRefresh);
        paycloseTimer.setRepeats(true);
        paycloseTimer.setInitialDelay(60*1000);
        paycloseTimer.start();
        
        workingTimer = new Timer(60*1000, workingRefresh);
        workingTimer.setRepeats(true);
        workingTimer.setInitialDelay(60*1000);
        workingTimer.start();
        
        readyTimer = new Timer(60*1000, readyRefresh);
        readyTimer.setRepeats(true);
        readyTimer.setInitialDelay(60*1000);
        readyTimer.start();
        
        completedTimer = new Timer(60*1000, completedRefresh);
        completedTimer.setRepeats(true);
        completedTimer.setInitialDelay(60*1000);
        completedTimer.start();
        
        messageArea.setVisible(false);
        displayGroup.setSelected(display30Days.getModel(), true);
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        payCycleLabel.setText("Pay Cycle: " + RegionData.getPayCycle());
        officeLabel.setText("Office: " + RegionData.getSiteDescription());
        payrollPeriodLabel.setText("Current Payroll Period Ends: " + Misc.dateToStringMDY(RegionData.getPayClose()));
        rosterUpdatedLabel.setText("MU Roster Updated: " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
        
        weeklyAdditionalFunctionsButton.setVisible((feeder.equals("STI") && RegionData.getNightDiff()) ||
                Oracle.does3DayRule(getFormComponent(), feeder, site) ||
                Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()));
        commentMaintenanceButton.setVisible(false); // DYADD disabled for INFOR for now, remove in future?
        validateAllocationsButton.setVisible(Oracle.doesCostAllocation(getFormComponent(), feeder, site, null));
        
        if ((feeder.equals("STI") && RegionData.getNightDiff()))
        {
            weeklyAdditionalFunctionsButton.setText("<html><div align='center' width='100%'>Compute Night Diff<br>Future Exceptions</div></html>");
        }
        else if (Oracle.does3DayRule(getFormComponent(), feeder, site))
        {
            weeklyAdditionalFunctionsButton.setText("Compute 3 Day Rule");
        }
        else if (Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()))
        {
            weeklyAdditionalFunctionsButton.setText("<html><div align='center' width='100%'>Compute Relief<br>Differentials</div></html>");
        }
        
        String userAccessLevel = UserData.getUserAccessLevel();
        beginNewPayrollButton.setEnabled(!userAccessLevel.equals("READONLY"));
        updateMURosterButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importFutureSchedulesButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importOptionsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        commentMaintenanceButton.setEnabled(!userAccessLevel.equals("READONLY"));
        weeklyAdditionalFunctionsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        addRecordsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        validateAllocationsButton.setEnabled(!userAccessLevel.equals("READONLY") && Oracle.checkPendingAllocation(getFormComponent(), feeder, site));
        if (!RegionData.getNewFeature())
        {
            updateMURosterButton.setVisible(false);
            muRosterMaintenanceButton.setVisible(false);
            EmpRosterMaintenanceButton.setVisible(false);
            rosterUpdatedLabel.setVisible(false);
            
            importIEXUpdatesButton.setText("Import IEX Updates");
            importIEXUpdatesButton.setPreferredSize(new java.awt.Dimension(160, 40));
            
            importFutureSchedulesButton.setText("Import Future Schedules");
            importFutureSchedulesButton.setPreferredSize(new java.awt.Dimension(160, 40));
            
            reviewUpdatesButton.setText("Review Updates");
            reviewUpdatesButton.setPreferredSize(new java.awt.Dimension(160, 40));
        }   
        else
        {
            employeeMaintenanceButton.setVisible(false);
            numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
            if (numberOfRosterRequesting > 0)
            {
                updatingMuRoster = true;
                updateMURosterButton.setText("<html><div align='center' width='100%'>Requesting<br>Please Wait</div></html>");
                updateMURosterButton.setEnabled(false);
            }
        }
    }
    
    public static void refreshInstance()
    {
        if (instance != null)
        {
            instance.refreshData();
        }
    }
    
    private void refreshData()
    {
        if (!refreshingPayClose)
        {
            paycloseTimer.setInitialDelay(0);
            paycloseTimer.restart();
        }
        if (workingSchedulesWorker == null || workingSchedulesWorker.isDone())
        {
            workingTimer.setInitialDelay(0);
            workingTimer.restart();
        }
        if (completedSchedulesWorker == null || completedSchedulesWorker.isDone())
        {
            completedTimer.setInitialDelay(0);
            completedTimer.restart();
        }
        if (readySchedulesWorker == null || readySchedulesWorker.isDone())
        {
            readyTimer.setInitialDelay(0);
            readyTimer.restart();
        }
        if (RegionData.getNewFeature())
        {
            if (updatingMuRoster)
            {
                numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
                if (numberOfRosterRequesting == 0)
                {
                    Misc.msgbox(getFormComponent(), "MU Roster successfully updated", "MU Roster Update", 1, 1, 1);
                    updatingMuRoster = false;
                    updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
                    updateMURosterButton.setEnabled(true);
                }
                muRosterTimer.setInitialDelay(0);
                muRosterTimer.restart();
            }
            if (Oracle.areAnyNewErrorFlag(getFormComponent(), feeder, site))
            {
                MURosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
            }
            rosterUpdatedLabel.setText("MU Roster Updated:  " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
        }
        validateAllocationsButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY") && Oracle.checkPendingAllocation(getFormComponent(), feeder, site));
    }
    
    private boolean checkPayrollClose(){
        TimeZone localTZ = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        Date curDate = Oracle.getCurTime(getFormComponent());
        TimeZone.setDefault(TimeZone.getTimeZone("PST"));

        //rounds the curDate time
        Calendar curRoundedCal = Calendar.getInstance();
        curRoundedCal.setTime(curDate);
        curRoundedCal.set(Calendar.HOUR_OF_DAY, 0);
        curRoundedCal.set(Calendar.MINUTE, 0);
        curRoundedCal.set(Calendar.SECOND, 0);
        curRoundedCal.set(Calendar.MILLISECOND, 0);
        Date curRoundedDate = curRoundedCal.getTime();
        
        String A1 = "A1";
        String B1 = "B1";

        //CHECKS IF TODAY IS A HOT DATE
        boolean hotDate = false;
        for (int i = 0; i < RegionData.getPayrollCloseDates().size(); i++)
        {
            if (A1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()) || B1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()))
            {
                if (curRoundedDate.equals(RegionData.getPayrollCloseDates().get(i).getHotDay()))
                {
                    hotDate = true;
                    break;
                }
            }
        }
            
        //if its a hotDate
        if(hotDate)
        {    
            //5:00 am
            Calendar startCal = Calendar.getInstance();
            startCal.set(Calendar.HOUR_OF_DAY, 5);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            Date startDate = startCal.getTime();

            //7:30 am
            Calendar endCal = Calendar.getInstance();
            endCal.set(Calendar.HOUR_OF_DAY, 7);
            endCal.set(Calendar.MINUTE, 30);
            endCal.set(Calendar.SECOND, 0);
            Date endDate = endCal.getTime();

            //Check if the time is between 5:00-7:30
            if (curDate.after(startDate) && curDate.before(endDate)){
                //checks if the curDate is not close date for the site
                if(curRoundedDate.compareTo(RegionData.getHotDay())!=0){
                    TimeZone.setDefault(localTZ); 
                    return false;
                }
            }
        }
        TimeZone.setDefault(localTZ);
        return true;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        displayGroup = new javax.swing.ButtonGroup();
        schedulePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        payCycleLabel = new javax.swing.JLabel();
        officeLabel = new javax.swing.JLabel();
        payrollPeriodLabel = new javax.swing.JLabel();
        rosterUpdatedLabel = new javax.swing.JLabel();
        beginNewPayrollButton = new javax.swing.JButton();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        display30Days = new javax.swing.JRadioButton();
        display1year = new javax.swing.JRadioButton();
        scheduleColumnsPanel = new javax.swing.JPanel();
        importColumnPane = new javax.swing.JPanel();
        importSchedulesLabel = new javax.swing.JLabel();
        importSchedulesPane = new javax.swing.JScrollPane();
        importSchedules = new javax.swing.JList<>();
        importButton = new javax.swing.JButton();
        importOptionsButton = new javax.swing.JButton();
        workingColumnPanel = new javax.swing.JPanel();
        workingSchedulesTitlePanel = new javax.swing.JPanel();
        workingSchedulesLabel = new javax.swing.JLabel();
        futureScheduleFlagLabel = new javax.swing.JLabel();
        workingSchedulesPane = new javax.swing.JScrollPane();
        loadingWorkingLabel = new javax.swing.JLabel();
        workingSchedulesControlPanel = new javax.swing.JPanel();
        workingScheduleOpenButton = new javax.swing.JButton();
        inforOperationsPanel = new javax.swing.JPanel();
        readyColumnPanel = new javax.swing.JPanel();
        readySchedulesLabel = new javax.swing.JLabel();
        readySchedulesPane = new javax.swing.JScrollPane();
        loadingReadyLabel = new javax.swing.JLabel();
        readyScheduleOpenButton = new javax.swing.JButton();
        validateAllocationsButton = new javax.swing.JButton();
        completedColumnPanel = new javax.swing.JPanel();
        completedSchedulesLabel = new javax.swing.JLabel();
        completedSchedulesPane = new javax.swing.JScrollPane();
        loadingCompletedLabel = new javax.swing.JLabel();
        completedScheduleOpenButton = new javax.swing.JButton();
        scheduleImportsCheckButton = new javax.swing.JButton();
        menuPane = new javax.swing.JPanel();
        weeklyFunctionsLabel = new javax.swing.JLabel();
        weeklyAdditionalFunctionsButton = new javax.swing.JButton();
        weeklyHoursCheckButton = new javax.swing.JButton();
        WeeklyTimecodeMinutesButton = new javax.swing.JButton();
        payrollEndingLabel = new javax.swing.JLabel();
        verificationlReportsButton = new javax.swing.JButton();
        payrollPeriodSummaryButton = new javax.swing.JButton();
        lookupByEmployeeLabel = new javax.swing.JLabel();
        employeeDetailButton = new javax.swing.JButton();
        otherLabel = new javax.swing.JLabel();
        employeeMaintenanceButton = new javax.swing.JButton();
        EmpRosterMaintenanceButton = new javax.swing.JButton();
        muRosterMaintenanceButton = new javax.swing.JButton();
        addRecordsButton = new javax.swing.JButton();
        commentMaintenanceButton = new javax.swing.JButton();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        updateMURosterButton = new javax.swing.JButton();
        importIEXUpdatesButton = new javax.swing.JButton();
        importFutureSchedulesButton = new javax.swing.JButton();
        reviewUpdatesButton = new javax.swing.JButton();
        messageArea = new javax.swing.JTextField();
        testDBLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Schedules");
        setBackground(new java.awt.Color(0, 204, 153));
        setMinimumSize(new java.awt.Dimension(1061, 639));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0);
        flowLayout1.setAlignOnBaseline(true);
        getContentPane().setLayout(flowLayout1);

        schedulePanel.setBackground(new java.awt.Color(0, 204, 153));
        schedulePanel.setMinimumSize(new java.awt.Dimension(1045, 640));
        schedulePanel.setPreferredSize(new java.awt.Dimension(1045, 640));
        schedulePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setText("TVI Time Reporting");
        schedulePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, -1, -1));

        exitButton.setBackground(new java.awt.Color(0, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(140, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        schedulePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, -1, -1));

        refreshButton.setBackground(new java.awt.Color(0, 204, 153));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        schedulePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, -1, -1));

        payCycleLabel.setText("Pay Cycle:");
        payCycleLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        schedulePanel.add(payCycleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, -1, -1));

        officeLabel.setText("Office:");
        officeLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        schedulePanel.add(officeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 15, -1, -1));

        payrollPeriodLabel.setText("Current Payroll Period Ends:");
        payrollPeriodLabel.setPreferredSize(new java.awt.Dimension(260, 30));
        schedulePanel.add(payrollPeriodLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 20));

        rosterUpdatedLabel.setText("MU Roster Last Updated: ");
        rosterUpdatedLabel.setPreferredSize(new java.awt.Dimension(260, 30));
        schedulePanel.add(rosterUpdatedLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 20));

        beginNewPayrollButton.setBackground(new java.awt.Color(0, 204, 153));
        beginNewPayrollButton.setText("Begin New Pay Period");
        beginNewPayrollButton.setMaximumSize(new java.awt.Dimension(137, 30));
        beginNewPayrollButton.setMinimumSize(new java.awt.Dimension(137, 30));
        beginNewPayrollButton.setPreferredSize(new java.awt.Dimension(160, 30));
        beginNewPayrollButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beginNewPayrollButtonActionPerformed(evt);
            }
        });
        schedulePanel.add(beginNewPayrollButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, -1, -1));

        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pickDateLabel.setText("Pick Date: ");
        pickDateLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setPreferredSize(new java.awt.Dimension(100, 20));
        schedulePanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        pickDate.setEditable(true);
        pickDate.setMaximumRowCount(14);
        pickDate.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDate.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDate.setName(""); // NOI18N
        pickDate.setPreferredSize(new java.awt.Dimension(100, 20));
        schedulePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        display30Days.setBackground(new java.awt.Color(0, 204, 153));
        displayGroup.add(display30Days);
        display30Days.setText("Display 30 Days");
        display30Days.setPreferredSize(new java.awt.Dimension(110, 20));
        display30Days.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display30DaysActionPerformed(evt);
            }
        });
        schedulePanel.add(display30Days, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 100, -1, -1));

        display1year.setBackground(new java.awt.Color(0, 204, 153));
        displayGroup.add(display1year);
        display1year.setText("Display 1 Year");
        display1year.setPreferredSize(new java.awt.Dimension(110, 20));
        display1year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display1yearActionPerformed(evt);
            }
        });
        schedulePanel.add(display1year, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 120, -1, -1));

        scheduleColumnsPanel.setBackground(new java.awt.Color(0, 204, 153));
        scheduleColumnsPanel.setMinimumSize(new java.awt.Dimension(835, 433));
        scheduleColumnsPanel.setPreferredSize(new java.awt.Dimension(835, 460));
        scheduleColumnsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 0));

        importColumnPane.setBackground(new java.awt.Color(0, 204, 153));
        importColumnPane.setMinimumSize(new java.awt.Dimension(100, 500));
        importColumnPane.setPreferredSize(new java.awt.Dimension(100, 500));

        importSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        importSchedulesLabel.setText("<html><u>Import Schedules</u></html>");
        importSchedulesLabel.setPreferredSize(new java.awt.Dimension(100, 15));
        importColumnPane.add(importSchedulesLabel);

        importSchedulesPane.setPreferredSize(new java.awt.Dimension(100, 350));

        importSchedulesPane.setViewportView(importSchedules);

        importColumnPane.add(importSchedulesPane);

        importButton.setBackground(new java.awt.Color(0, 204, 153));
        importButton.setText("Import MU");
        importButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(importButton);

        importOptionsButton.setBackground(new java.awt.Color(0, 204, 153));
        importOptionsButton.setText("Import Options");
        importOptionsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        importOptionsButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importOptionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importOptionsButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(importOptionsButton);

        scheduleColumnsPanel.add(importColumnPane);

        workingColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        workingColumnPanel.setMinimumSize(new java.awt.Dimension(285, 500));
        workingColumnPanel.setPreferredSize(new java.awt.Dimension(285, 500));

        workingSchedulesTitlePanel.setBackground(new java.awt.Color(0, 204, 153));
        workingSchedulesTitlePanel.setPreferredSize(new java.awt.Dimension(285, 15));
        workingSchedulesTitlePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 0));

        workingSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        workingSchedulesLabel.setText("<html><u>Working Schedules</u></html>");
        workingSchedulesLabel.setMaximumSize(new java.awt.Dimension(2147483647, 15));
        workingSchedulesLabel.setMinimumSize(new java.awt.Dimension(120, 15));
        workingSchedulesLabel.setPreferredSize(new java.awt.Dimension(120, 15));
        workingSchedulesTitlePanel.add(workingSchedulesLabel);

        futureScheduleFlagLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        futureScheduleFlagLabel.setText("F = Future Sched");
        futureScheduleFlagLabel.setPreferredSize(new java.awt.Dimension(100, 15));
        workingSchedulesTitlePanel.add(futureScheduleFlagLabel);

        workingColumnPanel.add(workingSchedulesTitlePanel);

        workingSchedulesPane.setPreferredSize(new java.awt.Dimension(285, 350));

        loadingWorkingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingWorkingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingWorkingLabel.setText("LOADING...");
        workingSchedulesPane.setViewportView(loadingWorkingLabel);

        workingColumnPanel.add(workingSchedulesPane);

        workingSchedulesControlPanel.setBackground(new java.awt.Color(0, 204, 153));
        workingSchedulesControlPanel.setPreferredSize(new java.awt.Dimension(285, 30));
        workingSchedulesControlPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        workingScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        workingScheduleOpenButton.setText("Open Selected");
        workingScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                workingScheduleOpenButtonActionPerformed(evt);
            }
        });
        workingSchedulesControlPanel.add(workingScheduleOpenButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 0, -1, -1));

        workingColumnPanel.add(workingSchedulesControlPanel);

        inforOperationsPanel.setBackground(new java.awt.Color(0, 204, 153));
        inforOperationsPanel.setPreferredSize(new java.awt.Dimension(285, 30));
        inforOperationsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        workingColumnPanel.add(inforOperationsPanel);

        scheduleColumnsPanel.add(workingColumnPanel);

        readyColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        readyColumnPanel.setMinimumSize(new java.awt.Dimension(175, 500));
        readyColumnPanel.setPreferredSize(new java.awt.Dimension(175, 500));

        readySchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        readySchedulesLabel.setText("<html><u>Ready Schedules</u></html>");
        readySchedulesLabel.setPreferredSize(new java.awt.Dimension(175, 15));
        readyColumnPanel.add(readySchedulesLabel);

        readySchedulesPane.setPreferredSize(new java.awt.Dimension(175, 350));

        loadingReadyLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingReadyLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingReadyLabel.setText("LOADING...");
        readySchedulesPane.setViewportView(loadingReadyLabel);

        readyColumnPanel.add(readySchedulesPane);

        readyScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        readyScheduleOpenButton.setText("Open Selected");
        readyScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        readyScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        readyScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        readyScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readyScheduleOpenButtonActionPerformed(evt);
            }
        });
        readyColumnPanel.add(readyScheduleOpenButton);

        validateAllocationsButton.setBackground(new java.awt.Color(0, 204, 153));
        validateAllocationsButton.setText("Validate Allocations");
        validateAllocationsButton.setPreferredSize(new java.awt.Dimension(130, 30));
        validateAllocationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                validateAllocationsButtonActionPerformed(evt);
            }
        });
        readyColumnPanel.add(validateAllocationsButton);

        scheduleColumnsPanel.add(readyColumnPanel);

        completedColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        completedColumnPanel.setMinimumSize(new java.awt.Dimension(175, 500));
        completedColumnPanel.setPreferredSize(new java.awt.Dimension(175, 500));

        completedSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        completedSchedulesLabel.setText("<html><u>Completed Schedules</u></html>");
        completedSchedulesLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        completedColumnPanel.add(completedSchedulesLabel);

        completedSchedulesPane.setPreferredSize(new java.awt.Dimension(175, 350));

        loadingCompletedLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingCompletedLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingCompletedLabel.setText("LOADING...");
        completedSchedulesPane.setViewportView(loadingCompletedLabel);

        completedColumnPanel.add(completedSchedulesPane);

        completedScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        completedScheduleOpenButton.setText("Open Selected");
        completedScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completedScheduleOpenButtonActionPerformed(evt);
            }
        });
        completedColumnPanel.add(completedScheduleOpenButton);

        scheduleImportsCheckButton.setBackground(new java.awt.Color(0, 204, 153));
        scheduleImportsCheckButton.setText("Schedule Imports Check");
        scheduleImportsCheckButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        scheduleImportsCheckButton.setMaximumSize(new java.awt.Dimension(110, 30));
        scheduleImportsCheckButton.setMinimumSize(new java.awt.Dimension(110, 30));
        scheduleImportsCheckButton.setPreferredSize(new java.awt.Dimension(140, 30));
        scheduleImportsCheckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleImportsCheckButtonActionPerformed(evt);
            }
        });
        completedColumnPanel.add(scheduleImportsCheckButton);

        scheduleColumnsPanel.add(completedColumnPanel);

        schedulePanel.add(scheduleColumnsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 835, 480));

        menuPane.setBackground(new java.awt.Color(0, 204, 153));
        menuPane.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        weeklyFunctionsLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        weeklyFunctionsLabel.setText("<html><u>Weekly Functions</u></html>");
        weeklyFunctionsLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        weeklyFunctionsLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(weeklyFunctionsLabel);

        weeklyAdditionalFunctionsButton.setBackground(new java.awt.Color(0, 204, 153));
        weeklyAdditionalFunctionsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weeklyAdditionalFunctionsButton.setText("<html><div align='center' width='100%'>Compute Night Diff<br>Future Exceptions</div></html>");
        weeklyAdditionalFunctionsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        weeklyAdditionalFunctionsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        weeklyAdditionalFunctionsButton.setPreferredSize(new java.awt.Dimension(190, 40));
        weeklyAdditionalFunctionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weeklyAdditionalFunctionsButtonActionPerformed(evt);
            }
        });
        menuPane.add(weeklyAdditionalFunctionsButton);

        weeklyHoursCheckButton.setBackground(new java.awt.Color(0, 204, 153));
        weeklyHoursCheckButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weeklyHoursCheckButton.setText("<html><div align='center' width='100%'>Weekly Scheduled<br>Hours Check</div></html>");
        weeklyHoursCheckButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        weeklyHoursCheckButton.setPreferredSize(new java.awt.Dimension(190, 40));
        weeklyHoursCheckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weeklyHoursCheckButtonActionPerformed(evt);
            }
        });
        menuPane.add(weeklyHoursCheckButton);

        WeeklyTimecodeMinutesButton.setBackground(new java.awt.Color(0, 204, 153));
        WeeklyTimecodeMinutesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        WeeklyTimecodeMinutesButton.setText("<html><div align='center' width='100%'>Weekly Timecode<br>Minutes Check</div></html>");
        WeeklyTimecodeMinutesButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        WeeklyTimecodeMinutesButton.setMinimumSize(new java.awt.Dimension(77, 39));
        WeeklyTimecodeMinutesButton.setPreferredSize(new java.awt.Dimension(190, 40));
        WeeklyTimecodeMinutesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WeeklyTimecodeMinutesButtonActionPerformed(evt);
            }
        });
        menuPane.add(WeeklyTimecodeMinutesButton);

        payrollEndingLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        payrollEndingLabel.setText("<html><u>Payroll Ending Functions</u></html>");
        payrollEndingLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        payrollEndingLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(payrollEndingLabel);

        verificationlReportsButton.setBackground(new java.awt.Color(0, 204, 153));
        verificationlReportsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        verificationlReportsButton.setText("<html><div align='center' width='100%'>Verification Reports</div></html>");
        verificationlReportsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        verificationlReportsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        verificationlReportsButton.setPreferredSize(new java.awt.Dimension(190, 40));
        verificationlReportsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verificationlReportsButtonActionPerformed(evt);
            }
        });
        menuPane.add(verificationlReportsButton);

        payrollPeriodSummaryButton.setBackground(new java.awt.Color(0, 204, 153));
        payrollPeriodSummaryButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        payrollPeriodSummaryButton.setText("<html><div align='center' width='100%'>Payroll Period Summary</div></html>");
        payrollPeriodSummaryButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        payrollPeriodSummaryButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        payrollPeriodSummaryButton.setPreferredSize(new java.awt.Dimension(190, 40));
        payrollPeriodSummaryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payrollPeriodSummaryButtonActionPerformed(evt);
            }
        });
        menuPane.add(payrollPeriodSummaryButton);

        lookupByEmployeeLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lookupByEmployeeLabel.setText("<html><u>Lookup By Employee</u></html>");
        lookupByEmployeeLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        lookupByEmployeeLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(lookupByEmployeeLabel);

        employeeDetailButton.setBackground(new java.awt.Color(0, 204, 153));
        employeeDetailButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        employeeDetailButton.setText("<html><div align='center' width='100%'>Time Reporting Data<br>By Employee</div></html>");
        employeeDetailButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        employeeDetailButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeDetailButton.setPreferredSize(new java.awt.Dimension(190, 40));
        employeeDetailButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeDetailButtonActionPerformed(evt);
            }
        });
        menuPane.add(employeeDetailButton);

        otherLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        otherLabel.setText("<html><u>Other Functions</u></html>");
        otherLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        otherLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(otherLabel);

        employeeMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        employeeMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        employeeMaintenanceButton.setText("Employee Maintenance");
        employeeMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        employeeMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 40));
        employeeMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(employeeMaintenanceButton);

        EmpRosterMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        EmpRosterMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        EmpRosterMaintenanceButton.setText("Employee Maintenance");
        EmpRosterMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EmpRosterMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        EmpRosterMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 40));
        EmpRosterMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpRosterMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(EmpRosterMaintenanceButton);

        muRosterMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        muRosterMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        muRosterMaintenanceButton.setText("MU Roster Maintenance");
        muRosterMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        muRosterMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        muRosterMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 40));
        muRosterMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muRosterMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(muRosterMaintenanceButton);

        addRecordsButton.setBackground(new java.awt.Color(0, 204, 153));
        addRecordsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        addRecordsButton.setText("Add Records for Employee");
        addRecordsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addRecordsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        addRecordsButton.setPreferredSize(new java.awt.Dimension(190, 40));
        addRecordsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRecordsButtonActionPerformed(evt);
            }
        });
        menuPane.add(addRecordsButton);

        commentMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        commentMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        commentMaintenanceButton.setText("Comment Maintenance");
        commentMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        commentMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        commentMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 40));
        commentMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                commentMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(commentMaintenanceButton);

        schedulePanel.add(menuPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 45, 190, 575));

        feederSitePanel.setBackground(new java.awt.Color(0, 204, 153));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederLabel.setPreferredSize(new java.awt.Dimension(90, 16));
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        siteLabel.setPreferredSize(new java.awt.Dimension(70, 16));
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        schedulePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 0));

        updateMURosterButton.setBackground(new java.awt.Color(0, 204, 153));
        updateMURosterButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
        updateMURosterButton.setToolTipText("");
        updateMURosterButton.setMargin(new java.awt.Insets(2, 4, 2, 4));
        updateMURosterButton.setPreferredSize(new java.awt.Dimension(110, 40));
        updateMURosterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateMURosterButtonActionPerformed(evt);
            }
        });
        jPanel1.add(updateMURosterButton);

        importIEXUpdatesButton.setBackground(new java.awt.Color(0, 204, 153));
        importIEXUpdatesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        importIEXUpdatesButton.setText("<html><div align='center' width='100%'>Import IEX<br>Updates</div></html>");
        importIEXUpdatesButton.setMargin(new java.awt.Insets(2, 4, 2, 4));
        importIEXUpdatesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        importIEXUpdatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importIEXUpdatesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(importIEXUpdatesButton);

        importFutureSchedulesButton.setBackground(new java.awt.Color(0, 204, 153));
        importFutureSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        importFutureSchedulesButton.setText("<html><div align='center' width='100%'>Import Future<br>Schedules</div></html>");
        importFutureSchedulesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        importFutureSchedulesButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        importFutureSchedulesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        importFutureSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importFutureSchedulesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(importFutureSchedulesButton);

        reviewUpdatesButton.setBackground(new java.awt.Color(0, 204, 153));
        reviewUpdatesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        reviewUpdatesButton.setText("<html><div align='center' width='100%'>Review<br>Updates</div></html>");
        reviewUpdatesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        reviewUpdatesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        reviewUpdatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewUpdatesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(reviewUpdatesButton);

        schedulePanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 560, 40));

        messageArea.setEditable(false);
        messageArea.setBackground(new java.awt.Color(255, 255, 51));
        messageArea.setText("message");
        messageArea.setMargin(new java.awt.Insets(2, 5, 2, 2));
        messageArea.setPreferredSize(new java.awt.Dimension(500, 20));
        schedulePanel.add(messageArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 75, 500, -1));

        testDBLabel.setBackground(new java.awt.Color(255, 51, 51));
        testDBLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        testDBLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        testDBLabel.setText("TEST DATABASE");
        testDBLabel.setName(""); // NOI18N
        schedulePanel.add(testDBLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, -1, -1));

        getContentPane().add(schedulePanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void weeklyHoursCheckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weeklyHoursCheckButtonActionPerformed
        WeeklyScheduledHoursCheck.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_weeklyHoursCheckButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void importButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importButtonActionPerformed
        if (!checkPayrollClose()){
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("h:mm a");

            ZoneId pacificTimeZoneId = ZoneId.of("America/Los_Angeles");
            ZoneId localTimeZoneId = ZoneId.systemDefault();

            ZonedDateTime startTime  = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 05:00", dateFormat), pacificTimeZoneId, localTimeZoneId);
            ZonedDateTime endTime = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 07:30", dateFormat), pacificTimeZoneId, localTimeZoneId);       

            Misc.msgbox(getFormComponent(), "Importing is not allowed between " 
                    + startTime.format(timeFormat) 
                    + "-" + endTime.format(timeFormat) + " " 
                    + localTimeZoneId.getDisplayName(TextStyle.SHORT_STANDALONE, Locale.ENGLISH) 
                    + " because today is not your payroll close", "", 1, 1, 1);
            return;
        }
        setCursor(Constants.HOURGLASS);
        List selectedMUs = importSchedules.getSelectedValuesList();
        boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
        if (okToImport)
        {
            RegionData.updateSiteInfo(getFormComponent(), feeder, site);
            okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
        }
        if (!okToImport)
        {
            setCursor(Constants.NORMAL);
            return;
        }
        if (updatingMuRoster && RegionData.getNewFeature())
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Cannot import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
            return;
        }
        Date importDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (importDate == null)
        {
            setCursor(Constants.NORMAL);
            return;
        }
        if (importSchedules.getSelectedValue() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must select an MU from the list!", "Import Schedules", 1, 1, 1);
            return;
        }
        if (pickDate.getSelectedItem() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must Pick or Enter a Date!", "Import Schedules", 1, 1, 1);
            return;
        }
        else if (!Misc.isDate(pickDate.getSelectedItem().toString()))
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must first Pick or Enter a valid Date", "Importing Schedules", 1, 1, 1);
            return;
        }
        else
        {
            Calendar cal = Calendar.getInstance();
            cal.setTime(todaysDate);
            cal.add(Calendar.YEAR, -1);
            Date lastYear = cal.getTime();
            Date selectedDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
            setCursor(Constants.NORMAL);
            if (selectedDate == null)
            {
                return;
            }
            if (selectedDate.compareTo(lastYear) < 0)
            {
                Misc.msgbox(getFormComponent(), "Selected date must be in the last year.", "Importing Schedules", 1, 1, 1);
                return;
            }
        }
        
        String importType = "REPLACE";
        String lockedBy;
        String scheduleStatus;
        boolean includesReimport = false;
        int choice;
        if (selectedMUs.size() > 0)
        {
            for (Object mu : selectedMUs)
            {
                lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu.toString(), importDate);
                scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu.toString(), importDate);
                if (scheduleStatus == null)
                {
                    //normal import
                }
                else if (scheduleStatus.equals("Sent Waiting Results"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has been Sent to Infor - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("In Use"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has some or all records locked by another user - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("Load Failed"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "Last import attempt failed on the schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " - You cannot import. Email TVI Support: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (Arrays.asList("Requesting", "Loading").contains(scheduleStatus))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " is currently processing an import request - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("Imported"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has status of Imported - open the schedule to update status.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (lockedBy != null)
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " is LOCKED by: " + lockedBy + " - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else
                {
                    includesReimport = true;
                }
            }
            if (includesReimport)
            {
                setCursor(Constants.NORMAL);
                choice = JOptionPane.showOptionDialog
                (
                    null,
                    "At least one of the selected schedules already exists.",
                    "Re-Importing Schedule",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"UPDATE", "CANCEL"},
                    "UPDATE"
                );
                switch (choice)
                {
                    case 0: // UPDATE
                        importType = "UPDATE";
                        break;
                    default: // user cancel
                        return;
                }
            }
        }
        setCursor(Constants.HOURGLASS);
        for (Object mu : selectedMUs)
        {
            if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, importDate, importDate))
            {
                setCursor(Constants.NORMAL);
                return;
            }
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu.toString(), importDate, importDate, importType, UserData.getUUID());
        }
        setCursor(Constants.NORMAL);
        refreshData();
    }//GEN-LAST:event_importButtonActionPerformed
    
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed
    
    private void employeeDetailButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeDetailButtonActionPerformed
        TimeReportingByEmployee.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_employeeDetailButtonActionPerformed

    private void payrollPeriodSummaryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payrollPeriodSummaryButtonActionPerformed
        PayrollPeriodSummary.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_payrollPeriodSummaryButtonActionPerformed

    private void verificationlReportsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verificationlReportsButtonActionPerformed
        VerificationReportsMenu.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_verificationlReportsButtonActionPerformed

    private void beginNewPayrollButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beginNewPayrollButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        String siteLock = RegionData.getSiteLock();
        String payCycle = RegionData.getPayCycle();
        Date   payClose = RegionData.getPayClose();
        Date   hotDay   = RegionData.getHotDay();
        Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), payCycle, payClose);
        if ((feeder.equals("STI") && RegionData.getNightDiff()) ||
            Oracle.doesCostAllocation(getFormComponent(), feeder, site, null) ||
            Oracle.does3DayRule(getFormComponent(), feeder, site) ||
            !Oracle.checkFutureSchedulesUpdated(getFormComponent(), feeder, site, payStartDate, payClose) ||
            Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()))
        {
            BeginNewPayPeriod.getInstance(getFormComponent(), feeder, site, payStartDate, payClose);
        }
        else
        {
            if (UserData.getUserType().equals("POWER") ||
                Misc.isBeginNewPayPeriodOkay(getFormComponent(), feeder, site, siteLock, payCycle, payClose, hotDay))
            {
                setCursor(Constants.HOURGLASS);
                Date nextPayClose = Oracle.getNextPayrollEndDate(getFormComponent(), payCycle, Misc.dateAddDays(Oracle.getCurTime(getFormComponent()), -1));
                if (Oracle.updatePayClose(getFormComponent(), feeder, site, nextPayClose))
                {
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "Next Payroll Period has been started", "Begin New Payroll Period", 1, 1, 1);
                    refreshData();
                }
                setCursor(Constants.NORMAL);
            }
        }
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_beginNewPayrollButtonActionPerformed

    private void display1yearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display1yearActionPerformed
        completedTimer.setInitialDelay(0);
        completedTimer.setDelay(5*60*1000);
        if (completedTimer.isRunning())
        {
            completedTimer.restart();
        }
        else
        {
            completedTimer.start();
        }
    }//GEN-LAST:event_display1yearActionPerformed

    private void display30DaysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display30DaysActionPerformed
        completedTimer.setInitialDelay(0);
        completedTimer.setDelay(60*1000);
        if (completedTimer.isRunning())
        {
            completedTimer.restart();
        }
        else
        {
            completedTimer.start();
        }
    }//GEN-LAST:event_display30DaysActionPerformed

    private void weeklyAdditionalFunctionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weeklyAdditionalFunctionsButtonActionPerformed
        if ((feeder.equals("STI") && RegionData.getNightDiff()))
        {
            ComputeNightDiff.getInstance(getFormComponent(), feeder, site);
        }
        else if (Oracle.does3DayRule(getFormComponent(), feeder, site))
        {
            Compute3DayRule.getInstance(getFormComponent(), feeder, site);
        }
        else if (Arrays.asList("ATI_IBEW_1_3", "ATI_IBEW_4_5").contains(RegionData.getSiteUnion()))
        {
            ComputeReliefDifferential.getInstance(getFormComponent(), feeder, site, UserData.getUUID());
        }
        else
        {
            Misc.msgbox(getFormComponent(), "No weekly additional functions available for this site.", "Weekly Functions", 2, 1, 1);
        }
    }//GEN-LAST:event_weeklyAdditionalFunctionsButtonActionPerformed

    private void importOptionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importOptionsButtonActionPerformed
        ImportOptions.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_importOptionsButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void workingScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_workingScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(workingSchedulesTable)).start();
    }//GEN-LAST:event_workingScheduleOpenButtonActionPerformed

    private void completedScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completedScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(completedSchedulesTable)).start();
    }//GEN-LAST:event_completedScheduleOpenButtonActionPerformed

    private void readyScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readyScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(readySchedulesTable)).start();
    }//GEN-LAST:event_readyScheduleOpenButtonActionPerformed

    private void updateMURosterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateMURosterButtonActionPerformed
        if (Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site))
        {
            if (Oracle.getNumSchedulesRequesting(getFormComponent(), feeder, site) == 0)
            {
                updatingMuRoster = true;
                updateMURosterButton.setText("<html><div align='center' width='100%'>Requesting<br>Please Wait</div></html>");
                updateMURosterButton.setEnabled(false);
                Oracle.updateIexMuRoster(getFormComponent(), feeder, site, UserData.getUUID());
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Cannot update MU Roster while schedules are being requested.", "MU Roster Update Locked", 1, 1, 1);
            }
        }
        else
        {
            Misc.msgbox(getFormComponent(), "Cannot update MU Roster while importing is locked", "MU Roster Update Locked", 1, 1, 1);
        }

    }//GEN-LAST:event_updateMURosterButtonActionPerformed

    private void reviewUpdatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewUpdatesButtonActionPerformed
        String mu = "ALL";
        if (RegionData.getReviewByMU())
        {
            // labels
            JLabel muLabel = new JLabel("Select MUs to review updates for:");
            muLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
            muLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            muLabel.setPreferredSize(new Dimension(260, 20));
            
            JLabel selectionLabel = new JLabel("(To select multiple MUs, Ctrl + Click)");
            selectionLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
            selectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            selectionLabel.setPreferredSize(new Dimension(260, 20));
            
            // mu selection list
            JScrollPane muScrollPane = new JScrollPane();
            muScrollPane.setPreferredSize(new Dimension(100, 250));
            JList<String> muList = new JList<>();
            muList.setFont(new java.awt.Font("Tahoma", 0, 14));
            muList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            muScrollPane.setViewportView(muList);
            DefaultListModel<String> muModel = new DefaultListModel<>();
            
            // checkbox
            JCheckBox rememberSelectionsCheckBox = new JCheckBox();
            rememberSelectionsCheckBox.setFont(new java.awt.Font("Tahoma", 0, 14));
            rememberSelectionsCheckBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            rememberSelectionsCheckBox.setPreferredSize(new Dimension(260, 20));
            rememberSelectionsCheckBox.setText("Remember my current selections");
            
            // populate mulist
            for (String s : RegionData.getMuList())
            {
                if (!Misc.isAlpha(s.substring(0, 1)))
                {
                    muModel.addElement(s);
                }
            }
            muList.setModel(muModel);
            
            String userMuList = Oracle.getUserSetting(getFormComponent(), feeder, site, UserData.getUUID(), "REVIEW_UPDATES");
            if (userMuList == null || userMuList.isEmpty())
            {
                muList.setSelectedIndex(0);
            }
            else
            {
                rememberSelectionsCheckBox.setSelected(true);
                List<String> musToSelect = Misc.stringCSVToList(userMuList);
                List<Integer> indicesToSelect = new ArrayList<>();
                for (String muString : musToSelect)
                {
                    for (int i = 0; i < muList.getModel().getSize(); i++)
                    {
                        if (muString.equals(muList.getModel().getElementAt(i)))
                        {
                            indicesToSelect.add(i);
                        }
                    }
                }
                muList.setSelectedIndices(indicesToSelect.stream().mapToInt(i->i).toArray());
            }
            
            // panel
            JPanel panel = new JPanel();
            panel.setPreferredSize(new Dimension(300, 370));
            FlowLayout layout = new FlowLayout();
            layout.setVgap(10);
            panel.setLayout(layout);
            panel.add(muLabel);
            panel.add(selectionLabel);
            panel.add(muScrollPane);
            panel.add(rememberSelectionsCheckBox);
            
            int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Review Updates", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (rc != 0) // cancelled
            {
                return;
            }
            
            List<String> selectedMUs = muList.getSelectedValuesList();
            mu = String.join(",", selectedMUs);
            boolean rememberSelections = rememberSelectionsCheckBox.isSelected();
            
            if (rememberSelections)
            {
                Oracle.setUserSetting(getFormComponent(), feeder, site, UserData.getUUID(), "REVIEW_UPDATES", mu);
            }
        }
        
        TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, null, null, RegionData.getSiteUnion(), "REVIEW UPDATES");
    }//GEN-LAST:event_reviewUpdatesButtonActionPerformed

    private void employeeMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMaintenanceButtonActionPerformed
        EmployeeMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_employeeMaintenanceButtonActionPerformed

    private void commentMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_commentMaintenanceButtonActionPerformed
        CommentList.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_commentMaintenanceButtonActionPerformed

    private void importFutureSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importFutureSchedulesButtonActionPerformed
        //gets current date/time in PST
        TimeZone localTZ = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        Date curDate = Oracle.getCurTime(getFormComponent());
        TimeZone.setDefault(TimeZone.getTimeZone("PST"));
        
        //rounds the curDate time
        Calendar curRoundedCal = Calendar.getInstance();
        curRoundedCal.setTime(curDate);
        curRoundedCal.set(Calendar.HOUR_OF_DAY, 0);
        curRoundedCal.set(Calendar.MINUTE, 0);
        curRoundedCal.set(Calendar.SECOND, 0);
        curRoundedCal.set(Calendar.MILLISECOND, 0);
        Date curRoundedDate = curRoundedCal.getTime();
        
        String A1 = "A1";
        String B1 = "B1";
        
        //CHECKS IF TODAY IS A HOT DATE
        boolean hotDate = false;
        for (int i = 0; i < RegionData.getPayrollCloseDates().size(); i++)
        {
            if (A1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()) || B1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()))
            {
                if (curRoundedDate.equals(RegionData.getPayrollCloseDates().get(i).getHotDay()))
                {
                    hotDate = true;
                    break;
                }
            }
        }
        
        //check if day of week is a hotDate
        if(hotDate){
            //5:00 am
            Calendar startCal = Calendar.getInstance();
            startCal.set(Calendar.HOUR_OF_DAY, 5);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            Date startDate = startCal.getTime();

            //7:30 am
            Calendar endCal = Calendar.getInstance();
            endCal.set(Calendar.HOUR_OF_DAY, 7);
            endCal.set(Calendar.MINUTE, 30);
            endCal.set(Calendar.SECOND, 0);
            Date endDate = endCal.getTime();
        
            //if the time is between 5:00-7:30 am, message pops up
            if (curDate.after(startDate) && curDate.before(endDate)){
                TimeZone.setDefault(localTZ);
                
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("h:mm a");

                ZoneId pacificTimeZoneId = ZoneId.of("America/Los_Angeles");
                ZoneId localTimeZoneId = ZoneId.systemDefault();

                ZonedDateTime startTime  = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 05:00", dateFormat), pacificTimeZoneId, localTimeZoneId);
                ZonedDateTime endTime = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 07:30", dateFormat), pacificTimeZoneId, localTimeZoneId);       
               
                Misc.msgbox(getFormComponent(), "Import Future Schedules is unavailable between " 
                        + startTime.format(timeFormat) 
                        + "-" + endTime.format(timeFormat) + " " 
                        + localTimeZoneId.getDisplayName(TextStyle.SHORT_STANDALONE, Locale.ENGLISH) 
                        + " because of payroll close", "", 1, 1, 1);
            }
            TimeZone.setDefault(localTZ);
        }
        else{
            TimeZone.setDefault(localTZ);
             ImportSchedulesFuture.getInstance(getFormComponent(), feeder, site);
        }
        
    }//GEN-LAST:event_importFutureSchedulesButtonActionPerformed

    private void addRecordsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRecordsButtonActionPerformed
        AddRecords.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_addRecordsButtonActionPerformed

    private void scheduleImportsCheckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleImportsCheckButtonActionPerformed
        ScheduleImportsStatus.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_scheduleImportsCheckButtonActionPerformed

    private void validateAllocationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_validateAllocationsButtonActionPerformed
        new Thread(new validateAllocationThread()).start();
    }//GEN-LAST:event_validateAllocationsButtonActionPerformed

    private void EmpRosterMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpRosterMaintenanceButtonActionPerformed
        EmployeeRosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_EmpRosterMaintenanceButtonActionPerformed

    private void muRosterMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muRosterMaintenanceButtonActionPerformed
        MURosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_muRosterMaintenanceButtonActionPerformed

    private void importIEXUpdatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importIEXUpdatesButtonActionPerformed
        /*
        //IEX updates not allowed mondays between 5:00-7:30 am PT.
        //gets current date/time in PST
        TimeZone localTZ = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        Date curDate = Oracle.getCurTime(getFormComponent());
        TimeZone.setDefault(TimeZone.getTimeZone("PST"));

        //rounds the curDate time
        Calendar curRoundedCal = Calendar.getInstance();
        curRoundedCal.setTime(curDate);
        curRoundedCal.set(Calendar.HOUR_OF_DAY, 0);
        curRoundedCal.set(Calendar.MINUTE, 0);
        curRoundedCal.set(Calendar.SECOND, 0);
        curRoundedCal.set(Calendar.MILLISECOND, 0);
        Date curRoundedDate = curRoundedCal.getTime();
        
        String A1 = "A1";
        String B1 = "B1";
        
        //CHECKS IF TODAY IS A HOT DATE
        boolean hotDate = false;
        for (int i = 0; i < RegionData.getPayrollCloseDates().size(); i++)
        {
            if (A1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()) || B1.equals(RegionData.getPayrollCloseDates().get(i).getPayrollGroup()))
            {
                if (curRoundedDate.equals(RegionData.getPayrollCloseDates().get(i).getHotDay()))
                {
                    hotDate = true;
                    break;
                }
            }
        }
        
        //check if day of week is a hotDate
        if(hotDate){
            //5:00 am
            Calendar startCal = Calendar.getInstance();
            startCal.set(Calendar.HOUR_OF_DAY, 5);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            Date startDate = startCal.getTime();

            //7:30 am
            Calendar endCal = Calendar.getInstance();
            endCal.set(Calendar.HOUR_OF_DAY, 7);
            endCal.set(Calendar.MINUTE, 30);
            endCal.set(Calendar.SECOND, 0);
            Date endDate = endCal.getTime();
        
            //if the time is between 5:00-7:30 am, message pops up
            if (curDate.after(startDate) && curDate.before(endDate)){
                TimeZone.setDefault(localTZ);
                
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("h:mm a");

                ZoneId pacificTimeZoneId = ZoneId.of("America/Los_Angeles");
                ZoneId localTimeZoneId = ZoneId.systemDefault();

                ZonedDateTime startTime  = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 05:00", dateFormat), pacificTimeZoneId, localTimeZoneId);
                ZonedDateTime endTime = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 07:30", dateFormat), pacificTimeZoneId, localTimeZoneId);       
               
                Misc.msgbox(getFormComponent(), "Import IEX Updates is unavailable between " 
                        + startTime.format(timeFormat) 
                        + "-" + endTime.format(timeFormat) + " " 
                        + localTimeZoneId.getDisplayName(TextStyle.SHORT_STANDALONE, Locale.ENGLISH) 
                        + " because of payroll close", "", 1, 1, 1);
            }
            TimeZone.setDefault(localTZ);
        }
        else{
            TimeZone.setDefault(localTZ);
            ImportSchedulesUpdate.getInstance(getFormComponent(), feeder, site);
        }
        */
        if (!checkPayrollClose()){
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("h:mm a");

            ZoneId pacificTimeZoneId = ZoneId.of("America/Los_Angeles");
            ZoneId localTimeZoneId = ZoneId.systemDefault();

            ZonedDateTime startTime  = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 05:00", dateFormat), pacificTimeZoneId, localTimeZoneId);
            ZonedDateTime endTime = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 07:30", dateFormat), pacificTimeZoneId, localTimeZoneId);       

            Misc.msgbox(getFormComponent(), "Importing is not allowed between " 
                    + startTime.format(timeFormat) 
                    + "-" + endTime.format(timeFormat) + " " 
                    + localTimeZoneId.getDisplayName(TextStyle.SHORT_STANDALONE, Locale.ENGLISH) 
                    + " because today is not your payroll close", "", 1, 1, 1);
            return;
        }
        ImportSchedulesUpdate.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_importIEXUpdatesButtonActionPerformed

    private void WeeklyTimecodeMinutesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WeeklyTimecodeMinutesButtonActionPerformed
        WeeklyTimecodeMinutesCheck.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_WeeklyTimecodeMinutesButtonActionPerformed
    
    private class validateAllocationThread implements Runnable
    {
        @Override
        public void run()
        {
            if (Misc.validateAllocationsLock.tryAcquire())
            {
                try
                {
                    setControlsEnabled(false);
                    
                    CustomTableModel errorData = Misc.validateAllocations(getFormComponent(), feeder, site);
                    if (errorData != null)
                    {
                        ValidationErrors.getInstance(getFormComponent(), feeder, site, errorData);
                    }
                    
                    validateAllocationsButton.setEnabled(Oracle.checkPendingAllocation(getFormComponent(), feeder, site));
                }
                finally
                {
                    setControlsEnabled(true);
                    Misc.validateAllocationsLock.release();
                }
            }
        }
    }
    
    private class OpenScheduleThread implements Runnable
    {
        JTable table;
        
        public OpenScheduleThread(JTable table)
        {
            this.table = table;
        }
        
        @Override
        public void run()
        {
            if (this.table == null)
            {
                return;
            }
            if (openingScheduleLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setControlsEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    int selectedRow = this.table.getSelectedRow();
                    if (selectedRow == -1)
                    {
                        Misc.msgbox(getFormComponent(), "You must select a schedule first.", "", 1, 1, 1);
                        return;
                    }
                    String selectedMU = this.table.getValueAt(selectedRow, idx_MU).toString();
                    Date selectedDate = (Date) this.table.getValueAt(selectedRow, idx_REPORTING_DATE);
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, selectedMU, selectedDate);
                    if (Arrays.asList("Requesting", "Loading", "Load Failed", "Sent Waiting Results", "Send Failed").contains(scheduleStatus))
                    {
                        String message = "Cannot open schedule with status of \"" + scheduleStatus + "\".";
                        if (scheduleStatus.equals("Load Failed") || scheduleStatus.equals("Send Failed"))
                        {
                            message += "\nEmail TVI Support: " + Constants.EMAIL;
                        }
                        Misc.msgbox(getFormComponent(), message, "Schedule Locked", 1, 1, 1);
                    }
                    else if (Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, selectedMU, selectedDate) != null)
                    {
                        String lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, selectedMU, selectedDate);
                        Misc.msgbox(getFormComponent(), "Cannot open schedule at this time, it is currently locked by: " + lockedBy, "Schedule Locked", 1, 1, 1);
                    }
                    else
                    {
                        final String mu = selectedMU;
                        final Date reportingDate = selectedDate;
                        final String union = this.table.getValueAt(selectedRow, idx_UNION_FLAG).toString();
                        if (scheduleStatus.equals("Imported"))
                        {
                            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "IMPORTED");
                        }
                        else
                        {
                            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
                        }
                    }
                }
                finally
                {
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            openingScheduleLock.release();
                            setControlsEnabled(true);
                        }
                    });
                }
            }
        }
    }
    
    private class RefreshWorkingSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshWorkingSchedulesLock.tryAcquire())
            {
                try
                {
                    workingSchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    workingSchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    workingSchedulesWorker = new TableSwingWorker(getFormComponent(), workingSchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    workingSchedulesWorker.execute();
                }
                finally
                {
                    if (workingSchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingWorkingLabel.setText("ERROR");
                            }
                        });
                        refreshWorkingSchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (workingSchedulesTable != null)
                    {
                        workingRowCount = workingSchedulesTable.getRowCount();
                        workingScrollPosition = workingSchedulesPane.getVerticalScrollBar().getValue();
                        workingSortKeys = workingSchedulesTable.getRowSorter().getSortKeys();
                        workingSelectedRow = workingSchedulesTable.getSelectedRow();
                        if (workingSelectedRow >= 0)
                        {
                            workingSelectedMu = workingSchedulesTable.getValueAt(workingSelectedRow, idx_MU).toString();
                            workingSelectedDate = workingSchedulesTable.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    workingSchedulesPane.setViewportView(loadingWorkingLabel);
                    gotImporting = false;
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsSchedulesInfor(getFormComponent(), feeder, site, 365, "Working");
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                
                data = new Object[]
                {
                    rs.getString("MU"),            // idx_MU
                    rs.getDate("REPORTING_DATE"),  // idx_REPORTING_DATE
                    rs.getString("STATUS"),        // idx_STATUS
                    rs.getString("TOTALVIEWID"),   // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),    // idx_UNION_FLAG
                    futureFlag,                    // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")  // idx_IMPORT_LOCKED
                };
                
                String status = rs.getString("STATUS");
                if (Arrays.asList("Importing", "Loading", "Requesting").contains(status))
                {
                    gotImporting = true;
                }
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Working Schedules data.");
                workingSchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                workingSchedulesTable.setPreferredScrollableViewportSize(workingSchedulesTable.getPreferredSize());
                if (workingSelectedRow >= 0 && workingSelectedMu != null && workingSelectedDate != null && workingSelectedRow <= workingSchedulesTable.getRowCount() - 1)
                {
                    if (workingSchedulesTable.getValueAt(workingSelectedRow, idx_MU).equals(workingSelectedMu) &&
                        workingSchedulesTable.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString().equals(workingSelectedDate))
                    {
                        workingSchedulesTable.changeSelection(workingSelectedRow, 0, false, false);
                    }
                }
                workingSchedulesPane.setViewportView(workingSchedulesTable);
                revalidate();
                int position = workingScrollPosition + (workingSchedulesTable.getRowCount() - workingRowCount) * 16;
                if (workingScrollPosition != 0 && position > 0)
                {
                    workingSchedulesPane.getVerticalScrollBar().setValue(position);
                }
                if (completedTimer.getDelay() != 60*1000)
                {
                    completedTimer.setDelay(60*1000);
                    completedTimer.setInitialDelay(60*1000);
                    completedTimer.restart();
                }
                if (gotImporting)
                {
                    if (workingTimer.getDelay() != 30*1000)
                    {
                        workingTimer.setDelay(30*1000);
                        workingTimer.setInitialDelay(30*1000);
                        workingTimer.restart();
                    }
                }
                else if (workingTimer.getDelay() != 60*1000)
                {
                    workingTimer.setDelay(60*1000);
                    workingTimer.setInitialDelay(60*1000);
                    workingTimer.restart();
                }
            }
            refreshWorkingSchedulesLock.release();
        }
        
        private void createTable()
        {
            workingSchedulesTable = new JTable(workingSchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (workingSchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            workingSchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(workingSchedulesTable)).start();
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            Misc.configureTable(workingSchedulesTable, true, false, false);
            if (workingSortKeys != null)
            {
                workingSchedulesTable.getRowSorter().setSortKeys(workingSortKeys);
            }
            Misc.setHeaderRenderer(workingSchedulesTable, true, true, null);
            Misc.setColumnSettings(workingSchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(workingSchedulesTable, idx_REPORTING_DATE, 75);
            Misc.setColumnSettings(workingSchedulesTable, idx_STATUS, 120);
            Misc.setColumnSettings(workingSchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(workingSchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(workingSchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(workingSchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private class RefreshCompletedSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshCompletedSchedulesLock.tryAcquire())
            {
                try
                {
                    completedSchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    completedSchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    completedSchedulesWorker = new TableSwingWorker(getFormComponent(), completedSchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    completedSchedulesWorker.execute();
                }
                finally
                {
                    if (completedSchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingCompletedLabel.setText("ERROR");
                            }
                        });
                        refreshCompletedSchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (completedSchedulesTable != null)
                    {
                        completedRowCount = completedSchedulesTable.getRowCount();
                        completedScrollPosition = completedSchedulesPane.getVerticalScrollBar().getValue();
                        completedSortKeys = completedSchedulesTable.getRowSorter().getSortKeys();
                        completedSelectedRow = completedSchedulesTable.getSelectedRow();
                        if (completedSelectedRow >= 0)
                        {
                            completedSelectedMu = completedSchedulesTable.getValueAt(completedSelectedRow, idx_MU).toString();
                            completedSelectedDate = completedSchedulesTable.getValueAt(completedSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    completedSchedulesPane.setViewportView(loadingCompletedLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            int days = 30;
            if (!displayGroup.getSelection().equals(display30Days.getModel()))
            {
                days = 365;
            }
            return Oracle.getResultsSchedulesInfor(getFormComponent(), feeder, site, days, "Completed");
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                data = new Object[]
                {
                    rs.getString("MU"),            // idx_MU
                    rs.getDate("REPORTING_DATE"),  // idx_REPORTING_DATE
                    rs.getString("STATUS"),        // idx_STATUS
                    rs.getString("TOTALVIEWID"),   // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),    // idx_UNION_FLAG
                    futureFlag,                    // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")  // idx_IMPORT_LOCKED
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Coompleted Schedules data.");
                completedSchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                if (completedSelectedRow >= 0 && completedSelectedMu != null && completedSelectedDate != null && completedSelectedRow <= completedSchedulesTable.getRowCount() - 1)
                {
                    if (completedSchedulesTable.getValueAt(completedSelectedRow, idx_MU).equals(completedSelectedMu) &&
                        completedSchedulesTable.getValueAt(completedSelectedRow, idx_REPORTING_DATE).toString().equals(completedSelectedDate))
                    {
                        completedSchedulesTable.changeSelection(completedSelectedRow, 0, false, false);
                    }
                }
                completedSchedulesPane.setViewportView(completedSchedulesTable);
                revalidate();
                int position = completedScrollPosition + (completedSchedulesTable.getRowCount() - completedRowCount) * 16;
                if (completedScrollPosition != 0 && position > 0)
                {
                    completedSchedulesPane.getVerticalScrollBar().setValue(position);
                }
            }
            refreshCompletedSchedulesLock.release();
        }
        
        private void createTable()
        {
            completedSchedulesTable = new JTable(completedSchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (completedSchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            completedSchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(completedSchedulesTable)).start();
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            
            Misc.configureTable(completedSchedulesTable, true, false, false);
            if (completedSortKeys != null)
            {
                completedSchedulesTable.getRowSorter().setSortKeys(completedSortKeys);
            }
            Misc.setHeaderRenderer(completedSchedulesTable, true, true, null);
            Misc.setColumnSettings(completedSchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(completedSchedulesTable, idx_REPORTING_DATE, 85);
            Misc.setColumnSettings(completedSchedulesTable, idx_STATUS, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(completedSchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private class RefreshReadySchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshReadySchedulesLock.tryAcquire())
            {
                try
                {
                    readySchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    readySchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    readySchedulesWorker = new TableSwingWorker(getFormComponent(), readySchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    readySchedulesWorker.execute();
                }
                finally
                {
                    if (readySchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingReadyLabel.setText("ERROR");
                            }
                        });
                        refreshReadySchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (readySchedulesTable != null)
                    {
                        readyRowCount = readySchedulesTable.getRowCount();
                        readyScrollPosition = readySchedulesPane.getVerticalScrollBar().getValue();
                        readySortKeys = readySchedulesTable.getRowSorter().getSortKeys();
                        readySelectedRow = readySchedulesTable.getSelectedRow();
                        if (readySelectedRow >= 0)
                        {
                            readySelectedMu = readySchedulesTable.getValueAt(readySelectedRow, idx_MU).toString();
                            readySelectedDate = readySchedulesTable.getValueAt(readySelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    readySchedulesPane.setViewportView(loadingReadyLabel);
                    display30Days.setEnabled(false);
                    display1year.setEnabled(false);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsSchedulesInfor(getFormComponent(), feeder, site, 365, "Ready");
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                data = new Object[]
                {
                    rs.getString("MU"),             // idx_MU
                    rs.getDate("REPORTING_DATE"),   // idx_REPORTING_DATE
                    rs.getString("STATUS"),         // idx_STATUS
                    rs.getString("TOTALVIEWID"),    // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),     // idx_UNION_FLAG
                    futureFlag,                     // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")   // idx_IMPORT_LOCKED
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Ready Schedules data.");
                readySchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                if (readySelectedRow >= 0 && readySelectedMu != null && readySelectedDate != null && readySelectedRow <= readySchedulesTable.getRowCount() - 1)
                {
                    if (readySchedulesTable.getValueAt(readySelectedRow, idx_MU).equals(readySelectedMu) &&
                        readySchedulesTable.getValueAt(readySelectedRow, idx_REPORTING_DATE).toString().equals(readySelectedDate))
                    {
                        readySchedulesTable.changeSelection(readySelectedRow, 0, false, false);
                    }
                }
                readySchedulesPane.setViewportView(readySchedulesTable);
                revalidate();
                int position = readyScrollPosition + (readySchedulesTable.getRowCount() - readyRowCount) * 16;
                if (readyScrollPosition != 0 && position > 0)
                {
                    readySchedulesPane.getVerticalScrollBar().setValue(position);
                }

                display30Days.setEnabled(true);
                display1year.setEnabled(true);
            }
            refreshReadySchedulesLock.release();
        }
        
        private void createTable()
        {
            readySchedulesTable = new JTable(readySchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (readySchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            readySchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(readySchedulesTable)).start();
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            
            Misc.configureTable(readySchedulesTable, true, false, false);
            if (readySortKeys != null)
            {
                readySchedulesTable.getRowSorter().setSortKeys(readySortKeys);
            }
            Misc.setHeaderRenderer(readySchedulesTable, true, true, null);
            Misc.setColumnSettings(readySchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(readySchedulesTable, idx_REPORTING_DATE, 85);
            Misc.setColumnSettings(readySchedulesTable, idx_STATUS, 0, false);
            Misc.setColumnSettings(readySchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(readySchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(readySchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(readySchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private void createSchedulePopup(MouseEvent e)
    {
        final JTable table = (JTable) e.getComponent();
        final int row = table.rowAtPoint(e.getPoint());
        if (row >= 0 && row < table.getRowCount())
        {
            table.setRowSelectionInterval(row, row);
        }
        else
        {
            table.clearSelection();
        }
        
        int rowindex = table.getSelectedRow();
        if (rowindex < 0)
        {
            return;
        }
        if (e.isPopupTrigger() && e.getComponent() instanceof JTable)
        {
            JPopupMenu popup = new JPopupMenu();
            JMenuItem openScheduleOption = new JMenuItem("Open Schedule");
            JMenuItem importUpdatesOption = new JMenuItem("Re-Import Schedule");
            JMenuItem lockImportingOption = new JMenuItem("Toggle Importing Lock");
            JMenuItem viewHistoryOption = new JMenuItem("Schedule Import History");
            JMenuItem deleteScheduleOption = new JMenuItem("Delete Schedule");
            openScheduleOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    new Thread(new OpenScheduleThread(table)).start();
                }
            });
            importUpdatesOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    final String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    if (Misc.isAlpha(mu.substring(0, 1)))
                    {
                        Misc.msgbox(getFormComponent(), "Cannot re-import NON-TV schedules", "Re-Importing Schedule", 1, 1, 1);
                        return;
                    }
                    boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
                    if (!okToImport)
                    {
                        return;
                    }
                    
                    
                    if (updatingMuRoster && RegionData.getNewFeature())
                    {
                        setCursor(Constants.NORMAL);
                        Misc.msgbox(getFormComponent(), "Cannot re-import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
                        return;
                    }
					String importType = "UPDATE";							 
                    
                    final Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu, reportingDate);
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate);
                    if (scheduleStatus.equals("In Use"))
                    {
                        Misc.msgbox(getFormComponent(), "Schedule has some or all records locked by another user - You cannot import.", "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (scheduleStatus.equals("Load Failed"))
                    {
                        Misc.msgbox(getFormComponent(), "Last import attempt failed - You cannot import. Email TVI Support: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (Arrays.asList("Requesting", "Loading").contains(scheduleStatus))
                    {
                        Misc.msgbox(getFormComponent(), "Currently processing an import request - You cannot import. If this status persists email: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (lockedBy != null)
                    {
                        Misc.msgbox(getFormComponent(), "Schedule is LOCKED by: " + lockedBy + " - You cannot import.", "Import Schedules", 1, 1, 1);
                        return;
                    }
                    
                    refreshData();
                    if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, reportingDate, reportingDate))
                    {
                        return;
                    }
                    setCursor(Constants.HOURGLASS);
                    Oracle.requestSchedule(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, importType, UserData.getUUID());
                    setCursor(Constants.NORMAL);
                }
            });
            lockImportingOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    final String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    final Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String lockedBy = "";
                    if (Misc.objectToString(table.getValueAt(row, idx_IMPORT_LOCKED)).equals(""))
                    {
                        lockedBy = UserData.getUUID();
                    }
                    setCursor(Constants.HOURGLASS);
                    Oracle.updateScheduleImportLock(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, lockedBy);
                    setCursor(Constants.NORMAL);
                    refreshData();
                }
            });
            viewHistoryOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    String mu = Misc.objectToString(table.getValueAt(rowindex, idx_MU));
                    Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    ScheduleImportHistory.getInstance(getFormComponent(), feeder, site, mu, reportingDate, reportingDate);
                }
            });
            deleteScheduleOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    if (!UserData.getUserType().equals("POWER"))
                    {
                        return;
                    }
                    
                    String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate);
                    switch (scheduleStatus)
                    {
                        case "Sent Waiting Results":
                            Misc.msgbox(getFormComponent(), "Schedule is Sent Waiting Results - You cannot delete.", "Delete Schedule", 1, 1, 1);
                            return;
                        case "Requesting":
                        case "Loading":
                            Misc.msgbox(getFormComponent(), "Currently processing an import request - You cannot delete.", "Delete Schedule", 1, 1, 1);
                            return;
                    }
                    
                    if (!Misc.msgbox(getFormComponent(), "Are you sure you want to delete?", "Delete Schedule", 1, 2, 1))
                    {
                        return;
                    }
                    
                    setCursor(Constants.HOURGLASS);
                    Oracle.deleteSchedule(getFormComponent(), feeder, site, mu, reportingDate);
                    refreshData();
                    setCursor(Constants.NORMAL);
                }
            });
            popup.add(openScheduleOption);
            popup.add(importUpdatesOption);
            popup.add(lockImportingOption);
            popup.add(viewHistoryOption);
            if (UserData.getUserType().equals("POWER"))
            {
                popup.add(deleteScheduleOption);
            }
            popup.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    
    private void setControlsEnabled(boolean enabled)
    {
        workingScheduleOpenButton.setEnabled(enabled);
        completedScheduleOpenButton.setEnabled(enabled);
        readyScheduleOpenButton.setEnabled(enabled);
    }
    
    private void closeForm()
    {
        // stop the refresh timers if they haven't been already
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                if (paycloseTimer.isRunning())
                {
                    paycloseTimer.stop();
                }
                if (workingTimer.isRunning())
                {
                    workingTimer.stop();
                }
                if (completedTimer.isRunning())
                {
                    completedTimer.stop();
                }
                if (readyTimer.isRunning())
                {
                    readyTimer.stop();
                }
                if (RegionData.getNewFeature())
                {
                    if (muRosterTimer.isRunning())
                    {
                        muRosterTimer.stop();
                    }
                }
            }
        });
        
        // if the refresh schedules threads are currently working
        if (refreshingPayClose)
        {
            // flag the threads to close & return
            disableRefreshing = true;
            refreshButton.setEnabled(false);
            return;
        }
        
        if (workingSchedulesWorker != null)
        {
            workingSchedulesWorker.cancel(true);
        }
        if (completedSchedulesWorker != null)
        {
            completedSchedulesWorker.cancel(true);
        }
        if (readySchedulesWorker != null)
        {
            readySchedulesWorker.cancel(true);
        }
        
        // close the form
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private class RefreshPayCloseThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshPayCloseLock.tryAcquire())
            {
                try
                {
                    refreshingPayClose = true;
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    
                    // refresh payroll period end date label and the begin new payroll period button
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            payrollPeriodLabel.setText("Current Payroll Period Ends: " + Misc.dateToStringMDY(RegionData.getPayClose()));
                            beginNewPayrollButton.setEnabled(todaysDate.compareTo(RegionData.getHotDay()) >= 0);
                        }
                    });
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    Date payEndDate = RegionData.getPayClose();
                    Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), payEndDate);
                    String siteLock = RegionData.getSiteLock();
                    if (siteLock != null && !siteLock.isEmpty())
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                switch (siteLock)
                                {
                                    case "PAY PERIOD":
                                        messageArea.setText("Site is locked, you must begin new payroll period.");
                                        break;
                                    case "COMPUTE 40":
                                        messageArea.setText("Site is temporarily locked by Compute 40 Hr check, call TVI Support if you have any questions.");
                                        break;
                                    case "COMPUTE FUTURE":
                                        messageArea.setText("Site is temporarily locked by Compute future exceptions, call TVI Support if you have any questions.");
                                        break;
                                    default:
                                        messageArea.setText("Site is currently locked, email TVI Support at " + Constants.EMAIL + " if you have any questions.");
                                        break;
                                }
                                messageArea.setVisible(true);
                            }
                        });
                    }
                    else if (todaysDate.compareTo(RegionData.getHotDay()) == 0)
                    {
                        // Set update future schedules reminder
                        boolean futureSchedulesNeedApproval = !Oracle.checkFutureSchedulesUpdated(getFormComponent(), feeder, site, payStartDate, payEndDate);
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (futureSchedulesNeedApproval)
                                {
                                    messageArea.setText("Reminder: Future schedules - Import updates for future schedules before payroll close.");
                                    messageArea.setVisible(true);
                                }
                                else
                                {
                                    messageArea.setVisible(false);
                                }
                            }
                        });
                        
                        // Set ComputeNightDiff reminders
                        if (feeder.equals("STI"))
                        {
                            if (!Oracle.checkFutureExceptions(getFormComponent(), feeder, site, payStartDate, payEndDate))
                            {
                                SwingUtilities.invokeLater(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        messageArea.setText("Reminder: Run weekly compute night diff - 3 week rule before payroll close!");
                                        messageArea.setVisible(true);
                                    }
                                });
                            }
                        }
                    }
                    else
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                messageArea.setVisible(false);
                            }
                        });
                    }
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    // Set weekly additional function reminder for STI
                    boolean computeAdditional;
                    if (feeder.equals("STI") && todaysDate == Misc.dateNoTime(RegionData.getHotDay()))
                    {
                        computeAdditional = !Oracle.checkFutureExceptions(getFormComponent(), feeder, site, payStartDate, payEndDate);
                    }
                    else
                    {
                        computeAdditional = false;
                    }
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            if (computeAdditional)
                            {
                                weeklyAdditionalFunctionsButton.setBackground(Color.RED);
                            }
                            else
                            {
                                weeklyAdditionalFunctionsButton.setBackground(Constants.GREEN);
                            }
                        }
                    });
                }
                finally
                {
                    refreshingPayClose = false;
                    refreshPayCloseLock.release();
                    if (disableRefreshing)
                    {
                        closeForm();
                    }
                }
            }
        }
    }
    
    private class RefreshMURosterThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshMURosterLock.tryAcquire())
            {
                try
                {
                    if (updatingMuRoster)
                    {
                        numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
                        if (numberOfRosterRequesting == 0)
                        {
                            Misc.msgbox(getFormComponent(), "MU Roster successfully updated", "MU Roster Update", 1, 1, 1);
                            updatingMuRoster = false;
                            updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
                            updateMURosterButton.setEnabled(true);
                        }
                    }
                }
                finally
                {
                    rosterUpdatedLabel.setText("MU Roster Updated:  " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
                    refreshMURosterLock.release();
                }
            }
        }
    }
        
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EmpRosterMaintenanceButton;
    private javax.swing.JButton WeeklyTimecodeMinutesButton;
    private javax.swing.JButton addRecordsButton;
    private javax.swing.JButton beginNewPayrollButton;
    private javax.swing.JButton commentMaintenanceButton;
    private javax.swing.JPanel completedColumnPanel;
    private javax.swing.JButton completedScheduleOpenButton;
    private javax.swing.JLabel completedSchedulesLabel;
    private javax.swing.JScrollPane completedSchedulesPane;
    private javax.swing.JRadioButton display1year;
    private javax.swing.JRadioButton display30Days;
    private javax.swing.ButtonGroup displayGroup;
    private javax.swing.JButton employeeDetailButton;
    private javax.swing.JButton employeeMaintenanceButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel futureScheduleFlagLabel;
    private javax.swing.JButton importButton;
    private javax.swing.JPanel importColumnPane;
    private javax.swing.JButton importFutureSchedulesButton;
    private javax.swing.JButton importIEXUpdatesButton;
    private javax.swing.JButton importOptionsButton;
    private javax.swing.JList<String> importSchedules;
    private javax.swing.JLabel importSchedulesLabel;
    private javax.swing.JScrollPane importSchedulesPane;
    private javax.swing.JPanel inforOperationsPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel loadingCompletedLabel;
    private javax.swing.JLabel loadingReadyLabel;
    private javax.swing.JLabel loadingWorkingLabel;
    private javax.swing.JLabel lookupByEmployeeLabel;
    private javax.swing.JPanel menuPane;
    private javax.swing.JTextField messageArea;
    private javax.swing.JButton muRosterMaintenanceButton;
    private javax.swing.JLabel officeLabel;
    private javax.swing.JLabel otherLabel;
    private javax.swing.JLabel payCycleLabel;
    private javax.swing.JLabel payrollEndingLabel;
    private javax.swing.JLabel payrollPeriodLabel;
    private javax.swing.JButton payrollPeriodSummaryButton;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JPanel readyColumnPanel;
    private javax.swing.JButton readyScheduleOpenButton;
    private javax.swing.JLabel readySchedulesLabel;
    private javax.swing.JScrollPane readySchedulesPane;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton reviewUpdatesButton;
    private javax.swing.JLabel rosterUpdatedLabel;
    private javax.swing.JPanel scheduleColumnsPanel;
    private javax.swing.JButton scheduleImportsCheckButton;
    private javax.swing.JPanel schedulePanel;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel testDBLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JButton updateMURosterButton;
    private javax.swing.JButton validateAllocationsButton;
    private javax.swing.JButton verificationlReportsButton;
    private javax.swing.JButton weeklyAdditionalFunctionsButton;
    private javax.swing.JLabel weeklyFunctionsLabel;
    private javax.swing.JButton weeklyHoursCheckButton;
    private javax.swing.JPanel workingColumnPanel;
    private javax.swing.JButton workingScheduleOpenButton;
    private javax.swing.JPanel workingSchedulesControlPanel;
    private javax.swing.JLabel workingSchedulesLabel;
    private javax.swing.JScrollPane workingSchedulesPane;
    private javax.swing.JPanel workingSchedulesTitlePanel;
    // End of variables declaration//GEN-END:variables
}
