package tvi.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.resources.Resources;

public final class WeeklyScheduledHoursCheck extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile WeeklyScheduledHoursCheck instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    Dimension loadingPanelDimensions = new Dimension(825, 250);
    
    Date endDate = null;
    double hours = 40;
    String hoursStr = "40";
    
    final static int idx_EMPID          = 0;
    final static int idx_EMPLOYEE       = 1;
    final static int idx_MU             = 2;
    final static int idx_PARTTIME_FLAG  = 3;
    final static int idx_REPORTING_DAY  = 4;
    final static int idx_REPORTING_DATE = 5;
    final static int idx_SHIFT          = 6;
    final static int idx_REGTOTAL       = 7;
    final static int idx_TOTALHOURS     = 8;
    final static int idx_DAYSREPORTED   = 9;
    
    public synchronized static WeeklyScheduledHoursCheck getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new WeeklyScheduledHoursCheck(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private WeeklyScheduledHoursCheck(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Calendar cal = Calendar.getInstance();
        cal.setTime(Misc.dateAddDays(Misc.getNextDayOfWeek(cal.getTime(), RegionData.getLastDayOfWeek(), true), 14));
        for (int i = 0; i < 55; i++)
        {
            pickDate.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, - 7);
        }
        pickDate.setSelectedIndex(2);
        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                                loadingLabel.setVisible(true);
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    loadingLabel.setText("LOADING...");
                    loadingLabel.setVisible(true);
                    scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
                    validate();
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "AT&T ID",                                      // idx_EMPID
                "Employee",                                     // idx_EMPLOYEE
                "MU",                                           // idx_MU
                Misc.centerHTML("Part<br>Time"),                // idx_PARTTIME_FLAG
                Misc.centerHTML("Day<br>of Week"),              // idx_REPORTING_DAY
                "Date",                                         // idx_REPORTING_DATE
                "Shift",                                        // idx_SHIFT
                Misc.centerHTML("Reg<br>+ Abs"),                // idx_REGTOTAL
                Misc.centerHTML("Hours<br>for Week"),           // idx_TOTALHOURS
                Misc.centerHTML("Days Reported<br>should be 7")  // idx_DAYSREPORTED   // US ONLY
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsHoursCheckInfor(getFormComponent(), feeder, site, endDate, hoursStr);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("EMPID"),                             // idx_EMPID
                    rs.getString("EMPLOYEE"),                          // idx_EMPLOYEE
                    rs.getString("MU"),                                // idx_MU
                    Misc.oracleToBoolean(rs.getInt("PARTTIME_FLAG")),  // idx_PARTTIME_FLAG
                    rs.getDate("REPORTING_DATE"),                      // idx_REPORTING_DAY
                    rs.getDate("REPORTING_DATE"),                      // idx_REPORTING_DATE
                    rs.getBigDecimal("SHIFT"),                         // idx_SHIFT
                    rs.getBigDecimal("REGTOTAL"),                      // idx_REGTOTAL
                    rs.getBigDecimal("TOTALHOURS"),                    // idx_TOTALHOURS
                    rs.getInt("DAYSREPORTED")                          // idx_DAYSREPORTED
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading scheduled hours check data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                if (dataModel.getRowCount() > 0)
                {
                    Misc.scaleScrollPaneToTable(getFormComponent(), scheduledHoursCheckScrollPane, table);
                    scheduledHoursCheckScrollPane.setViewportView(table);
                }
                else
                {
                    loadingLabel.setText("NO ERRORS");
                    loadingLabel.setVisible(true);
                    scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
                    scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
                }
                validate();
            }
            else
            {
                clearTable();
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_SHIFT:
                        case idx_REGTOTAL:
                        case idx_TOTALHOURS:
                            return BigDecimal.class;
                        case idx_PARTTIME_FLAG:
                            return Boolean.class;
                        case idx_REPORTING_DAY:
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_DAYSREPORTED:
                            return Integer.class;
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_MU:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, true, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_EMPID, 80);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 160, Constants.LEFT);
            Misc.setColumnSettings(table, idx_MU, 60);
            Misc.setColumnSettings(table, idx_PARTTIME_FLAG, 50, false);
            Misc.setColumnSettings(table, idx_REPORTING_DAY, 70, "EEE", Constants.CENTER);
            Misc.setColumnSettings(table, idx_REPORTING_DATE, 100);
            Misc.setColumnSettings(table, idx_SHIFT, 50);
            Misc.setColumnSettings(table, idx_REGTOTAL, 65);
            Misc.setColumnSettings(table, idx_TOTALHOURS, 65);
            Misc.setColumnSettings(table, idx_DAYSREPORTED, 105);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        hoursRadioGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        hoursPerWeekPanel = new javax.swing.JPanel();
        hoursPerWeekLabel = new javax.swing.JLabel();
        radioOption40 = new javax.swing.JRadioButton();
        radioOption375 = new javax.swing.JRadioButton();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        subtitleLabel = new javax.swing.JLabel();
        weekEndingLabel = new javax.swing.JLabel();
        retrieveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        centerPanel = new javax.swing.JPanel();
        scheduledHoursCheckScrollPane = new javax.swing.JScrollPane();
        loadingPanel = new javax.swing.JPanel();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        printButton = new javax.swing.JButton();
        employeeMaintenanceButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Weekly Scheduled Hours Check");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(841, 500));
        setPreferredSize(new java.awt.Dimension(825, 500));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setToolTipText("");
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setMinimumSize(new java.awt.Dimension(805, 120));
        titlePanel.setPreferredSize(new java.awt.Dimension(825, 120));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hoursPerWeekPanel.setBackground(new java.awt.Color(120, 200, 200));
        hoursPerWeekPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        hoursPerWeekLabel.setText("Hours/Week:");
        hoursPerWeekPanel.add(hoursPerWeekLabel);

        radioOption40.setBackground(new java.awt.Color(120, 200, 200));
        hoursRadioGroup.add(radioOption40);
        radioOption40.setSelected(true);
        radioOption40.setText("40.0");
        radioOption40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioOption40ActionPerformed(evt);
            }
        });
        hoursPerWeekPanel.add(radioOption40);

        radioOption375.setBackground(new java.awt.Color(120, 200, 200));
        hoursRadioGroup.add(radioOption375);
        radioOption375.setText("37.5");
        radioOption375.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioOption375ActionPerformed(evt);
            }
        });
        hoursPerWeekPanel.add(radioOption375);

        titlePanel.add(hoursPerWeekPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 70, 80));

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Scheduled Hours Error Report ");
        titleLabel.setPreferredSize(new java.awt.Dimension(325, 25));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        pickDate.setPreferredSize(new java.awt.Dimension(150, 25));
        pickDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickDateActionPerformed(evt);
            }
        });
        titlePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, -1, -1));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("The following employees have schedules for the week that do NOT = 40 hours OR are missing days in the week!");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(825, 20));
        titlePanel.add(subtitleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 95, -1, -1));

        weekEndingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        weekEndingLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        weekEndingLabel.setText("Pick Week Ending Date:");
        weekEndingLabel.setPreferredSize(new java.awt.Dimension(200, 20));
        titlePanel.add(weekEndingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 60, 220, -1));

        retrieveButton.setBackground(new java.awt.Color(120, 200, 200));
        retrieveButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        retrieveButton.setText("Retrieve");
        retrieveButton.setPreferredSize(new java.awt.Dimension(130, 35));
        retrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retrieveButtonActionPerformed(evt);
            }
        });
        titlePanel.add(retrieveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 55, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(70, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(745, 10, 80, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMaximumSize(new java.awt.Dimension(825, 1600));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        scheduledHoursCheckScrollPane.setAlignmentY(0.0F);
        scheduledHoursCheckScrollPane.setMaximumSize(new java.awt.Dimension(825, 450));
        scheduledHoursCheckScrollPane.setMinimumSize(new java.awt.Dimension(825, 23));

        loadingPanel.setPreferredSize(new java.awt.Dimension(823, 248));
        loadingPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 100));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingPanel.add(loadingLabel);

        scheduledHoursCheckScrollPane.setViewportView(loadingPanel);

        centerPanel.add(scheduledHoursCheckScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(825, 20));
        bottomPanel.setPreferredSize(new java.awt.Dimension(825, 70));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 80, 20));

        printButton.setBackground(new java.awt.Color(120, 200, 200));
        printButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        printButton.setText("Print");
        printButton.setPreferredSize(new java.awt.Dimension(80, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(printButton);

        employeeMaintenanceButton.setBackground(new java.awt.Color(120, 200, 200));
        employeeMaintenanceButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        employeeMaintenanceButton.setText("Employee Maintenance");
        employeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(180, 30));
        employeeMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMaintenanceButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(employeeMaintenanceButton);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", hoursStr + " Hour Check");
    }//GEN-LAST:event_printButtonActionPerformed

    private void retrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retrieveButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_retrieveButtonActionPerformed

    private void radioOption40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioOption40ActionPerformed
        hours = 40;
        hoursStr = "40";
        subtitleLabel.setText("The following employees have schedules for the week that do NOT = 40 hours OR are missing days in the week!");
    }//GEN-LAST:event_radioOption40ActionPerformed

    private void radioOption375ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioOption375ActionPerformed
        hours = 37.5;
        hoursStr = "37.5";
        subtitleLabel.setText("The following employees have schedules for the week that do NOT = 37.5 hours OR are missing days in the week!");
    }//GEN-LAST:event_radioOption375ActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void employeeMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMaintenanceButtonActionPerformed
        if (table.getSelectedRow() == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select a record first.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        String empidSelected = Misc.objectToString(table.getValueAt(table.getSelectedRow(), idx_EMPID));
        EmployeeMaintenance.getInstance(getFormComponent(), feeder, site, empidSelected);
    }//GEN-LAST:event_employeeMaintenanceButtonActionPerformed

    private void pickDateActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_pickDateActionPerformed
    {//GEN-HEADEREND:event_pickDateActionPerformed
        setCursor(Constants.HOURGLASS);
        if (worker != null)
        {
            worker.cancel(true);
        }
        clearTable();
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_pickDateActionPerformed
    
    private void clearTable()
    {
        loadingLabel.setVisible(false);
        scheduledHoursCheckScrollPane.setMaximumSize(loadingPanelDimensions);
        scheduledHoursCheckScrollPane.setPreferredSize(loadingPanelDimensions);
        scheduledHoursCheckScrollPane.setViewportView(loadingPanel);
        validate();
        
        table = null;
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton employeeMaintenanceButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel hoursPerWeekLabel;
    private javax.swing.JPanel hoursPerWeekPanel;
    private javax.swing.ButtonGroup hoursRadioGroup;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel loadingPanel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JButton printButton;
    private javax.swing.JRadioButton radioOption375;
    private javax.swing.JRadioButton radioOption40;
    private javax.swing.JButton retrieveButton;
    private javax.swing.JScrollPane scheduledHoursCheckScrollPane;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JLabel weekEndingLabel;
    // End of variables declaration//GEN-END:variables
}
