/**
 * This form can be opened in several different ways.
 *   These are determined by the string editType, which can be the following values:
 *     NORMAL           - Displays all employees by feeder & site
 *     DETAIL           - Displays a detailed view on a single employee, set by passing a non-null attid value in the constructor
 */

package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class EmployeeHistory extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile EmployeeHistory instance;
    
    private final String feeder;
    private final String site;
    private final String empid;
    String attid;
    String editType;
    
    JTable rosterTable = new JTable();
    CustomTableModel rosterData;
    TableSwingWorker rosterWorker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    boolean formClosing = false;
    boolean changingEmployees = false;
    boolean changingRoster = false;
    
    boolean rosterUpdated = false;
    int currentRosterRow = -1;
    int rosterCount = 0;
    
    boolean filterEnabled = true;
    int filterColumn = -1;
    boolean filterCoachDiscrepancies = false;
    
    // Define index variables to reference columns in the IEX_MU_ROSTER empTable
    final static int idx_Mu_IEX_INSTANCE            = 0;
    final static int idx_Mu_FEEDER                  = 1;
    final static int idx_Mu_SITE                    = 2;
    final static int idx_Mu_MU                      = 3;
    final static int idx_Mu_EMPLOYEE                = 4;
    final static int idx_Mu_EMPID                   = 5;
    final static int idx_Mu_AGENTID                 = 6;
    final static int idx_Mu_TVIP                    = 7;
    final static int idx_Mu_CUSTNUM                 = 8;
    final static int idx_Mu_START_DATE              = 9;
    final static int idx_Mu_END_DATE                = 10;
    final static int idx_Mu_STATUS                  = 11;
    final static int idx_Mu_DO_NOT_IMPORT           = 12;
    final static int idx_Mu_FLAG                    = 13;
    
    public synchronized static EmployeeHistory getInstance(Component parentFrame, String feeder, String site, String empid)
    {
        if (instance != null)
        {
            instance.toFront();
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new EmployeeHistory(feeder, site, empid);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private EmployeeHistory(String feeder, String site, String empid)
    {
        this.feeder = feeder;
        this.site = site;
        this.empid = empid;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        subtitleLabel2.setText("Employees marked in gray are active on another site.");

    }
    
    public String getATTID()
    {
        return attid;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        rosterScrollPane = new javax.swing.JScrollPane();
        loadingLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Employee Maintenance");
        setBackground(new java.awt.Color(183, 255, 255));
        setMinimumSize(new java.awt.Dimension(700, 400));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(183, 255, 255));
        topPanel.setMinimumSize(new java.awt.Dimension(700, 90));
        topPanel.setPreferredSize(new java.awt.Dimension(700, 90));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(183, 255, 255));
        titlePanel.setMinimumSize(new java.awt.Dimension(700, 90));
        titlePanel.setName(""); // NOI18N
        titlePanel.setPreferredSize(new java.awt.Dimension(700, 90));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(183, 255, 255));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(100, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Employee History");
        titleLabel.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 580, -1));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("Employees marked in grey are active on another site.");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 590, 20));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(183, 255, 255));
        centerPanel.setMaximumSize(new java.awt.Dimension(590, 500));
        centerPanel.setMinimumSize(new java.awt.Dimension(590, 310));
        centerPanel.setPreferredSize(new java.awt.Dimension(590, 310));
        centerPanel.setRequestFocusEnabled(false);
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        rosterScrollPane.setMaximumSize(new java.awt.Dimension(590, 290));
        rosterScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        rosterScrollPane.setPreferredSize(new java.awt.Dimension(590, 120));

        loadingLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel1.setText("LOADING...");
        loadingLabel1.setPreferredSize(new java.awt.Dimension(207, 25));
        rosterScrollPane.setViewportView(loadingLabel1);

        centerPanel.add(rosterScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
        
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
                                                    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        ResultSetWrapper results = null;
        boolean finishedMURoster = false;
        boolean cancelRefresh = false;
        
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    rosterWorker = null;
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // builds the column names and create the data model - buildEmpColumnNames is defined below inside this thread
                    rosterData = new CustomTableModel(buildRosterColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethodMURoster = this::getResults;
                    Function<ResultSet, Object[]> processResultsFuncMURoster = this::processResultsMURoster;
                    Consumer<Boolean> finalizeRefreshMethodMURoster = this::finalizeRefreshMURoster;
                    
                    // initialize the custom swing worker
                    rosterWorker = new TableSwingWorker(getFormComponent(), rosterData, getResultsMethodMURoster, processResultsFuncMURoster, finalizeRefreshMethodMURoster);
                    
                    if (cancelRefresh)
                    {
                        rosterWorker.cancel(true);
                    }
                    
                    if (!rosterWorker.isCancelled())
                    {
                        getResults();
                    }   
                    // start the worker.  it will get results from the database and add row to the empTable in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    rosterWorker.execute();
                }
                finally
                {
                    if (rosterWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel1.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading empTable, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the empTable.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    rosterScrollPane.setViewportView(loadingLabel1);
                }
            });
        }
        
        /**
        * buildRosterColumnNames()
        * 
        * Builds the column names to use for the rosterTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildRosterColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("IEX<br>Instance"),   //idx_Mu_IEX_INSTANCE
                "Feeder",                             //idx_Mu_FEEDER
                "Site",                               //idx_Mu_SITE
                "MU",                                 //idx_Mu_MU
                "Employee",                           //idx_Mu_EMPLOYEE
                Misc.centerHTML("AT&T<br>ID"),           //idx_Mu_EMPID
                Misc.centerHTML("Agent<br>ID"),       //idx_Mu_AGENTID
                "",                                   //idx_Mu_TVIP
                "",                                   //idx_Mu_CUSTNUM
                Misc.centerHTML("Start<br>Date"),     //idx_Mu_START_DATE
                Misc.centerHTML("End<br>Date"),       //idx_Mu_END_DATE
                "Status",                             //idx_Mu_STATUS
                Misc.centerHTML("Do Not<br>Import"),  //idx_Mu_DO_NOT_IMPORT
                ""                                    //idx_Mu_FLAG
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progress bar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.employeeHistory(getFormComponent(), empid);
        }
        
        /**
        * processResultsMURoster
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the empTable from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of empTable
        */
        private Object[] processResultsMURoster(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object []
                {
                    rs.getString("IEX_INSTANCE"),                       //idx_Mu_IEX_INSTANCE
                    rs.getString("FEEDER"),                             //idx_Mu_FEEDER
                    rs.getString("SITE"),                               //idx_Mu_SITE
                    rs.getString("MU"),                                 //idx_Mu_MU
                    rs.getString("EMPLOYEE"),                           //idx_Mu_EMPLOYEE
                    rs.getString("EMPID"),                              //idx_Mu_EMPID
                    rs.getString("AGENTID"),                            //idx_Mu_AGENTID
                    rs.getString("TVIP"),                               //idx_Mu_TVIP
                    rs.getInt("CUSTNUM"),                               //idx_Mu_CUSTNUM
                    rs.getDate("START_DATE"),                           //idx_Mu_START_DATE
                    rs.getDate("END_DATE"),                             //idx_Mu_END_DATE
                    rs.getString("STATUS"),                             //idx_Mu_STATUS
                    Misc.oracleToBoolean(rs.getObject("DO_NOT_IMPORT")),//idx_Mu_DO_NOT_IMPORT
                    rs.getString("FLAG")                                //idx_Mu_FLAG
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Employee Maintenance data.");
                rosterWorker.cancel(true);
            }
            rosterCount++;
            return data;
        }
        
        /**
        * finalizeRefreshMURoster
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the empTable - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the empTable is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshMURoster(Boolean cancelled)
        {
            if (!cancelled)
            {
                createRosterTable(); //defined below inside this thread
                configureRosterTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), rosterScrollPane, rosterTable);
                rosterScrollPane.setViewportView(rosterTable);
            }
            finishedMURoster = true;
            if (finishedMURoster)
            {
                finalizeRefresh();
            }
        }

        
        /**
        * finalizeRefresh
        * 
        * Called once all four table workers are finished executing.
        * This closes the callable statement and releases the semaphore lock.
        * 
        * Once this code is executed, if not cancelled, the tables are finished and displayed, ready for the user.
        */
        private void finalizeRefresh()
        {
            if (!rosterWorker.isCancelled())
            {
                RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                
                rosterScrollPane.setViewportView(rosterTable);
                rosterScrollPane.setVisible(true);
                rosterTable.setFillsViewportHeight(false);
                rosterTable.requestFocusInWindow();
                validate();
            }
            
            refreshTableLock.release();
        }
        
        private void createRosterTable()
        {
            rosterTable = new JTable(rosterData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Mu_DO_NOT_IMPORT:
                            return Boolean.class;
                        case idx_Mu_START_DATE:
                        case idx_Mu_END_DATE:
                            return Date.class;
                        case idx_Mu_IEX_INSTANCE:
                        case idx_Mu_FEEDER:
                        case idx_Mu_SITE:
                        case idx_Mu_MU:
                        case idx_Mu_EMPLOYEE:
                        case idx_Mu_EMPID:
                        case idx_Mu_AGENTID:
                        case idx_Mu_TVIP:
                        case idx_Mu_CUSTNUM:
                        case idx_Mu_STATUS:
                        case idx_Mu_FLAG: 
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= rosterCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (UserData.getUserAccessLevel().equals("READONLY") ||
                            !rosterTable.getValueAt(row, idx_Mu_FEEDER).toString().equals(feeder) ||
                            !rosterTable.getValueAt(row, idx_Mu_SITE).toString().equals(site))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                    }
                    return c;
                }
            };
        }

        private void configureRosterTable()
        {
            Misc.configureTable(rosterTable, false, true, false);
            Misc.setTableSorterNumeralComparator(rosterTable);
            Misc.setHeaderRenderer(rosterTable, true, true, null);
            Misc.setColumnSettings(rosterTable, idx_Mu_IEX_INSTANCE, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_FEEDER, 60);
            Misc.setColumnSettings(rosterTable, idx_Mu_SITE, 40);
            Misc.setColumnSettings(rosterTable, idx_Mu_MU, 50);
            Misc.setColumnSettings(rosterTable, idx_Mu_EMPLOYEE, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_EMPID, 60);
            Misc.setColumnSettings(rosterTable, idx_Mu_AGENTID, 60);
            Misc.setColumnSettings(rosterTable, idx_Mu_TVIP, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_CUSTNUM, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_START_DATE, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_END_DATE, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_STATUS, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_DO_NOT_IMPORT, 60, false);
            Misc.setColumnSettings(rosterTable, idx_Mu_FLAG, 0);
            
            rosterTable.setRowHeight(20);
        }
    }
  
    private void closeForm()
    {
        if (rosterWorker != null)
        {
            rosterWorker.cancel(true);
        }
        formClosing = true;
        if (rosterTable != null && rosterTable.isEditing())
        {
            rosterTable.getCellEditor().stopCellEditing();
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel loadingLabel1;
    private javax.swing.JScrollPane rosterScrollPane;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
