package tvicore.objects;

import java.awt.Component;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import tvicore.miscellaneous.Misc;

public class CellRenderer implements TableCellRenderer
{
    DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
    SimpleDateFormat formatter;
    boolean hideZeroes = false;
    
    public CellRenderer(TableColumn model, String dateFormat, boolean hideZeroValues, int alignment)
    {
        if (dateFormat == null || dateFormat.equals(""))
        {
            dateFormat = "MM/dd/yyyy";
        }
        formatter = new SimpleDateFormat(dateFormat);
        hideZeroes = hideZeroValues;
        renderer.setHorizontalAlignment(alignment);
    }
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col)
    {
        if (value instanceof Date || value instanceof java.sql.Date)
        {
            value = formatter.format(value);
        }
        else if (value instanceof BigDecimal)
        {
            value = ((BigDecimal)value).setScale(2, RoundingMode.HALF_EVEN);
            if (hideZeroes && value.toString().equals("0.00"))
            {
                value = "";
            }
        }
        else if (value instanceof Double)
        {
            if (hideZeroes && Misc.objectToDouble(value) == 0)
            {
                value = "";
            }
        }
        else if (value instanceof Integer)
        {
            if (hideZeroes && Misc.objectToInt(value) == 0)
            {
                value = "";
            }
        }
        return renderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
    }
}