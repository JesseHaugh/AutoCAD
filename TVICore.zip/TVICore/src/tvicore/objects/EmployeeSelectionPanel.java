package tvicore.objects;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableRowSorter;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

/**
 * EmployeeSelectionTable
 * 
 * Generic employee selection table used by multiple forms.
 */
public final class EmployeeSelectionPanel extends JPanel
{
    final Component parentFrame;
    final String feeder;
    final String site;
    final String sbcid;
    final Semaphore employeeSelectionLock;
    final Color bgColor;
    final String acceptedFeeders;
    
    ButtonGroup buttonGroup = new ButtonGroup();
    JPanel topPanel = new JPanel();
    JLabel titleLabel = new JLabel();
    JPanel centerPanel = new JPanel();
    JPanel headerPanel = new JPanel();
    JLabel feederLabel = new JLabel();
    JLabel siteLabel = new JLabel();
    JLabel muLabel = new JLabel();
    JPanel bodyPanel = new JPanel();
    JScrollPane feedersScrollPane = new JScrollPane();
    JLabel feedersLoadingLabel = new JLabel();
    JScrollPane sitesScrollPane = new JScrollPane();
    JLabel sitesLoadingLabel = new JLabel();
    JScrollPane musScrollPane = new JScrollPane();
    JLabel musLoadingLabel = new JLabel();
    JPanel employeeHeaderPanel = new JPanel();
    JPanel radioButtonsPanel = new JPanel();
    JRadioButton allEmployeesRadioButton = new JRadioButton();
    JRadioButton selectEmployeesRadioButton = new JRadioButton();
    JPanel messagePanel = new JPanel();
    JLabel messageLabel = new JLabel();
    JScrollPane employeesScrollPane = new JScrollPane();
    JLabel employeesLoadingLabel = new JLabel();
    JPanel bottomPanel = new JPanel();
    JLabel filterLabel = new JLabel();
    JTextField filterTextField = new JTextField();
    JButton clearFiltersButton = new JButton();
    
    JTable feedersTable = new JTable();
    JTable sitesTable = new JTable();
    JTable musTable = new JTable();
    JTable employeesTable = new JTable();
    CustomTableModel feedersData;
    CustomTableModel sitesData;
    CustomTableModel musData;
    CustomTableModel employeesData;
    TableSwingWorker feedersWorker;
    TableSwingWorker sitesWorker;
    TableSwingWorker musWorker;
    TableSwingWorker employeesWorker;
    
    TableRowSorter<CustomTableModel> feederSorter;
    TableRowSorter<CustomTableModel> siteSorter;
    TableRowSorter<CustomTableModel> muSorter;
    TableRowSorter<CustomTableModel> employeeSorter;
    
    boolean sitesSelectionListenerEnabled = true;
    boolean musSelectionListenerEnabled = true;
    boolean processingFilters = false;
    
    final static int idx_FEEDER    = 0;
    final static int idx_SITE      = 1;
    final static int idx_MU        = 2;
    final static int idx_EMPID     = 3;
    final static int idx_EMPLOYEE  = 4;
    final static int idx_LAST_DATE = 5;
    
    /**
     * EmployeeSelectionPanel
     * 
     * @param parentFrame
     * @param feeder default feeder to select. can pass "ALL"
     * @param site default site to select. can pass "ALL"
     * @param sbcid attid of the user whose permissions will be used to populate the table
     * @param employeeSelectionLock semaphore used to prevent simultaneous procedure calls - the procedure uses a single temporary table that cannot be shared
     * @param bgColor the background Color to use for created components so that they match the parentFrame
     * @param acceptedFeeders comma separated list of feeders to include in results. can pass "ALL"
     */
    public EmployeeSelectionPanel(Component parentFrame, String feeder, String site, String sbcid, Semaphore employeeSelectionLock, Color bgColor, String acceptedFeeders)
    {
        this.parentFrame = parentFrame;
        this.feeder = feeder;
        this.site = site;
        this.sbcid = sbcid;
        this.employeeSelectionLock = employeeSelectionLock;
        this.bgColor = bgColor;
        this.acceptedFeeders = acceptedFeeders;
        
        this.setLayout(new java.awt.BorderLayout());
        this.setMinimumSize(new Dimension(1, 1));
        this.setMaximumSize(new Dimension(615, 2400));
        
        createPanel();
    }
    
    private void createPanel()
    {
        //***  top panel
        topPanel.setBackground(bgColor);
        topPanel.setMinimumSize(new Dimension(615, 80));
        topPanel.setLayout(new java.awt.BorderLayout());
        
        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18));
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Employee Selection");
        titleLabel.setMaximumSize(new Dimension(300, 30));
        titleLabel.setMinimumSize(new Dimension(300, 30));
        titleLabel.setPreferredSize(new Dimension(615, 30));
        topPanel.add(titleLabel, java.awt.BorderLayout.PAGE_START);
        //this.add(topPanel, java.awt.BorderLayout.PAGE_START);
        
        //*** center panel
        centerPanel.setBackground(bgColor);
        centerPanel.setMinimumSize(new Dimension(615, 300));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));
        
        headerPanel.setBackground(bgColor);
        headerPanel.setMaximumSize(new Dimension(615, 30));
        headerPanel.setMinimumSize(new Dimension(615, 30));
        headerPanel.setPreferredSize(new Dimension(615, 30));
        headerPanel.setLayout(new javax.swing.BoxLayout(headerPanel, javax.swing.BoxLayout.LINE_AXIS));
        
        feederLabel = new JLabel();
        feederLabel.setBackground(bgColor);
        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        feederLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        feederLabel.setText("FEEDER");
        feederLabel.setMaximumSize(new Dimension(205, 30));
        feederLabel.setMinimumSize(new Dimension(205, 30));
        feederLabel.setPreferredSize(new Dimension(205, 30));
        headerPanel.add(feederLabel);
        
        siteLabel.setBackground(bgColor);
        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        siteLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        siteLabel.setText("SITE");
        siteLabel.setMaximumSize(new Dimension(205, 30));
        siteLabel.setMinimumSize(new Dimension(205, 30));
        siteLabel.setPreferredSize(new Dimension(205, 30));
        headerPanel.add(siteLabel);
        
        muLabel.setBackground(bgColor);
        muLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        muLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        muLabel.setText("MU");
        muLabel.setMaximumSize(new Dimension(205, 30));
        muLabel.setMinimumSize(new Dimension(205, 30));
        muLabel.setPreferredSize(new Dimension(205, 30));
        headerPanel.add(muLabel);
        
        centerPanel.add(headerPanel);
        
        bodyPanel.setBackground(bgColor);
        bodyPanel.setMaximumSize(new Dimension(615, 219));
        bodyPanel.setMinimumSize(new Dimension(615, 219));
        bodyPanel.setPreferredSize(new Dimension(615, 219));
        bodyPanel.setLayout(new javax.swing.BoxLayout(bodyPanel, javax.swing.BoxLayout.LINE_AXIS));
        
        feedersScrollPane.setAlignmentY(0.0F);
        feedersScrollPane.setFocusable(false);
        feedersScrollPane.setMaximumSize(new Dimension(205, 220));
        feedersScrollPane.setMinimumSize(new Dimension(205, 220));
        feedersScrollPane.setPreferredSize(new Dimension(205, 220));
        
        feedersLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        feedersLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        feedersLoadingLabel.setText("LOADING...");
        feedersScrollPane.setViewportView(feedersLoadingLabel);
        
        bodyPanel.add(feedersScrollPane);
        
        sitesScrollPane.setAlignmentY(0.0F);
        sitesScrollPane.setFocusable(false);
        sitesScrollPane.setMaximumSize(new Dimension(205, 220));
        sitesScrollPane.setMinimumSize(new Dimension(205, 220));
        sitesScrollPane.setPreferredSize(new Dimension(205, 220));
        
        sitesLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        sitesLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sitesLoadingLabel.setText("LOADING...");
        sitesScrollPane.setViewportView(sitesLoadingLabel);
        
        bodyPanel.add(sitesScrollPane);
        
        musScrollPane.setAlignmentY(0.0F);
        musScrollPane.setFocusable(false);
        musScrollPane.setMaximumSize(new Dimension(205, 220));
        musScrollPane.setMinimumSize(new Dimension(205, 220));
        musScrollPane.setPreferredSize(new Dimension(205, 220));
        
        musLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        musLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        musLoadingLabel.setText("LOADING...");
        musScrollPane.setViewportView(musLoadingLabel);
        
        bodyPanel.add(musScrollPane);
        
        centerPanel.add(bodyPanel);
        
        employeeHeaderPanel.setBackground(bgColor);
        employeeHeaderPanel.setMaximumSize(new java.awt.Dimension(615, 60));
        employeeHeaderPanel.setMinimumSize(new java.awt.Dimension(615, 60));
        employeeHeaderPanel.setPreferredSize(new java.awt.Dimension(615, 60));
        employeeHeaderPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        
        radioButtonsPanel.setBackground(bgColor);
        radioButtonsPanel.setMaximumSize(new java.awt.Dimension(250, 60));
        radioButtonsPanel.setMinimumSize(new java.awt.Dimension(250, 60));
        radioButtonsPanel.setPreferredSize(new java.awt.Dimension(250, 60));
        radioButtonsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        
        allEmployeesRadioButton.setBackground(bgColor);
        buttonGroup.add(allEmployeesRadioButton);
        allEmployeesRadioButton.setFont(new java.awt.Font("Tahoma", 0, 12));
        allEmployeesRadioButton.setSelected(true);
        allEmployeesRadioButton.setText("All Employees");
        allEmployeesRadioButton.setPreferredSize(new java.awt.Dimension(250, 30));
        allEmployeesRadioButton.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                employeesRadioButtonActionPerformed(evt);
            }
        });
        radioButtonsPanel.add(allEmployeesRadioButton);
        
        selectEmployeesRadioButton.setBackground(bgColor);
        buttonGroup.add(selectEmployeesRadioButton);
        selectEmployeesRadioButton.setFont(new java.awt.Font("Tahoma", 0, 12));
        selectEmployeesRadioButton.setText("Select Individual Employee(s) Below");
        selectEmployeesRadioButton.setPreferredSize(new java.awt.Dimension(250, 30));
        selectEmployeesRadioButton.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                employeesRadioButtonActionPerformed(evt);
            }
        });
        radioButtonsPanel.add(selectEmployeesRadioButton);
        
        employeeHeaderPanel.add(radioButtonsPanel);
        
        messagePanel.setBackground(bgColor);
        messagePanel.setMaximumSize(new java.awt.Dimension(305, 60));
        messagePanel.setMinimumSize(new java.awt.Dimension(305, 60));
        messagePanel.setPreferredSize(new java.awt.Dimension(355, 60));
        messagePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 20));
        
        messageLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        messageLabel.setText("<html>NOTE: Text filters will have no effect on report generation;<br>Highlight the desired employee(s) below to narrow selection.");
        messageLabel.setToolTipText("");
        messageLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        messageLabel.setMaximumSize(new java.awt.Dimension(355, 60));
        messageLabel.setMinimumSize(new java.awt.Dimension(355, 60));
        messageLabel.setPreferredSize(new java.awt.Dimension(340, 30));
        messageLabel.setVisible(false);
        messagePanel.add(messageLabel);
        
        employeeHeaderPanel.add(messagePanel);
        
        centerPanel.add(employeeHeaderPanel);
        
        employeesScrollPane.setAlignmentY(0.0F);
        employeesScrollPane.setFocusable(false);
        employeesScrollPane.setMaximumSize(new Dimension(615, 600));
        employeesScrollPane.setMinimumSize(new Dimension(240, 20));
        employeesScrollPane.setPreferredSize(new Dimension(615, 600));
        
        employeesLoadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
        employeesLoadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        employeesLoadingLabel.setText("LOADING...");
        employeesScrollPane.setViewportView(employeesLoadingLabel);
        
        centerPanel.add(employeesScrollPane);
        this.add(centerPanel, java.awt.BorderLayout.CENTER);
        
        //*** bottom panel
        bottomPanel.setBackground(bgColor);
        bottomPanel.setPreferredSize(new Dimension(615, 50));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 10));
        
        filterLabel.setText("Text Filter:");
        filterLabel.setMaximumSize(new java.awt.Dimension(50, 30));
        filterLabel.setMinimumSize(new java.awt.Dimension(50, 30));
        filterLabel.setPreferredSize(new java.awt.Dimension(60, 30));
        bottomPanel.add(filterLabel);
        
        filterTextField.setPreferredSize(new Dimension(180, 30));
        filterTextField.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override public void insertUpdate(DocumentEvent e)  { filterTextFieldActionPerformed(); }
            @Override public void removeUpdate(DocumentEvent e)  { filterTextFieldActionPerformed(); }
            @Override public void changedUpdate(DocumentEvent e) { filterTextFieldActionPerformed(); }
        });
        bottomPanel.add(filterTextField);
        
        clearFiltersButton.setBackground(bgColor);
        clearFiltersButton.setFont(new java.awt.Font("Tahoma", 1, 13));
        clearFiltersButton.setText("Clear Filters");
        clearFiltersButton.setMaximumSize(new Dimension(130, 30));
        clearFiltersButton.setMinimumSize(new Dimension(130, 30));
        clearFiltersButton.setPreferredSize(new Dimension(130, 30));
        clearFiltersButton.addActionListener(new java.awt.event.ActionListener()
        {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                clearSelections();
            }
        });
        bottomPanel.add(clearFiltersButton);
        this.add(bottomPanel, java.awt.BorderLayout.PAGE_END);
    }
    
    private void filterTextFieldActionPerformed()
    {
        messageLabel.setVisible(!filterTextField.getText().equals(""));
        employeesTable.clearSelection();
        allEmployeesRadioButton.setSelected(true);
        employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
        processFilters();
    }
    
    private void employeesRadioButtonActionPerformed(java.awt.event.ActionEvent evt)
    {
        if (employeesTable == null)
        {
            return;
        }
        employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
    }
    
    private void processFilters()
    {
        if (!processingFilters)
        {
            processingFilters = true;
            // feeder filter
            RowFilter<CustomTableModel, Object> feederFilter = null;
            if (feedersTable.getSelectedRowCount() > 0)
            {
                StringBuilder feedersToFilter = new StringBuilder();
                if (feedersTable.getSelectedRowCount() > 1)
                {
                    for (int i = 0; i < feedersTable.getSelectedRows().length; i++)
                    {
                        feedersToFilter.append(Misc.objectToString(feedersTable.getValueAt(feedersTable.getSelectedRows()[i], idx_FEEDER)));
                        if (i < feedersTable.getSelectedRows().length - 1)
                        {
                            feedersToFilter.append("|");
                        }
                    }
                }
                else
                {
                    feedersToFilter.append(Misc.objectToString(feedersTable.getValueAt(feedersTable.getSelectedRow(), idx_FEEDER)));
                }
                if (!Misc.objectEquals(feedersToFilter.toString(), "ALL"))
                {
                    feederFilter = RowFilter.regexFilter(feedersToFilter.toString(), idx_FEEDER);
                }
            }
            
            // site filter
            RowFilter<CustomTableModel, Object> siteFilter = null;
            if (sitesTable.getSelectedRowCount() > 0)
            {
                if (!(sitesTable.getSelectedRowCount() == 1 && Misc.objectToString(sitesTable.getValueAt(sitesTable.getSelectedRow(), idx_SITE)).equals("ALL")))
                {   // at least one site is selected
                    List<RowFilter<CustomTableModel, Object>> sitesToFilter = new ArrayList<>();
                    RowFilter<CustomTableModel, Object> columnFilter;
                    for (int i = 0; i < sitesTable.getSelectedRows().length; i++)
                    {
                        if (!Misc.objectToString(sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_SITE)).equals("ALL"))
                        {
                            List<RowFilter<CustomTableModel, Object>> currentSiteFilter = new ArrayList<>();
                            columnFilter = RowFilter.regexFilter("^" + sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_FEEDER).toString() + "$", idx_FEEDER);
                            currentSiteFilter.add(columnFilter);
                            columnFilter = RowFilter.regexFilter("^" + sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_SITE).toString() + "$", idx_SITE);
                            currentSiteFilter.add(columnFilter);
                            sitesToFilter.add(RowFilter.andFilter(currentSiteFilter));
                        }
                    }
                    siteFilter = RowFilter.orFilter(sitesToFilter);
                }
            }
            
            // mu filter
            RowFilter<CustomTableModel, Object> muFilter = null;
            if (musTable.getSelectedRowCount() > 0)
            {
                if (!(musTable.getSelectedRowCount() == 1 && Misc.objectToString(musTable.getValueAt(musTable.getSelectedRow(), idx_MU)).equals("ALL")))
                {   // at least one mu is selected
                    List<RowFilter<CustomTableModel, Object>> musToFilter = new ArrayList<>();
                    RowFilter<CustomTableModel, Object> columnFilter;
                    for (int i = 0; i < musTable.getSelectedRows().length; i++)
                    {
                        if (!Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_MU)).equals("ALL"))
                        {
                            List<RowFilter<CustomTableModel, Object>> currentMuFilter = new ArrayList<>();
                            columnFilter = RowFilter.regexFilter("^" + musTable.getValueAt(musTable.getSelectedRows()[i], idx_FEEDER).toString() + "$", idx_FEEDER);
                            currentMuFilter.add(columnFilter);
                            columnFilter = RowFilter.regexFilter("^" + musTable.getValueAt(musTable.getSelectedRows()[i], idx_SITE).toString() + "$", idx_SITE);
                            currentMuFilter.add(columnFilter);
                            columnFilter = RowFilter.regexFilter("^" + musTable.getValueAt(musTable.getSelectedRows()[i], idx_MU).toString() + "$", idx_MU);
                            currentMuFilter.add(columnFilter);
                            musToFilter.add(RowFilter.andFilter(currentMuFilter));
                        }
                    }
                    muFilter = RowFilter.orFilter(musToFilter);
                }
            }
            
            // text input filter
            RowFilter<CustomTableModel, Object> inputFilter = null;
            List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
            if (filterTextField.getText().length() > 0)
            {
                RowFilter<CustomTableModel, Object> textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
                inputFilters.add(textFilter);
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    RowFilter<CustomTableModel, Object> dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
                    inputFilters.add(dateFilter);
                }
                inputFilter = RowFilter.orFilter(inputFilters);
            }
            
            
            // APPLY FILTERS
            List<RowFilter<CustomTableModel, Object>> siteFilters = new ArrayList<>();
            List<RowFilter<CustomTableModel, Object>> muFilters = new ArrayList<>();
            List<RowFilter<CustomTableModel, Object>> employeeFilters = new ArrayList<>();
            
            if (feederFilter != null)
            {
                siteFilters.add(feederFilter);
                muFilters.add(feederFilter);
                employeeFilters.add(feederFilter);
            }
            if (siteFilter != null)
            {
                muFilters.add(siteFilter);
                employeeFilters.add(siteFilter);
            }
            if (muFilter != null)
            {
                employeeFilters.add(muFilter);
            }
            if (inputFilter != null)
            {
                employeeFilters.add(inputFilter);
            }
            
            if (siteSorter != null)
            {
                List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
                filters.add(RowFilter.andFilter(siteFilters));
                filters.add(RowFilter.regexFilter("^ALL$", idx_SITE));
                siteSorter.setRowFilter(RowFilter.orFilter(filters));
            }
            if (muSorter != null)
            {
                List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
                filters.add(RowFilter.andFilter(muFilters));
                filters.add(RowFilter.regexFilter("^ALL$", idx_MU));
                muSorter.setRowFilter(RowFilter.orFilter(filters));
            }
            if (employeeSorter != null)
            {
                employeeSorter.setRowFilter(RowFilter.andFilter(employeeFilters));
            }
            
            processingFilters = false;
        }
    }
    
    public void refreshData()
    {
        new Thread(new RefreshTablesThread()).start();
    }
    
    /**
    * getEmployeeSelection
    * 
    * returns the current table selections with the following format:
    *   "feeder,site,mu,empid|feeder,site,mu,empid"
    */
    public String getEmployeeSelection()
    {
        StringBuilder employeeSelection = new StringBuilder();
        
        if (selectEmployeesRadioButton.isSelected() && employeesTable.getSelectedRowCount() > 0)
        { // if any employees are selected
            for (int i = 0; i < employeesTable.getSelectedRowCount(); i++)
            {
                employeeSelection.append(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_FEEDER).toString());
                employeeSelection.append(",");
                employeeSelection.append(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_SITE).toString());
                employeeSelection.append(",");
                employeeSelection.append(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_MU).toString());
                employeeSelection.append(",");
                employeeSelection.append(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_EMPID).toString());
                employeeSelection.append("|");
            }
        }
        else if (musTable.getSelectedRowCount() > 0 &&
                !(musTable.getSelectedRowCount() == 1 && musTable.getValueAt(musTable.getSelectedRow(), idx_MU).equals("ALL")))
        { // if any mus are selected
            for (int i = 0; i < musTable.getSelectedRowCount(); i++)
            {
                String mu = musTable.getValueAt(musTable.getSelectedRows()[i], idx_MU).toString();
                if (!mu.equals("ALL"))
                {
                    employeeSelection.append(musTable.getValueAt(musTable.getSelectedRows()[i], idx_FEEDER).toString());
                    employeeSelection.append(",");
                    employeeSelection.append(musTable.getValueAt(musTable.getSelectedRows()[i], idx_SITE).toString());
                    employeeSelection.append(",");
                    employeeSelection.append(mu);
                    employeeSelection.append("|");
                }
            }
        }
        else if (sitesTable.getSelectedRowCount() > 0 &&
                !(sitesTable.getSelectedRowCount() == 1 && sitesTable.getValueAt(sitesTable.getSelectedRow(), idx_SITE).equals("ALL")))
        { // if any sites are selected
            for (int i = 0; i < sitesTable.getSelectedRowCount(); i++)
            {
                String curSite = sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_SITE).toString();
                if (!curSite.equals("ALL"))
                {
                    employeeSelection.append(sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_FEEDER).toString());
                    employeeSelection.append(",");
                    employeeSelection.append(curSite);
                    employeeSelection.append("|");
                }
            }
        }
        else
        { // "ALL" sites are selected
            for (int i = 0; i < sitesTable.getRowCount(); i++)
            {
                String curSite = sitesTable.getValueAt(i, idx_SITE).toString();
                if (!curSite.equals("ALL"))
                {
                    employeeSelection.append(sitesTable.getValueAt(i, idx_FEEDER).toString());
                    employeeSelection.append(",");
                    employeeSelection.append(curSite);
                    employeeSelection.append("|");
                }
            }
        }
        
        return employeeSelection.toString();
    }
    
    private void clearSelections()
    {
        processingFilters = true;
        feedersTable.setRowSelectionInterval(0, 0);
        sitesTable.setRowSelectionInterval(0, 0);
        musTable.setRowSelectionInterval(0, 0);
        allEmployeesRadioButton.setSelected(true);
        employeesTable.clearSelection();
        filterTextField.setText("");
        processingFilters = false;
        processFilters();
        
        processingFilters = true;
        for (int i = 0; i < feedersTable.getRowCount(); i++)
        {
            if (feedersTable.getValueAt(i, idx_FEEDER).equals(feeder))
            {
                feedersTable.setRowSelectionInterval(i, i);
                break;
            }
        }
        
        for (int i = 0; i < sitesTable.getRowCount(); i++)
        {
            if (Misc.objectEquals(sitesTable.getValueAt(i, idx_FEEDER), feeder) && 
                sitesTable.getValueAt(i, idx_SITE).equals(site))
            {
                sitesTable.setRowSelectionInterval(i, i);
                break;
            }
        }
        processingFilters = false;
        processFilters();
    }
    
    private class RefreshTablesThread implements Runnable
    {
        CountDownLatch latch;
        ResultSetWrapper results = null;
        boolean finishedFeeders = false;
        boolean finishedSites = false;
        boolean finishedMus = false;
        boolean finishedEmployees = false;
        
        @Override
        public void run()
        {
            if (employeeSelectionLock.tryAcquire())
            {
                try
                {
                    feedersWorker = null;
                    sitesWorker = null;
                    musWorker = null;
                    employeesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    feedersData = new CustomTableModel(buildColumnNamesFeeders());
                    sitesData = new CustomTableModel(buildColumnNamesSites());
                    musData = new CustomTableModel(buildColumnNamesMus());
                    employeesData = new CustomTableModel(buildColumnNamesEmployees());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethodFeeders = this::getResultsFeeders;
                    Supplier<ResultSetWrapper> getResultsMethodSites = this::getResultsSites;
                    Supplier<ResultSetWrapper> getResultsMethodMus = this::getResultsMus;
                    Supplier<ResultSetWrapper> getResultsMethodEmployees = this::getResultsEmployees;
                    Function<ResultSet, Object[]> processResultsFuncFeeders = this::processResultsFeeders;
                    Function<ResultSet, Object[]> processResultsFuncSites = this::processResultsSites;
                    Function<ResultSet, Object[]> processResultsFuncMus = this::processResultsMus;
                    Function<ResultSet, Object[]> processResultsFuncEmployees = this::processResultsEmployees;
                    Consumer<Boolean> finalizeRefreshMethodFeeders = this::finalizeRefreshFeeders;
                    Consumer<Boolean> finalizeRefreshMethodSites = this::finalizeRefreshSites;
                    Consumer<Boolean> finalizeRefreshMethodMus = this::finalizeRefreshMus;
                    Consumer<Boolean> finalizeRefreshMethodEmployees = this::finalizeRefreshEmployees;
                    
                    // initialize a CountDownLatch with the number of workers to wait for
                    latch = new CountDownLatch(4);
                    
                    // initialize the custom swing workers
                    feedersWorker = new TableSwingWorker(parentFrame, feedersData, getResultsMethodFeeders, processResultsFuncFeeders, finalizeRefreshMethodFeeders, latch);
                    sitesWorker = new TableSwingWorker(parentFrame, sitesData, getResultsMethodSites, processResultsFuncSites, finalizeRefreshMethodSites, latch);
                    musWorker = new TableSwingWorker(parentFrame, musData, getResultsMethodMus, processResultsFuncMus, finalizeRefreshMethodMus, latch);
                    employeesWorker = new TableSwingWorker(parentFrame, employeesData, getResultsMethodEmployees, processResultsFuncEmployees, finalizeRefreshMethodEmployees, latch);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    if (!feedersWorker.isCancelled() && !sitesWorker.isCancelled() && !musWorker.isCancelled() && !employeesWorker.isCancelled())
                    {
                        getResults();
                    }
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    feedersWorker.execute();
                    sitesWorker.execute();
                    musWorker.execute();
                    employeesWorker.execute();
                }
                finally
                {
                    if (feedersWorker == null || sitesWorker == null || musWorker == null || employeesWorker == null) // The thread encountered an error before the workers could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                employeesLoadingLabel.setText("ERROR");
                            }
                        });
                        employeeSelectionLock.release();
                        Misc.msgbox(parentFrame, "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Canceling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Canceling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    employeesScrollPane.setViewportView(employeesLoadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNamesFeeders()
        * 
        * Builds the column names to use for the feeders table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesFeeders()
        {
            return new String[]
            {
                "Feeder"             // idx_FEEDER
            };
        }
        
        /**
        * buildColumnNamesSites()
        * 
        * Builds the column names to use for the sites table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesSites()
        {
            return new String[]
            {
                "Feeder",            // idx_FEEDER
                "Site"               // idx_SITE
            };
        }
        
        /**
        * buildColumnNamesMus()
        * 
        * Builds the column names to use for the mus table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesMus()
        {
            return new String[]
            {
                "Feeder",            // idx_FEEDER
                "Site",              // idx_SITE
                "MU"                 // idx_MU
            };
        }
        
        /**
        * buildColumnNamesEmployees()
        * 
        * Builds the column names to use for the employees table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesEmployees()
        {
            return new String[]
            {
                "Feeder",            // idx_FEEDER
                "Site",              // idx_SITE
                "MU",                // idx_MU
                "AT&T ID",           // idx_EMPID
                "Name",              // idx_EMPLOYEE
                "Last Report Date"   // idx_LAST_DATE
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private void getResults()
        {
            results = Oracle.getResultsEmployeeSelection(parentFrame, feeder, site, acceptedFeeders, sbcid);
        }
        
        /**
        * getResultsFeeders()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the feeders resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsFeeders()
        {
            return new ResultSetWrapper(results.getResultSetArray()[0]);
        }
        
        /**
        * getResultsSites()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the sites resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsSites()
        {
            return new ResultSetWrapper(results.getResultSetArray()[1]);
        }
        
        /**
        * getResultsMus()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the mus resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsMus()
        {
            return new ResultSetWrapper(results.getResultSetArray()[2]);
        }
        
        /**
        * getResultsEmployees()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the employees resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsEmployees()
        {
            return new ResultSetWrapper(results.getResultSetArray()[3]);
        }
        
        /**
        * processResultsFeeders
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsFeeders(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("FEEDER")       // idx_FEEDER
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error loading employee selection feeder data.");
                feedersWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsSites
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsSites(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("FEEDER"),      // idx_FEEDER
                    rs.getString("SITE")         // idx_SITE
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error loading employee selection site data.");
                sitesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsMus
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsMus(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("FEEDER"),      // idx_FEEDER
                    rs.getString("SITE"),        // idx_SITE
                    rs.getString("MU")           // idx_MU
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error loading employee selection mu data.");
                musWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsEmployees
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsEmployees(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("FEEDER"),      // idx_FEEDER
                    rs.getString("SITE"),        // idx_SITE
                    rs.getString("MU"),          // idx_MU
                    rs.getString("EMPID"),       // idx_EMPID
                    rs.getString("EMPLOYEE"),    // idx_EMPLOYEE
                    rs.getDate("LAST_DATE")      // idx_LAST_DATE
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error loading employee selection employee data.");
                employeesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefreshFeeders
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshFeeders(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methos are defined below inside this thread
                createFeedersTable();
                configureFeedersTable();
            }
            
            finishedFeeders = true;
            if (finishedFeeders && finishedSites && finishedMus && finishedEmployees)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshSites
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshSites(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methos are defined below inside this thread
                createSitesTable();
                configureSitesTable();
            }
            
            finishedSites = true;
            if (finishedFeeders && finishedSites && finishedMus && finishedEmployees)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshMus
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshMus(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methos are defined below inside this thread
                createMusTable();
                configureMusTable();
            }
            
            finishedMus = true;
            if (finishedFeeders && finishedSites && finishedMus && finishedEmployees)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshEmployees
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshEmployees(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methos are defined below inside this thread
                createEmployeesTable();
                configureEmployeesTable();
            }
            
            finishedEmployees = true;
            if (finishedFeeders && finishedSites && finishedMus && finishedEmployees)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefresh
        * 
        * Called once all four table workers are finished executing.
        * This closes the callable statement and releases the semaphore lock.
        * 
        * Once this code is executed, if not cancelled, the tables are finished and displayed, ready for the user.
        */
        private void finalizeRefresh()
        {
            try
            {
                // wait for all of the workers to properly finish and release their latches
                latch.await();
                if (results != null)
                {
                    results.close();
                }
            }
            catch (InterruptedException ex) { }
            if (!feedersWorker.isCancelled() && !sitesWorker.isCancelled() && !musWorker.isCancelled() && !employeesWorker.isCancelled())
            {
                clearSelections();
                feedersScrollPane.setViewportView(feedersTable);
                sitesScrollPane.setViewportView(sitesTable);
                musScrollPane.setViewportView(musTable);
                employeesScrollPane.setViewportView(employeesTable);
            }
            employeeSelectionLock.release();
        }
        
        private void createFeedersTable()
        {
            feedersTable = new JTable(feedersData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_FEEDER:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void createSitesTable()
        {
            sitesTable = new JTable(sitesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_FEEDER:
                        case idx_SITE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void createMusTable()
        {
            musTable = new JTable(musData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_FEEDER:
                        case idx_SITE:
                        case idx_MU:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void createEmployeesTable()
        {
            employeesTable = new JTable(employeesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_LAST_DATE:
                            return Date.class;
                        case idx_SITE:
                            return Integer.class;
                        case idx_FEEDER:
                        case idx_MU:
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureFeedersTable()
        {
            Misc.configureTable(feedersTable, true, true, false);
            Misc.setHeaderRenderer(feedersTable, true, true, null);
            Misc.setColumnSettings(feedersTable, idx_FEEDER, 185);
            feederSorter = new TableRowSorter<>(feedersData);
            for (int i = 0; i < feedersTable.getColumnCount(); i++)
            {
                feederSorter.setSortable(i, false);
            }
            feedersTable.setRowSorter(feederSorter);
            
            feedersTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        // UPDATE OTHER TABLE SELECTIONS
                        if (feedersTable.getSelectedRowCount() > 0)
                        {
                            // get selected feeder(s), if any
                            List<String> selectedFeeders = new ArrayList<>();
                            for (int i = 0; i < feedersTable.getSelectedRowCount(); i++)
                            {
                                String selectedFeeder = Misc.objectToString(feedersTable.getValueAt(feedersTable.getSelectedRows()[i], idx_FEEDER));
                                if (!Arrays.asList("", "ALL").contains(selectedFeeder))
                                {
                                    selectedFeeders.add(selectedFeeder);
                                }
                            }
                            if (!selectedFeeders.isEmpty())
                            {
                                // UPDATE SITES TABLE SELECTIONS
                                sitesSelectionListenerEnabled = false;
                                for (int i = sitesTable.getSelectedRowCount() - 1; i >= 0; i--)
                                {
                                    String selectedFeeder = Misc.objectToString(sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_FEEDER));
                                    if (!selectedFeeders.contains(selectedFeeder))
                                    {
                                        sitesTable.getSelectionModel().removeIndexInterval(sitesTable.getSelectedRows()[i], sitesTable.getSelectedRows()[i]);
                                    }
                                }
                                if (sitesTable.getSelectedRowCount() == 0)
                                {
                                    sitesTable.setRowSelectionInterval(0, 0);
                                }
                                sitesSelectionListenerEnabled = true;
                                
                                // UPDATE MUS TABLE SELECTIONS
                                musSelectionListenerEnabled = false;
                                for (int i = musTable.getSelectedRowCount() - 1; i >= 0; i--)
                                {
                                    String selectedFeeder = Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_FEEDER));
                                    if (!selectedFeeders.contains(selectedFeeder))
                                    {
                                        musTable.getSelectionModel().removeIndexInterval(musTable.getSelectedRows()[i], musTable.getSelectedRows()[i]);
                                    }
                                }
                                if (musTable.getSelectedRowCount() == 0)
                                {
                                    musTable.setRowSelectionInterval(0, 0);
                                }
                                musSelectionListenerEnabled = true;
                                
                                // UPDATE EMPLOYEES TABLE SELECTIONS
                                for (int i = employeesTable.getSelectedRowCount() - 1; i >= 0; i--)
                                {
                                    String selectedFeeder = Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_FEEDER));
                                    if (!selectedFeeders.contains(selectedFeeder))
                                    {
                                        employeesTable.getSelectionModel().removeIndexInterval(employeesTable.getSelectedRows()[i], employeesTable.getSelectedRows()[i]);
                                    }
                                    if (employeesTable.getSelectedRowCount() == 0)
                                    {
                                        allEmployeesRadioButton.setSelected(true);
                                        employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
                                    }
                                }
                            }
                        }
                        processFilters();
                    }
                }
            });
        }
        
        private void configureSitesTable()
        {
            Misc.configureTable(sitesTable, true, true, false);
            Misc.setHeaderRenderer(sitesTable, true, true, null);
            Misc.setColumnSettings(sitesTable, idx_FEEDER, 60);
            Misc.setColumnSettings(sitesTable, idx_SITE, 125);
            siteSorter = new TableRowSorter<>(sitesData);
            for (int i = 0; i < sitesTable.getColumnCount(); i++)
            {
                siteSorter.setSortable(i, false);
            }
            sitesTable.setRowSorter(siteSorter);
                    
            sitesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (sitesSelectionListenerEnabled && !e.getValueIsAdjusting())
                    {
                        // UPDATE OTHER TABLE SELECTIONS
                        if (sitesTable.getSelectedRowCount() > 0)
                        {
                            // get selected site(s), if any
                            List<String> selectedSites = new ArrayList<>();
                            for (int i = 0; i < sitesTable.getSelectedRowCount(); i++)
                            {
                                String selectedSite = Misc.objectToString(sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_FEEDER)) + Misc.objectToString(sitesTable.getValueAt(sitesTable.getSelectedRows()[i], idx_SITE));
                                if (!Arrays.asList("", "ALL").contains(selectedSite))
                                {
                                    selectedSites.add(selectedSite);
                                }
                            }
                            if (!selectedSites.isEmpty())
                            {
                                // UPDATE MUS TABLE SELECTIONS
                                musSelectionListenerEnabled = false;
                                for (int i = musTable.getSelectedRowCount() - 1; i >= 0; i--)
                                {
                                    String selectedSite = Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_FEEDER))
                                                        + Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_SITE));
                                    if (!selectedSites.contains(selectedSite))
                                    {
                                        musTable.getSelectionModel().removeIndexInterval(musTable.getSelectedRows()[i], musTable.getSelectedRows()[i]);
                                    }
                                }
                                if (musTable.getSelectedRowCount() == 0)
                                {
                                    musTable.setRowSelectionInterval(0, 0);
                                }
                                musSelectionListenerEnabled = true;
                                
                                // UPDATE EMPLOYEES TABLE SELECTIONS
                                for (int i = employeesTable.getSelectedRowCount() - 1; i >= 0; i--)
                                {
                                    String selectedSite = Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_FEEDER))
                                                        + Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_SITE));
                                    if (!selectedSites.contains(selectedSite))
                                    {
                                        employeesTable.getSelectionModel().removeIndexInterval(employeesTable.getSelectedRows()[i], employeesTable.getSelectedRows()[i]);
                                    }
                                }
                                if (employeesTable.getSelectedRowCount() == 0)
                                {
                                    allEmployeesRadioButton.setSelected(true);
                                    employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
                                }
                            }
                        }
                        processFilters();
                    }
                }
            });
        }
        
        private void configureMusTable()
        {
            Misc.configureTable(musTable, true, true, false);
            Misc.setHeaderRenderer(musTable, true, true, null);
            Misc.setColumnSettings(musTable, idx_FEEDER, 55);
            Misc.setColumnSettings(musTable, idx_SITE, 55);
            Misc.setColumnSettings(musTable, idx_MU, 75);
            muSorter = new TableRowSorter<>(musData);
            for (int i = 0; i < musTable.getColumnCount(); i++)
            {
                muSorter.setSortable(i, false);
            }
            musTable.setRowSorter(muSorter);
            
            musTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (musSelectionListenerEnabled && !e.getValueIsAdjusting())
                    {
                        // UPDATE OTHER TABLE SELECTIONS
                        if (musTable.getSelectedRowCount() > 0)
                        {
                            // get selected mu(s), if any
                            List<String> selectedMus = new ArrayList<>();
                            for (int i = 0; i < musTable.getSelectedRowCount(); i++)
                            {
                                String selectedMu = Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_FEEDER))
                                                  + Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_SITE))
                                                  + Misc.objectToString(musTable.getValueAt(musTable.getSelectedRows()[i], idx_MU));
                                if (!Arrays.asList("", "ALL").contains(selectedMu))
                                {
                                    selectedMus.add(selectedMu);
                                }
                            }
                            if (!selectedMus.isEmpty())
                            {
                                // UPDATE EMPLOYEES TABLE SELECTIONS
                                for (int i = employeesTable.getSelectedRowCount() - 1; i>= 0; i--)
                                {
                                    String selectedMu = Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_FEEDER))
                                                      + Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_SITE))
                                                      + Misc.objectToString(employeesTable.getValueAt(employeesTable.getSelectedRows()[i], idx_MU));
                                    if (!selectedMus.contains(selectedMu))
                                    {
                                        employeesTable.getSelectionModel().removeIndexInterval(employeesTable.getSelectedRows()[i], employeesTable.getSelectedRows()[i]);
                                    }
                                }
                                if (employeesTable.getSelectedRowCount() == 0)
                                {
                                    allEmployeesRadioButton.setSelected(true);
                                    employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
                                }
                            }
                        }
                        processFilters();
                    }
                }
            });
        }
        
        private void configureEmployeesTable()
        {
            Misc.configureTable(employeesTable, true, true, false);
            Misc.setHeaderRenderer(employeesTable, true, true, null);
            Misc.setColumnSettings(employeesTable, idx_FEEDER, 60);
            Misc.setColumnSettings(employeesTable, idx_SITE, 60);
            Misc.setColumnSettings(employeesTable, idx_MU, 60);
            Misc.setColumnSettings(employeesTable, idx_EMPID, 100);
            Misc.setColumnSettings(employeesTable, idx_EMPLOYEE, 205, Constants.LEFT);
            Misc.setColumnSettings(employeesTable, idx_LAST_DATE, 110);
            
            employeeSorter = new TableRowSorter<CustomTableModel>(employeesData)
            {
                @Override
                public Comparator<?> getComparator(final int column)
                {
                    if (Arrays.asList(idx_SITE, idx_MU).contains(column))
                    {
                        Comparator c = new Comparator()
                        {
                            @Override
                            public int compare(Object a, Object b)
                            {
                                if (a == b)
                                {
                                    return 0;
                                }
                                if (a == null)
                                {
                                    return -1;
                                }
                                if (b == null)
                                {
                                    return 1;
                                }
                                if (Misc.isInteger(a.toString()))
                                {
                                    if (Misc.isInteger(b.toString()))
                                    {
                                        return Integer.compare(Integer.parseInt(a.toString()), Integer.parseInt(b.toString()));
                                    }
                                    else
                                    {
                                        return -1;
                                    }
                                }
                                else if (Misc.isInteger(b.toString()))
                                {
                                    return 1;
                                }
                                return Misc.objectToString(a).compareTo(Misc.objectToString(b));
                            }
                        };
                        return c;
                    }
                    else
                    {
                        return super.getComparator(column);
                    }
                }
            };
            employeesTable.setRowSorter(employeeSorter);
            
            employeesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        if (employeesTable.getSelectedRowCount() > 0)
                        {
                            selectEmployeesRadioButton.setSelected(true);
                        }
                        employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());           
                    }
                }
            });
            
            employeesTable.setRowSelectionAllowed(selectEmployeesRadioButton.isSelected());
        }
    }
}
