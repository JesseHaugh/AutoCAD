package tvicore.dao;

import java.util.Date;

public class PayrollCloseRecord
{
    private Date payrollClose;
    private Date hotDay;
    private String payrollGroup;
    
    public PayrollCloseRecord(Date payrollClose, Date hotDay, String payrollGroup)
    {
        this.payrollClose = payrollClose;
        this.hotDay = hotDay;
        this.payrollGroup = payrollGroup;
    }
    
    public Date getPayrollClose()   { return new Date(payrollClose.getTime()); }
    public Date getHotDay()         { return new Date(hotDay.getTime()); }
    public String getPayrollGroup() { return payrollGroup; }
    
    public void setPayrollClose(Date value)   { payrollClose = value; }
    public void setHotDay(Date value)         { hotDay = value; }
    public void setPayrollGroup(String value) { payrollGroup = value; }
}