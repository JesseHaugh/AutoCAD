package tvicore.resources;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class Resources
{
    private static Image TVIICON;
    private static ImageIcon iconChecked60;
    private static ImageIcon iconUnchecked60;
    private static ImageIcon iconChecked45;
    private static ImageIcon iconUnchecked45;
    
    public static Image getTVIICON()
    {
        if (TVIICON == null)
        {
            TVIICON = Toolkit.getDefaultToolkit().getImage(Resources.class.getClassLoader().getResource("tvicore/resources/clock.png"));
        }
        return TVIICON;
    }
    
    public static ImageIcon getIconChecked60()
    {
        if (iconChecked60 == null)
        {
            iconChecked60 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(Resources.class.getClassLoader().getResource("tvicore/resources/checkbox_checked_60px.png")));
        }
        return iconChecked60;
    }
    
    public static ImageIcon getIconUnchecked60()
    {
        if (iconUnchecked60 == null)
        {
            iconUnchecked60 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(Resources.class.getClassLoader().getResource("tvicore/resources/checkbox_unchecked_60px.png")));
        }
        return iconUnchecked60;
    }
    
    public static ImageIcon getIconChecked45()
    {
        if (iconChecked45 == null)
        {
            iconChecked45 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(Resources.class.getClassLoader().getResource("tvicore/resources/checkbox_checked_45px.png")));
        }
        return iconChecked45;
    }
    
    public static ImageIcon getIconUnchecked45()
    {
        if (iconUnchecked45 == null)
        {
            iconUnchecked45 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(Resources.class.getClassLoader().getResource("tvicore/resources/checkbox_unchecked_45px.png")));
        }
        return iconUnchecked45;
    }
}
