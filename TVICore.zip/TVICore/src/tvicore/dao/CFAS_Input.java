package tvicore.dao;

import java.util.ArrayList;
import java.util.List;

public class CFAS_Input
{
    private final List<CFAS_Input_Record_Container> validate;
    
    public CFAS_Input()
    {
        validate = new ArrayList<>();
    }
    
    public void addRecord(CFAS_Input_Record record)
    {
        CFAS_Input_Record_Container rec = new CFAS_Input_Record_Container(record);
        validate.add(rec);
    }
}

class CFAS_Input_Record_Container
{
    private final CFAS_Input_Record rec;
    
    public CFAS_Input_Record_Container(CFAS_Input_Record rec)
    {
        this.rec = rec;
    }
}
