package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.reports.ExcelReports;
import tvicore.resources.Resources;

public final class ScheduleImportsStatus extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ScheduleImportsStatus instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    Dimension loadingPanelDimensions = new Dimension(790, 200);
    
    Date endDate = RegionData.getPayClose();
    Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
    int[] hiddenColumns;
    
    final static int idx_week_one_mu   = 0;
    final static int idx_week_one_day1 = 1;
    final static int idx_week_one_day2 = 2;
    final static int idx_week_one_day3 = 3;
    final static int idx_week_one_day4 = 4;
    final static int idx_week_one_day5 = 5;
    final static int idx_week_one_day6 = 6;
    final static int idx_week_one_day7 = 7;
    final static int idx_week_two_mu   = 8;
    final static int idx_week_two_day1 = 9;
    final static int idx_week_two_day2 = 10;
    final static int idx_week_two_day3 = 11;
    final static int idx_week_two_day4 = 12;
    final static int idx_week_two_day5 = 13;
    final static int idx_week_two_day6 = 14;
    final static int idx_week_two_day7 = 15;
    
    public synchronized static ScheduleImportsStatus getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ScheduleImportsStatus(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ScheduleImportsStatus(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        Oracle.setupPickEndDate(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getNextPayClose(), 52);
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    loadingLabel.setText("LOADING...");
                    scheduleImportScrollPane.setMaximumSize(loadingPanelDimensions);
                    scheduleImportScrollPane.setPreferredSize(loadingPanelDimensions);
                    scheduleImportScrollPane.setViewportView(loadingPanel);
                    validate();
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("MU<br>Week One"),                                                         // idx_week_one_mu
                Misc.centerHTML(Misc.dateToString(startDate, "MM/dd") + "<br>Sun"),                        // idx_week_one_day1
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 1), "MM/dd") + "<br>Mon"),   // idx_week_one_day2
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 2), "MM/dd") + "<br>Tues"),  // idx_week_one_day3
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 3), "MM/dd") + "<br>Weds"),  // idx_week_one_day4
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 4), "MM/dd") + "<br>Thur"),  // idx_week_one_day5
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 5), "MM/dd") + "<br>Fri"),   // idx_week_one_day6
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 6), "MM/dd") + "<br>Sat"),   // idx_week_one_day7
                Misc.centerHTML("MU<br>Week Two"),                                                         // idx_week_two_mu
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 7), "MM/dd") + "<br>Sun"),   // idx_week_two_day1
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 8), "MM/dd") + "<br>Mon"),   // idx_week_two_day2
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 9), "MM/dd") + "<br>Tues"),  // idx_week_two_day3
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 10), "MM/dd") + "<br>Weds"), // idx_week_two_day4
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 11), "MM/dd") + "<br>Thur"), // idx_week_two_day5
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 12), "MM/dd") + "<br>Fri"),  // idx_week_two_day6
                Misc.centerHTML(Misc.dateToString(Misc.dateAddDays(startDate, 13), "MM/dd") + "<br>Sat"),  // idx_week_two_day7
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
            startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);

            return Oracle.getResultsSchedulesImported(getFormComponent(), feeder, site, startDate, endDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU_WEEK1"),  // idx_week_one_mu
                    rs.getInt("WEEK_ONE_SUN"), // idx_week_one_day1
                    rs.getInt("WEEK_ONE_MON"), // idx_week_one_day2
                    rs.getInt("WEEK_ONE_TUE"), // idx_week_one_day3
                    rs.getInt("WEEK_ONE_WED"), // idx_week_one_day4
                    rs.getInt("WEEK_ONE_THU"), // idx_week_one_day5
                    rs.getInt("WEEK_ONE_FRI"), // idx_week_one_day6
                    rs.getInt("WEEK_ONE_SAT"), // idx_week_one_day7
                    rs.getString("MU_WEEK2"),  // idx_week_two_mu
                    rs.getInt("WEEK_TWO_SUN"), // idx_week_two_day1
                    rs.getInt("WEEK_TWO_MON"), // idx_week_two_day2
                    rs.getInt("WEEK_TWO_TUE"), // idx_week_two_day3
                    rs.getInt("WEEK_TWO_WED"), // idx_week_two_day4
                    rs.getInt("WEEK_TWO_THU"), // idx_week_two_day5
                    rs.getInt("WEEK_TWO_FRI"), // idx_week_two_day6
                    rs.getInt("WEEK_TWO_SAT"), // idx_week_two_day7
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading schedule import check data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), scheduleImportScrollPane, table);
                scheduleImportScrollPane.setViewportView(table);
                getFormComponent().validate();
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_week_one_day1:
                        case idx_week_one_day2:
                        case idx_week_one_day3:
                        case idx_week_one_day4:
                        case idx_week_one_day5:
                        case idx_week_one_day6:
                        case idx_week_one_day7:
                        case idx_week_two_day1:
                        case idx_week_two_day2:
                        case idx_week_two_day3:
                        case idx_week_two_day4:
                        case idx_week_two_day5:
                        case idx_week_two_day6:
                        case idx_week_two_day7:
                            return Integer.class;
                        case idx_week_one_mu:
                        case idx_week_two_mu:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public void paintComponent(Graphics g)
                {
                    super.paintComponent(g);
                    if (table.getRowCount() > 0)
                    {
                        int x = 0;
                        for (int i = 0; i < idx_week_two_mu; i++)
                        {
                            x += table.getColumnModel().getColumn(i).getPreferredWidth();
                        }
                        g.drawLine(x, 0, x, table.getHeight() - 20);
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, false, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_week_one_mu, 70, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day1, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day2, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day3, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day4, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day5, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day6, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_one_day7, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_mu, 70, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day1, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day2, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day3, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day4, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day5, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day6, 45, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_week_two_day7, 45, true, Constants.CENTER);
            
            table.setRowHeight(25);
            table.setSelectionBackground(Constants.SALMON);
            table.setSelectionForeground(Color.BLACK);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        siteLabel = new javax.swing.JLabel();
        feederLabel = new javax.swing.JLabel();
        formTitlePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        retrieveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        subtitleLabel = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        scheduleImportScrollPane = new javax.swing.JScrollPane();
        loadingPanel = new javax.swing.JPanel();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        scheduleImportHistoryButton = new javax.swing.JButton();
        employeeMovementReportButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Schedule Import Check");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(980, 550));
        setPreferredSize(new java.awt.Dimension(980, 550));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setPreferredSize(new java.awt.Dimension(970, 115));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setPreferredSize(new java.awt.Dimension(900, 115));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 80, -1));

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 100, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        formTitlePanel.setBackground(new java.awt.Color(120, 200, 200));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setText("Schedule Import Check by Pay Period");
        formTitlePanel.add(titleLabel);

        titlePanel.add(formTitlePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 390, 40));

        pickDateLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pickDateLabel.setText("Payroll Ending:");
        pickDateLabel.setPreferredSize(new java.awt.Dimension(95, 25));
        titlePanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 10, 100, -1));

        pickDate.setPreferredSize(new java.awt.Dimension(140, 23));
        pickDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickDateActionPerformed(evt);
            }
        });
        titlePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 10, -1, -1));

        retrieveButton.setBackground(new java.awt.Color(120, 200, 200));
        retrieveButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        retrieveButton.setText("Retrieve Data");
        retrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retrieveButtonActionPerformed(evt);
            }
        });
        titlePanel.add(retrieveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 40, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(70, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 20, -1, -1));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel.setText("Displays the number of employees on each schedule.");
        titlePanel.add(subtitleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, -1, -1));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel2.setText("Click on a day to see employee movement.");
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, -1, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(900, 200));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        scheduleImportScrollPane.setAlignmentY(0.0F);
        scheduleImportScrollPane.setMaximumSize(new java.awt.Dimension(790, 200));
        scheduleImportScrollPane.setMinimumSize(new java.awt.Dimension(600, 200));
        scheduleImportScrollPane.setPreferredSize(new java.awt.Dimension(790, 200));

        loadingPanel.setPreferredSize(new java.awt.Dimension(788, 198));
        loadingPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setPreferredSize(new java.awt.Dimension(200, 25));
        loadingPanel.add(loadingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(295, 80, -1, -1));

        scheduleImportScrollPane.setViewportView(loadingPanel);

        centerPanel.add(scheduleImportScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(980, 60));
        bottomPanel.setPreferredSize(new java.awt.Dimension(980, 60));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 15));

        scheduleImportHistoryButton.setBackground(new java.awt.Color(120, 200, 200));
        scheduleImportHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        scheduleImportHistoryButton.setText("Schedule Import History");
        scheduleImportHistoryButton.setPreferredSize(new java.awt.Dimension(180, 30));
        scheduleImportHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleImportHistoryButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(scheduleImportHistoryButton);

        employeeMovementReportButton.setBackground(new java.awt.Color(120, 200, 200));
        employeeMovementReportButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeMovementReportButton.setText("Employee Movement");
        employeeMovementReportButton.setPreferredSize(new java.awt.Dimension(180, 30));
        employeeMovementReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMovementReportButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(employeeMovementReportButton);

        printButton.setBackground(new java.awt.Color(120, 200, 200));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setPreferredSize(new java.awt.Dimension(150, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(printButton);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void retrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retrieveButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_retrieveButtonActionPerformed
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void pickDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pickDateActionPerformed
        if (pickDate.isEnabled())
        {
            setCursor(Constants.HOURGLASS);
            clearTable();
            setCursor(Constants.NORMAL);
        }
        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (endDate == null)
        {
            Misc.msgbox(getFormComponent(), "Select a payroll ending date.", "Missing end date", 1, 1, 1);
            worker.cancel(true);
            return;
        }
        startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
    }//GEN-LAST:event_pickDateActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "LANDSCAPE", "Schedule Import Check");
    }//GEN-LAST:event_printButtonActionPerformed

    private void employeeMovementReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMovementReportButtonActionPerformed
        new Thread(new GenerateEmployeeMovementReportThread()).start();
    }//GEN-LAST:event_employeeMovementReportButtonActionPerformed

    private void scheduleImportHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleImportHistoryButtonActionPerformed
        String mu;
        
        int choice = JOptionPane.showOptionDialog
        (
            null,
            "This will show the schedule import history for the selected payroll period.\nDo you want to view a SINGLE MU, or ALL MUS?",
            "Schedule Import History",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new String[]{"SINGLE MU", "ALL MUS", "CANCEL"},
            "SINGLE MU"
        );
        switch (choice)
        {
            case 0: // SINGLE MU
                String selectedMU = null;
                if (table != null)
                {
                    int selectedRow = table.getSelectedRow();

                    if (selectedRow > -1)
                    {
                        selectedMU = Misc.objectToString(table.getValueAt(selectedRow, idx_week_one_mu));
                    }
                }
                
                // labels
                JLabel muLabel = new JLabel("Select MU to review:");
                muLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
                muLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                muLabel.setPreferredSize(new Dimension(260, 20));
                
                // mu selection list
                JScrollPane muScrollPane = new JScrollPane();
                muScrollPane.setPreferredSize(new Dimension(100, 250));
                JList<String> muList = new JList<>();
                muList.setFont(new java.awt.Font("Tahoma", 0, 14));
                muScrollPane.setViewportView(muList);
                DefaultListModel<String> muModel = new DefaultListModel<>();
                
                // populate mulist
                for (String s : RegionData.getMuList())
                {
                    if (!Misc.isAlpha(s.substring(0, 1)))
                    {
                        muModel.addElement(s);
                    }
                }
                muList.setModel(muModel);
                
                if (selectedMU != null)
                {
                    for (int i = 0; i < muList.getModel().getSize(); i++)
                    {
                        if (selectedMU.equals(muList.getModel().getElementAt(i)))
                        {
                            muList.setSelectedIndex(i);
                            break;
                        }
                    }
                }
                else
                {
                    muList.setSelectedIndex(0);
                }
                
                // panel
                JPanel panel = new JPanel();
                panel.setPreferredSize(new Dimension(300, 330));
                FlowLayout layout = new FlowLayout();
                layout.setVgap(10);
                panel.setLayout(layout);
                panel.add(muLabel);
                panel.add(muScrollPane);
                
                int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Schedule Import History", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (rc != 0) // cancelled
                {
                    return;
                }
                
                mu = muList.getSelectedValue();
                break;
            case 1: // ALL MUS
                mu = "ALL";
                break;
            default: // user cancel
                return;
        }
        ScheduleImportHistory.getInstance(getFormComponent(), feeder, site, mu, startDate, endDate);
    }//GEN-LAST:event_scheduleImportHistoryButtonActionPerformed
    
    private void clearTable()
    {
        table = null;
        loadingLabel.setText("");
        scheduleImportScrollPane.setMaximumSize(loadingPanelDimensions);
        scheduleImportScrollPane.setPreferredSize(loadingPanelDimensions);
        scheduleImportScrollPane.setViewportView(loadingPanel);
        validate();
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        ScheduleNewGone.closeInstance();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private class GenerateEmployeeMovementReportThread implements Runnable
    {
        // this thread exists in 3 locations: ExcelReportsMenu, ScheduleImportsStatus, & ScheduleImportsStatusMonthly.
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                employeeMovementReportButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JPanel panel = new JPanel();
                    GridLayout gridLayout = new GridLayout(2, 0);
                    gridLayout.setVgap(10);
                    panel.setLayout(gridLayout);
                    
                    JLabel startDateLabel = new JLabel("Start Date:");
                    JComboBox<String> startDateCombo = new JComboBox<>();
                    startDateCombo.setEditable(true);
                    
                    JLabel endDateLabel = new JLabel("End Date:");
                    JComboBox<String> endDateCombo = new JComboBox<>();
                    endDateCombo.setEditable(true);
                    
                    Date selectedPayClose = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                    Date nextPayClose = Oracle.getNextPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose);
                    Date prevPayStart = Oracle.getPreviousPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(nextPayClose);
                    int daysBack = Misc.daysBetween(nextPayClose, prevPayStart);
                    for (int i = 0; i <= daysBack; i++)
                    {
                        startDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
                        endDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
                        cal.add(Calendar.DAY_OF_YEAR, -1);
                    }
                    
                    startDateCombo.setSelectedItem(Misc.dateToStringMDY(Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose)));
                    endDateCombo.setSelectedItem(Misc.dateToStringMDY(selectedPayClose));
                    
                    panel.add(startDateLabel);
                    panel.add(startDateCombo);
                    panel.add(endDateLabel);
                    panel.add(endDateCombo);
                    
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Select a start and end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    Date startDate = Misc.stringToDateMDY(getFormComponent(), startDateCombo.getSelectedItem().toString());
                    Date endDate = Misc.stringToDateMDY(getFormComponent(), endDateCombo.getSelectedItem().toString());
                    
                    if (rc == 0) // OK was selected
                    {
                        ExcelReports.fillEmployeeMovementReport(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                employeeMovementReportButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton employeeMovementReportButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JPanel formTitlePanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel loadingPanel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JButton printButton;
    private javax.swing.JButton retrieveButton;
    private javax.swing.JButton scheduleImportHistoryButton;
    private javax.swing.JScrollPane scheduleImportScrollPane;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
