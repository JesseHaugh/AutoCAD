package tvicore.dao;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.awt.Component;
import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import javax.swing.JComboBox;
import oracle.jdbc.OracleTypes;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import oracle.jdbc.OracleResultSet;
import tvicore.miscellaneous.Encryption;

public class Oracle
{
    private volatile static Connection conn;
    private static String dbName = "TVI01P";
    private static String dbPassword;
    private static final int MAX_RETRIES = 1;
    private static int retryCount = 0;
    private static String broadcastMessage = "";
    
    public static String getDatabaseName()     { return dbName; }
    public static String getDatabasePassword() { return dbPassword; }
    
    /**
     * Initializes the database connection
     * 
     * @param dbName
     * @param dbPassword
     * @throws java.sql.SQLException
     */
    public static void initializeConnection(String dbName, String dbPassword) throws SQLException
    {
        Oracle.dbName = dbName;
        Oracle.dbPassword = dbPassword;
        System.setProperty("java.security.egd", "file:///dev/urandom");
        System.setProperty("oracle.jdbc.javaNetNio", "false");
        
        // property settings for net encryption
        Properties props = new Properties();
        props.put("oracle.net.crypto_checksum_types_client", "SHA1");
        props.put("oracle.net.crypto_checksum_client", "REQUIRED");
        props.put("oracle.net.encryption_types_client", "AES256,AES192,AES128,RC4_128");
        props.put("oracle.net.encryption_client", "REQUIRED");
        props.put("user", "m16666");
        props.put("password", dbPassword);
        
        String dbUrl = "jdbc:oracle:thin:@ldap://odmsvr.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com "
                                      + "ldap://odmsvr1.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com "
                                      + "ldap://odmsvr2.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com "
                                      + "ldap://odmsvr3.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com "
                                      + "ldap://odmsvr4.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com "
                                      + "ldap://odmsvr5.sbc.com:3060/" + dbName + ",cn=OracleContext,dc=sbc,dc=com";
        
        //for testing connection without LDAP
        //dbUrl = "jdbc:oracle:thin:@t7tvi1d2.az.3pc.att.com:1524:t7tvi1d2";
        //dbUrl = "jdbc:oracle:thin:@p7tvi1d3.az.3pc.att.com:1521:p7tvi1d3";
        
        conn = DriverManager.getConnection(dbUrl, props);
        conn.setAutoCommit(false);
        retryCount = 0;
    }
    
    /**
     * Gets database name and password from TVIClient.cfg, and then attempts to connect to the database
     * //DYADD can remove after INFOR release, new config logic
     * @param dbName
     * @param dbPassword
     * @throws java.sql.SQLException
     */
    public static void connectToDatabase(Component parentFrame)
    {
        TimeZone localTZ = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("PST"));
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

        String password1 = "";
        String password2 = "";
        Date effectiveDate1 = null;
        Date effectiveDate2 = null;
        Date effectiveDate2Plus10, effectiveDate2Plus180;
        Date curDate = new Date();// Date from local datetime, server connection hasn't been made yet

        try (BufferedReader file = new BufferedReader(new FileReader("TVIClient.cfg")))
        {
            effectiveDate1 = dateFormatter.parse(file.readLine());
            password1 = Encryption.decrypt256(file.readLine());
            effectiveDate2 = dateFormatter.parse(file.readLine());
            password2 = Encryption.decrypt256(file.readLine());
            String dbNameEncrypted = file.readLine();
            if (dbNameEncrypted != null)
            {
                if (dbNameEncrypted.length() > 2)
                {
                    dbName = Encryption.decryptDBName(dbNameEncrypted);
                }
            }
        }
        catch (IOException ex)
        {
            Misc.errorMsgCritical(parentFrame, ex, "Failed to read values from config file, contact TVI support.");
        }
        catch (ParseException ex)
        {
            Misc.errorMsgCritical(parentFrame, ex, "Failed to parse config dates, contact TVI support.");
        }
        
        effectiveDate2Plus10 = Misc.dateAddDays(effectiveDate2, 10);
        effectiveDate2Plus180 = Misc.dateAddDays(effectiveDate2, 180);

        try
        {
            if (curDate.compareTo(effectiveDate1) >= 0 && curDate.compareTo(effectiveDate2) < 0)
            {
                dbPassword = password1;
                try
                {
                    Oracle.initializeConnection(dbName, dbPassword);
                }
                catch (SQLException ex)
                {
                    switch (ex.getSQLState())
                    {
                        case "08006":
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to establish connection to database.");
                            break;
                        case "72000":
                            dbPassword = password2;
                            try
                            {
                                initializeConnection(dbName, dbPassword);
                            }
                            catch (SQLException ex3)
                            {
                                Misc.errorMsgDatabase(parentFrame, ex3, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login with both password1 and password2.");
                            }
                            break;
                        default:
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Error logging into database.");
                            break;
                    }
                }
            }
            else if (curDate.compareTo(effectiveDate1) >= 0 && curDate.compareTo(effectiveDate2Plus180) < 0)
            {
                if (password2.equals("LOCKOUT"))//261286307359418490566
                {
                    throw new Exception("TVI config file out of date, contact TVI Support.");
                }
                dbPassword = password2;
                try
                {
                    initializeConnection(dbName, dbPassword);
                }
                catch (SQLException ex)
                {
                    switch (ex.getSQLState())
                    {
                        case "08006":
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to establish connection to database.");
                            break;
                        case "72000":
                            if (curDate.compareTo(effectiveDate2Plus10) < 0)
                            {
                                dbPassword = password1;
                                try
                                {
                                    initializeConnection(dbName, dbPassword);
                                }
                                catch (SQLException ex2)
                                {
                                    Misc.errorMsgDatabase(parentFrame, ex2, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login with both password1 and password2.");
                                }
                            }
                            else
                            {
                                Misc.errorMsgDatabase(parentFrame, ex, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login using password2.");
                            }
                            break;
                        default:
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Error logging into database.");
                            break;
                    }
                }
            }
            else
            {
                throw new Exception("Outside of effective date ranges, call TVI Support immediately.");
            }
        }
        catch (Exception ex)
        {
            Misc.errorMsgCritical(parentFrame, ex, "Failed to login using current configuration credentials.");
        }
        TimeZone.setDefault(localTZ);
    }
    
    /**
     * Attempts to connect to the database with the provided configuration information
     * 
     * @param dbName
     * @param dbPassword
     * @throws java.sql.SQLException
     */
    public static void connectToDatabase(Component parentFrame, Config config)
    {
        TimeZone localTZ = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("PST"));
        
        dbName = config.getDbName();
        String password1 = config.getPassword1();
        String password2 = config.getPassword2();
        Date effectiveDate1 = config.getEffectiveDate1();
        Date effectiveDate2 = config.getEffectiveDate2();
        Date effectiveDate2Plus10 = Misc.dateAddDays(effectiveDate2, 10);
        Date effectiveDate2Plus180 = Misc.dateAddDays(effectiveDate2, 180);
        Date curDate = new Date();// Date from local datetime, server connection hasn't been made yet
        
        try
        {
            if (curDate.compareTo(effectiveDate1) >= 0 && curDate.compareTo(effectiveDate2) < 0)
            {
                dbPassword = password1;
                try
                {
                    Oracle.initializeConnection(dbName, dbPassword);
                }
                catch (SQLException ex)
                {
                    switch (ex.getSQLState())
                    {
                        case "08006":
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to establish connection to database.");
                            break;
                        case "72000":
                            dbPassword = password2;
                            try
                            {
                                initializeConnection(dbName, dbPassword);
                            }
                            catch (SQLException ex3)
                            {
                                Misc.errorMsgDatabase(parentFrame, ex3, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login with both password1 and password2.");
                            }
                            break;
                        default:
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Error logging into database.");
                            break;
                    }
                }
            }
            else if (curDate.compareTo(effectiveDate1) >= 0 && curDate.compareTo(effectiveDate2Plus180) < 0)
            {
                if (password2.equals("LOCKOUT"))//261286307359418490566
                {
                    throw new Exception("TVI config file out of date, contact TVI Support.");
                }
                dbPassword = password2;
                try
                {
                    initializeConnection(dbName, dbPassword);
                }
                catch (SQLException ex)
                {
                    switch (ex.getSQLState())
                    {
                        case "08006":
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to establish connection to database.");
                            break;
                        case "72000":
                            if (curDate.compareTo(effectiveDate2Plus10) < 0)
                            {
                                dbPassword = password1;
                                try
                                {
                                    initializeConnection(dbName, dbPassword);
                                }
                                catch (SQLException ex2)
                                {
                                    Misc.errorMsgDatabase(parentFrame, ex2, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login with both password1 and password2.");
                                }
                            }
                            else
                            {
                                Misc.errorMsgDatabase(parentFrame, ex, true, "WARNING! Do not attempt to log on to TVI again.", "Email TVI Support immediately at " + Constants.EMAIL, "Failed to login using password2.");
                            }
                            break;
                        default:
                            Misc.errorMsgDatabase(parentFrame, ex, true, "Error logging into database.");
                            break;
                    }
                }
            }
            else
            {
                throw new Exception("Outside of effective date ranges, call TVI Support immediately.");
            }
        }
        catch (Exception ex)
        {
            Misc.errorMsgCritical(parentFrame, ex, "Failed to login using current configuration credentials.");
        }
        TimeZone.setDefault(localTZ);
    }
    
    /**
     * Gets the current connection to the database that was set in initializeConnection()
     * 
     * @throws java.sql.SQLException
     */
    public static Connection getConnection()
    {
        try
        {
            if (conn == null || conn.isClosed())
            {
                if (retryCount < MAX_RETRIES)
                {
                    retryCount++;
                    initializeConnection(dbName, dbPassword);
                }
                else
                {
                    Misc.errorMsgCritical(null, null, "Could not establish connection to the database.");
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(null, ex, true, "Could not establish connection to the database.");
        }
        
        return conn;
    }
    
    /**
     * Checks if the connection is active
     * 
     * @return true if connection exists and is not closed, false otherwise
     */
    public static boolean hasConnection()
    {
        boolean output = false;
        try
        {
            if (conn != null && !conn.isClosed())
            {
                output = true;
            }
        }
        catch (SQLException ex)
        {
            output = false;
        }
        return output;
    }
    
    /**
     * Closes the database connection.
     */
    public synchronized static void closeConnection()
    {
        if (conn != null)
        {
            try
            {
                conn.close();
                conn = null;
            }
            catch (SQLException e)
            {
                for (Throwable t : e) { }
            }
        }
    }
    
    /**
     * Attempts to close the callable statement
     * 
     * @param parentFrame the frame to center messages on
     * @param ocs the callable statement to close
     * @return true if successful, false otherwise
     */
    public static boolean closeCallableStatement(Component parentFrame, CallableStatement ocs)
    {
        boolean output = true;
        try
        {
            if (ocs != null)
            {
                if (!ocs.isClosed())
                {
                    ocs.close();
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "Failed to close connection to database.");
            output = false;
        }
        return output;
    }
    
    /**
     * Closes the passed cursors
     * 
     * @param parentFrame the frame to center messages on
     * @param ps the PreparedStatement to close
     * @param rs the ResultSet to close
     */
    public static void closeCursors(Component parentFrame, PreparedStatement ps, ResultSet rs)
    {
        try
        {
            if (ps != null)
            {
                if (!ps.isClosed())
                {
                    ps.close();
                }
            }
            if (rs != null)
            {
                if (!rs.isClosed())
                {
                    rs.close();
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error closing cursors.");
        }
    }
    
    /**
     * Calls the procedure COMPUTE40HRS, which generates PR05 for all hours greater than 40 in the work week (Internet Services only)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param weekEndingDate the Saturday at the end of the week
     * @param empid
     * @return true if successful, false otherwise
     */
    public static boolean compute40HourPremium(Component parentFrame, String feeder, String site, Date weekEndingDate, String empid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE40HRS.Main ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(weekEndingDate));
            ocs.setString(4, empid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE40HRS.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Calls the procedure COMPUT_NIGHT_SHIFT, which generates night diffs (Southeast only)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param weekEndingDate the Saturday at the end of the week
     * @return true if successful, false otherwise
     */
    public static boolean compute3WeekRuleSW(Component parentFrame, String feeder, String site, Date weekEndingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_NIGHT_SHIFT ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(weekEndingDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE_NIGHT_SHIFT.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Calls the procedure COMPUTE_NIGHT_3DAY_RULE
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param unionFlag
     * @param weekEndingDate the Saturday at the end of the week
     * @return true if successful, false otherwise
     */
    public static boolean compute3DayRule(Component parentFrame, String feeder, String site, String unionFlag, Date weekEndingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_NIGHT_3DAY_RULE ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, unionFlag);
            ocs.setDate(4, Misc.dateToSqlDate(weekEndingDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE_NIGHT_3DAY_RULE.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Computes absence relief differentials for ATI_IBEW_1_3 and ATI_IBEW_4_5
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param sbcid the user's AT&T UUID
     * @param startDate
     * @param endDate
     * @return true if successful, false otherwise
     */
    public static boolean computeReliefDifferential(Component parentFrame, String feeder, String site, String sbcid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_ABS_RELIEF_DIFF ( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, sbcid);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error computing absence relief differentials.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Calls the procedure COMPUTE_OTCC_OVERTIME, which generates EXTA for overtime caught on a call (BTI only)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @param payCycle
     * @return true if successful, false otherwise
     */
    public static boolean computeOTCC(Component parentFrame, String feeder, String site, Date endDate, String payCycle)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_OTCC_OVERTIME ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(getPayrollStartDate(parentFrame, payCycle, endDate)));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to compute OTCC.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates a user's access log with a new action.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param statusIn "IN" if the action is logging in, "OUT" if the user is exiting.
     * @param loginFailures number of login failures, 0 if not applicable
     * @param exitType description of the exit type, null if not applicable
     * @param userIP the user's local IP
     */
    public static void updateUserAccessLog(Component parentFrame, String sbcid, String statusIn, int loginFailures, String exitType, String userIP)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL USER_ACCESS_LOG_INSERT ( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, sbcid);
            ocs.setString(2, statusIn);
            ocs.setInt(3, loginFailures);
            ocs.setString(4, exitType);
            ocs.setString(5, userIP);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error updating user access log.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Returns the specified user's stored name and phone number
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     */
    public static ArrayList<String> getUserContactInfo(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        ArrayList<String> userInfo = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT USER_NAME, USER_PHONE "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            rs.next();
            userInfo.add(rs.getString("USER_NAME"));
            userInfo.add(rs.getString("USER_PHONE"));
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error retrieving user info.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return userInfo;
    }
    
    /**
     * Attempts to download and open the What's New document for the specified TVI version number
     * 
     * @param parentFrame the frame to center messages on
     * @param version the tvi client version number
     */
    public static void downloadAndOpenWhatsNew(Component parentFrame, String clientName, String version)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String serverFilename = "TVI_WHATS_NEW_" + clientName + "_" + version + ".docx";
            String filename = "TVI_WHATS_NEW_" + clientName + ".docx";
            String sqlString = "SELECT BFILENAME('TVIDATA', ?) FROM DUAL";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, serverFilename);
            rs = ps.executeQuery();
            if (rs.next())
            {
                oracle.jdbc.OracleBfile bfile = ((OracleResultSet)rs).getBFILE(1);
                if (downloadFileFromServer(parentFrame, bfile, filename))
                {
                    try
                    {
                        Desktop.getDesktop().open(new File(filename));
                    }
                    catch (IOException ex)
                    {
                        Misc.errorMsgDefault(parentFrame, ex, "Failed to open " + filename);
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error retrieving user info.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
    }
    
    /**
     * Updates a user's access version.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param version the user's current java runtime version
     */
    public static void updateUserAccessVersion(Component parentFrame, String sbcid, String version)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE USERS SET ACCESSVERSION = ? "
                      +    " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, version);
            ps.setString(2, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error updating user's java version.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Gets the user's last status from the user access log
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @return either "IN" or "OUT"
     */
    public static String getLastUserAccessLog(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String lastUserAccessLog = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT STATUS "
                             +    " FROM USER_ACCESS_LOG "
                             +        " WHERE SBCID = ? "
                             +        " ORDER BY ACCESS_TIME DESC";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                lastUserAccessLog = rs.getString("STATUS");
            }
            else
            {
                throw new SQLException("User not found.");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting last user access status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return lastUserAccessLog;
    }
    
    /**
     * Moves the pay close date forward to the specified payroll close date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param newPayrollClose
     * @return true if successful, false otherwise
     */
    public static boolean updatePayClose(Component parentFrame, String feeder, String site, Date newPayrollClose)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SITE_UPDATE_PAYCYCLE ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(newPayrollClose));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SITE_UPDATE_PAYCYCLE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules or records before the end of the current pay period are all approved.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if all approved, false otherwise
     */
    public static boolean checkAllApproved(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_ALL_APPROVED ( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_ALL_APPROVED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if all TVI changes in the date range have been approved.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if all approved, false otherwise
     */
    public static boolean checkAllChangesApproved(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_ALL_CHANGES_APPROVED ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_ALL_CHANGES_APPROVED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the compute premium function has been run on all records in the date range.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if done, false otherwise
     */
    public static boolean checkAllComputePremium(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_COMPUTE_PREMIUM ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_COMPUTE_PREMIUM.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the three day rule function has been run on all records in the date range.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if done, false otherwise
     */
    public static boolean check3DayRule(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_THREE_DAY_RULE ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_THREE_DAY_RULE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the compute relief differential function has been run on all records in the date range. (ATI_IBEW_1_3 and ATI_IBEW_4_5 only)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if done, false otherwise
     */
    public static boolean checkReliefDifferential(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_ABS_RELIEF_DIFF ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if absence relief differentials have been computed.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the future exceptions function has been run on all the records in the selected date range.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if done, false otherwise
     */
    public static boolean checkFutureExceptions(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_FUTURE_EXCEPTIONS ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_FUTURE_EXCEPTIONS.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the OTCC function has been run on all the records in the selected date range.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate typically the payroll start date
     * @param endDate typically the payroll end date
     * @return true if done, false otherwise
     */
    public static boolean checkOTCC(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_OTCC ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to check OTCC.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Imports schedules for the specified date range
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate first day in the date range
     * @param endDate last day in the date range; for a single day, identical to startDate
     * @param format the type of import to perform: "REPLACE", "UPDATE", or "FUTURE"
     * @param sbcid uuid of the current user
     */
    public static void requestSchedule(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate, String format, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            boolean importLocked = Oracle.getScheduleImportLock(parentFrame, feeder, site, mu, startDate, endDate);
            if (importLocked)
            {
                Misc.msgbox(parentFrame, "At least one selected schedule is locked preventing imports.\nTo import you must first remove any import locks.", "Importing Locked", 1, 1, 1);
            }
            else
            {
                ocs = c.prepareCall("{ CALL SCHEDULE_1_REQUEST.MAIN ( ?, ?, ?, ?, ?, ?, ?) }");
                ocs.setString(1, feeder);
                ocs.setString(2, site);
                ocs.setString(3, mu);
                ocs.setDate(4, Misc.dateToSqlDate(startDate));
                ocs.setDate(5, Misc.dateToSqlDate(endDate));
                ocs.setString(6, sbcid);
                ocs.setString(7, format);
                ocs.execute();
            }
        }
        catch (SQLException ex)
        {
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SCHEDULE_1_REQUEST.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates statuses for the specified schedules
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate first day in the date range
     * @param endDate last day in the date range; for a single day, identical to startDate
     * @param type the originating process type: "NORMAL", "DETAIL", "UPDATE", or "RESULTS"
     */
    public static void updateScheduleStatus(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate, String type)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SCHEDULE_UPDATE_STATUS ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.setString(6, type);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.msgbox(parentFrame, "ERROR updating Schedule Status: " + ex, "TVI Database Update Error", 1, 1, 2);
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates a schedule to the specifieed state
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param totalviewID
     * @param mu
     * @param reportingDate
     * @param status the new status of the schedule
     * @param lockedBy the new lockedBy value, or null if not locked
     */
    public static void updateSchedule(Component parentFrame, String feeder, String site, int totalviewID, String mu, Date reportingDate, String status, String lockedBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SCHEDULE_UPDATE ( ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, totalviewID);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, status);
            ocs.setInt(7, 0); // all schedules have available = 0... remove?
            ocs.setString(8, lockedBy);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SCHEDULE_UPDATE.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Deletes the specified schedule
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if successful, false otherwise
     */
    public static boolean deleteSchedule(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SCHEDULE_DELETE ( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, getTotalviewID(parentFrame, feeder, site, mu));
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SCHEDULE_DELETE.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Loads the user's information
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getUserInfo(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DEFAULT_VALIDATION, DATE_CHGD, USER_TYPE, STATUS "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting user info.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of feeders and sites the specified user has permissions for, including which client they apply to.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getUserPermissions(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_USER_PERMISSIONS(?, ?) }");
            ocs.setString(1, sbcid);
            ocs.registerOutParameter(2, OracleTypes.CURSOR);
            ocs.setFetchSize(100);
            ocs.execute();
            rs = (ResultSet) ocs.getObject(2);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting user permissions.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of sites the given user has permission for in the specified feeder.
     * DYADD can remove after INFOR release, replaced with RS_USER_PERMISSIONS
     * @param parentFrame
     * @param feeder
     * @param sbcid
     * @param userType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getSitePermissions(Component parentFrame, String feeder, String sbcid, String userType)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            if (userType.equals("POWER"))
            {
                sqlString = " SELECT SITE "
                          +    " FROM SITES "
                          +        " WHERE FEEDER = ? "
                          +          " AND ACTIVESITE = -1 "
                          +        " ORDER BY TO_NUMBER(SITE)";
                ps = c.prepareStatement(sqlString);
                ps.setFetchSize(100);
                ps.setString(1, feeder);
            }
            else
            {
                sqlString = "SELECT A.SITE, A.ACCESS_LEVEL "
                          +    " FROM PERMISSIONS A "
                          + " INNER JOIN SITES B ON (A.SITE = B.SITE) "
                          +                   " AND (A.FEEDER = B.FEEDER) "
                          +    " WHERE A.FEEDER = ? "
                          +      " AND A.SBCID = ? "
                          +      " AND B.ACTIVESITE = -1";
                ps = c.prepareStatement(sqlString);
                ps.setFetchSize(100);
                ps.setString(1, feeder);
                ps.setString(2, sbcid);
            }
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting site permissions.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * gets configuration variables for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getSiteInfo(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT PAY_CYCLE, DESCRIPTION, NIGHT_DIFF_OFFICE, NEW_FEATURE_RELEASE, NEW_FEATURE_RELEASE2, REVIEW_BY_MU, "
                             +        " TO_CHAR(CURRENT_PAY_PERIOD, 'MM/DD/YYYY') AS CURRENT_PAY_PERIOD, UNION_PROCCESS_FLAG, SITE_LOCKED "
                             +     " FROM SITES "
                             +         " WHERE FEEDER = ? "
                             +           " AND SITE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error getting site info.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Checks if the current client is online. If offline, gives message and exits
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName
     */
    public static void checkClientStatus(Component parentFrame, String userType, String clientName)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_CLIENT_STATUS(?, ?) }");
            ocs.setString(1, clientName);
            ocs.registerOutParameter(2, OracleTypes.CURSOR);
            ocs.execute();
            rs = (ResultSet) ocs.getObject(2);
            
            if (rs.next())
            {
                if (rs.getInt("DB_ONLINE") != -1)
                {
                    if (userType.equals("POWER"))
                    {
                        Misc.msgbox(parentFrame, "TVI Database is OFFLINE.\nProceed with caution.", "", -1, 1, 1);
                    }
                    else
                    {
                        String message = "TVI Database is OFFLINE.";
                        String dbMessage = rs.getString("DB_MESSAGE");
                        if (dbMessage != null && !dbMessage.isEmpty())
                        {
                            message = dbMessage;
                        }
                        
                        Misc.msgbox(parentFrame, message, "TVI Client Status", -1, 1, 1);
                        Misc.exit(parentFrame, "DATABASE OFFLINE");
                    }
                }
            }
            else
            {
                Misc.msgbox(parentFrame, "Unable to check client status.  For access email " + Constants.EMAIL, "", 1, 1, 1);
                Misc.exit(parentFrame, "NO ACCESS");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error checking client status.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
            closeCursors(parentFrame, null, rs);
        }
    }
    
    /**
     * Gets the list of attendance codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAttendanceCodes(Component parentFrame, String clientName, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString;
            if (clientName.equals("INFOR"))
            {
                sqlString = "SELECT SAP_CODE_AREC, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, PROCESS4, UNION_FLAG "
                             +    " FROM TVI_INF_WORK_CODES "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY DESCRIPTION";
            }
            else
            {
                sqlString = "SELECT SAP_CODE_AREC, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, PROCESS4, UNION_FLAG "
                             +    " FROM TVI_TIME_WORKED_CODES_J "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY SAP_CODE_AREC";
            }
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting attendance codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of absence codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAbsenceCodes(Component parentFrame, String clientName, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString;
            if (clientName.equals("INFOR"))
            {
                sqlString = "SELECT SAP_CODE, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, REASON_CODE_REQUIRED, ADD2REGPLUSABS, UNION_FLAG "
                             +    " FROM TVI_INF_ABSENCE_CODES "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY DESCRIPTION";
            }
            else
            {
                sqlString = "SELECT SAP_CODE, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, REASON_CODE_REQUIRED, ADD2REGPLUSABS, UNION_FLAG "
                             +    " FROM TVI_ABSENCE_CODES "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY SAP_CODE";
            }
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting absence codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of reason codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsReasonCodes(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT SAP_CODE, SAP_REASON_CODE, DESCRIPTION, UNION_FLAG "
                             +    " FROM TVI_REASON_CODES "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY SAP_CODE, SAP_REASON_CODE";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting reason codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of extra payment codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsExtraPaymentCodes(Component parentFrame, String clientName, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            
            String sqlString;
            if (clientName.equals("INFOR"))
            {
                sqlString = "SELECT EREC_CODE, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, COST_ASSIGNMENT, AMOUNT_TYPE, UNION_FLAG "
                             +    " FROM TVI_INF_EREC_CODES "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY DESCRIPTION";
            }
            else
            {
                sqlString = "SELECT EREC_CODE, DESCRIPTION, PROCESS1, PROCESS2, PROCESS3, COST_ASSIGNMENT, AMOUNT_TYPE, UNION_FLAG "
                             +    " FROM TVI_EREC_CODES_J "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY EREC_CODE";
            }
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting extra payment codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of DWS codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsDWSCodes(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * "
                             +    " FROM TVI_DAILY_WORK_SCHEDULES2 "
                             +        " WHERE FEEDER = ? "
                             +        " ORDER BY HRS_PER_DAY";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting DWS codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of shift codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsShiftCodes(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT HRS_PER_DAY, UNION_FLAG "
                             +    " FROM TVI_DAILY_WORK_SCHEDULES2 "
                             +        " WHERE FEEDER = ? "
                             +        " GROUP BY HRS_PER_DAY, UNION_FLAG "
                             +        " ORDER BY TO_NUMBER(HRS_PER_DAY, '999D99','NLS_NUMERIC_CHARACTERS=''.,''')";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting shift codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of payroll close dates for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollCloseDates(Component parentFrame)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT PAYROLL_CLOSE, HOT_DAY, PAYROLL_GROUP "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_CLOSE > SYSDATE - 400 "
                             +        " ORDER BY PAYROLL_CLOSE";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting payroll close dates.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of holiday codes for the specified feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHolidayCodes(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT HOLIDAY, THE_TYPE, THE_NAME "
                             +    " FROM TVI_HOLIDAYS "
                             +        " WHERE FEEDER = ? AND HOLIDAY > SYSDATE - 400 "
                             +        " ORDER BY HOLIDAY";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting holiday codes.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of MUs for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMUs(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MU "
                             +    " FROM MU "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND VALIDATED = -1 "
                             +        " ORDER BY (CASE WHEN IS_ALPHA(SUBSTR(MU, 1, 1)) = -1 THEN 0 ELSE TO_NUMBER(MU) END)";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting site mu list.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Deletes the specified absence.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param reportingDate
     * @param recKey
     */
    public static void deleteAbsence(Component parentFrame, String empid, Date reportingDate, String recKey)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ABS_DELETE ( ?, ?, ? ) }");
            int recKeyOut = Integer.parseInt(recKey);
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKeyOut);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting absence.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates the specified absence record.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate the date of the record
     * @param empid the employee's AT&T UUID
     * @param recKey record key of the record
     * @param sapCodeTrec existing absence code to update
     * @param codeDescription the new absence code description
     * @param hoursTrec the new absence code hours, HOURS_TREC
     * @param reasonCode the new REASON_CODE value
     * @param reasonText the new REASON_TEXT value
     * @param readyFlag the new READYFLAG value
     * @param reasonDescription the new REASON_DESCRIPTION value
     * @param changedBy the AT&T UUID of the user submitting the update
     * @param minsTrec
     */
    public static void updateAbsence(Component parentFrame, Date reportingDate, String empid, int recKey, String sapCodeTrec,
        String codeDescription, double hoursTrec, String reasonCode, String reasonText,
        int readyFlag, String reasonDescription, String changedBy, int minsTrec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ABS_UPDATE ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKey);
            ocs.setString(4, sapCodeTrec);
            ocs.setString(5, codeDescription);
            ocs.setDouble(6, hoursTrec);
            ocs.setString(7, reasonCode);
            ocs.setString(8, reasonText);
            ocs.setInt(9, readyFlag);
            ocs.setString(10, reasonDescription);
            ocs.setString(11, changedBy);
            ocs.setInt(12, minsTrec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating absence.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Adds a new absence record, as specified.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param totalviewID
     * @param mu
     * @param reportingDate
     * @param empid the employee's AT&T UUID
     * @param recKey the new record key
     * @param sapCodeTrec the new absence code
     * @param codeDescription the new absence code description
     * @param hoursTrec the new absence code hours, HOURS_TREC
     * @param reasonCode the new REASON_CODE value
     * @param reasonText the new REASON_TEXT value
     * @param readyFlag the new READYFLAG value
     * @param reasonDescription the new REASON_DESCRIPTION value
     * @param changedBy the AT&T UUID of the user submitting the insert
     * @param minsTrec
     */
    public static void insertAbsence(Component parentFrame, String feeder, String site, int totalviewID,
        String mu, Date reportingDate, String empid, int recKey, String sapCodeTrec,
        String codeDescription, double hoursTrec, String reasonCode, String reasonText,
        int readyFlag, String reasonDescription, String changedBy, int minsTrec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ABS_INSERT ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, totalviewID);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, empid);
            ocs.setInt(7, recKey);
            ocs.setString(8, sapCodeTrec);
            ocs.setString(9, codeDescription);
            ocs.setDouble(10, hoursTrec);
            ocs.setString(11, reasonCode);
            ocs.setString(12, reasonText);
            ocs.setInt(13, readyFlag);
            ocs.setString(14, reasonDescription);
            ocs.setString(15, changedBy);
            ocs.setInt(16, minsTrec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting absence.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates the specified Time Totals record.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate the date to update
     * @param empid AT&T UUID of the employee to update
     * @param dws
     * @param parttimeFlag
     * @param holidayFlag
     * @param reg
     * @param overtime
     * @param callout
     * @param total
     * @param regTotal
     * @param absencesTotal
     * @param absencesExtTotal
     * @param ccTotal
     * @param extraPayFlag
     * @param diffShiftCWA
     * @param leadHoursRegCWA
     * @param flexHours
     * @param workedPdoBefore
     * @param workedPdoAfter
     * @param absencesReady
     * @param timeWorkedReady
     * @param timeTotalsReady
     * @param message
     * @param highlightName
     * @param status
     * @param tardyPaid1
     * @param tardyPaid2
     * @param tardyPaid3
     * @param tardyPaid4
     * @param overtimeRefused
     * @param overtimeNotAvailable
     * @param diffHoursRegCWA
     * @param leadHoursExtCWA
     * @param holidayTraded
     * @param ovnt
     * @param bilingualDiffHourly
     * @param bilingualDiffDaily
     * @param leadHoursRegIBEW
     * @param leadHoursExtIBEW
     * @param diffHrsRegIBEW
     * @param diffHoursExtIBEW
     * @param workedHdBeforePost
     * @param workedHdAfterPost
     * @param holi
     * @param rd
     * @param TiuFlag
     * @param mealAllowance
     * @param rdHours
     * @param rdAmt
     * @param chgdBy
     * @param diffHoursExtCWA
     * @param diffSource
     * @param callup
     * @param sixthDay
     * @param otherFlags
     * @param shift
     * @param attendFlag
     * @param carfareFlag
     * @param loadStatus
     * @param dateTVModified
     * @param shiftTraded
     * @param tardyFlag
     * @param maFlag
     * @param rnaFlag
     * @param bilingualFlag
     * @param prem
     * @param sund
     * @param cfasValidated
     * @param resendFlag
     */
    public static void updateTimeTotals(Component parentFrame, Date reportingDate, String empid, String dws,
        int parttimeFlag, int holidayFlag, double reg, double overtime, double callout,
        double total, double regTotal, double absencesTotal, double absencesExtTotal,
        double ccTotal, int extraPayFlag, int diffShiftCWA, double leadHoursRegCWA,
        double flexHours, int workedPdoBefore, int workedPdoAfter, int absencesReady,
        int timeWorkedReady, int timeTotalsReady, String message, int highlightName,
        String status, int tardyPaid1, int tardyPaid2, int tardyPaid3, int tardyPaid4,
        double overtimeRefused, double overtimeNotAvailable, double diffHoursRegCWA,
        double leadHoursExtCWA, int holidayTraded, int ovnt, double bilingualDiffHourly,
        double bilingualDiffDaily, double leadHoursRegIBEW, double leadHoursExtIBEW,
        double diffHrsRegIBEW, double diffHoursExtIBEW, int workedHdBeforePost,
        int workedHdAfterPost, double holi, double rd, int TiuFlag, double mealAllowance,
        double rdHours, double rdAmt, String chgdBy, double diffHoursExtCWA, int diffSource,
        double callup, int sixthDay, int otherFlags, double shift, int attendFlag,
        int carfareFlag, int loadStatus, int dateTVModified, int shiftTraded, int tardyFlag, int maFlag,
        int rnaFlag, int bilingualFlag, Double prem, Double sund, int cfasValidated, int resendFlag
        )
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TT_UPDATE_NEW ( "
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + " ?, ?, ?, ?, ?, ?, ?, ?, ? )}"
            );
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setString(3, dws);
            ocs.setInt(4, parttimeFlag);
            ocs.setInt(5, holidayFlag);
            ocs.setDouble(6, reg);
            ocs.setDouble(7, overtime);
            ocs.setDouble(8, callout);
            ocs.setDouble(9, total);
            ocs.setDouble(10, regTotal);
            ocs.setDouble(11, absencesTotal);
            ocs.setDouble(12, absencesExtTotal);
            ocs.setDouble(13, ccTotal);
            ocs.setInt(14, extraPayFlag);
            ocs.setInt(15, diffShiftCWA);
            ocs.setDouble(16, leadHoursRegCWA);
            ocs.setDouble(17, flexHours);
            ocs.setInt(18, workedPdoBefore);
            ocs.setInt(19, workedPdoAfter);
            ocs.setInt(20, absencesReady);
            ocs.setInt(21, timeWorkedReady);
            ocs.setInt(22, timeTotalsReady);
            ocs.setString(23, message);
            ocs.setInt(24, highlightName);
            ocs.setString(25, status);
            ocs.setInt(26, tardyPaid1);
            ocs.setInt(27, tardyPaid2);
            ocs.setInt(28, tardyPaid3);
            ocs.setInt(29, tardyPaid4);
            ocs.setDouble(30, overtimeRefused);
            ocs.setDouble(31, overtimeNotAvailable);
            ocs.setDouble(32, diffHoursRegCWA);
            ocs.setDouble(33, leadHoursExtCWA);
            ocs.setInt(34, holidayTraded);
            ocs.setInt(35, ovnt);
            ocs.setDouble(36, bilingualDiffHourly);
            ocs.setDouble(37, bilingualDiffDaily);
            ocs.setDouble(38, leadHoursRegIBEW);
            ocs.setDouble(39, leadHoursExtIBEW);
            ocs.setDouble(40, diffHrsRegIBEW);
            ocs.setDouble(41, diffHoursExtIBEW);
            ocs.setInt(42, workedHdBeforePost);
            ocs.setInt(43, workedHdAfterPost);
            ocs.setDouble(44, holi);
            ocs.setDouble(45, rd);
            ocs.setInt(46, TiuFlag);
            ocs.setDouble(47, mealAllowance);
            ocs.setDouble(48, rdHours);
            ocs.setDouble(49, rdAmt);
            ocs.setString(50, chgdBy);
            ocs.setDouble(51, diffHoursExtCWA);
            ocs.setInt(52, diffSource);
            ocs.setDouble(53, callup);
            ocs.setInt(54, sixthDay);
            ocs.setInt(55, otherFlags);
            ocs.setDouble(56, shift);
            ocs.setInt(57, attendFlag);
            ocs.setInt(58, carfareFlag);
            ocs.setInt(59, loadStatus);
            ocs.setInt(60, dateTVModified);
            ocs.setInt(61, shiftTraded);
            ocs.setInt(62, tardyFlag);
            ocs.setInt(63, maFlag);
            ocs.setInt(64, rnaFlag);
            ocs.setInt(65, bilingualFlag);
            ocs.setDouble(66, prem);
            ocs.setDouble(67, sund);
            ocs.setInt(68, cfasValidated);
            ocs.setInt(69, resendFlag);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating time totals.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Create a new Time Totals record.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empid
     * @param employee
     * @param agentid
     * @param coach
     * @param changedBy the AT&T UUID of the user creating the record
     * @return true if successful, false otherwise
     */
    public static boolean insertTimeTotals(Component parentFrame, String feeder, String site, String mu,
        Date reportingDate, String empid, String employee, String agentid, String coach, String changedBy)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TT_INSERT ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, -1); // totalviewID, no longer used by procedure
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, empid);
            ocs.setString(7, agentid);
            ocs.setString(8, employee);
            ocs.setString(9, coach);
            ocs.setString(10, changedBy);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
 
    /**
     * Sets the status of the specified Time Totals record to "Completed".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empid
     * @param completedBy the AT&T UUID of the user completing the record
     */
    public static void manualComplete(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String empid, String completedBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TT_UPDATE_MAN_CLOSE_STATUS ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.setString(5, empid);
            ocs.setString(6, completedBy);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error during manual complete.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * POWER user only; sets the Time Totals record status to "Ready" and sets MESSAGE = "FYI: Manually Completed by TVI Support."
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empid
     * @param completedBy the AT&T UUID of the user completing the record
     */
    public static void manualCompletePower(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String empid, String completedBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TT_UPDATE_MAN_COMPLETE_POWER ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.setString(5, empid);
            ocs.setString(6, completedBy);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error during manual complete.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Deletes the Time Totals record for the given employee and date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empid
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean deleteEmployee(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String empid, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL TT_DELETE ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu); 
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.setString(5, empid);
            ocs.setString(6, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting employee.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates BEGIN and LAST dates for the EMPLOYEES_TVI record for the given employee based on the process that was run.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param processType "CHGEMPID", "RESTORE", "TTDELETE"
     * @return true if site is ready, false if compute premium needs to be run
     */
    public static boolean updateEmployeeRecordsBeginLastDates(Component parentFrame, String feeder, String site, String mu, String empid, String processType)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL EMPLOYEES_TVI_UPDATE_BEG_LAST( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setString(5, processType);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to EMPLOYEES_TVI_UPDATE_BEG_LAST.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the employee has a completed record in history for the given date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empid
     * @return true if there exists a completed history record, false otherwise
     */
    public static boolean wasCompleted(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String empid)
    {
        Connection c = getConnection();
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MAX(COMP_OR_LOAD_DATE) LAST_COMPLETED_DATE "
                             +    " FROM TIME_TOTALS_HISTORY "
                             +        " WHERE FEEDER = ? AND SITE = ? AND MU = ? AND REPORTING_DATE = ? AND EMPID = ? AND TO_ELINK_DATE_TIME IS NOT NULL";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            ps.setString(5, empid);
            
            rs = ps.executeQuery();
            if (rs.next())
            {
                output = rs.getString("LAST_COMPLETED_DATE") != null;
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "Failed to check employee history.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Deletes the specified Time Totals record.  Attempt to restore the most recent previously completed value from history, if it exists.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param sbcid
     */
    public static void restoreFromHistory(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RESTORE_FROM_HISTORY (?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error restoring history record.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Deletes the specified attendance record.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param reportingDate
     * @param recKey
     */
    public static void deleteAttendance(Component parentFrame, String empid, Date reportingDate, String recKey)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TIMEWORKED_DELETE ( ?, ?, ? ) }");
            int recKeyOut = Integer.parseInt(recKey);
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKeyOut);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting attendance.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates the specified attendance record.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate date of the record to update
     * @param empid AT&T UUID of the employee to update
     * @param recKey record key to update
     * @param sapCodeArec new attendance code value
     * @param codeDescription new attendance code description
     * @param hoursArec new attendance hours value
     * @param activity new attendance ACTIVITY value
     * @param costCenter new attendance COST_CENTER value
     * @param locationCode new attendance LOCATION_CODE value
     * @param projectNumber new attendance PROJECT_NUMBER value
     * @param deptTrackingCode new attendance DEPT_TRACKING_CODE value
     * @param readyFlag new attendance READYFLAG value
     * @param taxArea new attendance TAX_AREA value
     * @param frc new attendance FRC value
     * @param ec new attendance EC value
     * @param changedBy the AT&T UUID of the user submitting the update
     * @param minsArec
     */
    public static void updateAttendance(Component parentFrame, Date reportingDate,
                 String empid, int recKey, String sapCodeArec,
                 String codeDescription, double hoursArec, String activity,
                 String costCenter, String locationCode, String projectNumber,
                 String deptTrackingCode, int readyFlag, String taxArea,
                 String frc, String ec, String changedBy, int minsArec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TIMEWORKED_UPDATE ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKey);
            ocs.setString(4, sapCodeArec);
            ocs.setString(5, codeDescription);
            ocs.setDouble(6, hoursArec);
            ocs.setString(7, activity);
            ocs.setString(8, costCenter);
            ocs.setString(9, locationCode);
            ocs.setString(10, projectNumber);
            ocs.setString(11, deptTrackingCode);
            ocs.setInt(12, readyFlag);
            ocs.setString(13, taxArea);
            ocs.setString(14, frc);
            ocs.setString(15, ec);
            ocs.setString(16, changedBy);
            ocs.setInt(17, minsArec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating attendance.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Updates the specified attendance record in INFOR
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate date of the record to update
     * @param empid AT&T UUID of the employee to update
     * @param recKey record key to update
     * @param sapCodeArec new attendance code value
     * @param codeDescription new attendance code description
     * @param hoursArec new attendance hours value
     * @param activity new attendance ACTIVITY value
     * @param costCenter new attendance COST_CENTER value
     * @param locationCode new attendance LOCATION_CODE value
     * @param projectNumber new attendance PROJECT_NUMBER value
     * @param deptTrackingCode new attendance DEPT_TRACKING_CODE value
     * @param readyFlag new attendance READYFLAG value
     * @param taxArea new attendance TAX_AREA value
     * @param frc new attendance FRC value
     * @param ec new attendance EC value
     * @param changedBy the AT&T UUID of the user submitting the update
     * @param minsArec
     * #param costCenterEmployee
     * @param jfc
     */
    public static void updateAttendanceINFOR(Component parentFrame, Date reportingDate,
                 String empid, int recKey, String sapCodeArec,
                 String codeDescription, double hoursArec, String activity,
                 String costCenter, String locationCode, String projectNumber,
                 String deptTrackingCode, int readyFlag, String taxArea,
                 String frc, String ec, String changedBy, int minsArec,
                 String costCenterEmployee, String jfc)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TIMEWORKED_UPDATE_INFOR ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKey);
            ocs.setString(4, sapCodeArec);
            ocs.setString(5, codeDescription);
            ocs.setDouble(6, hoursArec);
            ocs.setString(7, activity);
            ocs.setString(8, costCenter);
            ocs.setString(9, locationCode);
            ocs.setString(10, projectNumber);
            ocs.setString(11, deptTrackingCode);
            ocs.setInt(12, readyFlag);
            ocs.setString(13, taxArea);
            ocs.setString(14, frc);
            ocs.setString(15, ec);
            ocs.setString(16, changedBy);
            ocs.setInt(17, minsArec);
            ocs.setString(18, costCenterEmployee);
            ocs.setString(19, jfc);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating attendance.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Creates a new Attendance record.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param totalviewID
     * @param mu
     * @param reportingDate
     * @param empid
     * @param recKey
     * @param sapCodeArec
     * @param codeDescription
     * @param hoursArec
     * @param activity
     * @param costCenter
     * @param locationCode
     * @param projectNumber
     * @param deptTrackingCode
     * @param readyFlag
     * @param taxArea
     * @param frc
     * @param ec
     * @param changedBy the AT&T UUID of the user creating the record
     * @param minsArec
     */
    public static void insertAttendance(Component parentFrame, String feeder, String site, int totalviewID,
            String mu, Date reportingDate, String empid, int recKey, String sapCodeArec,
            String codeDescription, double hoursArec, String activity, String costCenter,
            String locationCode, String projectNumber, String deptTrackingCode, int readyFlag,
            String taxArea, String frc, String ec, String changedBy, int minsArec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TIMEWORKED_INSERT ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, totalviewID);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, empid);
            ocs.setInt(7, recKey);
            ocs.setString(8, sapCodeArec);
            ocs.setString(9, codeDescription);
            ocs.setDouble(10, hoursArec);
            ocs.setString(11, activity);
            ocs.setString(12, costCenter);
            ocs.setString(13, locationCode);
            ocs.setString(14, projectNumber);
            ocs.setString(15, deptTrackingCode);
            ocs.setInt(16, readyFlag);
            ocs.setString(17, taxArea);
            ocs.setString(18, frc);
            ocs.setString(19, ec);
            ocs.setString(20, changedBy);
            ocs.setInt(21, minsArec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting attendance.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Creates a new Attendance record in INFOR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param totalviewID
     * @param mu
     * @param reportingDate
     * @param empid
     * @param recKey
     * @param sapCodeArec
     * @param codeDescription
     * @param hoursArec
     * @param activity
     * @param costCenter
     * @param locationCode
     * @param projectNumber
     * @param deptTrackingCode
     * @param readyFlag
     * @param taxArea
     * @param frc
     * @param ec
     * @param changedBy the AT&T UUID of the user creating the record
     * @param minsArec
     * @param costCenterEmployee
     * @param jfc
     */
    public static void insertAttendanceINFOR(Component parentFrame, String feeder, String site, int totalviewID,
            String mu, Date reportingDate, String empid, int recKey, String sapCodeArec,
            String codeDescription, double hoursArec, String activity, String costCenter,
            String locationCode, String projectNumber, String deptTrackingCode, int readyFlag,
            String taxArea, String frc, String ec, String changedBy, int minsArec, String costCenterEmployee, String jfc)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TIMEWORKED_INSERT_INFOR ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, totalviewID);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, empid);
            ocs.setInt(7, recKey);
            ocs.setString(8, sapCodeArec);
            ocs.setString(9, codeDescription);
            ocs.setDouble(10, hoursArec);
            ocs.setString(11, activity);
            ocs.setString(12, costCenter);
            ocs.setString(13, locationCode);
            ocs.setString(14, projectNumber);
            ocs.setString(15, deptTrackingCode);
            ocs.setInt(16, readyFlag);
            ocs.setString(17, taxArea);
            ocs.setString(18, frc);
            ocs.setString(19, ec);
            ocs.setString(20, changedBy);
            ocs.setInt(21, minsArec);
            ocs.setString(22, costCenterEmployee);
            ocs.setString(23, jfc);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting attendance.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Deletes the specified Extra Payment record.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param reportingDate
     * @param recKey
     */
    public static void deleteExtraPayment(Component parentFrame, String empid, Date reportingDate, String recKey)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL EXTRAPAY_DELETE ( ?, ?, ? ) }");
            int recKeyOut = Integer.parseInt(recKey);
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKeyOut);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting extra payment.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * updateExtraPayment
     * 
     * Updates the specified Extra Payment record.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate date of the Extra Payment to update
     * @param empid AT&T UUID of the employee to update
     * @param recKey record key to update
     * @param sapCodeErec the new Extra Payment code
     * @param codeDescription the new Extra Payment code description
     * @param amountErec the new Extra Payment AMOUNT value
     * @param amountType the new Extra Payment AMOUNT_TYPE value
     * @param activity the new Extra Payment ACTIVITY value
     * @param costCenter the new Extra Payment COST_CENTER value
     * @param locationCode the new Extra Payment LOCATION_CODE value
     * @param deptTrackingCode the new Extra Payment DEPT_TRACKING_CODE value
     * @param projectNumber the new Extra Payment PROJECT_NUMBER value
     * @param ec the new Extra Payment EX value
     * @param changedBy the AT&T UUID of the user submitting the update
     * @param minsErec
     */
    public static void updateExtraPayment(Component parentFrame, Date reportingDate, String empid, int recKey,
            String sapCodeErec, String codeDescription, double amountErec, String amountType, String activity, String costCenter,
            String locationCode, String deptTrackingCode, String projectNumber, String ec, String changedBy, int minsErec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL EXTRAPAY_UPDATE ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKey);
            ocs.setString(4, sapCodeErec);
            ocs.setString(5, codeDescription);
            ocs.setDouble(6, amountErec);
            ocs.setString(7, changedBy);
            ocs.setString(8, activity);
            ocs.setString(9, costCenter);
            ocs.setString(10, locationCode);
            ocs.setString(11, deptTrackingCode);
            ocs.setString(12, projectNumber);
            ocs.setString(13, ec);
            ocs.setString(14, amountType);
            ocs.setInt(15, minsErec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating extra payments.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * updateExtraPaymentInfor
     * 
     * Updates the specified Extra Payment record for INFOR.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate date of the Extra Payment to update
     * @param empid AT&T UUID of the employee to update
     * @param recKey record key to update
     * @param sapCodeErec the new Extra Payment code
     * @param codeDescription the new Extra Payment code description
     * @param amountErec the new Extra Payment AMOUNT value
     * @param amountType the new Extra Payment AMOUNT_TYPE value
     * @param activity the new Extra Payment ACTIVITY value
     * @param costCenter the new Extra Payment COST_CENTER value
     * @param locationCode the new Extra Payment LOCATION_CODE value
     * @param deptTrackingCode the new Extra Payment DEPT_TRACKING_CODE value
     * @param projectNumber the new Extra Payment PROJECT_NUMBER value
     * @param ec the new Extra Payment EX value
     * @param changedBy the AT&T UUID of the user submitting the update
     * @param minsErec
     */
    public static void updateExtraPaymentInfor(Component parentFrame, Date reportingDate, String empid, int recKey, String sapCodeErec,
            String codeDescription, double amountErec, String amountType, String deptTrackingCode, String ec, String changedBy, int minsErec)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL EXTRAPAY_UPDATE_INFOR ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, empid);
            ocs.setInt(3, recKey);
            ocs.setString(4, sapCodeErec);
            ocs.setString(5, codeDescription);
            ocs.setDouble(6, amountErec);
            ocs.setString(7, changedBy);
            ocs.setString(8, deptTrackingCode);
            ocs.setString(9, ec);
            ocs.setString(10, amountType);
            ocs.setInt(11, minsErec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating extra payments.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Creates a new Extra Payment record.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param totalviewID
     * @param mu
     * @param reportingDate
     * @param empid
     * @param recKey
     * @param sapCodeErec
     * @param codeDescription
     * @param amountErec
     * @param minsErec
     * @param amountType
     * @param activity
     * @param costCenter
     * @param locationCode
     * @param deptTrackingCode
     * @param projectNumber
     * @param ec
     * @param changedBy
     */
    public static void insertExtraPayment(Component parentFrame, String feeder, String site, int totalviewID,
            String mu, Date reportingDate, String empid, int recKey, String sapCodeErec,
            String codeDescription, double amountErec, int minsErec, String amountType,
            String activity, String costCenter, String locationCode, String deptTrackingCode,
            String projectNumber, String ec, String changedBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL EXTRAPAY_INSERT ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, totalviewID);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, empid);
            ocs.setInt(7, recKey);
            ocs.setString(8, sapCodeErec);
            ocs.setString(9, codeDescription);
            ocs.setDouble(10, amountErec);
            ocs.setString(11, changedBy);
            ocs.setString(12, activity);
            ocs.setString(13, costCenter);
            ocs.setString(14, locationCode);
            ocs.setString(15, deptTrackingCode);
            ocs.setString(16, projectNumber);
            ocs.setString(17, ec);
            ocs.setString(18, amountType);
            ocs.setInt(19, minsErec);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting extra payment.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Update the specified employee's AT&T UUID.
     * 
     * @param parentFrame the frame to center messages on
     * @param reportingDate
     * @param oldEmpid
     * @param newEmpid
     * @return true if successful, false otherwise
     */
    public static boolean changeUUID(Component parentFrame, Date reportingDate, String oldEmpid, String newEmpid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL CHANGE_EMPID ( ?, ?, ?, ? ) }");
            ocs.setDate(1, Misc.dateToSqlDate(reportingDate));
            ocs.setString(2, oldEmpid);
            ocs.setString(3, newEmpid);
            ocs.setString(4, "JAVA");
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            String dateString = Misc.dateToStringMDY(reportingDate);
            int errorCode = ex.getErrorCode();
            switch (errorCode)
            {
                case 20002:
                    Misc.msgbox(parentFrame, "Record already exists on this date for attid: " + newEmpid + " on " + dateString + "  Email TVI support if you need help: " + Constants.EMAIL, "TVI - AT&T ID not changed", 1, 1, 2);
                    break;
                case 20001:
                    Misc.msgbox(parentFrame, "Record does not exist on this date for attid: " + newEmpid + " on " + dateString + "  Email TVI support if you need help: " + Constants.EMAIL, "TVI - AT&T ID not changed", 1, 1, 2);
                    break;
                default:
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHANGE_EMPID.");
                    break;
            }
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates the user's stored TVI version number.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param clientName
     * @param version the new TVI version value
     */
    public static void updateUserVersion(Component parentFrame, String sbcid, String clientName, String version)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_USER_VERSION ( ?, ?, ? ) }");
            ocs.setString(1, sbcid);
            ocs.setString(2, clientName);
            ocs.setString(3, version);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_USER_VERSION.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Determines the DWS value of the given record.
     * 
     * @param parentFrame the frame to center messages on
     * @param p_feeder
     * @param p_shiftHours
     * @param p_NightDiff
     * @param p_union
     * @param p_CarFare
     * @param p_diff_15Percent
     * @param p_RNA_FLAG
     * @param p_Diff060
     * @param p_Diff150
     * @param p_Diff185
     * @param p_Diff200
     * @param p_Diff220
     * @param p_Diff250
     * @param p_Diff270
     * @param p_Diff300
     * @param p_Diff400
     * @param p_Diff500
     * @param p_Diff900
     * @param p_Diff600
     * @param p_Diff800
     * @param p_Diff_1_percent
     * @param p_Diff_1_5_percent
     * @param p_Diff_2_percent
     * @param p_Diff_2_5_percent
     * @param p_Diff_3_percent
     * @param p_Gap
     * @return DWS string
     */
    public static String encodeDWS(
            Component parentFrame,
            String p_feeder,
            double p_shiftHours,
            int p_NightDiff,
            String p_union,
            int p_CarFare,
            int p_diff_15Percent,
            int p_RNA_FLAG,
            int p_Diff060,
            int p_Diff150,
            int p_Diff185,
            int p_Diff200,
            int p_Diff220,
            int p_Diff250,
            int p_Diff270,
            int p_Diff300,
            int p_Diff400,
            int p_Diff500,
            int p_Diff900,
            int p_Diff600,
            int p_Diff800,
            int p_Diff_1_percent,
            int p_Diff_1_5_percent,
            int p_Diff_2_percent,
            int p_Diff_2_5_percent,
            int p_Diff_3_percent,
            int p_Gap)
    {
        Connection c = getConnection();
        String newDWS = "";
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := COMPUTE_DWS ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, p_feeder);
            ocs.setDouble(3, p_shiftHours);
            ocs.setInt(4, p_NightDiff);
            ocs.setString(5, p_union);
            ocs.setInt(6, p_CarFare);
            ocs.setInt(7, p_diff_15Percent);
            ocs.setInt(8, p_RNA_FLAG);
            ocs.setInt(9, p_Diff060);
            ocs.setInt(10, p_Diff150);
            ocs.setInt(11, p_Diff185);
            ocs.setInt(12, p_Diff200);
            ocs.setInt(13, p_Diff220);
            ocs.setInt(14, p_Diff250);
            ocs.setInt(15, p_Diff270);
            ocs.setInt(16, p_Diff300);
            ocs.setInt(17, p_Diff400);
            ocs.setInt(18, p_Diff500);
            ocs.setInt(19, p_Diff900);
            ocs.setInt(20, p_Diff600);
            ocs.setInt(21, p_Diff800);
            ocs.setInt(22, p_Diff_1_percent);
            ocs.setInt(23, p_Diff_1_5_percent);
            ocs.setInt(24, p_Diff_2_percent);
            ocs.setInt(25, p_Diff_2_5_percent);
            ocs.setInt(26, p_Diff_3_percent);
            ocs.setInt(27, p_Gap);
            ocs.execute();
            newDWS = ocs.getString(1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE_DWS.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return newDWS;
    }
    
    /**
     * Updates basic user information.
     * 
     * @param parentFrame the frame to center messages on
     * @param empName the user's name
     * @param empNumber the user's phone number, no formatting or spaces
     * @param defaultFeeder the user's preferred default feeder
     * @param defaultSite the user's preferred default site
     * @param noFullscreen true if the user doesn't want fullscreen form windows
     * @param sbcid the AT&T UUID of the user to update
     * @return true if successful, false otherwise
     */
    public static boolean updateUserInfo(Component parentFrame, String empName, String empNumber, String defaultFeeder, String defaultSite, boolean noFullscreen, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL USER_INFO_UPDATE ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, empName);
            ocs.setString(2, empNumber);
            ocs.setString(3, defaultFeeder);
            ocs.setString(4, defaultSite);
            ocs.setInt(5, Misc.booleanToOracle(noFullscreen));
            ocs.setString(6, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating user info.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Creates a new comment for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param comment the new comment string
     * @return true if successful, false otherwise
     */
    public static boolean insertComment(Component parentFrame, String feeder, String site, String comment)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMMENTS_INSERT ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, comment);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting comment.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Removes a comment for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param comment the comment string to remove
     * @return true if successful, false otherwise
     */
    public static boolean deleteComment(Component parentFrame, String feeder, String site, String comment)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMMENTS_DELETE ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, comment);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            if (ex.getErrorCode() == 20001)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error: comment not found.");
            }
            else
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting comment.");
            }
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Adds a new cost center for the specified site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param costCenter the new cost center string to add
     * @return true if successful, false otherwise
     */
    public static boolean insertCostCenter(Component parentFrame, String feeder, String site, String costCenter)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COST_CENTERS_INSERT ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, costCenter);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inserting cost center.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Removes a cost center for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param costCenter the cost center string to remove
     * @return true if successful, false otherwise
     */
    public static boolean deleteCostCenter(Component parentFrame, String feeder, String site, String costCenter)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COST_CENTERS_DELETE ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, costCenter);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            if (ex.getErrorCode() == 20001)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error: cost center not found.");
            }
            else
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting cost center.");
            }
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * For downloading TVIUpgrade.jar & TVIClient.jar from the TVIDATA directory
     * 
     * @param parentFrame
     * @param filename
     * @return resultset with BFILE
     */
    public static ResultSetWrapper getBFILE(Component parentFrame, String filename)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT BFILENAME('TVIDATA', ?) FROM DUAL";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, filename);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error retrieving file " + filename);
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    
    /**
     * Downloads and saves the specified file from the server.
     * 
     * @param parentFrame the frame to center messages on
     * @param fileToRead BFILE object to download
     * @param fileToWrite filename to save as
     * @return true if successful, false otherwise
     */
    public static boolean downloadFileFromServer(Component parentFrame, oracle.jdbc.OracleBfile fileToRead, String fileToWrite)
    {
        boolean output = true;
        try
        {
            int bytesRead;
            Misc.deleteFile(fileToWrite);
            File fileOnDisk = new File(fileToWrite);
            try (FileOutputStream fileOnDiskStream = new FileOutputStream(fileOnDisk))
            {
                fileToRead.openFile();
                try (InputStream in = fileToRead.getBinaryStream())
                {
                    byte[] buf = new byte[8192];
                    while ((bytesRead = in.read(buf)) != -1)
                    {
                        fileOnDiskStream.write(buf, 0, bytesRead);
                    }
                }
                fileToRead.close();
            }
        }
        catch (IOException ex)
        {
            output = false;
            Misc.errorMsgDefault(parentFrame, ex);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error while downloading file from server.");
        }
        return output;
    }
    
    /**
     * Gets the most recent union flag for the specified employee
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param daysBack number of days to go back from reportingDate
     * @return the employee's most recent union flag, or "NONE" if none found, or "ERROR"
     */
    public static String getUnionFlag(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, int daysBack)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        String unionFlag = "ERROR";
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_UNION_FLAG( ?, ?, ?, ?, ?, ?) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            ocs.setInt(7, daysBack);
            ocs.execute();
            unionFlag = ocs.getString(1);
            
            if ("NONE".equals(unionFlag))
            {
                Misc.msgbox(parentFrame, "No employees exist for this payroll period.", "Database Error", 1, 1, 2);
            }
        }
        catch (SQLException ex)
        {
            Misc.msgbox(parentFrame, "ERROR Retrieving Union Process Flag - EMAIL TVI Support at " + Constants.EMAIL, "TVI Database Update Error", 1, 1, 2);
            return unionFlag;
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return unionFlag;
    }
    
    /**
     * Updates the config file.
     * //DYADD can remove after INFOR release, new config process
     * @param parentFrame the frame to center messages on
     */
    public static void updateConfig(Component parentFrame)
    {
        Connection c = getConnection();
        String password1 = "";
        String password2 = "";
        String dbNameOut = "";
        Date effectiveDate1 = null;
        Date effectiveDate2 = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT PASSWORD1, PASSWORD2, EFFECTIVE_DATE1, EFFECTIVE_DATE2, DBNAME FROM FEEDER WHERE FEEDER = ?");
            ps.setString(1, "ALL");
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                password1 = rs.getString("PASSWORD1");
                password2 = rs.getString("PASSWORD2");
                effectiveDate1 = Misc.sqlDateToDate(rs.getDate("EFFECTIVE_DATE1"));
                effectiveDate2 = Misc.sqlDateToDate(rs.getDate("EFFECTIVE_DATE2"));
                dbNameOut = rs.getString("DBNAME");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to update config file, contact TVI support.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        try (FileWriter cfgWriter = new FileWriter("TVIClient.cfg"))
        {
            cfgWriter.append(Misc.dateToStringMDY(effectiveDate1) + "\n");
            cfgWriter.append(password1 + "\n");
            cfgWriter.append(Misc.dateToStringMDY(effectiveDate2) + "\n");
            cfgWriter.append(password2 + "\n");
            cfgWriter.append(dbNameOut);
        }
        catch (IOException ex)
        {
            Misc.errorMsgCritical(parentFrame, ex, "Failed to write config file, contact TVI support");
        }
    }
    
    /**
     * Gets the config items from the TVI_CLIENTS table
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName leave null to default to 'ALL', otherwise specify client name to filter by
     */
    public static ResultSetWrapper getClientConfig(Component parentFrame, String clientName)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_CLIENT_CONFIG(?, ?) }");
            ocs.setString(1, clientName);
            ocs.registerOutParameter(2, OracleTypes.CURSOR);
            ocs.execute();
            rs = (ResultSet) ocs.getObject(2);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting client configuration records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks if there is a broadcast message to display.
     * 
     * @param feeder
     */
    public static void checkBroadcastMessage(final String feeder)
    {
        String message = null;
        Connection c = getConnection();
        PreparedStatement ps1 = null;
        PreparedStatement ps2 = null;
        ResultSet rs1 = null;
        ResultSet rs2 = null;
        boolean showMessage = false;
        try
        {
            ps1 = c.prepareStatement("SELECT DB_SHOW_MESSAGE, DB_MESSAGE_BROADCAST FROM FEEDER WHERE FEEDER = ?");
            ps2 = c.prepareStatement("SELECT DB_SHOW_MESSAGE, DB_MESSAGE_BROADCAST FROM FEEDER WHERE FEEDER = ?");
            ps1.setString(1, feeder);
            ps2.setString(1, "ALL");
            rs1 = ps1.executeQuery();
            rs2 = ps2.executeQuery();
            
            if (rs1.next())
            {
                // check if the current feeder has a specific message
                if (showMessage = Misc.oracleToBoolean(rs1.getInt("DB_SHOW_MESSAGE")))
                {
                    message = rs1.getString("DB_MESSAGE_BROADCAST");
                }
                // otherwise check if there's a global message
                else if (rs2.next())
                {
                    if (showMessage = Misc.oracleToBoolean(rs2.getInt("DB_SHOW_MESSAGE")))
                    {
                        message = rs2.getString("DB_MESSAGE_BROADCAST");
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(null, ex, true, "SQL Error checking broadcast message.");
        }
        finally
        {
            closeCursors(null, ps1, rs1);
            closeCursors(null, ps2, rs2);
        }
        
        if (message == null || message.equals(broadcastMessage))
        {
            showMessage = false;
        }
        if (showMessage)
        {
            Misc.msgbox(null, message, "TVI Broadcast Message", 1, 1, 1);
        }
        broadcastMessage = message;
    }
    
    /**
     * Checks if the specified feeder is online.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return true if the feeder is online, false otherwise
     */
    public static boolean isFeederOnline(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        boolean feederOnline;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DB_ONLINE "
                             +    " FROM FEEDER "
                             +        " WHERE FEEDER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
            if (rs.next())
            {
                feederOnline = Misc.oracleToBoolean(rs.getInt("DB_ONLINE"));
            }
            else
            {
                feederOnline = false;
            }
        }
        catch (SQLException ex)
        {
            feederOnline = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check feeder database status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return feederOnline;
    }
    
    /**
     * Checks if the specified feeder is online.
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName
     * @return true if the feeder is online, false otherwise
     */
    public static boolean isClientOnline(Component parentFrame, String clientName)
    {
        Connection c = getConnection();
        boolean clientOnline;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DB_ONLINE "
                             +    " FROM TVI_CLIENTS "
                             +        " WHERE CLIENT_NAME = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, clientName);
            rs = ps.executeQuery();
            if (rs.next())
            {
                clientOnline = Misc.oracleToBoolean(rs.getInt("DB_ONLINE"));
            }
            else
            {
                clientOnline = false;
            }
        }
        catch (SQLException ex)
        {
            clientOnline = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check client database status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return clientOnline;
    }
    
    /**
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @return true if the instance is online, false otherwise
     */
    public static boolean isTVIPOnline(Component parentFrame, String feeder, String site, String mu)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := IS_TVIP_ONLINE ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check instance status.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the specified client and feeder is online, initiates a shutdown if offline.
     * Routinely run by an automatic timer.
     * 
     * @param clientName
     * @param feeder
     * @return String - null if feeder is online
     */
    public static String checkClientOnline(final String clientName, final String feeder)
    {
        String msg = null;
        if (!isClientOnline(null, "ALL"))
        {
            msg = "<html>The client is going offline, your session will terminate in 5 minutes.<br>"
                + "Some unsaved data may be lost at shutdown, please finish any pending work and exit TVI.";
        }
        else if (!isClientOnline(null, clientName))
        {
            msg = "<html>Your current client is going offline, your session will terminate in 5 minutes.<br>"
                + "Some unsaved data may be lost at shutdown, please finish any pending work and exit TVI.";
        }
        else if (!isFeederOnline(null, "ALL"))
        {
            msg = "<html>The feeder is going offline, your session will terminate in 5 minutes.<br>"
                + "Some unsaved data may be lost at shutdown, please finish any pending work and exit TVI.";
        }
        else if (!isFeederOnline(null, feeder))
        {
            msg = "<html>Your current feeder is going offline, your session will terminate in 5 minutes.<br>"
                + "Some unsaved data may be lost at shutdown, please finish any pending work and change feeder or exit TVI.";
        }
        return msg;
    }
    
    /**
     * Gets the last stored unique computer identifier for the specified user.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid AT&T UUID of the user
     * @return the last stored computer ID for the user (motherboard serial number)
     */
    public static String getUniqueCompID(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String uniqueCompID = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT UNIQUE_COMP_ID "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
                                   
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            rs.next();
            uniqueCompID = rs.getString("UNIQUE_COMP_ID");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting UNIQUE_COMP_ID.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return uniqueCompID;
    }
    
    /**
     * Updates the specified user's stored unique computer ID.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param motherboardSN the machine's motherboard serial number
     */
    public static void updateUniqueCompID(Component parentFrame, String sbcid, String motherboardSN)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS "
                             +    " SET UNIQUE_COMP_ID = ? "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, motherboardSN);
            ps.setString(2, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating UNIQUE_COMP_ID.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Gets the user's last online date.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @return the last day the user was online, or null
     */
    public static Date getLastOnline(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        Date lastOnline = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT LAST_ONLINE "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                lastOnline = Misc.timestampToDate(rs.getTimestamp("LAST_ONLINE"));
            }
            else
            {
                throw new SQLException("User not found.");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting LAST_ONLINE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return lastOnline;
    }
    
    /**
     * Updates the user's last online date.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     */
    public static void updateLastOnline(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS "
                             +    " SET LAST_ONLINE = SYSDATE "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating LAST_ONLINE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Gets the user's local current date & time from the server.
     * 
     * @param parentFrame the frame to center messages on
     * @return the current timestamp from the server, in the user's local time zone
     */
    public static Date getCurTimeLocal(Component parentFrame)
    {
        Connection c = getConnection();
        Date curDate = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT SYSTIMESTAMP FROM DUAL");
            rs = ps.executeQuery();
            rs.next();
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            curDate = Misc.stringToDate(parentFrame, ZonedDateTime.ofInstant(rs.getTimestamp("SYSTIMESTAMP").toInstant(), ZoneId.systemDefault()).format(dateFormat), "yyyy-MM-dd HH:mm");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting SYSTIMESTAMP.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return curDate;
    }
    
    /**
     * Gets the current date & time from the server.
     * 
     * @param parentFrame the frame to center messages on
     * @return the current timestamp from the server (in the server's time zone)
     */
    public static Date getCurTime(Component parentFrame)
    {
        Connection c = getConnection();
        Date curDate = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT SYSDATE FROM DUAL");
            rs = ps.executeQuery();
            rs.next();
            curDate = Misc.timestampToDate(rs.getTimestamp("SYSDATE"));
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting SYSDATE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return curDate;
    }
    
    /**
     * Checks if the specified user has been flagged to have their current session terminated.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @return true if the user is flagged, false otherwise
     */
    public static boolean isForceLogoff(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        boolean forceLogoff = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT FORCE_LOGOFF "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                forceLogoff = Misc.oracleToBoolean(rs.getInt("FORCE_LOGOFF"));
            }
            else
            {
                Misc.msgbox(parentFrame, "Empty resultset, sbcid not found.", "SQL Error getting FORCE_LOGOFF", 1, 1, 1);
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting FORCE_LOGOFF.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return forceLogoff;
    }
    
    /**
     * Gets the force logoff message for the specified user
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @return the force logoff message for the user
     */
    public static String getForceLogoffMsg(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String forceLogoffMsg = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT FORCE_LOGOFF_MESSAGE "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            rs.next();
            forceLogoffMsg = rs.getString("FORCE_LOGOFF_MESSAGE");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting FORCE_LOGOFF_MESSAGE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return forceLogoffMsg;
    }
    
    /**
     * Sets the specified user's force logoff flag and message.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param forceLogoff the new flag value, true or false
     * @param msg the new force logoff message (set to "" when clearing flag)
     */
    public static void updateForceLogoff(Component parentFrame, String sbcid, boolean forceLogoff, String msg)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS "
                             +    " SET FORCE_LOGOFF = ?, FORCE_LOGOFF_MESSAGE = ? "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(forceLogoff));
            ps.setString(2, msg);
            ps.setString(3, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating FORCE_LOGOFF.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Sets the specified user's default validation selection.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param validateType "PASSWORD", "PASSCODE", or "" for no selection
     */
    public static void updateDefaultValidation(Component parentFrame, String sbcid, String validateType)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS "
                             +    " SET DEFAULT_VALIDATION = ? "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, validateType);
            ps.setString(2, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating DEFAULT_VALIDATION.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Unlocks records currently locked by the specified user
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu if null, ALL MUs will be selected
     * @param empid if null, ALL employees will be selected
     * @param startDate the first day in the date range to unlock
     * @param endDate the last day in the date range to unlock
     * @param lockedProcess unlock records locked by this process type ("NORMAL", "APPR", "DETAIL", "PRIOR", "CHANGES", "UPDATE")
     * @param sbcid unlock records locked by this user's AT&T UUID
     */
    public static void setRecordsUnlocked(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String lockedProcess, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_RECORDS_UNLOCKED( ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, lockedProcess);
            ocs.setString(8, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error unlocking records.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Locks available records in the selection
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu if null, ALL MUs will be selected
     * @param empid if null, ALL employees will be selected
     * @param startDate the first day in the date range to lock
     * @param endDate the last day in the date range to lock
     * @param lockedBy the AT&T UUID of the user locking the records
     * @param lockedProcess the type of process being used ("NORMAL", "APPR", "DETAIL", "PRIOR", "CHANGES", "UPDATE")
     */
    public static void setRecordsLockedBy(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String lockedBy, String lockedProcess)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_RECORDS_LOCKED_BY( ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, lockedBy);
            ocs.setString(8, lockedProcess);
            ocs.setString(9, ""); // not used, remove?
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error locking records.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets the specified schedule's LOCKED_BY value
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return the AT&T UUID of the user that has the schedule locked, or null if the schedule isn't locked.
     */
    public static String getScheduleLockedBy(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String lockedBy = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT LOCKED_BY "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND MU = ? "
                             +          " AND REPORTING_DATE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                lockedBy = rs.getString("LOCKED_BY");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule LOCKED_BY.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return lockedBy;
    }
    
    /**
     * Gets the specified schedule's current status.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return the schedule's status ("Requesting", "Loading", "Load Failed", "Imported", "Not Ready", "Ready to Send", "Sent Waiting Results", "Send Failed", "eLink Errors", "Completed", "Approved", "In Use")
     */
    public static String getScheduleStatus(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String status;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT STATUS "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND MU = ? "
                             +          " AND REPORTING_DATE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                status = rs.getString("STATUS");
            }
            else
            {
                status = null;
            }
        }
        catch (SQLException ex)
        {
            status = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule STATUS.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return status;
    }
    
    /**
     * Approves the specified records.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu if null, ALL MUs will be selected
     * @param empid if null, ALL employees will be selected
     * @param startDate the first day in the date range to approve
     * @param endDate the last day in the date range to approve
     * @param approvedBy the AT&T UUID of the user approving the records
     * @param type the type of approval ("EMP", "MU", "PRIOR")
     * @param payrollStart the payroll start date
     * @param coach only approve records with the specified coach; or approve all when null
     * @return true if successful, false otherwise
     */
    public static boolean approveBy(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String approvedBy, String type, Date payrollStart, String coach)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL APPROVAL ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, approvedBy);
            ocs.setString(8, type);
            ocs.setDate(9, Misc.dateToSqlDate(payrollStart));
            ocs.setString(10, coach);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error calling APPROVAL.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any records in the specified selection aren't locked by the user
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param startDate
     * @param endDate
     * @param sbcid
     * @return true if there exist any records not locked by the user, false if all are locked
     */
    public static boolean areAnyRecordsNotLockedBy(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String sbcid)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_RECORDS_NOT_LOCKED ( ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, sbcid);
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking for unlocked records.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any records in the specified selection are locked
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param startDate
     * @param endDate
     * @return true if there exist any locked records in the selection, false otherwise
     */
    public static boolean areAnyRecordsLocked(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_RECORDS_LOCKED ( ?, ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking for locked records.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the user has any records locked by another form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu if null, ALL MUs will be selected
     * @param empid if null, ALL employees will be selected
     * @param startDate the first day in the date range to check
     * @param endDate the last day in the date range to check
     * @param sbcid the user's AT&T UUID
     * @param lockedProcess the type of process being used ("NORMAL", "APPR", "DETAIL", "PRIOR", "CHANGES", "UPDATE")
     * @return true if the user has records locked by another process, false otherwise
     */
    public static boolean areAnyRecordsLockedByAnotherForm(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String sbcid, String lockedProcess)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_RECORDS_LOCKED_OTHER ( ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, sbcid);
            ocs.setString(9, lockedProcess);
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking record locks.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules in the specified selection have a status where they can't be modified.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @return true if any schedules in the selection are restricted, false otherwise
     */
    public static boolean areAnySchedulesRestricted(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_SCHEDULES_RESTRICTED ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule statuses.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules in the specified selection aren't ready for payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @return true if any schedules in the selection are restricted, false otherwise
     */
    public static boolean areAnySchedulesNotReady(Component parentFrame, String feeder, String site, Date endDate)
    {
        Connection c = getConnection();
        boolean output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND REPORTING_DATE >= SYSDATE - 380 "
                             +          " AND REPORTING_DATE <= ? "
                             +          " AND STATUS NOT IN ('Completed', 'Approved')";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setDate(3, Misc.dateToSqlDate(endDate));
            rs = ps.executeQuery();
            
            output = rs.next();
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule statuses.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules in the specified selection have a status other than "Completed", or "Approved".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any schedules in the selection aren't completed, false otherwise
     */
    public static boolean areAnySchedulesNotCompleted(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND REPORTING_DATE >= SYSDATE - 370 "
                             +          " AND STATUS NOT IN ('Completed', 'Approved')";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            
            output = rs.next();
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule statuses.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules in the specified selection have a status of 'Ready to Send'.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any schedules in the selection are ready, false otherwise
     */
    public static boolean areAnySchedulesReady(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND REPORTING_DATE >= SYSDATE - 370 "
                             +          " AND STATUS = 'Ready to Send'";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            
            output = rs.next();
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking schedule statuses.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the total number of rows that will be loaded when opening Time Totals (for progress bar tracking).
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param startDate
     * @param endDate
     * @param process the type of process being used ("NORMAL", "APPR", "DETAIL", "PRIOR", "CHANGES", "UPDATE")
     * @return total number of rows
     */
    public static int getProgressRowCount(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String process)
    {
        Connection c = getConnection();
        int output = 0;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_PROGRESS_ROWCOUNT ( ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, process);
            ocs.execute();
            output = ocs.getInt(1);
        }
        catch (SQLException ex)
        {
            output = 0;
            
            if (ex.getErrorCode() == 20001)
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "Invalid process string, contact TVI Support: " + Constants.EMAIL);
            }
            else
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_PROGRESS_ROWCOUNT.");
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the first existing date for the site (chronologically)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return the earliest schedule date for the site
     */
    public static Date getEarliestScheduleDate(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MIN(REPORTING_DATE) AS MIN_YEAR "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = Misc.stringDateTimeToDateMDY(parentFrame, rs.getString("MIN_YEAR"));
            }
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting earliest schedule of site.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the records to display for a Time Reporting screen with editType = "NORMAL".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper containing array of sql resultsets containing TimeTotals, TimeWorked, TimeAbsences, & ExtraPayments records
     */
    public static ResultSetWrapper getResultsNormal(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsTT = null;
        ResultSet rsTW = null;
        ResultSet rsTA = null;
        ResultSet rsEP = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TIME_REPORTING_NORMAL(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTT = (ResultSet)ocs.getObject(6);
            rsTW = (ResultSet)ocs.getObject(7);
            rsTA = (ResultSet)ocs.getObject(8);
            rsEP = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Normal Time Reporting data.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsTT, rsTW, rsTA, rsEP}, ocs);
    }
    
    /**
     * Gets the records to display for a Time Reporting screen with editType = "BYEMPLOYEE".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper containing array of sql resultsets containing TimeTotals, TimeWorked, TimeAbsences, & ExtraPayments records
     */
    public static ResultSetWrapper getResultsByEmployee(Component parentFrame, String feeder, String site, String empid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsTT = null;
        ResultSet rsTW = null;
        ResultSet rsTA = null;
        ResultSet rsEP = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TIME_REPORTING_BYEMPLOYEE(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTT = (ResultSet)ocs.getObject(6);
            rsTW = (ResultSet)ocs.getObject(7);
            rsTA = (ResultSet)ocs.getObject(8);
            rsEP = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting time reporting by employee records.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsTT, rsTW, rsTA, rsEP}, ocs);
    }
    
    /**
     * Gets the records to display for a Time Reporting screen with editType = "CHANGES".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper containing array of sql resultsets containing TimeTotals, TimeWorked, TimeAbsences, & ExtraPayments records
     */
    public static ResultSetWrapper getResultsChanged(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsTT = null;
        ResultSet rsTW = null;
        ResultSet rsTA = null;
        ResultSet rsEP = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TIME_REPORTING_CHANGED(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTT = (ResultSet)ocs.getObject(5);
            rsTW = (ResultSet)ocs.getObject(6);
            rsTA = (ResultSet)ocs.getObject(7);
            rsEP = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting time reporting changed records.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsTT, rsTW, rsTA, rsEP}, ocs);
    }
    
    /**
     * Gets the records to display for a Time Reporting screen with editType = "PRIOR".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper containing array of sql resultsets containing TimeTotals, TimeWorked, TimeAbsences, & ExtraPayments records
     */
    public static ResultSetWrapper getResultsPrior(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsTT = null;
        ResultSet rsTW = null;
        ResultSet rsTA = null;
        ResultSet rsEP = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TIME_REPORTING_PRIOR(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTT = (ResultSet)ocs.getObject(5);
            rsTW = (ResultSet)ocs.getObject(6);
            rsTA = (ResultSet)ocs.getObject(7);
            rsEP = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Prior Time Reporting data.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsTT, rsTW, rsTA, rsEP}, ocs);
    }
    
    /**
     * Gets the records to display for a Time Reporting screen with editType = "UPDATE".
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu 'ALL' or comma delimited list of MUs
     * @return ResultSetWrapper containing array of sql resultsets containing TimeTotals, TimeWorked, TimeAbsences, & ExtraPayments records
     */
    public static ResultSetWrapper getResultsUpdated(Component parentFrame, String feeder, String site, String mu)
    {
        Connection c = getConnection();
        ResultSet rsTT = null;
        ResultSet rsTW = null;
        ResultSet rsTA = null;
        ResultSet rsEP = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TIME_REPORTING_UPDATES(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTT = (ResultSet)ocs.getObject(4);
            rsTW = (ResultSet)ocs.getObject(5);
            rsTA = (ResultSet)ocs.getObject(6);
            rsEP = (ResultSet)ocs.getObject(7);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Time Reporting updated records.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsTT, rsTW, rsTA, rsEP}, ocs);
    }
    
    /**
     * Gets the records to display for the ImportUpdateMessages screen.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu 'ALL' or comma delimited list of MUs
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMessagesUpdated(Component parentFrame, String feeder, String site, String mu)
    {
        Connection c = getConnection();
        ResultSet rsMsg = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_UPDATED_MESSAGES(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsMsg = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting update messages.");
        }
        return new ResultSetWrapper(rsMsg, ocs);
    }
    
    /**
     * Gets the employees to display for the AddEmployees screen.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAddEmployees(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ADD_EMPLOYEES(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet) ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting add employees data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the WeeklyScheduleHoursCheck form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @param hours
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHoursCheck(Component parentFrame, String feeder, String site, Date endDate, String hours)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_HOURS_CHECK(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.setString(4, hours);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting HoursCheck data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the WeeklyScheduleHoursCheck form for the INFOR client.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @param hours
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHoursCheckInfor(Component parentFrame, String feeder, String site, Date endDate, String hours)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_HOURS_CHECK_INFOR(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.setString(4, hours);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting HoursCheck data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the WeeklyTimecodeMinutesCheck form for the INFOR client.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @param empid
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsTimecodeCheck(Component parentFrame, String feeder, String site, Date endDate, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_CHECK_TIMECODE_MINUTES(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Timecode Discrepancies Data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the WeeklyScheduleHoursCheck form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHoursCheckMex(Component parentFrame, String feeder, String site, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_HOURS_CHECK_MEX(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting HoursCheck data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of employees with records since the specified reportingDate to display in the TimeReportingByEmployee employee selection table.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCurrentEmployees(Component parentFrame, String feeder, String site, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_CURRENT_EMPLOYEES(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting current employees data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of employees with records since the specified reportingDate to display in the AddRecords employee selection table.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAddRecords(Component parentFrame, String feeder, String site, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ADD_RECORDS(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting AddRecords data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the EmployeeMaintenance screen.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEmployeeMaintenance(Component parentFrame, String feeder, String site, String empid)
    {
        Connection c = getConnection();
        ResultSet rsEmployees = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EMPLOYEE_MAINTENANCE(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.setFetchSize(1000);
            ocs.execute();
            rsEmployees = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting employee maintenance records.");
        }
        return new ResultSetWrapper(rsEmployees, ocs);
    }
    
    /**
     * Gets the records to display for the EmployeeMaintenance screen in INFOR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEmployeeMaintenanceINFOR(Component parentFrame, String feeder, String site, String empid)
    {
        Connection c = getConnection();
        ResultSet rsEmployees = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EMP_MAINTENANCE_INFOR(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.setFetchSize(1000);
            ocs.execute();
            rsEmployees = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EMP_MAINTENANCE_INFOR.");
        }
        return new ResultSetWrapper(rsEmployees, ocs);
    }
    
    /**
     * Gets the records to display for the MURosterMaintenance screen in INFOR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMURosterMaintenance(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rsEmployees = null;
        ResultSet rsMURoster = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_MU_ROSTER_MAINTENANCE(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.setFetchSize(1000);
            ocs.execute();
            rsEmployees = (ResultSet) ocs.getObject(3);
            rsMURoster = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_MU_ROSTER_MAINTENANCE.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsEmployees, rsMURoster}, ocs);
    }
    
    /**
     * Gets the records to display for the MURosterErrors screen in INFOR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMURosterErrorsINFOR(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rsMURoster = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_MU_ROSTER_ERROR_INFOR(?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.setFetchSize(1000);
            ocs.execute();
            rsMURoster = (ResultSet) ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_MU_ROSTER_ERROR_INFOR.");
        }
        return new ResultSetWrapper (rsMURoster, ocs);
    }
    
    /**
     * Gets the DWS value from the database for the specified time totals record.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param reportingDate
     * @return DWS value
     */
    public static String getTimeTotalsDWS(Component parentFrame, String feeder, String site, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        String output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DWS "
                             +    " FROM TIME_TOTALS_MASTER "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND EMPID = ? "
                             +          " AND REPORTING_DATE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, empid);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getString("DWS");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking DWS value.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Approves the changes made in TVI for the specified selection.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param startDate the first day in the date range to be approved
     * @param endDate the last day in the date range to be approved
     * @param approvedBy the approving user's AT&T UUID
     * @param type the approval type: "EMP" or "ALL"
     * @return true if successful, false otherwise
     */
    public static boolean approveChanges(Component parentFrame, String feeder, String site, String empid, Date startDate, Date endDate, String approvedBy, String type)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL APPROVAL_CHANGES ( ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.setString(6, approvedBy);
            ocs.setString(7, type);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error calling APPROVAL_CHANGES.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the training class resultset.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param sbcid AT&T UUID of the user opening the screen
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getTrainingClasses(Component parentFrame, String feeder, String sbcid)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TRAINING_CLASSES(?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, feeder);
            ocs.setString(2, sbcid);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting training class data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Signs up a user for the specified training class.
     * 
     * @param parentFrame the frame to center messages on
     * @param meetingID the training class to sign the user up for
     * @param sbcidAttendee the user to sign up for the class
     * @param sbcid the user submitting the change
     * @return true if successful, false otherwise
     */
    public static boolean trainingSignUp(Component parentFrame, int meetingID, String sbcidAttendee, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TRAINING_SIGNUP(?, ?, ?) }");
            ocs.setInt(1, meetingID);
            ocs.setString(2, sbcidAttendee);
            ocs.setString(3, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "Training Classes", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error signing up for class.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Removes a user from the specified training class.
     * 
     * @param parentFrame the frame to center messages on
     * @param meetingID the training class to remove the user from
     * @param sbcidAttendee the user to remove from the class
     * @return true if successful, false otherwise
     */
    public static boolean trainingDropOut(Component parentFrame, int meetingID, String sbcidAttendee)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TRAINING_DROPOUT(?, ?) }");
            ocs.setInt(1, meetingID);
            ocs.setString(2, sbcidAttendee);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error dropping user out of class.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the next meeting ID (incremental index) from the database.
     * 
     * @param parentFrame the frame to center messages on
     * @return the next meeting ID integer, or -1 if an error occurred
     */
    public static int getNextMeetingID(Component parentFrame)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MAX(MEETING_ID) AS MAX_ID "
                             +    " FROM TRAINING_CLASSES";
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                if (rs.getObject("MAX_ID") == null)
                {
                    output = 1;
                }
                else
                {
                    output = Integer.parseInt(rs.getObject("MAX_ID").toString()) + 1;
                }
            }
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting next MEETING_ID number.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Creates a new training class with the specified settings.
     * 
     * @param parentFrame the frame to center messages on
     * @param meetingID the training class meetingID to update
     * @param title the new TITLE value
     * @param description the new DESCRIPTION value
     * @param feeder the new FEEDER value
     * @param startTime the new START_TIME value
     * @param duration the new DURATION_MINUTES value
     * @param slotsAvailable the new NUMBER_OF_SLOTS value
     * @return true if successful, false otherwise
     */
    public static boolean addTrainingClass(Component parentFrame, int meetingID, String title, String description, String feeder, Date startTime, int duration, int slotsAvailable)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "INSERT INTO TRAINING_CLASSES "
                             + " ( "
                             +     " MEETING_ID, "
                             +     " TITLE, "
                             +     " DESCRIPTION, "
                             +     " FEEDER, "
                             +     " START_TIME, "
                             +     " DURATION_MINUTES, "
                             +     " NUMBER_OF_SLOTS "
                             + " ) "
                             + " VALUES (?, ?, ?, ?, ?, ?, ?)";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, meetingID);
            ps.setString(2, title);
            ps.setString(3, description);
            ps.setString(4, feeder);
            ps.setTimestamp(5, Misc.dateToTimestamp(startTime));
            ps.setInt(6, duration);
            ps.setInt(7, slotsAvailable);
            rs = ps.executeQuery();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error adding new class.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Updates details for the specified training class.
     * 
     * @param parentFrame the frame to center messages on
     * @param meetingID
     * @param title
     * @param description
     * @param feeder
     * @param startTime
     * @param duration
     * @param slotsAvailable
     * @return true if successful, false otherwise
     */
    public static boolean updateTrainingClass(Component parentFrame, int meetingID, String title, String description, String feeder, Date startTime, int duration, int slotsAvailable)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TRAINING_CLASSES "
                             +    " SET TITLE = ?, "
                             +      " DESCRIPTION = ?, "
                             +      " FEEDER = ?, "
                             +      " START_TIME = ?, "
                             +      " DURATION_MINUTES = ?, "
                             +      " NUMBER_OF_SLOTS = ? "
                             +        " WHERE MEETING_ID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setString(3, feeder);
            ps.setTimestamp(4, Misc.dateToTimestamp(startTime));
            ps.setInt(5, duration);
            ps.setInt(6, slotsAvailable);
            ps.setInt(7, meetingID);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating class.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the start date of the payroll period that contains the specified date
     * 
     * @param parentFrame the frame to center messages on
     * @param payCycle
     * @param scheduleDate
     * @return the payroll start date
     */
    public static Date getPayrollStartDate(Component parentFrame, String payCycle, Date scheduleDate)
    {
        Connection c = getConnection();
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MAX(PAYROLL_CLOSE) + 1 AS STARTDATE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_CLOSE < ? "
                             +          " AND PAYROLL_GROUP = ?";
            ps = c.prepareStatement(sqlString);
            ps.setDate(1, Misc.dateToSqlDate(scheduleDate));
            ps.setString(2, payCycle);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getDate("STARTDATE");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting payroll start date.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the end date of the payroll period that contains the specified date.
     * 
     * @param parentFrame the frame to center messages on
     * @param payCycle
     * @param scheduleDate
     * @return the payroll end date
     */
    public static Date getPayrollEndDate(Component parentFrame, String payCycle, Date scheduleDate)
    {
        Connection c = getConnection();
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MIN(PAYROLL_CLOSE) AS ENDDATE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_CLOSE >= ? "
                             +          " AND PAYROLL_GROUP = ?";
            ps = c.prepareStatement(sqlString);
            ps.setDate(1, Misc.dateToSqlDate(scheduleDate));
            ps.setString(2, payCycle);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getDate("ENDDATE");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting payroll end date.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the end date of the payroll period that follows the given end date.
     * 
     * @param parentFrame the frame to center messages on
     * @param payCycle
     * @param endDate the payroll end date that precedes the desired one
     * @return the next payroll end date
     */
    public static Date getNextPayrollEndDate(Component parentFrame, String payCycle, Date endDate)
    {
        Connection c = getConnection();
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MIN(PAYROLL_CLOSE) AS NEXT_ENDDATE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_CLOSE > ? "
                             +          " AND PAYROLL_GROUP = ?";
            ps = c.prepareStatement(sqlString);
            ps.setDate(1, Misc.dateToSqlDate(endDate));
            ps.setString(2, payCycle);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getDate("NEXT_ENDDATE");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting payroll end date.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the start date of the payroll period that precedes the payroll period containing the specified date.
     * 
     * @param parentFrame the frame to center messages on
     * @param payCycle
     * @param scheduleDate
     * @return the previous payroll start date
     */
    public static Date getPreviousPayrollStartDate(Component parentFrame, String payCycle, Date scheduleDate)
    {
        return getPayrollStartDate(parentFrame, payCycle, getPreviousPayrollEndDate(parentFrame, payCycle, scheduleDate));
    }
    
    /**
     * Gets the end date of the pay period that precedes the payroll period containing the specified date.
     * 
     * @param parentFrame the frame to center messages on
     * @param payCycle
     * @param scheduleDate
     * @return the previous payroll end date
     */
    public static Date getPreviousPayrollEndDate(Component parentFrame, String payCycle, Date scheduleDate)
    {
        Connection c = getConnection();
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT MAX(PAYROLL_CLOSE) AS PREV_ENDDATE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_CLOSE < ? "
                             +          " AND PAYROLL_GROUP = ?";
            ps = c.prepareStatement(sqlString);
            ps.setDate(1, Misc.dateToSqlDate(scheduleDate));
            ps.setString(2, payCycle);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getDate("PREV_ENDDATE");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting previous payroll end date.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Populates the specified pickdate with a list of payroll end dates.
     * 
     * @param parentFrame the frame to center messages on
     * @param pickDate the JComboBox to populate
     * @param payCycle
     * @param nextPayClose
     * @param weeksBack the number of weeks to include in list of pay close dates
     */
    public static void setupPickEndDate(Component parentFrame, JComboBox<String> pickDate, String payCycle, Date nextPayClose, int weeksBack)
    {
        Connection c = getConnection();
        pickDate.setEnabled(false);//can add a check in ActionPerformed to prevent unwanted events
        java.sql.Date sqlDate = Misc.dateToSqlDate(nextPayClose);
        int daysBack = weeksBack * 7 + 15;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT PAYROLL_CLOSE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_GROUP = ? "
                             +          " AND PAYROLL_CLOSE > ? - ? "
                             +          " AND PAYROLL_CLOSE <= ? "
                             +        " ORDER BY PAYROLL_CLOSE DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, payCycle);
            ps.setDate(2, sqlDate);
            ps.setInt(3, daysBack);
            ps.setDate(4, sqlDate);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                pickDate.addItem(Misc.dateToStringMDY(rs.getDate("PAYROLL_CLOSE")));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating payroll end date pick list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        pickDate.setSelectedIndex(1);
        pickDate.setEnabled(true);
    }
    
    /**
     * Populates the specified pickdate with a list of payroll start dates.
     * 
     * @param parentFrame the frame to center messages on
     * @param pickDate the JComboBox to populate
     * @param payCycle
     * @param payClose
     * @param weeksBack the number of weeks to include in list of payroll start dates
     */
    public static void setupPickStartDate(Component parentFrame, JComboBox<String> pickDate, String payCycle, Date payClose, int weeksBack)
    {
        Connection c = getConnection();
        pickDate.setEnabled(false);//can add a check in ActionPerformed to prevent unwanted events
        java.sql.Date sqlDate = Misc.dateToSqlDate(payClose);
        int daysBack = weeksBack * 7 + 15;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT PAYROLL_CLOSE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_GROUP = ? "
                             +          " AND PAYROLL_CLOSE > ? - ? "
                             +          " AND PAYROLL_CLOSE <= ? "
                             +        " ORDER BY PAYROLL_CLOSE DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, payCycle);
            ps.setDate(2, sqlDate);
            ps.setInt(3, daysBack);
            ps.setDate(4, sqlDate);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                pickDate.addItem(Misc.dateToStringMDY(Misc.dateAddDays(rs.getDate("PAYROLL_CLOSE"), 1)));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating payroll start date pick list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        pickDate.setSelectedIndex(1);
        pickDate.setEnabled(true);
    }
    
    /**
     * Populates the specified pickdate with a list of month end dates.
     * Only works for feeders with monthly pay cycles.
     * 
     * @param parentFrame the frame to center messages on
     * @param pickDate the JComboBox to populate
     * @param payCycle
     * @param payClose
     * @param includeCurrent includes the current month if true, otherwise excludes
     */
    public static void setupPickMonth(Component parentFrame, JComboBox<String> pickDate, String payCycle, Date payClose, boolean includeCurrent)
    {
        Connection c = getConnection();
        pickDate.setEnabled(false);//can add a check in ActionPerformed to prevent unwanted events
        java.sql.Date sqlDate;
        Date reportingDate = payClose;
        if (!includeCurrent)
        {
            reportingDate = getPreviousPayrollEndDate(parentFrame, payCycle, reportingDate);
        }
        sqlDate = Misc.dateToSqlDate(reportingDate);
        int daysBack = 380;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT PAYROLL_CLOSE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_GROUP = ? "
                             +          " AND PAYROLL_CLOSE > ? - ? "
                             +          " AND PAYROLL_CLOSE <= ? "
                             +        " ORDER BY PAYROLL_CLOSE DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, payCycle);
            ps.setDate(2, sqlDate);
            ps.setInt(3, daysBack);
            ps.setDate(4, sqlDate);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                pickDate.addItem(Misc.dateToStringMDY(rs.getDate("PAYROLL_CLOSE")));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating month pick list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        pickDate.setSelectedIndex(0);
        pickDate.setEnabled(true);
    }
    
    /**
     * Populates the specified pickdate with a list of month start dates.
     * Only works for feeders with monthly pay cycles.
     * 
     * @param parentFrame the frame to center messages on
     * @param pickDate the JComboBox to populate
     * @param payCycle
     * @param payClose
     * @param includeCurrent includes the current month if true, otherwise excludes
     */
    public static void setupPickMonthStart(Component parentFrame, JComboBox<String> pickDate, String payCycle, Date payClose, boolean includeCurrent)
    {
        Connection c = getConnection();
        pickDate.setEnabled(false);//can add a check in ActionPerformed to prevent unwanted events
        java.sql.Date sqlDate;
        Date reportingDate = payClose;
        if (!includeCurrent)
        {
            reportingDate = getPreviousPayrollEndDate(parentFrame, payCycle, reportingDate);
        }
        sqlDate = Misc.dateToSqlDate(reportingDate);
        int daysBack = 380;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT PAYROLL_CLOSE "
                             +    " FROM TVI_PAYROLL_CLOSE_DATES "
                             +        " WHERE PAYROLL_GROUP = ? "
                             +          " AND PAYROLL_CLOSE > ? - ? "
                             +          " AND PAYROLL_CLOSE <= ? "
                             +        " ORDER BY PAYROLL_CLOSE DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, payCycle);
            ps.setDate(2, sqlDate);
            ps.setInt(3, daysBack);
            ps.setDate(4, sqlDate);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                pickDate.addItem(Misc.dateToStringMDY(Misc.dateAddDays(rs.getDate("PAYROLL_CLOSE"), 1)));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating month pick list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        pickDate.setSelectedIndex(0);
        pickDate.setEnabled(true);
    }
    
    /**
     * Populates the specified combobox with a list of MUs.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param combobox the JComboBox to populate
     */
    public static void setupPickMU(Component parentFrame, String feeder, String site, JComboBox<String> combobox)
    {
        Connection c = getConnection();
        combobox.setEnabled(false);//can add a check in ActionPerformed to prevent unwanted events
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DISTINCT MU "
                             +    " FROM SCHEDULES "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND REPORTING_DATE >= SYSDATE - 380 "
                             +        " ORDER BY MU";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                combobox.addItem(rs.getString("MU"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error creating MU pick list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        combobox.setSelectedIndex(0);
        combobox.setEnabled(true);
    }
    
    /**
     * Sets the user's preferred default feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the user's AT&T UUID
     * @param feeder
     * @return true if successful, false otherwise
     */
    public static boolean setDefaultFeeder(Component parentFrame, String sbcid, String feeder)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS "
                             +    " SET DEFAULT_FEEDER = ? "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, sbcid);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error setting default feeder.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the user's preferred default feeder
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the AT&T UUID of the user
     * @return the user's default feeder
     */
    public static String getDefaultFeeder(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DEFAULT_FEEDER "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getString("DEFAULT_FEEDER");
            if (output == null)
            {
                output = "";
            }
        }
        catch (SQLException ex)
        {
            output = "";
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting default feeder.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the user's preferred default site
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the AT&T UUID of the user
     * @return the user's default site
     */
    public static String getDefaultSite(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT DEFAULT_SITE "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            
            rs = ps.executeQuery();
            rs.next();
            output = rs.getString("DEFAULT_SITE");
            if (output == null)
            {
                output = "";
            }
        }
        catch (SQLException ex)
        {
            output = "";
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting default site.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the user's NO_FULLSCREEN preference setting.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid the AT&T UUID of the user
     * @return boolean, true if the user wants no fullscreen windows, false otherwise.
     */
    public static boolean getNoFullscreen(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT NO_FULLSCREEN "
                             +    " FROM USERS "
                             +        " WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            
            rs = ps.executeQuery();
            rs.next();
            output = Misc.oracleToBoolean(rs.getInt("NO_FULLSCREEN"));
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting user fullscreen preference.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks to make sure no future schedules exist that need to be updated.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate the first day in the date range to check
     * @param endDate the last day in the date range to check
     * @return true if all future schedules are updated, false otherwise
     */
    public static boolean checkFutureSchedulesUpdated(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_FUTURE_SCHEDULES_UPDATED ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_FUTURE_SCHEDULES_UPDATED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if all current payroll period records have been approved.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate
     * @param endDate
     * @return true if all current payroll period records are approved, false otherwise
     */
    public static boolean checkCurrentApproved(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_CURRENT_APPROVED ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_CURRENT_APPROVED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if all prior payroll period records have been approved.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate
     * @return true if all prior records are approved, false otherwise
     */
    public static boolean checkPriorApproved(Component parentFrame, String feeder, String site, Date startDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_PRIOR_APPROVED ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_PRIOR_APPROVED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Attempts to lock the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param lockedType the type of lock to set {"PAY PERIOD", "COMPUTE 40", "COMPUTE FUTURE", "ADDING RECORDS"}
     * @return true if successful, false otherwise
     */
    public static boolean setSiteLocked(Component parentFrame, String feeder, String site, String lockedType)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_SITE_LOCKED ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, lockedType);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SET_SITE_LOCKED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Attempts to unlock the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if successful, false otherwise
     */
    public static boolean setSiteUnlocked(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_SITE_UNLOCKED ( ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SET_SITE_UNLOCKED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Imports updates for the specified prior future schedules.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param uuid
     * @return true if successful, false otherwise
     */
    public static boolean updatePriorFutureSchedules(Component parentFrame, String feeder, String site, Date startDate, Date endDate, String uuid)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := UPDATE_PRIOR_FUTURE_SCHEDULES ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.setString(6, uuid);
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_PRIOR_FUTURE_SCHEDULES.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates the Saturday/Sunday importing rules for the specified MU.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param importSaturdays
     * @param importSundays
     * @return true if successful, false otherwise
     */
    public static boolean updateWeekendImportingRules(Component parentFrame, String feeder, String site, String mu, boolean importSaturdays, boolean importSundays)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE MU SET IMPORT_FUTURE_SATURDAYS = ?, IMPORT_FUTURE_SUNDAYS = ?"
                             + " WHERE FEEDER = ?"
                             + " AND SITE = ?"
                             + " AND MU = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(importSaturdays));
            ps.setInt(2, Misc.booleanToOracle(importSundays));
            ps.setString(3, feeder);
            ps.setString(4, site);
            ps.setString(5, mu);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating weekend importing rules.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the MU importing options for the specified MU.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param autoImport
     * @param skipReviewUpdates
     * @return true if successful, false otherwise
     */
    public static boolean updateImportingOptions(Component parentFrame, String feeder, String site, String mu, boolean autoImport, boolean skipReviewUpdates)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE MU SET AUTO_IMPORT = ?, SKIP_REVIEW_UPDATES = ?"
                             + " WHERE FEEDER = ?"
                             + " AND SITE = ?"
                             + " AND MU = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(autoImport));
            ps.setInt(2, Misc.booleanToOracle(skipReviewUpdates));
            ps.setString(3, feeder);
            ps.setString(4, site);
            ps.setString(5, mu);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating MU importing options.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Checks if the employee has a record in the specified schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if schedule exists, false otherwise
     */
    public static boolean doesScheduleExist(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM SCHEDULES"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND MU = ?"
                             +      " AND REPORTING_DATE = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if employee exists in schedule.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if the employee has a record in the specified schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if employee exists in schedule, false otherwise
     */
    public static boolean isEmployeeInSchedule(Component parentFrame, String empid, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM TIME_TOTALS_MASTER"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND MU = ?"
                             +      " AND REPORTING_DATE = ?"
                             +      " AND EMPID = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            ps.setString(5, empid);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if employee exists in schedule.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the total number of OFF days that an employee has in the given week so far.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param startDate
     * @param endDate
     * @return total number of OFF days so far in the week
     */
    public static int getNumOffDaysInWeek(Component parentFrame, String feeder, String site, String empid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM TIME_TOTALS_MASTER"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND EMPID = ?"
                             +      " AND REPORTING_DATE >= ?"
                             +      " AND REPORTING_DATE <= ?"
                             +      " AND DWS = 'OFF'";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, empid);
            ps.setDate(4, Misc.dateToSqlDate(startDate));
            ps.setDate(5, Misc.dateToSqlDate(endDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getInt("COUNT(*)");
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting OFF day count for employee.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Updates the TimeTotals message for the given employee and date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param reportingDate
     * @param message
     * @return true if successful, false otherwise
     */
    public static boolean setTimeTotalsMessage(Component parentFrame, String feeder, String site, String empid, Date reportingDate, String message)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TIME_TOTALS_MASTER"
                             +    " SET MESSAGE = ?"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND EMPID = ?"
                             +      " AND REPORTING_DATE = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, message);
            ps.setString(2, feeder);
            ps.setString(3, site);
            ps.setString(4, empid);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating TimeTotals message.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the list of supervisors for the specified time and region.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param startDate
     * @param endDate
     * @return ArrayList<String> of supervisors
     */
    public static ArrayList<String> getSupervisors(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ArrayList<String> supList = new ArrayList<>();
        CallableStatement ocs = null;
        ResultSet rs = null;
        String requestType;
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_SUPERVISORS_LIST(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setString(5, requestType);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(8);
            
            while (rs.next())
            {
                supList.add(rs.getString("COACH"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting supervisors list.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
            closeCursors(parentFrame, null, rs);
        }
        
        return supList;
    }
    
    /**
     * Gets the list of employees that report to the specified supervisor for the indicated region and time (also can be from a specified list of employees)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param supervisor
     * @param startDate
     * @param endDate
     * @return ArrayList<String> of employees
     */
    public static ArrayList<String> getEmployeesBySupervisor(Component parentFrame, String feeder, String site, String mu, List<String> empList, String supervisor, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ArrayList<String> supEmpList = new ArrayList<>();
        CallableStatement ocs = null;
        ResultSet rs = null;
        String requestType;
        
        if (empList.size() > 0)
        {
            requestType = "Emp";
        }
        else
        {
            requestType = "MU";
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL GET_EMPLOYEES_BY_SUPERVISOR(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setString(5, requestType);
            ocs.setString(6, supervisor);
            ocs.setDate(7, Misc.dateToSqlDate(startDate));
            ocs.setDate(8, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
            
            while (rs.next())
            {
                supEmpList.add(rs.getString("EMPID"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_EMPLOYEES_BY_SUPERVISOR.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
            closeCursors(parentFrame, null, rs);
        }
        
        return supEmpList;
    }
    
    /**
     * @param parentFrame the frame to center messages on
     * @param sbcid UUID of the user generating the reports
     * @param sendTo UUID of the supervisor to send the email to
     * @param fileToWrite filename to upload so it can be attached
     * @param timestamp datetime string formatted as "yyyyMMddHHmmssSSS"
     * @param index report number
     * @return true if successful, false otherwise
     */
    public static boolean uploadEmailAttachmentToServer(Component parentFrame, String sbcid, String sendTo, String fileToWrite, String timestamp, int index)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sql = "INSERT INTO TVI_EMAIL_ATTACHMENTS (SBCID, TO_ADDR, FILE_BLOB, DATE_TIME_STAMP, FILE_INDEX) VALUES (?, ?, ?, ?, ?)";
            ps = c.prepareStatement(sql);
            ps.setString(1, sbcid);
            ps.setString(2, sendTo);
            File image = new File(fileToWrite);
            try (InputStream fis = new FileInputStream(image))
            {
                int ilen = (int) image.length();
                ps.setBinaryStream(3, fis, ilen); //Sets the FILE_BLOB parameter to use the input stream
                ps.setString(4, timestamp);
                ps.setString(5, Integer.toString(index));
                ps.execute();
                
                c.commit();
            }
        }
        catch (IOException ex)
        {
            output = false;
            Misc.errorMsgDefault(parentFrame, ex);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error while uploading file to server.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Writes the temporary blob in the TVI_EMAIL_ATTACHMENTS table to file
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid UUID of the user generating the reports
     * @param sendTo UUID of the supervisor to send the email to
     * @param timestamp datetime string formatted as "yyyyMMddHHmmssSSS"
     * @param index report number
     * @param filename string to name the written file
     * @return true if successful, false otherwise
     */
    public static boolean writeFileToServer(Component parentFrame, String sbcid, String sendTo, String timestamp, int index, String filename)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL WRITE_BLOB_TO_FILE ( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, sbcid);
            ocs.setString(2, sendTo);
            ocs.setString(3, timestamp);
            ocs.setString(4, Integer.toString(index));
            ocs.setString(5, filename);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to WRITE_BLOB_TO_FILE.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Sends an email to the given supervisor with the specified subject, body, and attachment(s)
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid UUID of the user generating the reports
     * @param sendTo UUID of the supervisor to send the email to
     * @param subject email subject line
     * @param body email body text
     * @param timestamp datetime string formatted as "yyyyMMddHHmmssSSS"
     * @param numAttachments number of attachments to include (for now, this is always only 1)
     * @param filename name of the attachment
     * @param noReply if true, will send email from No-Reply; else from sbcid@att.com
     * @return true if successful, false otherwise
     */
    public static boolean sendEmailWithAttachments(Component parentFrame, String sbcid, String sendTo, String subject, String body, String timestamp, int numAttachments, String filename, boolean noReply)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SEND_EMAIL_WITH_ATTACHMENT ( ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, sbcid);
            ocs.setString(2, subject);
            ocs.setString(3, sendTo);
            ocs.setString(4, body);
            ocs.setString(5, timestamp);
            ocs.setString(6, Integer.toString(numAttachments));
            ocs.setString(7, filename);
            ocs.setInt(8, Misc.booleanToOracle(noReply));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SEND_EMAIL_WITH_ATTACHMENT.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the list of MUs for the specified feeder, site, and time frame
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ArrayList<String> of MUs
     */
    public static ArrayList<String> getMUList(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ArrayList<String> muList = new ArrayList<>();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_MU_LIST(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
            
            while (rs.next())
            {
                muList.add(rs.getString("MU"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU list data.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
            closeCursors(parentFrame, null, rs);
        }
        
        return muList;
    }
    
    /**
     * Gets the list of Employees for the specified feeder, site, mu, and time frame
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu can pass null or "ALL" for all MUs
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getEmpList(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EMPLOYEE_LIST(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting employee list data.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display for the configuration screen.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsConfiguration(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_CONFIGURATION(?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_CONFIGURATION.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of cost centers for the specified feeder & site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCostCenters(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_COST_CENTERS(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_COST_CENTERS.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of comments for the specified feeder & site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsComments(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_COMMENTS(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_COMMENTS.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of employees for the disabilty report form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsDisabilityReport(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL GET_DISABILITY_REPORT_RS(?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_DISABILITY_REPORT_RS.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of eLink errors from the last send.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsElinkErrors(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ELINK_ERRORS(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_ELINK_ERRORS.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the list of users enrolled for the given meeting ID.
     * If sbcid is passed, will return the list users that individual has enrolled.
     * 
     * @param parentFrame the frame to center messages on
     * @param meetingID
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEnrolledUsers(Component parentFrame, int meetingID, String sbcid) //DYADD change to procedure call to avoid dynamic sqlString creation risks?
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT * FROM TRAINING_SIGNUPS "
                      +     " WHERE MEETING_ID = ? ";
            if (sbcid != null)
            {
                sqlString +=  " AND SBCID = ? ";
            }
            sqlString +=    " ORDER BY SIGNUP_DATE";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, meetingID);
            if (sbcid != null)
            {
                ps.setString(2, sbcid);
            }
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Enrolled Users.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the start and stop times for the specified shift.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param recordType "Prior" or other for current
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsStartStops(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, String recordType)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_START_STOP_TIMES(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, recordType);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(7);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting start stop times.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the schedules for the specified feeder & site of the given type.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param daysBack only used when fetching approved schedules
     * @param scheduleType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSchedules(Component parentFrame, String feeder, String site, int daysBack, String scheduleType)
    {
        Connection c = getConnection();
        ResultSet rsSchedules = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULES(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, daysBack);
            ocs.setString(4, scheduleType);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsSchedules = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Schedules data.");
        }
        return new ResultSetWrapper(rsSchedules, ocs);
    }
    
    /**
     * Gets the schedules for the specified feeder & site of the given type for the ELINK client.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param daysBack only used when fetching approved schedules
     * @param scheduleType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSchedulesElink(Component parentFrame, String feeder, String site, int daysBack, String scheduleType)
    {
        Connection c = getConnection();
        ResultSet rsSchedules = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULES_ELINK(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, daysBack);
            ocs.setString(4, scheduleType);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsSchedules = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_SCHEDULES_ELINK.");
        }
        return new ResultSetWrapper(rsSchedules, ocs);
    }
    
    /**
     * Gets the schedules for the specified feeder & site of the given type for the INFOR client.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param daysBack only used when fetching completed schedules
     * @param scheduleType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSchedulesInfor(Component parentFrame, String feeder, String site, int daysBack, String scheduleType)
    {
        Connection c = getConnection();
        ResultSet rsSchedules = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULES_INFOR(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, daysBack);
            ocs.setString(4, scheduleType);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsSchedules = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting schedule records.");
        }
        return new ResultSetWrapper(rsSchedules, ocs);
    }
    
    /**
     * Gets the list of employees given night shift differentials for a schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param weekStartDate
     * @param weekEndDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsImport3DayNightDiff(Component parentFrame, String feeder, String site, String mu, Date weekStartDate, Date weekEndDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT MU, (EMPID || ' - ' || EMPLOYEE) AS EMPLOYEE, REPORTING_DATE, STATUS "
                      +     " FROM TIME_TOTALS_MASTER "
                      +         " WHERE FEEDER = ? "
                      +           " AND SITE = ? "
                      +           " AND MU = ? "
                      +           " AND REPORTING_DATE >= ? "
                      +           " AND REPORTING_DATE <= ? "
                      +           " AND DIFF_SOURCE = 4 "
                      +         " ORDER BY EMPLOYEE, REPORTING_DATE";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(weekStartDate));
            ps.setDate(5, Misc.dateToSqlDate(weekEndDate));
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting night differential employees.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of duplicate employees for a schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsImportDuplicateEmployees(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT EMPID, EMPLOYEE "
                      +    " FROM TIME_TOTALS_MASTER "
                      +        " WHERE FEEDER = ? "
                      +          " AND SITE = ? "
                      +          " AND MU = ? "
                      +          " AND REPORTING_DATE = ? "
                      +          " AND LOAD_STATUS = 5 "
                      +        " ORDER BY EMPLOYEE";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting duplicate employees.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of inactive employees for a schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsImportInactiveEmployees(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        java.sql.Timestamp loadDateTime = null;
        try
        {
            sqlString = "SELECT LOAD_DATE_TIME "
                      +    " FROM SCHEDULES "
                      +        " WHERE FEEDER = ? "
                      +          " AND SITE = ? "
                      +          " AND MU = ? "
                      +          " AND REPORTING_DATE = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
            if (rs.next())
            {
                loadDateTime = rs.getTimestamp("LOAD_DATE_TIME");
            }
            closeCursors(parentFrame, ps, rs);
            
            sqlString = "SELECT PROGRAM AS AGENTID, PROCESS AS EMPLOYEE, PROCESS_INFO "
                      +    " FROM PROCESS_USER_LOG "
                      +        " WHERE FEEDER = ? "
                      +          " AND SITE = ?"
                      +          " AND MU = ? "
                      +          " AND REPORTING_DATE = ? "
                      +          " AND PROGRAM_START = ? "
                      +          " AND ERROR_CODE = 3 "
                      +        " ORDER BY EMPLOYEE";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            ps.setTimestamp(5, loadDateTime);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting inactive employees.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of off days created by TVI for a schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param weekStartDate
     * @param weekEndDate
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsImportOffDays(Component parentFrame, String feeder, String site, String mu, Date weekStartDate, Date weekEndDate, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT A.EMPLOYEE, A.EMPID, A.AGENTID, NVL(B.NUMOFFDAYS, 0) AS NUMOFF, '' STATUS "
                      +    " FROM TIME_TOTALS_MASTER A "
                      + " LEFT JOIN "
                      + " ( "
                      +     " SELECT EMPID, COUNT(*) AS NUMOFFDAYS "
                      +         " FROM TIME_TOTALS_MASTER "
                      +             " WHERE FEEDER = ? "
                      +               " AND SITE = ? "
                      +               " AND MU = ? "
                      +               " AND REPORTING_DATE >= ? "
                      +               " AND REPORTING_DATE <= ? "
                      +               " AND REPORTING_DATE <> ? "
                      +               " AND SHIFT = 0 "
                      +             " GROUP BY EMPID "
                      + " ) B ON A.EMPID = B.EMPID "
                      +     " WHERE A.FEEDER = ? "
                      +       " AND A.SITE = ? "
                      +       " AND A.MU = ? "
                      +       " AND A.REPORTING_DATE = ? "
                      +       " AND LOAD_STATUS = 4 "
                      +     " ORDER BY NUMOFF DESC, A.EMPLOYEE ASC";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(weekStartDate));
            ps.setDate(5, Misc.dateToSqlDate(weekEndDate));
            ps.setDate(6, Misc.dateToSqlDate(reportingDate));
            ps.setString(7, feeder);
            ps.setString(8, site);
            ps.setString(9, mu);
            ps.setDate(10, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting generated OFF days.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of MUs and future import settings for the given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsFutureImportSettings(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT MU, IMPORT_FUTURE_SATURDAYS, IMPORT_FUTURE_SUNDAYS "
                      +    " FROM MU "
                      +        " WHERE FEEDER = ? "
                      +          " AND SITE = ? "
                      +          " AND VALIDATED = -1 "
                      +          " AND IS_ALPHA(SUBSTR(MU, 1, 1)) <> -1 "
                      +        " ORDER BY TO_NUMBER(MU)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting future import mu list.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets the list of MUs and import options for the given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsImportOptions(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT MU, AUTO_IMPORT, SKIP_REVIEW_UPDATES "
                      +    " FROM MU "
                      +        " WHERE FEEDER = ? "
                      +          " AND SITE = ? "
                      +          " AND VALIDATED = -1 "
                      +          " AND IS_ALPHA(SUBSTR(MU, 1, 1)) <> -1 "
                      +        " ORDER BY TO_NUMBER(MU)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU import options.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Updates the employees coaches to match the stored webphone supervisor value.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList list of empids; if null is passed, all employees on the given site and feeder will be updated
     * @return true if successful, false otherwise
     */
    public static boolean updateCoaches(Component parentFrame, String feeder, String site, ArrayList<String> empList)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        
        String empListCSV;
        if (empList == null)
        {
            empListCSV = "ALL";
        }
        else
        {
            empListCSV = Misc.listToStringCSV(empList);
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_COACHES( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating coaches.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Removes any pending statuses in the selection
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList formatted as empid||mu
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean clearEmployeesPendingStatuses(Component parentFrame, String feeder, String site, ArrayList<String> empList, String sbcid)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE EMPLOYEES_TVI SET PENDING_STATUS = NULL, PENDING_EFFECTIVE_DATE = NULL, LAST_CHG_BY = ?, LAST_CHG_DATE = SYSDATE "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND EMPID||MU IN (SELECT REGEXP_SUBSTR(?, '[^,]+', 1, LEVEL) TOKEN FROM DUAL CONNECT BY LEVEL <= LENGTH(?) - LENGTH(REPLACE(?, ',', '')) + 1) ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            ps.setString(2, feeder);
            ps.setString(3, site);
            if (empList != null)
            {
                String empids = Misc.listToStringCSV(empList);
                ps.setString(4, empids);
                ps.setString(5, empids);
                ps.setString(6, empids);
            }
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error clearing pending statuses.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the specified employee's information on the employee table.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param band
     * @param agentid
     * @param employee
     * @param coach
     * @param webphoneSupervisor
     * @param currentStatus
     * @param currentEffectiveDate
     * @param stopPayrollReporting
     * @param stopPayrollChgdBy
     * @param stopPayrollChgdDate
     * @param ncsDate
     * @param childBirthDate
     * @param extraOffDays
     * @param beginDate
     * @param lastDate
     * @param pendingStatus
     * @param pendingEffectiveDate
     * @param partTimeFlag
     * @param shift
     * @param hoursPerWeek
     * @param otherPayrollID
     * @param fourDay
     * @param sixDay
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean updateEmployeeTable(Component parentFrame, String feeder, String site, String band, String mu, String empid, String agentid, 
            String employee, String coach, String webphoneSupervisor, String currentStatus, Date currentEffectiveDate, int stopPayrollReporting,
            String stopPayrollChgdBy, Date stopPayrollChgdDate, Date ncsDate, Date childBirthDate, double extraOffDays, Date beginDate, Date lastDate, String pendingStatus, Date pendingEffectiveDate,
            int partTimeFlag, double shift, double hoursPerWeek, String otherPayrollID, int bilingualFlag, int fourDay, int sixDay, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_EMPLOYEES_TVI ( ?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setString(5, employee);
            ocs.setString(6, agentid);
            ocs.setString(7, coach);
            ocs.setString(8, webphoneSupervisor);
            ocs.setString(9, currentStatus);
            ocs.setDate(10, Misc.dateToSqlDate(currentEffectiveDate));
            ocs.setInt(11, partTimeFlag);
            ocs.setDouble(12, shift);
            ocs.setDouble(13, hoursPerWeek);
            ocs.setDate(14, Misc.dateToSqlDate(ncsDate));
            ocs.setDate(15, Misc.dateToSqlDate(beginDate));
            ocs.setDate(16, Misc.dateToSqlDate(lastDate));
            ocs.setString(17, otherPayrollID);
            ocs.setString(18, pendingStatus);
            ocs.setDate(19, Misc.dateToSqlDate(pendingEffectiveDate));
            ocs.setInt(20, stopPayrollReporting);
            ocs.setString(21, stopPayrollChgdBy);
            ocs.setTimestamp(22, Misc.dateToTimestamp(stopPayrollChgdDate));
            ocs.setString(23, band);
            ocs.setInt(24, bilingualFlag);
            ocs.setInt(25, fourDay);
            ocs.setInt(26, sixDay);
            ocs.setDate(27, Misc.dateToSqlDate(childBirthDate));
            ocs.setString(28, sbcid);
            ocs.setDouble(29, extraOffDays);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates the specified employee's information on the employee table in INFOR.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param band
     * @param agentid
     * @param employee
     * @param coach
     * @param webphoneSupervisor
     * @param currentStatus
     * @param currentEffectiveDate
     * @param stopPayrollReporting
     * @param stopPayrollChgdBy
     * @param stopPayrollChgdDate
     * @param ncsDate
     * @param beginDate
     * @param lastDate
     * @param pendingStatus
     * @param pendingEffectiveDate
     * @param partTimeFlag
     * @param shift
     * @param hoursPerWeek
     * @param otherPayrollID
     * @param fourDay
     * @param sixDay
     * @param sbcid
     * @param cost_center_employee
     * @param jfc
     * @return true if successful, false otherwise
     */
    public static boolean updateEmployeeTableINFOR(Component parentFrame, String feeder, String site, String band, String mu, String empid, String agentid, 
            String employee, String coach, String webphoneSupervisor, String currentStatus, Date currentEffectiveDate, int stopPayrollReporting,
            String stopPayrollChgdBy, Date stopPayrollChgdDate, Date ncsDate, Date childBirthDate, Date beginDate, Date lastDate, String pendingStatus, Date pendingEffectiveDate,
            int partTimeFlag, double shift, double hoursPerWeek, String otherPayrollID, int bilingualFlag, int fourDay, int sixDay, String sbcid, String cost_center_employee, String jfc)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_EMPLOYEES_TVI_INFOR ( ?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setString(5, employee);
            ocs.setString(6, agentid);
            ocs.setString(7, coach);
            ocs.setString(8, webphoneSupervisor);
            ocs.setString(9, currentStatus);
            ocs.setDate(10, Misc.dateToSqlDate(currentEffectiveDate));
            ocs.setInt(11, partTimeFlag);
            ocs.setDouble(12, shift);
            ocs.setDouble(13, hoursPerWeek);
            ocs.setDate(14, Misc.dateToSqlDate(ncsDate));
            ocs.setDate(15, Misc.dateToSqlDate(beginDate));
            ocs.setDate(16, Misc.dateToSqlDate(lastDate));
            ocs.setString(17, otherPayrollID);
            ocs.setString(18, pendingStatus);
            ocs.setDate(19, Misc.dateToSqlDate(pendingEffectiveDate));
            ocs.setInt(20, stopPayrollReporting);
            ocs.setString(21, stopPayrollChgdBy);
            ocs.setTimestamp(22, Misc.dateToTimestamp(stopPayrollChgdDate));
            ocs.setString(23, band);
            ocs.setInt(24, bilingualFlag);
            ocs.setInt(25, fourDay);
            ocs.setInt(26, sixDay);
            ocs.setDate(27, Misc.dateToSqlDate(childBirthDate));
            ocs.setString(28, sbcid);
            ocs.setString(29, cost_center_employee);
            ocs.setString(30, jfc);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }

    /**
     * Updates the specified employee's information on the  TVI employee table.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param employee
     * @param coach
     * @param webphoneSupervisor
     * @param currentStatus
     * @param ncsDate
     * @param childBirthDate
     * @param extraOffDays
     * @param partTimeFlag
     * @param hoursPerWeek
     * @param otherPayrollID
     * @param band
     * @param bilingualFlag
     * @param fourDay
     * @param sixDay
     * @param sbcid
     * @param cost_center_employee
     * @param jfc
     * @return true if successful, false otherwise
     */
    public static boolean updateTVIEmployeeTable(Component parentFrame, String empid, String employee, String coach, 
            String webphoneSupervisor, String currentStatus, Date ncsDate, Date childBirthDate, double extraOffDays, int partTimeFlag, double hoursPerWeek, 
            String otherPayrollID, String band, int bilingualFlag, int fourDay, int sixDay, String sbcid, String cost_center_employee, String jfc)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_TVI_EMPLOYEES ( ?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?, ?, ?, ?, "
                                                                    + "?, ?) }");
            ocs.setString(1, empid);
            ocs.setString(2, employee);
            ocs.setString(3, coach);
            ocs.setString(4, webphoneSupervisor);
            ocs.setString(5, currentStatus);
            ocs.setDate(6, Misc.dateToSqlDate(ncsDate));
            ocs.setDate(7, Misc.dateToSqlDate(childBirthDate));
            ocs.setDouble(8, extraOffDays);
            ocs.setInt(9, partTimeFlag);
            ocs.setDouble(10, hoursPerWeek);
            ocs.setString(11, otherPayrollID);
            ocs.setString(12, band);
            ocs.setInt(13, bilingualFlag);
            ocs.setInt(14, fourDay);
            ocs.setInt(15, sixDay);
            ocs.setString(16, sbcid);
            ocs.setString(17, cost_center_employee);
            ocs.setString(18, jfc);
            
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates the specified employee's information on the IEX_MU_ROSTER table in INFOR.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param feeder
     * @param site
     * @param mu
     * @param agentid
     * @param startDate
     * @param endDate
     * @param status
     * @param doNotImport
     * @param flag
     * @return true if successful, false otherwise
     */
    public static boolean updateMURosterTableINFOR(Component parentFrame, String empid, String feeder, String site,
            String mu, String agentid, Date startDate, Date endDate, String status, int doNotImport, String flag)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_IEX_MU_ROSTER_INFOR ( ?, ?, ?, ?, ?, "
                                                                    + "?, ?, ?, ?, ?)}");
            
            ocs.setString(1, empid);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, agentid);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, status);
            ocs.setInt(9, doNotImport);
            ocs.setString(10, flag);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
        
        /**
     * Updates the specified employee's information on the IEX_MU_ROSTER table in INFOR.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param employee
     * @param agentid
     * @param startDate
     * @param endDate
     * @param status
     * @param doNotImport
     * @param error
     * @param message
     * @return true if successful, false otherwise
     */
    public static boolean updateMURosterIssuesINFOR(Component parentFrame, String feeder, String site, String mu, String empid, String agentid, 
            String employee, Date startDate, Date endDate, String status, int doNotImport, int errorFlag, String error, String message)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_IEX_MU_ROSTER_ISSUE_INF ( ?, ?, ?, ?, ?, "
                                                                         + "?, ?, ?, ?, ?, "
                                                                         + "?, ?, ?)}");
            
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setString(5, agentid);
            ocs.setString(6, employee);
            ocs.setDate(7, Misc.dateToSqlDate(startDate));
            ocs.setDate(8, Misc.dateToSqlDate(endDate));
            ocs.setString(9, status);
            ocs.setInt(10, doNotImport);
            ocs.setInt(11, errorFlag);
            ocs.setString(12, error);
            ocs.setString(13, message);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating mu roster information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    /**
     * Updates the specified employee's information on the IEX_MU_ROSTER table in INFOR.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList
     * @return true if successful, false otherwise
     */

    public static boolean updateValidNewEmployees(Component parentFrame, String feeder, String site, ArrayList<String> empList)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        
        String empListCSV;
        if (empList == null)
        {
            empListCSV = "ALL";
        }
        else
        {
            empListCSV = Misc.listToStringCSV(empList);
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL VALIDATE_NEW_ROSTER_EMPS( ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating mu roster information.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the specified employee is active for the given location.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu when null, only looks in feeder & site
     * @param empid
     * @return true if the employee is active, false otherwise
     */
    public static boolean isEmployeeActiveOn(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_IF_EMPLOYEE_ACTIVE ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_IF_EMPLOYEE_ACTIVE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the location that the given employee is active on from the employee table.
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @return string containing location employee is active, formatted feeder + site + " " + mu, or null if not active anywhere
     */
    public static String getEmployeeActiveOn(Component parentFrame, String empid)
    {
        Connection c = getConnection();
        String sqlString;
        String output = null;
        PreparedStatement psCount = null;
        ResultSet rsCount = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) FROM EMPLOYEES_TVI "
                      +    " WHERE EMPID = ? "
                      +      " AND TVI_STATUS = 'ACTIVE'";
            psCount = c.prepareStatement(sqlString);
            psCount.setString(1, empid);
            rsCount = psCount.executeQuery();
            rsCount.next();
            
            boolean active = !rsCount.getString("COUNT(*)").equals("0");
            if (!active)
            {
                return null;
            }
            
            sqlString = "SELECT FEEDER || SITE || ' ' || MU AS ACTIVE_ON FROM EMPLOYEES_TVI "
                      +    " WHERE EMPID = ? "
                      +      " AND TVI_STATUS = 'ACTIVE'";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, empid);
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getString("ACTIVE_ON");
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, psCount, rsCount);
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if any of the specified employees are already active somewhere else.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empMUList formatted as empid||mu
     * @return ArrayList<ArrayList<String>> of employees that are active elsewhere (with the feeder, site, mu location)
     */
    public static ArrayList<ArrayList<String>> areAnyEmployeesActiveElsewhere(Component parentFrame, String feeder, String site, ArrayList<String> empMUList)
    {
        Connection c = getConnection();
        ArrayList<ArrayList<String>> activeEmployees = new ArrayList<>();
        ArrayList<String> empList = new ArrayList<>();
        for (int i = 0; i < empMUList.size(); i++)
        {
            empList.add(empMUList.get(i).substring(0, 6));
        }
        String empListCSV = Misc.listToStringCSV(empList);
        String empMUListCSV = Misc.listToStringCSV(empMUList);
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT EMPID, FEEDER, SITE, MU FROM EMPLOYEES_TVI "
                      +    " WHERE EMPID IN (SELECT REGEXP_SUBSTR(?, '[^,]+', 1, LEVEL) TOKEN FROM DUAL CONNECT BY LEVEL <= LENGTH(?) - LENGTH(REPLACE(?, ',', '')) + 1) "
                      +      " AND (TVI_STATUS = 'ACTIVE' OR PENDING_STATUS = 'ACTIVE') "
                      +      " AND (FEEDER <> ? OR SITE <> ? OR EMPID||MU NOT IN (SELECT REGEXP_SUBSTR(?, '[^,]+', 1, LEVEL) TOKEN FROM DUAL CONNECT BY LEVEL <= LENGTH(?) - LENGTH(REPLACE(?, ',', '')) + 1)) ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, empListCSV);
            ps.setString(2, empListCSV);
            ps.setString(3, empListCSV);
            ps.setString(4, feeder);
            ps.setString(5, site);
            ps.setString(6, empMUListCSV);
            ps.setString(7, empMUListCSV);
            ps.setString(8, empMUListCSV);
            rs = ps.executeQuery();
            
            while (rs.next())
            {
                ArrayList<String> employeeRecord = new ArrayList<>();
                employeeRecord.add(rs.getString("EMPID"));
                employeeRecord.add(rs.getString("FEEDER"));
                employeeRecord.add(rs.getString("SITE"));
                employeeRecord.add(rs.getString("MU"));
                activeEmployees.add(employeeRecord);
            }
        }
        catch (SQLException ex)
        {
            activeEmployees = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return activeEmployees;
    }
    
    /**
     * Checks if any of the specified employees have records on schedules for the specified FEEDER, SITE, MU on or after the given date
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param empList
     * @return ArrayList<ArrayList<String>> of employees that are on specified schedules (with the feeder, site, mu location)
     */
    public static ArrayList<ArrayList<String>> areAnyEmployeesOnOtherSchedules(Component parentFrame, String feeder, String site, String mu, Date reportingDate, ArrayList<String> empList)
    {
        Connection c = getConnection();
        ArrayList<ArrayList<String>> scheduledEmployees = new ArrayList<>();
        String empListCSV = Misc.listToStringCSV(empList);
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT EMPID, FEEDER, SITE, MU FROM TIME_TOTALS_MASTER "
                      +    " WHERE EMPID IN (SELECT REGEXP_SUBSTR(?, '[^,]+', 1, LEVEL) TOKEN FROM DUAL CONNECT BY LEVEL <= LENGTH(?) - LENGTH(REPLACE(?, ',', '')) + 1) "
                      +      " AND REPORTING_DATE >= ? "
                      +      " AND (FEEDER <> ? OR SITE <> ? OR MU <> ? ) ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, empListCSV);
            ps.setString(2, empListCSV);
            ps.setString(3, empListCSV);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            ps.setString(5, feeder);
            ps.setString(6, site);
            ps.setString(7, mu);
            rs = ps.executeQuery();
            
            while (rs.next())
            {
                ArrayList<String> employeeRecord = new ArrayList<>();
                employeeRecord.add(rs.getString("EMPID"));
                employeeRecord.add(rs.getString("FEEDER"));
                employeeRecord.add(rs.getString("SITE"));
                employeeRecord.add(rs.getString("MU"));
                scheduledEmployees.add(employeeRecord);
            }
        }
        catch (SQLException ex)
        {
            scheduledEmployees = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking for employee records.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return scheduledEmployees;
    }
    
    /**
     * Checks if the specified employee is already active somewhere else.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @return true if the employee is already active, false otherwise
     */
    public static boolean isEmployeeActiveElsewhere(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_IF_EMP_ACTIVE_ELSEWHERE ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_IF_EMP_ACTIVE_ELSEWHERE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the specified employee is inactive for the given feeder, site, mu.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @return true if the employee is active, false otherwise
     */
    public static boolean isEmployeeInactiveOn(Component parentFrame, String feeder, String site, String mu, String empid)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) FROM EMPLOYEES_TVI "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND MU = ? "
                      +      " AND EMPID = ? "
                      +      " AND TVI_STATUS = 'INACTIVE'";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, empid);
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if the specified employee already has an existing record for the given date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @return true if the employee has a conflicting record, false otherwise
     */
    public static boolean doesEmployeeRecordConflict(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) FROM TIME_TOTALS_MASTER "
                      +    " WHERE FEEDER||SITE||MU <> ? "
                      +      " AND EMPID = ? "
                      +      " AND REPORTING_DATE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder + site + mu);
            ps.setString(2, empid);
            ps.setDate(3, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Deletes the specified employee record
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @return true if successful, false otherwise
     */
    public static boolean deleteEmployeeRecord(Component parentFrame, String feeder, String site, String mu, String empid)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "DELETE FROM EMPLOYEES_TVI "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND MU = ? "
                      +      " AND EMPID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, empid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting employee record.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Calls COMPUTE_MEX_OT_PREMIUMS, which computes overtime premiums for the current pay period, and Completes the schedules.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @param empid
     * @return true if successful, false otherwise
     */
    public static boolean computePremiumMex(Component parentFrame, String feeder, String site, Date endDate, String empid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_MEX_OT_PREMIUMS.Main ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.setString(4, empid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE_MEX_OT_PREMIUMS.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Transfers the given employee record (EMPLOYEES_TVI) from one MU to another.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param fromMU
     * @param toMU
     * @param effectiveDate
     * @return true if successful, false otherwise
     */
    public static boolean transferEmployee(Component parentFrame, String feeder, String site, String empid, String fromMU, String toMU, Date effectiveDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TRANSFER_TO_NEW_MU ( ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.setString(4, fromMU);
            ocs.setString(5, toMU);
            ocs.setDate(6, Misc.dateToSqlDate(effectiveDate));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "Failed to transfer employee.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Attempts to inactivate an employee on the given feeder, site, mu.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param effectiveDate
     * @param changedBy AT&T UUID indicating the user submitting the change
     * @return true if successful, false otherwise
     */
    public static boolean inactivateEmployee(Component parentFrame, String feeder, String site, String mu, String empid, Date effectiveDate, String changedBy)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE EMPLOYEES_TVI "
                      + " SET TVI_STATUS = 'INACTIVE', STATUS_EFFECTIVE_DATE = ?, LAST_CHG_BY = ?, LAST_CHG_DATE = SYSDATE "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MU = ? "
                      +       " AND EMPID = ? "
                      +       " AND TVI_STATUS = 'ACTIVE'";
            ps = c.prepareStatement(sqlString);
            ps.setDate(1, Misc.dateToSqlDate(effectiveDate));
            ps.setString(2, changedBy);
            ps.setString(3, feeder);
            ps.setString(4, site);
            ps.setString(5, mu);
            ps.setString(6, empid);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inactivating employee.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the specified vacation code from VAC1 to VAC2 & adds comment.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param reportingDate
     * @param comment
     * @return true if successful, false otherwise
     */
    public static boolean updateVacationMEX(Component parentFrame, String feeder, String site, String empid, Date reportingDate, String comment)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE TIME_ABSENCES_MASTER "
                      + " SET SAP_CODE_TREC = 'VAC2', REASON_TEXT = ? "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND EMPID = ? "
                      +       " AND REPORTING_DATE = ? "
                      +       " AND SAP_CODE_TREC = 'VAC1'";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, comment);
            ps.setString(2, feeder);
            ps.setString(3, site);
            ps.setString(4, empid);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee VAC coding.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the last date the payroll was generated for the specified site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return date payroll was generated last, or null
     */
    public static Date getLastPayrollGeneratedDate(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        String sqlString;
        Date output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = " SELECT PAYROLL_GENERATION_DATE "
                      +     " FROM SITES "
                      +         " WHERE FEEDER = ? "
                      +           " AND SITE = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            if (rs.next())
            {
                output = Misc.timestampToDate(rs.getTimestamp("PAYROLL_GENERATION_DATE"));
            }
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting site's last payroll generation date.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks to make sure all employees have Payroll IDs for the given site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any employee(s) have OTHER_PAYROLL_ID = null, false otherwise
     */
    public static boolean areAnyEmployeesMissingPayrollID(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_EMPS_MISSING_PAYROLLID ( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_EMPS_MISSING_PAYROLLID.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks to make sure all of the given separated employees have Payroll IDs for the given site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList comma separated empids
     * @return true if any employee(s) have OTHER_PAYROLL_ID = null, false otherwise
     */
    public static boolean areAnySeparatedEmployeesMissingPayrollID(Component parentFrame, String feeder, String site, String empList)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_SEP_EMPS_PAYROLLID ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, empList);
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_SEP_EMPS_PAYROLLID.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks to make sure the site doesn't have any schedules in the working schedules column that need premiums computed.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if site is ready, false if compute premium needs to be run
     */
    public static boolean checkAllComputePremiumMEX(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT COUNT(*) "
                             +     " FROM TIME_TOTALS_MASTER "
                             +         " WHERE FEEDER = ? "
                             +           " AND SITE = ? "
                             +           " AND REPORTING_DATE >= SYSDATE - 370 "
                             +           " AND STATUS IN ('Ready', 'Not Ready', 'Updated', 'Error')";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking compute premium.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Inserts employee history for the specified pay period.
     * Called after beginning a new pay period and when generating payroll for terminated employees
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param lastPayrollGenerationDate
     * @param empidList pass null for all employees
     * @return true if successful, false otherwise
     */
    public static boolean insertHistoryInternational(Component parentFrame, String feeder, String site, Date startDate, Date endDate, Date lastPayrollGenerationDate, String empidList)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL HISTORY_INSERT_INTERNATIONAL ( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.setTimestamp(5, Misc.dateToTimestamp(lastPayrollGenerationDate));
            ocs.setString(6, empidList);
            
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to HISTORY_INSERT_INTERNATIONAL.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the absence records for MEX payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empidList "ALL" for all employees
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAbsencesMEX(Component parentFrame, String feeder, String site, String empidList)
    {
        Connection c = getConnection();
        ResultSet rsAbs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_ABS(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empidList);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsAbs = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_ABS.");
        }
        return new ResultSetWrapper(rsAbs, ocs);
    }
    
    /**
     * Gets the records for the sickness summary report for Europe.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param reportType "SICK" or "LOA"
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSicknessSummary(Component parentFrame, String feeder, String site, Date startDate, Date endDate, String reportType)
    {
        Connection c = getConnection();
        ResultSet rsAbs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_CZE_SICKNESS_SUMMARY(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.setString(5, reportType);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rsAbs = (ResultSet) ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_CZE_SICKNESS_SUMMARY.");
        }
        return new ResultSetWrapper(rsAbs, ocs);
    }
    
    /**
     * Gets the premium records for MEX payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empidList "ALL" for all employees
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPremiumMEX(Component parentFrame, String feeder, String site, String empidList)
    {
        Connection c = getConnection();
        ResultSet rsPREM = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_PRM(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empidList);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPREM = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RSEXCEL_PAYROLL_MEX_PRM.");
        }
        return new ResultSetWrapper(rsPREM, ocs);
    }
    
    /**
     * Gets the clear absence records for MEX payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empidList "ALL" for all employees
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsClearAbsencesMEX(Component parentFrame, String feeder, String site, String empidList)
    {
        Connection c = getConnection();
        ResultSet rsAbs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_CLEAR_ABS(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empidList);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsAbs = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_CLEAR_ABS.");
        }
        return new ResultSetWrapper(rsAbs, ocs);
    }
    
    /**
     * Gets the clear premium records for MEX payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empidList "ALL" for all employees
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsClearPremiumMEX(Component parentFrame, String feeder, String site, String empidList)
    {
        Connection c = getConnection();
        ResultSet rsPREM = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_CLEAR_PRM(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empidList);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPREM = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_CLEAR_PRM.");
        }
        return new ResultSetWrapper(rsPREM, ocs);
    }
    
    /**
     * Updates TO_ELINK_DATE_TIME for records after generating payroll.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param payrollGenerationDate
     * @param chgdBy
     * @param updateSite
     * @return true if successful, false otherwise
     */
    public static boolean updatePayrollRunDate(Component parentFrame, String feeder, String site, Date startDate, Date endDate, Date payrollGenerationDate, String chgdBy, boolean updateSite)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_PAYROLL_RUN_DATE_INT(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.setTimestamp(5, Misc.dateToTimestamp(payrollGenerationDate));
            ocs.setString(6, chgdBy);
            ocs.setInt(7, Misc.booleanToOracle(updateSite));
            
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_PAYROLL_RUN_DATE_INT.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates TO_ELINK_DATE_TIME for given separated employee records after generating payroll.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList
     * @param startDate
     * @param endDate
     * @param toElinkDateTime
     * @param chgdBy
     * @return true if successful, false otherwise
     */
    public static boolean updatePayrollSeparatedDate(Component parentFrame, String feeder, String site, String empList, Date startDate, Date endDate, Date toElinkDateTime, String chgdBy)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_PAYROLL_SEPARATED_DATE(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empList);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.setTimestamp(6, Misc.dateToTimestamp(toElinkDateTime));
            ocs.setString(7, chgdBy);
            
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_PAYROLL_SEPARATED_DATE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets a list of MUs and the corresponging number of schedules that exist in the specified payroll period.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return String listing MUs and the number of schedules in the given pay cycle
     */
    public static String getMUScheduleCountList(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        String output = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT 'MU: ' || MU || ' Count: ' || COUNT(*) AS MU_COUNT "
                             +     " FROM SCHEDULES "
                             +         " WHERE FEEDER = ? "
                             +           " AND SITE = ? "
                             +           " AND REPORTING_DATE >= ? "
                             +           " AND REPORTING_DATE <= ? "
                             +     " GROUP BY MU "
                             +     " ORDER BY MU";
            
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setDate(3, Misc.dateToSqlDate(startDate));
            ps.setDate(4, Misc.dateToSqlDate(endDate));
            
            rs = ps.executeQuery();
            
            StringBuilder buf = new StringBuilder();
            while (rs.next())
            {
                buf.append(rs.getString("MU_COUNT")).append("    ");
            }
            output = buf.toString();
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU schedule count list.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the list of available separated employees for MEX payroll generation.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSeparatedEmployeesMEX(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPREM = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SEPARATED_EMPS_MEX(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPREM = (ResultSet) ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            if (ex.getErrorCode() == 20001)
            {
                String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
            }
            else
            {
                Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting list of separated employees.");
            }
        }
        return new ResultSetWrapper(rsPREM, ocs);
    }
    
    /**
     * Gets the records to display for the LOAMex screen.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param daysBack
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsLOAMexico(Component parentFrame, String feeder, String site, int daysBack)
    {
        Connection c = getConnection();
        ResultSet rsEmployees = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_LOA_MEX(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, daysBack);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rsEmployees = (ResultSet) ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting LOA data.");
        }
        return new ResultSetWrapper(rsEmployees, ocs);
    }
    
    /**
     * Deletes the specified LOA record.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param startDate
     * @return true if successful, false otherwise
     */
    public static boolean deleteLOARecord(Component parentFrame, String feeder, String site, String empid, Date startDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "DELETE FROM TIME_LOA_MASTER "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND EMPID = ? "
                      +      " AND START_DATE = ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, empid);
            ps.setDate(4, Misc.dateToSqlDate(startDate));
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting LOA record.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the LOA TABLE - updates if record exists inserts if new
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param sapCodeTrec
     * @param codeDescription
     * @param startDate
     * @param endDate
     * @param medicalID
     * @param chgdby
     * @param initialMedicalID
     * @param preliminary
     * @param daysPaid
     * @return true if successful, false otherwise
     */
    public static boolean updateLOA(Component parentFrame, String feeder, String site, String empid, String sapCodeTrec, String codeDescription,
            Date startDate, Date endDate, String medicalID, String chgdby, String initialMedicalID, int preliminary, boolean daysPaid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_LOA ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.setString(4, sapCodeTrec);
            ocs.setString(5, codeDescription);
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, medicalID);
            ocs.setString(9, chgdby);
            ocs.setString(10, initialMedicalID);
            ocs.setInt(11, preliminary);
            ocs.setInt(12, Misc.booleanToOracle(daysPaid));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating LOA Records.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the list of all active employees for the given feeder & site.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getEmployeeListMex(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rsPREM = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL GET_EMPLOYEE_LIST_MEX(?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPREM = (ResultSet) ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_EMPLOYEE_LIST_MEX.");
        }
        return new ResultSetWrapper(rsPREM, ocs);
    }
    
    /**
     * Gets the current status for the specified employee for the given feeder, site, mu.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @return String status
     */
    public static String getEmployeeStatus(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        String empStatus = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_EMP_STATUS( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            ocs.execute();
            empStatus = ocs.getString(1);
        }
        catch (SQLException ex)
        {
            empStatus = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting employee status.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return empStatus;
    }
    
    /**
     * Updates the given employee's status as specified.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param employee
     * @param status
     * @param union
     * @param payCycle
     * @param effectiveDate
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean setEmployeeStatus(Component parentFrame, String feeder, String site, String mu, String empid, String employee, String status, String union, String payCycle, Date effectiveDate, String sbcid)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        boolean update = true;
        PreparedStatement psCount = null;
        ResultSet rsCount = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) "
                      +   " FROM EMPLOYEES_TVI "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MU = ? "
                      +       " AND EMPID = ?";
            psCount = c.prepareStatement(sqlString);
            psCount.setString(1, feeder);
            psCount.setString(2, site);
            psCount.setString(3, mu);
            psCount.setString(4, empid);
            
            rsCount = psCount.executeQuery();
            
            while (rsCount.next())
            {
                update = !rsCount.getString("COUNT(*)").equals("0");
            }
            
            if (update)
            {
                sqlString = "UPDATE EMPLOYEES_TVI "
                          +    " SET TVI_STATUS = ?, STATUS_EFFECTIVE_DATE = ?, LAST_CHG_BY = ?, LAST_CHG_DATE = SYSDATE"
                            +    " WHERE FEEDER = ? "
                            +      " AND SITE = ? "
                            +      " AND MU = ? "
                            +      " AND EMPID = ?";
                ps = c.prepareStatement(sqlString);
                ps.setString(1, status);
                ps.setDate(2, Misc.dateToSqlDate(effectiveDate));
                ps.setString(3, sbcid);
                ps.setString(4, feeder);
                ps.setString(5, site);
                ps.setString(6, mu);
                ps.setString(7, empid);
                ps.executeUpdate();
                c.commit();
            }
            else if (status.equals("ACTIVE")) //insert
            {
                sqlString = "INSERT INTO EMPLOYEES_TVI "
                          + " ( "
                          +     " EMPID, "
                          +     " AGENTID, "
                          +     " EMPLOYEE, "
                          +     " TVI_STATUS, "
                          +     " STATUS_EFFECTIVE_DATE, "
                          +     " FEEDER, "
                          +     " SITE, "
                          +     " MU, "
                          +     " UNION_FLAG, "
                          +     " PAY_CYCLE "
                          + " ) "
                          + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
                ps = c.prepareStatement(sqlString);
                ps.setString(1, empid);
                ps.setString(2, empid);
                ps.setString(3, employee);
                ps.setString(4, status);
                ps.setDate(5, Misc.dateToSqlDate(effectiveDate));
                ps.setString(6, feeder);
                ps.setString(7, site);
                ps.setString(8, mu);
                ps.setString(9, union);
                ps.setString(10, payCycle);
                ps.executeUpdate();
                c.commit();
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee status.");
        }
        finally
        {
            closeCursors(parentFrame, psCount, rsCount);
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Updates the given employee statuses as specified.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList formatted as empid||mu
     * @param status
     * @param effectiveDate
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean updateEmployeeStatuses(Component parentFrame, String feeder, String site, ArrayList<String> empList, String status, Date effectiveDate, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_EMPLOYEE_STATUSES(?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, Misc.listToStringCSV(empList));
            ocs.setString(4, status);
            ocs.setDate(5, Misc.dateToSqlDate(effectiveDate));
            ocs.setString(6, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee statuses.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display for the ImportTransferEmployees screen.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsTransferEmployees(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rsTransferEmps = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TRANSFERRED_EMPLOYEES(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsTransferEmps = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting list of trasnferred employees");
        }
        return new ResultSetWrapper(rsTransferEmps, ocs);
    }
    
    /**
     * Gets the payroll IDs for all employees on the given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return List<String[empid, payrollid]>
     */
    public static List<String[]> getEmployeePayrollIDs(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        List<String[]> employeePayrollIDs = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT EMPID, OTHER_PAYROLL_ID "
                             +     " FROM EMPLOYEES_TVI "
                             +         " WHERE FEEDER = ? "
                             +           " AND SITE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            while (rs.next())
            {
                employeePayrollIDs.add(new String[] {rs.getString("EMPID"), rs.getString("OTHER_PAYROLL_ID")});
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting employee payroll IDs.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return employeePayrollIDs;
    }
    
    /**
     * Updates the payroll ID for the given employee.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param payrollID
     * @return true if successful, false otherwise
     */
    public static boolean updateEmployeePayrollID(Component parentFrame, String feeder, String site, String empid, String payrollID)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_EMPLOYEE_PAYROLLID( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empid);
            ocs.setString(4, payrollID);
            
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_EMPLOYEE_PAYROLLID.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates payroll completed date for employee on given feeder & site if exists on other MU's
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param payrollCompleted
     * @param chgdBy
     * @param dateChanged
     * @return true if successful, false otherwise
     */
    public static boolean updateOtherPayrollCompleted(Component parentFrame, String feeder, String site, String mu, String empid, boolean payrollCompleted, String chgdBy, Date dateChanged)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE EMPLOYEES_TVI "
                             +    " SET STOP_PAYROLL_REPORTING = ?, STOP_PAYROLL_CHGD_BY = ?, STOP_PAYROLL_CHGD_DATE = ? "
                             +        " WHERE EMPID = ? "
                             +          " AND FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND MU <> ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(payrollCompleted));
            ps.setString(2, chgdBy);
            ps.setTimestamp(3, Misc.dateToTimestamp(dateChanged));
            ps.setString(4, empid);
            ps.setString(5, feeder);
            ps.setString(6, site);
            ps.setString(7, mu);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employee payroll completed data.");
            output = false;
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Sets the given employees payroll completed data on EMPLOYEES_TVI
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList
     * @param payrollCompleted
     * @param chgdBy
     * @param dateChanged
     * @return true if successful, false otherwise
     */
    public static boolean setEmployeesPayrollCompleted(Component parentFrame, String feeder, String site, String empList, boolean payrollCompleted, String chgdBy, Date dateChanged)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE EMPLOYEES_TVI "
                             +    " SET STOP_PAYROLL_REPORTING = ?, STOP_PAYROLL_CHGD_BY = ?, STOP_PAYROLL_CHGD_DATE = ? "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND EMPID IN (SELECT REGEXP_SUBSTR(?, '[^,]+', 1, LEVEL) TOKEN FROM DUAL CONNECT BY LEVEL <= LENGTH(?) - LENGTH(REPLACE(?, ',', '')) + 1)";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(payrollCompleted));
            ps.setString(2, chgdBy);
            ps.setTimestamp(3, Misc.dateToTimestamp(dateChanged));
            ps.setString(4, feeder);
            ps.setString(5, site);
            ps.setString(6, empList);
            ps.setString(7, empList);
            ps.setString(8, empList);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating employees payroll completed data.");
            output = false;
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the records to display in the CZE/SVK shift plan report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsShiftPlan(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsShiftPlan = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_SHIFT_PLAN_EUR(?, ?, ?, ?, ?) }"); // used by CZE, POL, SVK
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsShiftPlan = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CZE shift plan records.");
        }
        return new ResultSetWrapper(rsShiftPlan, ocs);
    }
    
    /**
     * Gets the records to display in the CZE payroll report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param corrections
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollCZE(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean corrections)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            if (corrections)
            {
                ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_CZE_PRIOR(?, ?, ?, ?, ?) }");
            }
            else
            {
                ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_CZE(?, ?, ?, ?, ?) }");
            }
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CZE payroll results.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Gets the records to display in the SVK payroll report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_SVK(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting SVK payroll results.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Gets the records to display in the POL payroll report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_POL(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_POL.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Gets the records to display in the MEX time data report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsTimeData(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_MEX_TIME_DATA(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_MEX_TIME_DATA1.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Gets the records to display in the SVK Payroll Review report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollReview(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            String procedureName;
            switch (feeder)
            {
                case "CZE":
                    procedureName = "RS_EXCEL_PAYROLL_REVIEW_CZE";
                    break;
                case "POL":
                    procedureName = "RS_EXCEL_PAYROLL_REVIEW_POL";
                    break;
                case "SVK":
                    procedureName = "RS_EXCEL_PAYROLL_REVIEW_SVK";
                    break;
                default:
                    Misc.msgbox(parentFrame, "Payroll review report is not available for feeder " + feeder, "Payroll Review Report", 2, 1, 1);
                    return null;
            }
            ocs = c.prepareCall("{ CALL " + procedureName + " (?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_" + feeder + "_PAYROLL_REVIEW.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Gets the records to display in the SVK meal voucher report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMealVouchersSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_SVK_MEAL_VOUCHERS(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_SVK_MEAL_VOUCHERS.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display in the SVK meal vouchers detail report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMeaVouchersDetailSVK(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_MEAL_VCH_DETAIL_SVK(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, employeeSelection);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_MEAL_VCH_DETAIL_SVK.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display from the monthly schedule imports status cell listener
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsNewGone(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rsNewGone = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_NEW_GONE(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsNewGone = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting New/Gone data.");
        }
        return new ResultSetWrapper(rsNewGone, ocs);
    }
    
    /**
     * Gets the records to display in the ScheduleImportStatus form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSchedulesImported(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULES_IMPORTED(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error querying schedules imported table model.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display in the ScheduleImportStatusMonthly form.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSchedulesImportedMonthly(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULES_IMPORTED_MONTHLY(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting schedules imported monthly data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the specified MU's union
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param union
     * @return union from MU table
     */
    public static String getUnion(Component parentFrame, String feeder, String site, String mu, String union)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT UNION_FLAG "
                             +    " FROM MU "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND MU = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            rs = ps.executeQuery();
            
            rs.next();
            union = rs.getString("UNION_FLAG");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting union.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return union; //returns passed SITEUNION by default
    }
    
    /**
     * Gets the specified MU's totalviewID
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @return totalviewID from MU table
     */
    public static int getTotalviewID(Component parentFrame, String feeder, String site, String mu)
    {
        Connection c = getConnection();
        int totalviewID = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT TOTALVIEWID "
                             +    " FROM MU "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND MU = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            rs = ps.executeQuery();
            
            rs.next();
            totalviewID = rs.getInt("TOTALVIEWID");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting totalviewID.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return totalviewID;
    }
    
    /**
     * Gets the actual schedules for the specified feeder & site of the given type.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param daysBack
     * @param reportType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsActualSchedules(Component parentFrame, String feeder, String site, int daysBack, String reportType)
    {
        Connection c = getConnection();
        ResultSet rsSchedules = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ACTUAL_SCHEDULES(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setInt(3, daysBack);
            ocs.setString(4, reportType);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsSchedules = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error actual schedules data.");
        }
        return new ResultSetWrapper(rsSchedules, ocs);
    }
    
    /**
     * Gets the actual vs schedule comparison report for the given feeder, site, mu, & date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsActualToSchedule(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rsMinutes = null;
        ResultSet rsDays = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ACTUAL_TO_SCHED(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rsMinutes = (ResultSet)ocs.getObject(5);
            rsDays = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_ACTUAL_TO_SCHED.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsMinutes, rsDays}, ocs);
    }
    
    /**
     * Imports actual schedules for the specified date
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param sbcid
     */
    public static void requestActualSchedule(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL CHECK_ACTSCH_1_REQUEST_FILES.MAIN ( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.setString(5, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_ACTSCH_1_REQUEST_FILES.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Imports actual schedules for the specified date for ALL mus on the current site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param reportingDate
     * @param sbcid
     */
    public static void requestActualScheduleALL(Component parentFrame, String feeder, String site, Date reportingDate, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ACTSCH_ALL_1_REQUEST_FILES.MAIN ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.setString(4, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to ACTSCH_ALL_1_REQUEST_FILES.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Imports actual schedules for the specified date for ALL mus on the current site (For EUR Incidental OT Excel Report)
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param reportingDate
     * @param sbcid
     */
    public static void requestIncidentalOTActuals(Component parentFrame, String feeder, String site, Date reportingDate, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL INCOT_1_REQUEST_FILES.MAIN ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.setString(4, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to INCOT_1_REQUEST_FILES.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Sets the specified schedule to the given status
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportType "ALL" for actsch, "ALLMU" for actsch-ALL, "INCOT" for incidental OT report
     * @param reportingDate
     * @param status
     * @return true if successful, false otherwise
     */
    public static boolean updateActualScheduleStatus(Component parentFrame, String feeder, String site, String mu, String reportType, Date reportingDate, String status)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE IMPORT_LOG_ACTUAL_SCHED "
                      +     " SET STATUS = ? "
                      +         " WHERE FEEDER = ? "
                      +           " AND SITE = ? "
                      +           " AND MU = ? "
                      +           " AND REPORT_TYPE = ? "
                      +           " AND REPORTING_DATE = ? ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, status);
            ps.setString(2, feeder);
            ps.setString(3, site);
            ps.setString(4, mu);
            ps.setString(5, reportType);
            ps.setDate(6, Misc.dateToSqlDate(reportingDate));
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating actual schedule status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Clears the actual schedule data for the specified schedule
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if successful, false otherwise
     */
    public static boolean clearActualSchedule(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "DELETE FROM IMPORT_ACTUAL_SCHED "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND (MU = ? OR ? = 'ALL')"
                      +       " AND REQUESTED_DATE = ? ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, mu);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error clearing actual schedule data.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Clears the actual schedule incidental overtime data for the specified schedule
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if successful, false otherwise
     */
    public static boolean clearActualScheduleIncOT(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "DELETE FROM IMPORT_ACTUAL_SCHED_INCOT "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND (MU = ? OR ? = 'ALL')"
                      +       " AND REQUESTED_DATE = ? ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, mu);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error clearing actual schedule data.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Checks if the given actual schedule exists.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportType "ALL" for actsch, "ALLMU" for actsch-ALL, "INCOT" for incidental OT report
     * @param reportingDate
     * @return true if successful, false otherwise
     */
    public static boolean actualScheduleIsRequesting(Component parentFrame, String feeder, String site, String mu, String reportType, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) AS NUM FROM IMPORT_LOG_ACTUAL_SCHED "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MU = ? "
                      +       " AND REPORT_TYPE = ? "
                      +       " AND REPORTING_DATE = ? "
                      +       " AND STATUS IN ('Requesting', 'Returned')";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, reportType);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("NUM").equals("0");
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking actual schedule status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if the given actual schedule exists.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportType "ALL" for actsch, "ALLMU" for actsch-ALL, "INCOT" for incidental OT report
     * @param reportingDate
     * @return true if schedule exists, false otherwise
     */
    public static boolean actualScheduleExists(Component parentFrame, String feeder, String site, String mu, String reportType, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) AS NUM FROM IMPORT_LOG_ACTUAL_SCHED "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MU = ? "
                      +       " AND REPORT_TYPE = ? "
                      +       " AND REPORTING_DATE = ? "
                      +       " AND STATUS NOT IN ('Requesting', 'Done')";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setString(4, reportType);
            ps.setDate(5, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("NUM").equals("0");
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking actual schedule status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the status of the given actual schedule.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param reportType
     * @return true if schedule exists with status of 'Available', false otherwise
     */
    public static boolean isActualScheduleAvailable(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String reportType)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) AS NUM FROM IMPORT_LOG_ACTUAL_SCHED "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? ";
            if (!mu.equals("ALL"))
            {
                sqlString +=  " AND MU = ? ";
            }
            sqlString +=      " AND REPORTING_DATE = ? ";
            if (!reportType.equals("ALL"))
            {
                sqlString +=  " AND REPORT_TYPE = ? ";
            }
            sqlString +=      " AND STATUS = 'Available'";
            
            ps = c.prepareStatement(sqlString);
            int index = 1;
            ps.setString(index++, feeder);
            ps.setString(index++, site);
            if (!mu.equals("ALL"))
            {
                ps.setString(index++, mu);
            }
            ps.setDate(index++, Misc.dateToSqlDate(reportingDate));
            if (!reportType.equals("ALL"))
            {
                ps.setString(index++, reportType);
            }
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("NUM").equals("0");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting actual schedule status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the records to display in the SVK sickness corrections payroll report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSVKSickness(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rsPayroll = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_SVK_SICK(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rsPayroll = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_SVK_SICK.");
        }
        return new ResultSetWrapper(rsPayroll, ocs);
    }
    
    /**
     * Checks if the given medicalID exists.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param medicalID
     * @return true if medicalID exists, false otherwise
     */
    public static boolean doesLOAMedicalIDExist(Component parentFrame, String feeder, String site, String medicalID)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) AS NUM FROM TIME_LOA_MASTER "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MEDICAL_ID = ? ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, medicalID);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("NUM").equals("0");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking LOA medical id.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if an empid exists on the EMPLOYEES_TVI table for the given feeder & site.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param empid
     * @return true if medicalID exists, false otherwise
     */
    public static boolean doesEmpidExist(Component parentFrame, String feeder, String site, String empid)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_EMPID ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, empid);
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_EMPID.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display for the Hours Summary excel report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHoursSummary(Component parentFrame, String feeder, String site, String mu, String empList, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_HOURS_SUMMARY(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empList);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(7);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_HOURS_SUMMARY.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks if the given payroll ID already exists for a different employee on the same feeder & site.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param empid
     * @param payrollID
     * @return true if conflicting payrollID exists, false otherwise
     */
    public static boolean otherPayrollIDAlreadyExists(Component parentFrame, String feeder, String site, String empid, String payrollID)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := PAYROLLID_ALREADY_EXISTS ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, empid);
            ocs.setString(5, payrollID);
            ocs.execute();
            output = (ocs.getInt(1) == 1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_EMPID.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the absence records for the excel report sheet.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param absCodeList
     * @param startDate
     * @param endDate
     * @param reportType
     * @param clientName
     * @return ResultSet
     */
    public static ResultSetWrapper getAbsencesReportRecords(Component parentFrame, String feeder, String site, String employeeSelection, List<String> absCodeList, Date startDate, Date endDate, String reportType, String clientName)
    {
        Connection c = getConnection();
        String sqlListAbs = Misc.listToStringCSV(absCodeList);
        if (sqlListAbs.equals(""))
        {
            sqlListAbs = "ALL";
        }
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ALL_ABS_CODES(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, employeeSelection);
            ocs.setString(4, sqlListAbs);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, reportType);
            ocs.setString(8, clientName);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting absence records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the attendance records for the excel report sheet.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param attCodeList
     * @param startDate
     * @param endDate
     * @param reportType
     * @param clientName
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getAttendancesReportRecords(Component parentFrame, String feeder, String site, String employeeSelection, List<String> attCodeList, Date startDate, Date endDate, String reportType, String clientName)
    {
        Connection c = getConnection();
        String sqlListAtt = Misc.listToStringCSV(attCodeList);
        if (sqlListAtt.equals(""))
        {
            sqlListAtt = "ALL";
        }
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ALL_ATT_CODES(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, employeeSelection);
            ocs.setString(4, sqlListAtt);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, reportType);
            ocs.setString(8, clientName);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting attendance records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the extra payment records for the excel report sheet.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param extCodeList
     * @param startDate
     * @param endDate
     * @param reportType
     * @param clientName
     * @return ResultSet
     */
    public static ResultSetWrapper getExtraPaymentsReportRecords(Component parentFrame, String feeder, String site, String employeeSelection, List<String> extCodeList, Date startDate, Date endDate, String reportType, String clientName)
    {
        Connection c = getConnection();
        String sqlListExt = Misc.listToStringCSV(extCodeList);
        if (sqlListExt.equals(""))
        {
            sqlListExt = "ALL";
        }
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ALL_EXT_CODES(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, employeeSelection);
            ocs.setString(4, sqlListExt);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, reportType);
            ocs.setString(8, clientName);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting extra payment records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks if the given date range overlaps LOAs that already exist for the specified employee.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param startDate
     * @param endDate
     * @return true if dates overlap, false otherwise.
     */
    public static boolean doesLOAOverlapExisting(Component parentFrame, String feeder, String site, String empid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM TIME_LOA_MASTER"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND EMPID = ?"
                             +      " AND NOT (START_DATE = ? AND END_DATE = ?)" // allow records that exactly match, the record will be overlayed
                             +      " AND NOT ((END_DATE < ?) OR (START_DATE > ?))";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, empid);
            ps.setDate(4, Misc.dateToSqlDate(startDate));
            ps.setDate(5, Misc.dateToSqlDate(endDate));
            ps.setDate(6, Misc.dateToSqlDate(startDate));
            ps.setDate(7, Misc.dateToSqlDate(endDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if dates overlap existing LOAs.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if the given date range overlaps LOAs that already exist for the specified employee.
     * Doesn't conflict with itself
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @param medicalID
     * @param startDate
     * @param endDate
     * @return true if dates overlap, false otherwise.
     */
    public static boolean doesLOAUpdateOverlapExisting(Component parentFrame, String feeder, String site, String empid, String medicalID, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM TIME_LOA_MASTER"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND EMPID = ?"
                             +      " AND MEDICAL_ID <> ?"
                             +      " AND NOT (START_DATE = ? AND END_DATE = ?)" // allow records that exactly match, the record will be overlayed
                             +      " AND NOT ((END_DATE < ?) OR (START_DATE > ?))";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, empid);
            ps.setString(4, medicalID);
            ps.setDate(5, Misc.dateToSqlDate(startDate));
            ps.setDate(6, Misc.dateToSqlDate(endDate));
            ps.setDate(7, Misc.dateToSqlDate(startDate));
            ps.setDate(8, Misc.dateToSqlDate(endDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if dates overlap existing LOAs.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the records to display for the Employee Movement report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEmployeeMovement(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_EMPLOYEE_MOVEMENT(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet) ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_EMPLOYEE_MOVEMENT.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks to make sure the specified feeder is able to generate payroll (EUROPE/MEXICO).
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return true if the site can send, false otherwise
     */
    public static boolean isGeneratePayrollFeederOK(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT SEND_TO_ELINK_OK, SEND_TO_ELINK_MESSAGE FROM FEEDER WHERE FEEDER = ?");
            ps.setString(1, feeder);
            rs = ps.executeQuery();

            rs.next();
            output = Misc.oracleToBoolean(rs.getInt("SEND_TO_ELINK_OK"));
            String message = rs.getString("SEND_TO_ELINK_MESSAGE");
            
            if (!output)
            {
                Misc.msgbox(parentFrame, message, "Payroll Generation Disabled", 1, 1, 1);
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking feeder payroll generation status.");
            output = false;
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        return output;
    }
    
    /**
     * Checks to make sure the specified site is able to generate payroll (EUROPE/MEXICO).
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @return true if the site can send, false otherwise
     */
    public static boolean isGeneratePayrollSiteOK(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT LOCKED_SEND_TO_ELINK FROM SITES WHERE FEEDER = ? AND SITE = ?");
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();

            rs.next();
            output = Misc.objectToString(rs.getString("LOCKED_SEND_TO_ELINK")).isEmpty();
            
            if (!output)
            {
                Misc.msgbox(parentFrame, "Payroll generation is currently disabled, email TVI Support at m16666@att.com if you have any questions.", "Payroll Generation Disabled", 1, 1, 1);
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking site payroll generation status.");
            output = false;
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        return output;
    }
    
    /**
     * Payroll close partial abs package for MEXICO
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payEndDate
     * @param type
     * @param runDate
     */
    public static void thresholdCalculationsMEX(Component parentFrame, String feeder, String site, Date payEndDate, String type, Date runDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL MEX_PARTIAL_DAYS.MAIN(?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payEndDate));
            ocs.setString(4, type);
            ocs.setDate(5, Misc.dateToSqlDate(runDate));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to MEX_PARTIAL_DAYS.MAIN.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Checks if the partial abs package for MEXICO has been run.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param payEndDate
     * @return true if the partial abs package has been run for this period
     */
    public static boolean areThresholdCalculationsDone(Component parentFrame, String feeder, String site, Date payEndDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := IS_PARTIAL_ABS_DONE ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(payEndDate));
            ocs.execute();
            output = Misc.oracleToBoolean(ocs.getInt(1));
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to IS_PARTIAL_ABS_DONE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Payroll close premium calculations package for MEXICO
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @return true if successful, false otherwise
     */
    public static boolean calculatePremiumsMEX(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL MEX_COMPUTE48HRS.MAIN(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to MEX_COMPUTE48HRS.MAIN.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the premium calculations package for MEXICO has been run.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate payroll start
     * @param endDate payroll end
     * @return true if the partial abs package has been run for this period
     */
    public static boolean arePremiumsCalculatedMEX(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_MEX_PREMIUM ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_MEX_PREMIUM.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Payroll close seven day worked check for MEXICO
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @return true if successful, false otherwise
     */
    public static boolean sevenDayWorkedCheckMEX(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL MEX_SPEC_PAY_7_DAY_WORKED(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to MEX_SPEC_PAY_7_DAY_WORKED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the seven day worked check for MEXICO has been run.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate payroll start
     * @param endDate payroll end
     * @return true if the partial abs package has been run for this period
     */
    public static boolean areSevenDaysWorkedChecked(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_MEX_7DAY ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_MEX_7DAY.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if OFF days have been computed yet for POL.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return true if all OFF days have been computed for the date range
     */
    public static boolean areOffDaysComputedPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_OFF_DAYS_POL ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_OFF_DAYS_POL.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Transfers the specified employees on the given effectiveDate
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param effectiveDate
     * @param empList
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean transferEmployees(Component parentFrame, String feeder, String site, String mu, Date effectiveDate, ArrayList<String> empList, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL TRANSFER_EMPLOYEES(?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(effectiveDate));
            ocs.setString(5, Misc.listToStringCSV(empList));
            ocs.setString(6, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to TRANSFER_EMPLOYEES.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if any schedules exist for the specified FEEDER, SITE, MU on or after the given date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return true if schedules exist, false otherwise
     */
    public static boolean doSchedulesExist(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT COUNT(*) FROM SCHEDULES"
                             +    " WHERE FEEDER = ?"
                             +      " AND SITE = ?"
                             +      " AND MU = ?"
                             +      " AND REPORTING_DATE >= ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("COUNT(*)").equals("0");
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if employee exists in schedule.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param reportingDate
     * @param FMLAType
     * @param llHours
     * @param iexHours
     * @return true if successful, false otherwise
     */
    public static boolean insertFMLAApprovals(Component parentFrame, String empid, Date reportingDate, String FMLAType, double llHours, double iexHours )
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL INSERT_FMLA_IN_GTT ( ?, ?, ?, ?, ?, ? )}" );
            
            ocs.setString(1, empid);
            ocs.setDate(2, Misc.dateToSqlDate(reportingDate));
            ocs.setInt(3, 99);
            ocs.setString(4, FMLAType);
            ocs.setDouble(5, llHours);
            ocs.setDouble(6, iexHours);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error Inserting FMLA Approvals in Temp Table");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        
        return output;
    }
    
    /**
     * @param parentFrame
     * @return true if successful, false otherwise
     */
    public static boolean deleteGTT_UPLOADED_FMLA_APPROVALSRecs(Component parentFrame)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        
        try
        {
            sqlString = "DELETE GTT_UPLOADED_FMLA_APPROVALS";
            ps = c.prepareStatement(sqlString );
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting FMLA Approvals in Temp Table");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @return ResultSetWrapper 
     */
    public static boolean updateFMLA(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_FMLA_APPROVALS(?) }");
            ocs.setString(1, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to UPDATE_FMLA_APPROVALS.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Inserts or updates the current user report settings.
     *
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @param reportName
     * @param is_public
     * @param feeder
     * @param absSelected
     * @param attSelected
     * @param extSelected
     * @param absCodeList
     * @param attCodeList
     * @param extCodeList
     * @return true if successful, false otherwise
     */
    public static boolean uploadUserReportSettings(Component parentFrame, String sbcid, String reportName, boolean is_public, String feeder, boolean absSelected, boolean attSelected, boolean extSelected, List<String> absCodeList, List<String> attCodeList, List<String> extCodeList)
    {
        Connection c = getConnection();
        String absListCSV = null;
        String attListCSV = null;
        String extListCSV = null;
        if (absSelected && !absCodeList.isEmpty())
        {
            absListCSV = Misc.listToStringCSV(absCodeList);
        }
        if (attSelected && !attCodeList.isEmpty())
        {
            attListCSV = Misc.listToStringCSV(attCodeList);
        }
        if (extSelected && !extCodeList.isEmpty())
        {
            extListCSV = Misc.listToStringCSV(extCodeList);
        }
        
        String sqlString;
        boolean output = true;
        boolean update = true;
        PreparedStatement psCount = null;
        ResultSet rsCount = null;
        PreparedStatement ps = null;
        try
        {
            sqlString = "SELECT COUNT(*) "
                      +   " FROM USER_REPORTS "
                      +     " WHERE SBCID = ? "
                      +       " AND REPORT_NAME = ?";
            psCount = c.prepareStatement(sqlString);
            psCount.setString(1, sbcid);
            psCount.setString(2, reportName);
            
            rsCount = psCount.executeQuery();
            
            while (rsCount.next())
            {
                update = !rsCount.getString("COUNT(*)").equals("0");
            }
            
            if (update)
            {
                sqlString = "UPDATE USER_REPORTS "
                          +    " SET IS_PUBLIC = ?, FEEDER = ?, ABS_SELECTED = ?, ATT_SELECTED = ?, EXT_SELECTED = ?, ABS_CODE_LIST = ?, ATT_CODE_LIST = ?, EXT_CODE_LIST = ? "
                            +    " WHERE SBCID = ? "
                            +      " AND REPORT_NAME = ?";
                ps = c.prepareStatement(sqlString);
                ps.setInt(1, Misc.booleanToOracle(is_public));
                ps.setString(2, feeder);
                ps.setInt(3, Misc.booleanToOracle(absSelected));
                ps.setInt(4, Misc.booleanToOracle(attSelected));
                ps.setInt(5, Misc.booleanToOracle(extSelected));
                ps.setString(6, absListCSV);
                ps.setString(7, attListCSV);
                ps.setString(8, extListCSV);
                ps.setString(9, sbcid);
                ps.setString(10, reportName);
                ps.executeUpdate();
                c.commit();
            }
            else //insert
            {
                sqlString = "INSERT INTO USER_REPORTS "
                          + " ( "
                          +     " SBCID, "
                          +     " REPORT_NAME, "
                          +     " IS_PUBLIC, "
                          +     " FEEDER, "
                          +     " ABS_SELECTED, "
                          +     " ATT_SELECTED, "
                          +     " EXT_SELECTED, "
                          +     " ABS_CODE_LIST, "
                          +     " ATT_CODE_LIST, "
                          +     " EXT_CODE_LIST "
                          + " ) "
                          + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                ps = c.prepareStatement(sqlString);
                ps.setString(1, sbcid);
                ps.setString(2, reportName);
                ps.setInt(3, Misc.booleanToOracle(is_public));
                ps.setString(4, feeder);
                ps.setInt(5, Misc.booleanToOracle(absSelected));
                ps.setInt(6, Misc.booleanToOracle(attSelected));
                ps.setInt(7, Misc.booleanToOracle(extSelected));
                ps.setString(8, absListCSV);
                ps.setString(9, attListCSV);
                ps.setString(10, extListCSV);
                ps.executeUpdate();
                c.commit();
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error uploading report settings.");
        }
        finally
        {
            closeCursors(parentFrame, psCount, rsCount);
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the list of available report settings for the specified user and feeder.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getUserReports(Component parentFrame, String sbcid, String feeder)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_USER_REPORTS(?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, sbcid);
            ocs.setString(2, feeder);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting saved user reports.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks if the given user already has a report with the specified name.
     * 
     * @param parentFrame
     * @param sbcid
     * @param reportName
     * @return true if the reportName exists, false otherwise
     */
    public static boolean doesUserReportNameExist(Component parentFrame, String sbcid, String reportName)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT COUNT(*) AS NUM FROM USER_REPORTS "
                      +     " WHERE SBCID = ? "
                      +       " AND REPORT_NAME = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            ps.setString(2, reportName);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = !rs.getString("NUM").equals("0");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking user reports.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Deletes the specified user report.
     *
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @param reportName
     * @return true if successful, false otherwise
     */
    public static boolean deleteUserReport(Component parentFrame, String sbcid, String reportName)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "DELETE FROM USER_REPORTS "
                      +    " WHERE SBCID = ? "
                      +      " AND REPORT_NAME = ? ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            ps.setString(2, reportName);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting user report.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the list of Help Topics to display
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param documentType "Help Topics" or "What's New"
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsHelpDocuments(Component parentFrame, String feeder, String documentType)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL GET_HELP_DOCUMENTS(?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, feeder);
            ocs.setString(2, documentType);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_HELP_DOCUMENTS.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the schedule verification report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param startDate
     * @param endDate
     * @param editType
     * @param uuid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsVerificationReport(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String editType, String uuid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_VERIFICATION(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, editType);
            ocs.setString(8, uuid);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_VERIFICATION.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the payroll period summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate payroll start
     * @param payrollCloseDate payroll end
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryReport(Component parentFrame, String feeder, String site, String mu, Date startDate, Date payrollCloseDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_PAYROLL_PERIOD_SUM(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(payrollCloseDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_PAYROLL_PERIOD_SUM.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the payroll period summary 2 report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param payrollCloseDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummary2Report(Component parentFrame, String feeder, String site, String mu, Date startDate, Date payrollCloseDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_PAYROLL_PERIOD_SUM2(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(payrollCloseDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_PAYROLL_PERIOD_SUM2.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the payroll detail by employee report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param startDate
     * @param endDate
     * @param requestType
     * @param sortBy
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsDetailByEmployeeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String requestType, String sortBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_DETAIL_BY_EMPLOYEE(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, requestType);
            ocs.setString(8, sortBy);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_DETAIL_BY_EMPLOYEE.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the payroll summary by employee report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param startDate
     * @param endDate
     * @param requestType
     * @param sortBy
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsSummaryByEmployeeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String requestType, String sortBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_SUMMARY_BY_EMPLOYEE(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, requestType);
            ocs.setString(8, sortBy);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_SUMMARY_BY_EMPLOYEE.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the compute night diff report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsNightDiffReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_NIGHT_DIFF(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_NIGHT_DIFF.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the approvals by payroll period report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param hotDay
     * @param startDate
     * @param endDate
     * @param sortBy
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsApprovalReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date hotDay, Date startDate, Date endDate, String sortBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_APPROVALS(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(hotDay));
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, sortBy);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_APPROVALS.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
	 /**  
     * Gets the results for the schedules and timecodedata sent to infor by payroll period report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param hotDay
     * @param startDate
     * @param endDate
     * @param sortBy
     * @param timeZone
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsInforReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date hotDay, Date startDate, Date endDate, String sortBy, String timeZone)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_DATA_SENT_TO_INFOR(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(hotDay));
            ocs.setDate(6, Misc.dateToSqlDate(startDate));
            ocs.setDate(7, Misc.dateToSqlDate(endDate));
            ocs.setString(8, sortBy);
            ocs.setString(9, timeZone);
            ocs.registerOutParameter(10, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(10);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_DATA_SENT_TO_INFOR.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for Feeder Indicator sent to infor
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param timeZone
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsFeederReport(Component parentFrame, String feeder, String site, String timeZone)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_FEEDER_INDICATOR(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, timeZone);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_FEEDER_INDICATOR.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    
    /**
     * Gets the results for the schedules and timecodedata sent to infor by payroll period report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param hotDay
     * @param startDate
     * @param endDate
     * @param sortBy
     * @param timeZone
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsBalancesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_BALANCES(?,?,?,?,?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_BALANCES.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the employee absence detail report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param startDate
     * @param endDate
     * @param sortBy
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAbsenceDetailReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String sortBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_ABSENCE_DETAIL(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, sortBy);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_ABSENCE_DETAIL.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the entitlements used report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param startDate
     * @param endDate
     * @param requestType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEntitlementsReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String requestType)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_ENTITLEMENTS(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, requestType);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_ENTITLEMENTS.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the late employees report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empList List<String>
     * @param hotDay
     * @param startDate
     * @param endDate
     * @param requestType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsLateEmployeesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String requestType)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_LATE_EMPLOYEES(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, requestType);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_LATE_EMPLOYEES.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the LOA PDF report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @param showOKUP
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsLOAReportPDF(Component parentFrame, String feeder, String site, Date startDate, Date endDate, boolean showOKUP)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_LOA_MEX(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.setInt(5, Misc.booleanToOracle(showOKUP));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_LOA_MEX.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the LOA Excel report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsLOAReportExcel(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_LOA_MEX(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_LOA_MEX.");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the partial absences report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param mu
     * @param empList List<String>
     * @param startDate
     * @param endDate
     * @param reportType
     * @param requestType
     * @param sortBy
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPartialAbsencesReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date startDate, Date endDate, String reportType, String requestType, String sortBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        String procedure = "RS_PDF_PARTIAL_ABS_DETAIL";
        if (reportType.equals("SUMMARY"))
        {
            procedure = "RS_PDF_PARTIAL_ABS_SUMMARY";
        }
        try
        {
            ocs = c.prepareCall("{ CALL " + procedure + "(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, Misc.listToStringCSV(empList));
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, requestType);
            ocs.setString(8, sortBy);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_PARTIAL_ABS_" + reportType);
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the MEX payroll period summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param empListCSV
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryMEXPrmReport(Component parentFrame, String feeder, String site, String empListCSV)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_PRM(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_PRM");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the MEX payroll period summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param empListCSV
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryMEXAbsReport(Component parentFrame, String feeder, String site, String empListCSV)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_ABS(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_ABS");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the MEX payroll period summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param empListCSV
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryMEXClearPrmReport(Component parentFrame, String feeder, String site, String empListCSV)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_CLEAR_PRM(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_CLEAR_PRM");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the MEX payroll period summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param empListCSV
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryMEXClearAbsReport(Component parentFrame, String feeder, String site, String empListCSV)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_MEX_CLEAR_ABS(?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_MEX_CLEAR_ABS");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the comp time by employee report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param mu
     * @param empList List<String>
     * @param endDate
     * @param requestType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCompTimeReport(Component parentFrame, String feeder, String site, String mu, List<String> empList, Date endDate, String requestType)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rsSummary = null;
        ResultSet rsAll = null;
        
        String empListCSV = Misc.listToStringCSV(empList);
        if (empListCSV.equals(""))
        {
            empListCSV = "ALL";
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_COMP_TIME_EUR(?, ?, ?, ?, ?, ?, ?, ?) }");
            //ocs = c.prepareCall("{ CALL RS_EXCEL_COMP_TIME_TEST(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empListCSV);
            ocs.setString(5, requestType);
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.execute();
            
            rsSummary = (ResultSet)ocs.getObject(7);
            rsAll = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_COMP_TIME_EUR");
        }
        
        return new ResultSetWrapper(new ResultSet[]{rsSummary,rsAll}, ocs);
    }
    
    /**
     * Gets the results for the employee activity report for EUR
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site 
     * @param mu
     * @param empList
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsEmployeeActivityReport(Component parentFrame, String feeder, String site, String mu, String empList, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_EMPLOYEE_ACTIVITY(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empList);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(7);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_EMPLOYEE_ACTIVITY");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the results for the FMLA Approvals report
     * 
     * @param parentFrame the frame to center messages on
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsFMLAApprovalsReport(Component parentFrame)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        ResultSet rs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_PDF_FMLA_APPROVALS(?) }");
            ocs.setFetchSize(1000);
            ocs.registerOutParameter(1, OracleTypes.CURSOR);
            ocs.execute();
            
            rs = (ResultSet)ocs.getObject(1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_PDF_FMLA_APPROVALS");
        }
        
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the resultset for the payroll period approval table.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @param uuid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollApproval(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate, String uuid)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_PAYROLL_APPROVAL(?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.setString(6, uuid);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(7);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting payroll approval records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the resultset for the PR05 by week table.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param weekEnding
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPR05(Component parentFrame, String feeder, String site, Date weekEnding)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_PR05_WEEK_OR_YEAR(?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(weekEnding));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting PR05 table data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the resultset for the minimum interval report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMinimumIntervalReport(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_MINIMUM_INTERVAL(?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error querying minimum interval report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the state for the specified MU
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @return state string
     */
    public static String getMuState(Component parentFrame, String feeder, String site, String mu)
    {
        Connection c = getConnection();
        String state = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT STATE "
                             +    " FROM MU "
                             +        " WHERE FEEDER = ?"
                             +          " AND SITE = ?"
                             +          " AND MU = ?";
            ps = c.prepareStatement(sqlString);
                                   
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            rs = ps.executeQuery();
            
            rs.next();
            state = rs.getString("STATE");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting mu STATE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return state;
    }
    
    /**
     * Checks if the given imported schedule has any notifications to review.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param union
     * @param reportingDate
     * @param lastDayOfWeek
     * @return state string
     */
    public static List<Integer> getImportNotifications(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        List<Integer> numberOfNotifications = new ArrayList<>();
        
        try
        {
            ocs = c.prepareCall("{ CALL CHECK_IMPORT_NOTIFICATIONS(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(5, OracleTypes.INTEGER);
            ocs.registerOutParameter(6, OracleTypes.INTEGER);
            ocs.registerOutParameter(7, OracleTypes.INTEGER);
            ocs.registerOutParameter(8, OracleTypes.INTEGER);
            
            ocs.execute();
            
            numberOfNotifications.add((Integer)ocs.getObject(5));   // numOfTransferredEmps
            numberOfNotifications.add((Integer)ocs.getObject(6));   // numOfOffDays
            numberOfNotifications.add((Integer)ocs.getObject(7));  // numOfDuplicateEmps
            numberOfNotifications.add((Integer)ocs.getObject(8));  // numOfInactiveEmps
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking imported schedule notifications.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        
        return numberOfNotifications;
    }
    
    /**
     * Gets the overtime premium calculations for MEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @param reportType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsOTPremiumsMEX(Component parentFrame, String feeder, String site, Date payrollEndDate, String reportType)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_MEX_48_HOUR_RULE(?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.setString(4, reportType);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting overtime premium calculations report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the calculated thresholds for MEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu "ALL" for all MUs
     * @param payCycle
     * @param empList "ALL" for all employees
     * @param payrollEndDate
     * @param reportType PAYROLL_CLOSE or REPORT_MENU
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCalculatedThresholdsMEX(Component parentFrame, String feeder, String site, String mu, String payCycle, String empList, Date payrollEndDate, String reportType)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        Date requestDate;
        if (reportType.equals("PAYROLL_CLOSE"))
        {
            requestDate = getCurTime(parentFrame);
        }
        else // "REPORT_MENU"
        {
            requestDate = payrollEndDate;
        }
        try
        {
            ocs = c.prepareCall("{ CALL RS_MEXICO_ABS_THRESHOLDS(?, ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empList);
            ocs.setDate(5, Misc.dateToSqlDate(getPayrollStartDate(parentFrame, payCycle, payrollEndDate)));
            ocs.setDate(6, Misc.dateToSqlDate(payrollEndDate));
            ocs.setString(7, reportType);
            ocs.setDate(8, Misc.dateToSqlDate(requestDate));
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting calculated thresholds report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Sets the specified user setting on USER_SETTINGS.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param sbcid
     * @param field
     * @param setting
     */
    public static void setUserSetting(Component parentFrame, String feeder, String site, String sbcid, String field, String setting)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_USER_SETTING( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, sbcid);
            ocs.setString(4, field);
            ocs.setString(5, setting);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating user settings.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets the user's saved setting for the specified field from USER_SETTINGS.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param sbcid
     * @param field
     * @return the user's saved setting string, or an empty string if none found
     */
    public static String getUserSetting(Component parentFrame, String feeder, String site, String sbcid, String field)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        String setting = "";
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_USER_SETTING( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, sbcid);
            ocs.setString(5, field);
            ocs.execute();
            setting = ocs.getString(1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error retrieving user settings");
            return setting;
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return setting;
    }
    
    /**
     * Gets the schedule import history
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @param reportType
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsScheduleImportHistory(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_SCHEDULE_IMPORT_HISTORY(?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting schedule import history.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Toggles setting the specified schedule's status to "Hold"
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @param status
     */
    public static void setScheduleHoldRelease(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String status)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_SCHEDULE_HOLD_RELEASE( ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setDate(4, Misc.dateToSqlDate(reportingDate));
            ocs.setString(5, status);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error holding or releasing schedule.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets the records to display in the POL payroll summary report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPayrollSummaryPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_PAYROLL_POL_SUMMARY(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_PAYROLL_POL_SUMMARY.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display in the SVK meal vouchers report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsMealVouchersReportSVK(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_MEAL_VOUCHERS_SVK(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to RS_EXCEL_MEAL_VOUCHERS_SVK.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Calls the procedure COMPUTE_OFF_DAYS, which generates OFF days for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param endDate
     * @return true if successful, false otherwise
     */
    public static boolean computeOffDays(Component parentFrame, String feeder, String site, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_OFFDAY_TAGS_POL ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(endDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to compute OFF Days.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display in the POL OFF Day Tags report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsOffDayTags(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_TAG_RPT_POL(?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting results for OFF Day Tags report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Calls the procedure UPDATE_ABSENCE_COMMENTS_POL, which labels comp days earned for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return true if successful, false otherwise
     */
    public static boolean labelCompDays(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_ABSENCE_COMMENTS_POL ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to label comp days earned.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display in the POL comp days earned report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCompDaysEarned(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ABS_COMMENTS_POL (?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting results for comp days earned report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Calls the procedure COMPUTE_ABS_ON_OFF_DAY, which updates absences on OFF Days for POL
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return true if successful, false otherwise
     */
    public static boolean computeOFFAbsPOL(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_ABS_ON_OFF_DAY ( ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to compute off day absences.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display in the POL Absences Remaining on OFF Days report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsOFFAbsRemaining(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_OFF_ABS_REMAINING (?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting results for absences remaining on OFF Days report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records to display in the POL comp days earned report
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCompDaysRemaining(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_COMP_DAYS_POL (?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting results for comp days report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets a list of employees for employee selection
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param acceptedFeeders
     * @param sbcid the user's AT&T UUID
     * @return ResultSetWrapper containing array of sql resultsets containing feeder, site, mu, and employee records
     */
    public static ResultSetWrapper getResultsEmployeeSelection(Component parentFrame, String feeder, String site, String acceptedFeeders, String sbcid)
    {
        Connection c = getConnection();
        ResultSet rsFeeders = null;
        ResultSet rsSites = null;
        ResultSet rsMus = null;
        ResultSet rsEmployees = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL GET_RECORDS_EMP_SELECTION2(?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(10000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, acceptedFeeders);
            ocs.setString(4, sbcid);
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            ocs.registerOutParameter(7, OracleTypes.CURSOR);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            
            ocs.execute();
            rsFeeders = (ResultSet)ocs.getObject(5);
            rsSites = (ResultSet)ocs.getObject(6);
            rsMus = (ResultSet)ocs.getObject(7);
            rsEmployees = (ResultSet)ocs.getObject(8);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_RECORDS_EMP_SELECTION2.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsFeeders, rsSites, rsMus, rsEmployees}, ocs);
    }
    
    /**
     * Calls the procedure MEX_COMPUTE_6_DAY_ABS_UNJ to correct absences for 6-day emps in MEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @return true if successful, false otherwise
     */
    public static boolean correctAbsencesMEX(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL MEX_COMPUTE_6_DAY_ABS_UNJ ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.execute();
        }
        catch(SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to correct absences for 6-day emps.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the entire week has been imported for all MUs for the giver site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return true if all schedules are present, false otherwise
     */
    public static boolean checkWeekImported(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_WEEK_IMPORTED ( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.execute();
            output = Misc.oracleToBoolean(ocs.getInt(1));
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_WEEK_IMPORTED.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the results for the TVIAdmin CMR report
     * 
     * @param parentFrame the frame to center messages on
     * @param projectListOnly
     * @param includeCompleted
     * @param includeCancelled
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsCMRReport(Component parentFrame, boolean projectListOnly, boolean includeCompleted, boolean includeCancelled)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT CMR_NUMBER, DESC_BRIEF, STATUS, TVI_VERSION, DESC_FULL, ASSIGNED_TO, DATE_TARGET,"
                             +       " TO_CHAR(DATE_COMPLETED, 'MM/DD/YYYY') AS DATE_COMPLETED, ESTIMATED_HOURS, ACTUAL_HOURS, CATEGORY"
                             +    " FROM TVI_ADMIN_CMR"
                             +        " WHERE CMR_NUMBER <> '-1'"
                             +          " AND (DATE_COMPLETED IS NULL OR DATE_COMPLETED >= ('1-dec-' || TO_CHAR(SYSDATE - 365, 'YYYY')))";//don't show completed older than december of last year.
            if (projectListOnly)
            {
                sqlString += " AND ON_PROJECT_LIST = '-1'";
            }
            if (!includeCompleted)
            {
                sqlString += " AND STATUS <> 'COMPLETED'";
            }
            if (!includeCancelled)
            {
                sqlString += " AND STATUS <> 'CANCELLED'";
            }
            sqlString +=     " ORDER BY CMR_ORDER, TO_DATE(DATE_COMPLETED, 'MM/DD/YYYY') DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CMR report results.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Adds a new CMR to the TVI_ADMIN_CMR table
     * 
     * @param parentFrame
     * @param cmr
     * @param order
     * @param briefDesc
     * @param fullDesc
     * @param type
     * @param onList
     * @param userImpact
     * @param status
     * @param category
     * @param assignedTo
     * @param version
     * @param dateTarget
     * @param dateCompleted
     * @param dateCreated
     * @param customerName
     * @param projectName
     * @param estimatedHours
     * @param actualHours
     * @return true if successful, false otherwise
     */
    public static boolean addNewCMR(Component parentFrame, String cmr, Double order, String briefDesc, String fullDesc,
            String type, boolean onList, String userImpact, String status, String category,
            String assignedTo, String version, String dateTarget, Date dateCompleted, Date dateCreated,
            String customerName, String projectName, String estimatedHours, String actualHours)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "INSERT INTO TVI_ADMIN_CMR("
                             +     "CMR_NUMBER, "
                             +     "CMR_ORDER, "
                             +     "DESC_BRIEF, "
                             +     "DESC_FULL, "
                             +     "TYPE, "
                             +     "ON_PROJECT_LIST, "
                             +     "USER_IMPACT, "
                             +     "STATUS, "
                             +     "CATEGORY, "
                             +     "ASSIGNED_TO, "
                             +     "TVI_VERSION, "
                             +     "DATE_TARGET, "
                             +     "DATE_COMPLETED, "
                             +     "DATE_CREATED, "
                             +     "CUSTOMER_NAME, "
                             +     "PROJECT_NAME, "
                             +     "ESTIMATED_HOURS, "
                             +     "ACTUAL_HOURS) "
                             + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, cmr);
            ps.setString(2, Misc.objectToString(order));
            ps.setString(3, briefDesc);
            ps.setString(4, fullDesc);
            ps.setString(5, type);
            ps.setInt(6, Misc.booleanToOracle(onList));
            ps.setString(7, userImpact);
            ps.setString(8, status);
            ps.setString(9, category);
            ps.setString(10, assignedTo);
            ps.setString(11, version);
            ps.setString(12, dateTarget);
            ps.setDate(13, Misc.dateToSqlDate(dateCompleted));
            ps.setDate(14, Misc.dateToSqlDate(dateCreated));
            ps.setString(15, customerName);
            ps.setString(16, projectName);
            ps.setString(17, estimatedHours);
            ps.setString(18, actualHours);
            rs = ps.executeQuery();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error adding CMR values.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the next valid CMR number
     * 
     * @param parentFrame
     * @return int
     */
    public static int getNextCMRNumber(Component parentFrame)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT MAX(CMR_NUMBER) AS MAX_CMR FROM TVI_ADMIN_CMR");
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                if (rs.getObject("MAX_CMR") == null)
                {
                    output = 1;
                }
                else
                {
                    output = Integer.parseInt(rs.getObject("MAX_CMR").toString()) + 1;
                }
            }
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting next CMR number.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Deletes the specified CMR number
     * 
     * @param parentFrame
     * @param cmr
     * @return true if successful, false otherwise
     */
    public static boolean deleteCMR(Component parentFrame, String cmr)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            ps = c.prepareStatement("DELETE TVI_ADMIN_CMR WHERE CMR_NUMBER = ?");
            ps.setString(1, cmr);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting CMR values.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the specified CMR record
     * 
     * @param parentFrame
     * @param cmr
     * @param order
     * @param briefDesc
     * @param fullDesc
     * @param type
     * @param onList
     * @param userImpact
     * @param status
     * @param category
     * @param assignedTo
     * @param version
     * @param dateTarget
     * @param dateCompleted
     * @param dateCreated
     * @param customerName
     * @param projectName
     * @param estimatedHours
     * @param actualHours
     * @return true if successful, false otherwise
     */
    public static boolean updateCMRRecord(Component parentFrame, String cmr, Double order, String briefDesc, String fullDesc,
            String type, boolean onList, String userImpact, String status, String category,
            String assignedTo, String version, String dateTarget, Date dateCompleted, Date dateCreated,
            String customerName, String projectName, String estimatedHours, String actualHours)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TVI_ADMIN_CMR SET "
                             + "CMR_ORDER = ?, "
                             + "DESC_BRIEF = ?, "
                             + "DESC_FULL = ?, "
                             + "TYPE = ?, "
                             + "ON_PROJECT_LIST = ?, "
                             + "USER_IMPACT = ?, "
                             + "STATUS = ?, "
                             + "CATEGORY = ?, "
                             + "ASSIGNED_TO = ?, "
                             + "TVI_VERSION = ?, "
                             + "DATE_TARGET = ?, "
                             + "DATE_COMPLETED = ?, "
                             + "DATE_CREATED = ?, "
                             + "CUSTOMER_NAME = ?, "
                             + "PROJECT_NAME = ?, "
                             + "ESTIMATED_HOURS = ?, "
                             + "ACTUAL_HOURS = ? "
                             + "WHERE CMR_NUMBER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, order.toString());
            ps.setString(2, briefDesc);
            ps.setString(3, fullDesc);
            ps.setString(4, type);
            ps.setInt(5, Misc.booleanToOracle(onList));
            ps.setString(6, userImpact);
            ps.setString(7, status);
            ps.setString(8, category);
            ps.setString(9, assignedTo);
            ps.setString(10, version);
            ps.setString(11, dateTarget);
            ps.setDate(12, Misc.dateToSqlDate(dateCompleted));
            ps.setDate(13, Misc.dateToSqlDate(dateCreated));
            ps.setString(14, customerName);
            ps.setString(15, projectName);
            ps.setString(16, estimatedHours);
            ps.setString(17, actualHours);
            ps.setString(18, cmr);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error saving CMR values.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the version number of the specified client
     * 
     * @param parentFrame
     * @param clientName
     * @return String
     */
    public static String getClientVersion(Component parentFrame, String clientName)
    {
        Connection c = getConnection();
        String output = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            ps = c.prepareStatement("SELECT CLIENT_VERSION FROM TVI_CLIENTS WHERE CLIENT_NAME = ?");
            ps.setString(1, clientName);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = rs.getObject("CLIENT_VERSION").toString();
            }
        }
        catch (SQLException ex)
        {
            output = "";
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting client version.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Updates settings on the TVI_CLIENTS table
     * 
     * @param parentFrame
     * @param clientName
     * @param clientVersion
     * @param online
     * @param dbMessage
     * @param sendOK
     * @param sendMessage
     * @param importOK
     * @param importMessage
     * @param broadcast
     * @param broadcastMessage
     * @return true if successful, false otherwise
     */
    public static boolean updateClient(Component parentFrame, String clientName, String clientVersion, boolean online, String dbMessage, boolean sendOK, String sendMessage, boolean importOK, String importMessage, boolean broadcast, String broadcastMessage)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TVI_CLIENTS SET "
                             + "CLIENT_VERSION = ?, "
                             + "DB_ONLINE = ?, "
                             + "DB_MESSAGE = ?, "
                             + "SEND_OK = ?, "
                             + "SEND_MESSAGE = ?, "
                             + "IMPORT_OK = ?, "
                             + "IMPORT_MESSAGE = ?, "
                             + "DB_SHOW_MESSAGE = ?, "
                             + "DB_MESSAGE_BROADCAST = ? "
                             + "WHERE CLIENT_NAME = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, clientVersion);
            ps.setInt(2, Misc.booleanToOracle(online));
            ps.setString(3, dbMessage);
            ps.setInt(4, Misc.booleanToOracle(sendOK));
            ps.setString(5, sendMessage);
            ps.setInt(6, Misc.booleanToOracle(importOK));
            ps.setString(7, importMessage);
            ps.setInt(8, Misc.booleanToOracle(broadcast));
            ps.setString(9, broadcastMessage);
            ps.setString(10, clientName);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating client values.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates settings on the FEEDER table
     * 
     * @param parentFrame
     * @param feeder
     * @param online
     * @param dbMessage
     * @param sendOK
     * @param sendMessage
     * @param importOK
     * @param importMessage
     * @param broadcast
     * @param broadcastMessage
     * @return true if successful, false otherwise
     */
    public static boolean updateFeeder(Component parentFrame, String feeder, boolean online, String dbMessage, boolean sendOK, String sendMessage, boolean importOK, String importMessage, boolean broadcast, String broadcastMessage)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE FEEDER SET "
                             + "DB_ONLINE = ?, "
                             + "DB_MESSAGE = ?, "
                             + "SEND_TO_ELINK_OK = ?, "
                             + "SEND_TO_ELINK_MESSAGE = ?, "
                             + "IMPORT_OK = ?, "
                             + "IMPORT_MESSAGE = ?, "
                             + "DB_SHOW_MESSAGE = ?, "
                             + "DB_MESSAGE_BROADCAST = ? "
                             + "WHERE FEEDER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(online));
            ps.setString(2, dbMessage);
            ps.setInt(3, Misc.booleanToOracle(sendOK));
            ps.setString(4, sendMessage);
            ps.setInt(5, Misc.booleanToOracle(importOK));
            ps.setString(6, importMessage);
            ps.setInt(7, Misc.booleanToOracle(broadcast));
            ps.setString(8, broadcastMessage);
            ps.setString(9, feeder);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating feeder values.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates the TVIClient version on the FEEDER table
     * 
     * @param parentFrame
     * @param version
     * @return true if successful, false otherwise
     */
    public static boolean updateFeederVersion(Component parentFrame, String version)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE FEEDER SET CLIENT_VERSION = ? WHERE FEEDER = 'ALL'";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, version);
            
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating feeder version number.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the total number of users that will be loaded on the TVIAdmin Users table to set the progressbar maximum
     * 
     * @param parentFrame
     * @param onlineOnly
     * @return int
     */
    @SuppressFBWarnings(value="SQL_PREPARED_STATEMENT_GENERATED_FROM_NONCONSTANT_STRING", justification="no opportunity for SQL injection")
    public static int getUsersTableProgressRowCount(Component parentFrame, boolean onlineOnly)
    {
        Connection c = getConnection();
        int output = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sqlString;
        try
        {
            if (onlineOnly)
            {
                sqlString = "SELECT COUNT(*) AS ROWCOUNT FROM "
                          + "(SELECT A.SBCID, A.LAST_LOG, B.STATUS FROM "
                          + "(SELECT SBCID, MAX(ACCESS_TIME) LAST_LOG FROM USER_ACCESS_LOG WHERE SBCID IN "
                          + "(SELECT SBCID FROM USERS WHERE LAST_ONLINE > (SYSDATE - (15/24/60))) GROUP BY SBCID) A "
                          + "LEFT JOIN USER_ACCESS_LOG B ON A.SBCID = B.SBCID AND A.LAST_LOG = B.ACCESS_TIME WHERE B.STATUS = 'IN') C "
                          + "LEFT JOIN USERS D ON C.SBCID = D.SBCID";
            }
            else
            {
                sqlString = "SELECT COUNT(*) AS ROWCOUNT FROM USERS";
            }
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = rs.getInt("ROWCOUNT");
            }
        }
        catch (SQLException ex)
        {
            output = 0;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting USERS rowcount.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Adds a new user to the USERS table
     * 
     * @param parentFrame
     * @param sbcid
     * @param name
     * @param phone
     * @param email
     * @param type
     * @param addedBy
     */
    public static void addUser(Component parentFrame, String sbcid, String name, String phone, String email, String type, String addedBy)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        CallableStatement ocs = null;
        try
        {
            String sqlString = "INSERT INTO USERS("
                             + "SBCID, "
                             + "USER_NAME, "
                             + "USER_PHONE, "
                             + "USER_EMAIL, "
                             + "USER_TYPE, "
                             + "STATUS, "
                             + "DATE_ADDED, "
                             + "ADDED_BY, "
                             + "CHGD_BY, "
                             + "DATE_CHGD) "
                             + "VALUES (?, ?, ?, ?, ?, ?, SYSDATE, ?, ?, SYSDATE)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            ps.setString(2, name);
            ps.setString(3, phone);
            ps.setString(4, email);
            ps.setString(5, type);
            ps.setString(6, "ACTIVE");
            ps.setString(7, addedBy);
            ps.setString(8, addedBy);
            ps.executeUpdate();
            c.commit();
            
            try
            {
                Thread.sleep(1000);// to avoid USERS_AUDIT PK unique constraint on DATE_CHGD
            }
            catch (InterruptedException ex) { }
            
            Misc.msgbox(parentFrame, "User " + sbcid + " added successfully.", "", 1, 1, 1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error adding user.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets the specified user's current status
     * 
     * @param parentFrame
     * @param sbcid
     * @return String
     */
    public static String getCurrentStatus(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT STATUS FROM USERS WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            rs.next();
            output = rs.getString("STATUS");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting STATUS.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        return output;
    }
    
    /**
     * Gets the specified user's current user type
     * 
     * @param parentFrame
     * @param sbcid
     * @return String
     */
    public static String getUserType(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        String output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT USER_TYPE FROM USERS WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
            
            rs.next();
            output = rs.getString("USER_TYPE");
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting USER_TYPE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        
        return output;
    }
    
    /**
     * Sets the specified user as INACTIVE
     * 
     * @param parentFrame
     * @param sbcid
     * @param inactiveBy
     * @return true if successful, false otherwise
     */
    public static boolean setUserInactive(Component parentFrame, String sbcid, String inactiveBy)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SET_USER_INACTIVE( ?, ? ) }");
            ocs.setString(1, sbcid);
            ocs.setString(2, inactiveBy);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error setting user status to INACTIVE.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Sets the specified user's user type
     * 
     * @param parentFrame
     * @param sbcid
     * @param type
     * @return true if successful, false otherwise
     */
    public static boolean setUserType(Component parentFrame, String sbcid, String type)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE USERS SET USER_TYPE = ? WHERE SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, type);
            ps.setString(2, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating USER_TYPE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Adds to the specified user's permissions
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param accessLevel
     * @param sbcid
     * @param changedBy
     * @return true if successful, false otherwise
     */
    public static boolean addPermissions(Component parentFrame, String feeder, String site, String accessLevel, String sbcid, String changedBy)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "INSERT INTO PERMISSIONS("
                             +     "FEEDER, "
                             +     "SITE, "
                             +     "SBCID, "
                             +     "ACCESS_LEVEL, "
                             +     "DATE_CHANGED, "
                             +     "CHANGED_BY) "
                             + "VALUES (?, ?, ?, ?, SYSDATE, ?)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, sbcid);
            ps.setString(4, accessLevel);
            ps.setString(5, changedBy);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error adding user permissions.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Removes from the specified user's permissions
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean removePermissions(Component parentFrame, String feeder, String site, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "DELETE FROM PERMISSIONS WHERE FEEDER = ? AND SITE = ? AND SBCID = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error removing user permissions.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Updates the specified user's FORCE_LOGOFF status
     * 
     * @param parentFrame
     * @param forceLogoff
     * @param sbcid
     * @return true if successful, false otherwise
     */
    public static boolean updateForceLogoff(Component parentFrame, boolean forceLogoff, String sbcid)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            ps = c.prepareStatement("UPDATE USERS SET FORCE_LOGOFF = ? WHERE SBCID = ?");
            ps.setInt(1, Misc.booleanToOracle(forceLogoff));
            ps.setString(2, sbcid);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating FORCE_LOGOFF.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the next valid help topic file id
     * 
     * @param parentFrame
     * @return String
     */
    public static String getNextHelpTopicFileId(Component parentFrame)
    {
        Connection c = getConnection();
        String output = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT TO_CHAR(MAX(FILEID) + 1) AS NEXT_ID FROM TVI_DOCUMENTS";
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = rs.getString("NEXT_ID");
            }
        }
        catch (SQLException ex)
        {
            output = null;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting next FILE_ID.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Adds a help topic to the TVI_DOCUMENTS table
     * 
     * @param parentFrame
     * @param fileId
     * @param feeder
     * @param filename
     * @return true if successful, false otherwise
     */
    public static boolean addHelpTopic(Component parentFrame, String fileId, String feeder, String filename)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "INSERT INTO TVI_DOCUMENTS "
                             + " (FILEID, FILENAME, FEEDER, FILELOCATOR) "
                             + " (SELECT ?, ?, ?, BFILENAME('TVIDATA', ?) FROM DUAL)";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, fileId);
            ps.setString(2, filename);
            ps.setString(3, feeder);
            if (feeder.equals("NEW"))
            {
                ps.setString(4, filename);
            }
            else
            {
                ps.setString(4, "TVIHelp_" + filename);
            }
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error adding help topic.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Removes a help topic from the TVI_DOCUMENTS table
     * 
     * @param parentFrame
     * @param fileId
     * @param feeder
     * @return true if successful, false otherwise
     */
    public static boolean deleteHelpTopic(Component parentFrame, String fileId, String feeder)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "DELETE FROM TVI_DOCUMENTS "
                             + " WHERE FILEID = ? "
                             +   " AND FEEDER = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, fileId);
            ps.setString(2, feeder);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error deleting help topic.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Changes which feeders have access to a given help topic
     * 
     * @param parentFrame
     * @param fileId
     * @param oldFeeder
     * @param newFeeder
     * @return true if successful, false otherwise
     */
    public static boolean moveHelpTopic(Component parentFrame, String fileId, String oldFeeder, String newFeeder)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TVI_DOCUMENTS SET FEEDER = ? "
                             + " WHERE FILEID = ? "
                             +   " AND FEEDER = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, newFeeder);
            ps.setString(2, fileId);
            ps.setString(3, oldFeeder);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error moving help topic.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        
        return output;
    }
    
    /**
     * Makes the given user INACTIVE
     * 
     * @param parentFrame
     * @param uuid
     */
    public static void inactivateUser(Component parentFrame, String uuid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ZSUP_INACTIVATE_USER( ? ) }");
            ocs.setString(1, uuid);
            ocs.execute();
            Misc.msgbox(parentFrame, "User no longer active.", "Inactivate User", 1, 1, 1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inactivating user.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Checks if the given CMR is currently locked
     * 
     * @param parentFrame
     * @param CMRNumber
     * @return boolean
     */
    public static boolean getCMRLocked(Component parentFrame, int CMRNumber)
    {
        Connection c = getConnection();
        boolean output = false;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT LOCKED_BY FROM TVI_ADMIN_CMR WHERE CMR_NUMBER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, CMRNumber);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = rs.getString("LOCKED_BY") != null;
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking CMR lock.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Checks if the given CMR is currently locked
     * 
     * @param parentFrame
     * @param CMRNumber
     * @return String
     */
    public static String getCMRLockedBy(Component parentFrame, int CMRNumber)
    {
        Connection c = getConnection();
        String lockedBy = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT LOCKED_BY FROM TVI_ADMIN_CMR WHERE CMR_NUMBER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, CMRNumber);
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                lockedBy = Misc.objectToString(rs.getString("LOCKED_BY"));
            }
        }
        catch (SQLException ex)
        {
            lockedBy = "";
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking CMR lock.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return lockedBy;
    }
    
    /**
     * Locks or unlocks the given CMR record
     * 
     * @param parentFrame
     * @param CMRNumber
     * @param lockedBy
     * @return true if successful, false otherwise
     */
    public static boolean setCMRLocked(Component parentFrame, int CMRNumber, String lockedBy)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TVI_ADMIN_CMR SET LOCKED_BY = ? WHERE CMR_NUMBER = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, lockedBy);
            ps.setInt(2, CMRNumber);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error setting CMR lock.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Clears all CMR record locks for the given user
     * 
     * @param parentFrame
     * @param lockedBy
     * @return
     */
    public static boolean clearCMRLocks(Component parentFrame, String lockedBy)
    {
        Connection c = getConnection();
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE TVI_ADMIN_CMR SET LOCKED_BY = NULL WHERE LOCKED_BY = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, lockedBy);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error clearing CMR locks.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets details for the given CMR record
     * 
     * @param parentFrame
     * @param CMRNumber
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getCMRRow(Component parentFrame, int CMRNumber)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT "
                             +     "CMR_NUMBER, CMR_ORDER, DESC_BRIEF, DESC_FULL, TYPE, ON_PROJECT_LIST, USER_IMPACT, STATUS, "
                             +     "CATEGORY, DATE_CREATED, DATE_TARGET, DATE_COMPLETED, TVI_VERSION, ASSIGNED_TO, "
                             +     "CUSTOMER_NAME, PROJECT_NAME, ESTIMATED_HOURS, ACTUAL_HOURS "
                             + "FROM TVI_ADMIN_CMR "
                             +     "WHERE CMR_NUMBER = ? ";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, CMRNumber);
            
            rs = ps.executeQuery();
            rs.next();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CMR row.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Copies the permissions from one user to another
     * 
     * @param parentFrame
     * @param existingUUID
     * @param newUUID
     */
    public static void mirrorPermissions(Component parentFrame, String existingUUID, String newUUID)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL ZSUP_MIRROR_PERMISSIONS( ?, ? ) }");
            ocs.setString(1, existingUUID);
            ocs.setString(2, newUUID);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error mirroring permissions.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets permissions data for the given user
     * 
     * @param parentFrame
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsPermissions(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT FEEDER, SITE, ACCESS_LEVEL FROM PERMISSIONS "
                             + "WHERE SBCID = ? ORDER BY FEEDER, CAST(SITE AS INT)";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting user permissions data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets user access log data for the given user
     * 
     * @param parentFrame
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsUserAccessLog(Component parentFrame, String sbcid)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT ACCESS_TIME, STATUS, LOGON_FAILURE, EXIT_TYPE FROM USER_ACCESS_LOG "
                             + "WHERE SBCID = ? AND ACCESS_TIME > SYSDATE - 30 ORDER BY ACCESS_TIME DESC";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, sbcid);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting user access log data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets CMR table data for the Admin module
     * 
     * @param parentFrame
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminCMRs(Component parentFrame)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT CMR_NUMBER, CMR_ORDER, DESC_BRIEF, DESC_FULL, TYPE, ON_PROJECT_LIST, USER_IMPACT, STATUS, "
                             +     "CATEGORY, DATE_CREATED, DATE_TARGET, DATE_COMPLETED, TVI_VERSION, ASSIGNED_TO, "
                             +     "CUSTOMER_NAME, PROJECT_NAME, ESTIMATED_HOURS, ACTUAL_HOURS "
                             + "FROM TVI_ADMIN_CMR ORDER BY CMR_ORDER ASC, CAST(CMR_NUMBER AS INT), CAST(CMR_ORDER AS NUMBER)";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(1000);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CMR data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets users table data for the Admin module
     * 
     * @param parentFrame
     * @param onlineOnly
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminUsers(Component parentFrame, boolean onlineOnly)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_ADMIN_USERS( ?, ? ) }");
            ocs.setFetchSize(100);
            ocs.setInt(1, Misc.booleanToOracle(onlineOnly));
            ocs.registerOutParameter(2, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(2);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting users data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets help topics data for the Admin module
     * 
     * @param parentFrame
     * @param feeder
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminHelpTopics(Component parentFrame, String feeder)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT FILEID, FILENAME, FILELOCATOR FROM TVI_DOCUMENTS "
                             + " WHERE (FEEDER = ?) "
                             + " AND FILEID NOT IN (0,1) ORDER BY FILENAME";
            ps = c.prepareStatement(sqlString);
            ps.setFetchSize(100);
            ps.setString(1, feeder);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting help topics data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets clients table data for the Admin module
     * 
     * @param parentFrame
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminClients(Component parentFrame)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT CLIENT_NAME, CLIENT_VERSION, DB_ONLINE, DB_MESSAGE, SEND_OK, SEND_MESSAGE, IMPORT_OK, IMPORT_MESSAGE, DB_SHOW_MESSAGE, DB_MESSAGE_BROADCAST "
                             + "FROM TVI_CLIENTS ORDER BY CLIENT_NAME";
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting client data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets feeders table data for the Admin module
     * 
     * @param parentFrame
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminFeeders(Component parentFrame)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT FEEDER, DB_ONLINE, DB_MESSAGE, SEND_TO_ELINK_OK, SEND_TO_ELINK_MESSAGE, IMPORT_OK, IMPORT_MESSAGE, DB_SHOW_MESSAGE, DB_MESSAGE_BROADCAST "
                             + "FROM FEEDER ORDER BY FEEDER";
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting feeder data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Gets nde table data for the Admin module
     * 
     * @param parentFrame
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAdminNde(Component parentFrame)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT TVIP, NDE_ONLINE FROM NDE_URL ORDER BY TVIP";
            ps = c.prepareStatement(sqlString);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting nde data.");
        }
        return new ResultSetWrapper(rs, ps);
    }
    
    /**
     * Updates the NDE_URL table from the admin module.
     * 
     * @param parentFrame the frame to center messages on
     * @param tvip 
     * @param nde_online
     */
    public static void updateNde(Component parentFrame, String tvip, boolean nde_online)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        try
        {
            String sqlString = "UPDATE NDE_URL "
                             +    " SET NDE_ONLINE = ? "
                             +        " WHERE TVIP = ?";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, Misc.booleanToOracle(nde_online));
            ps.setString(2, tvip);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating NDE_ONLINE.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Gets the reconciliations date for the given site
     * 
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param startDate
     * @param endDate
     * @param sbcid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsReconciliations(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String sbcid)
    {
        Connection c = getConnection();
        ResultSet rsAbsences = null;
        ResultSet rsClockTimes = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_RECONCILIATIONS( ?, ?, ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(startDate));
            ocs.setDate(6, Misc.dateToSqlDate(endDate));
            ocs.setString(7, sbcid);
            ocs.registerOutParameter(8, OracleTypes.CURSOR);
            ocs.registerOutParameter(9, OracleTypes.CURSOR);
            
            ocs.execute();
            rsAbsences = (ResultSet)ocs.getObject(8);
            rsClockTimes = (ResultSet)ocs.getObject(9);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting reconciliations data.");
        }
        return new ResultSetWrapper(new ResultSet[]{rsAbsences, rsClockTimes}, ocs);
    }
    
    /**
     * Gets the data for the absence summary report for MEX
     * 
     * @param feeder
     * @param site
     * @param empList
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsAbsenceSummaryReportMEX(Component parentFrame, String feeder, String site, String empList, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ABSENCE_SUMMARY_MEX( ?, ?, ?, ?, ?, ? ) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empList);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting hours summary report data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the data for the extra off report for SVK, CZE
     * 
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsExtraOffReport(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_EXTRA_OFF( ?, ?, ?, ?, ? ) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting extra off report data.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Gets the records for the Absence Attendances Summary excel report.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param employeeSelection
     * @param startDate
     * @param endDate
     * @return ResultSet
     */
    public static ResultSetWrapper getAbsAttSummaryReportRecords(Component parentFrame, String feeder, String site, String employeeSelection, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_ABS_ATT_SUMMARY(?, ?, ?, ?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, employeeSelection);
            ocs.setDate(4, Misc.dateToSqlDate(startDate));
            ocs.setDate(5, Misc.dateToSqlDate(endDate));
            
            ocs.registerOutParameter(6, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(6);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting abs att sum records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Updates the import lock for specified schedule(s).
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @param lockedBy
     */
    public static void updateScheduleImportLock(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate, String lockedBy)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE SCHEDULES SET IMPORT_LOCKED = ? "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND MU = ? "
                      +      " AND REPORTING_DATE >= ? "
                      +      " AND REPORTING_DATE <= ? ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, lockedBy);
            ps.setString(2, feeder);
            ps.setString(3, site);
            ps.setString(4, mu);
            ps.setDate(5, Misc.dateToSqlDate(startDate));
            ps.setDate(6, Misc.dateToSqlDate(endDate));
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error updating import lock for schedule.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
    }
    
    /**
     * Gets the import lock for a specified schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @return true if any schedules are locked, false otherwise
     */
    public static boolean getScheduleImportLock(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean importLocked = false;
        try
        {
            sqlString = "SELECT COUNT(IMPORT_LOCKED) AS LOCKED FROM SCHEDULES "
                      +    " WHERE FEEDER = ? "
                      +      " AND SITE = ? "
                      +      " AND MU = ? "
                      +      " AND REPORTING_DATE >= ? "
                      +      " AND REPORTING_DATE <= ? "
                      +      " AND (IMPORT_LOCKED IS NOT NULL OR IMPORT_LOCKED <> '')";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(startDate));
            ps.setDate(5, Misc.dateToSqlDate(endDate));
            rs = ps.executeQuery();
            rs.next();
            importLocked = rs.getInt("LOCKED") > 0;
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error getting import lock for schedule.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return importLocked;
    }
    
    /**
     * Gets the employee's extra off days hour amount from the EMPLOYEES_TVI table.
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @return double hourAmount
     */
    public static double getExtraOffHours(Component parentFrame, String feeder, String site, String mu, String empid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        double extraOff = 0;
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_EXTRA_OFF_DAYS( ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.execute();
            extraOff = ocs.getDouble(1);
        }
        catch (SQLException ex)
        {
            extraOff = 0;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting employee extra off days.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return extraOff;
    }
    
    /**
     * Gets the sum of extra off hours taken for an employee for the given date range (start & end of year)
     *
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param empid
     * @param startDate
     * @param endDate
     * @return double hourAmount
     */
    public static double getExtraOffTaken(Component parentFrame, String feeder, String empid, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        String sqlString;
        double output = 0;
        PreparedStatement ps = null;
        ResultSet rs;
        try
        {
            sqlString = "SELECT SUM(HOURS_TREC) AS HOURS_TAKEN FROM TIME_ABSENCES_MASTER"
                      +   " WHERE FEEDER = ?" 
                      +     " AND EMPID = ?"
                      +     " AND SAP_CODE_TREC IN ('0112', '0530')"
                      +     " AND REPORTING_DATE >= ?"
                      +     " AND REPORTING_DATE <= ?";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, empid);
            ps.setDate(3, Misc.dateToSqlDate(startDate));
            ps.setDate(4, Misc.dateToSqlDate(endDate));
            rs = ps.executeQuery();
            
            if (rs.next())
            {
                output = Misc.objectToDouble(rs.getString("HOURS_TAKEN"));
            }
        }
        catch (SQLException ex)
        {
            output = 0;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting extra off day hours taken.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Gets the records for the CFAS validation input.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @return ResultSet
     */
    public static ResultSetWrapper getCFASValidationRecords(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_CFAS_VALIDATION(?, ?, ?) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            
            ocs.registerOutParameter(3, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(3);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting CFAS validation input records.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
    
    /**
     * Checks if there are any CFAS records ready to send that need to be validated by the CFAS ICE API
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if count > 0, false otherwise
     */
    public static boolean checkPendingAllocation(Component parentFrame, String feeder, String site)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_CFAS_VALIDATED ( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            output = (ocs.getInt(1) != 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking if cost allocations need to be validated.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * @param parentFrame the frame to center messages on
     * @param clientName
     * @param clientVersion
     * @return true if the version matches, false otherwise
     */
    public static boolean doesClientVersionMatch(Component parentFrame, String clientName, String clientVersion)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := DOES_CLIENT_VERSION_MATCH ( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, clientName);
            ocs.setString(3, clientVersion);
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check client version number.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the list of available clients for the given userid
     * 
     * @param parentFrame
     * @param sbcid
     * @return List<String> of available client names
     */
    public static List<String> getAvailableClients(Component parentFrame, String sbcid)
    {
        List<String> availableClients = new ArrayList<>();
        Connection c = getConnection();
        
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_USER_PERMISSIONS(?, ?) }");
            ocs.setString(1, sbcid);
            
            ocs.registerOutParameter(2, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(2);
            while (rs.next())
            {
                String clientName = rs.getString("CLIENT_NAME");
                if (!availableClients.contains(clientName))
                {
                    availableClients.add(clientName);
                }
            }
        }
        catch (SQLException ex)
        {
            // do nothing, return empty list of clients
        }
        finally
        {
            closeCursors(parentFrame, null, rs);
            closeCallableStatement(parentFrame, ocs);
        }
        return availableClients;
    }
    
    /**
     * Checks if the given MU(s) send cost allocation data
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu can pass null to check all MUs on site
     * @return true if the mu(s) have cost allocation data, false otherwise
     */
    public static boolean doesCostAllocation(Component parentFrame, String feeder, String site, String mu)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := DOES_COST_ALLOCATION ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check mu cost allocation usage.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the given employee has any sent records for the specified date.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @return true if there are any records currently sending, false otherwise
     */
    public static boolean isRecordSending(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := IS_RECORD_SENDING ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, empid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check if employee record is sending.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * gets the PayCycle for the given site
     * //DYADD can remove after INFOR release is completed and Misc.isImportAllowedInforTransition() is no longer used
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return String payCycle code
     */
    public static String getPayCycle(Component parentFrame, String feeder, String site)
    {
        String payCycle = "";
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT PAY_CYCLE FROM SITES WHERE FEEDER = ? AND SITE = ?";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            if (rs.next())
            {
                payCycle = rs.getString("PAY_CYCLE");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU pay cycle.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return payCycle;
    }
    
    /**
     * Updates TIME_TOTALS_MASTER records based on results from the ICE validation API and populates the PAYROLL_CFAS_DATA table
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param errorList
     * @param sbcid
     */
    public static void validateAllocations(Component parentFrame, String feeder, String site, String errorList, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL SEND_TO_CFAS(?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, errorList);
            ocs.setString(4, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error validating allocations - processing validation results.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Checks if it's okay to send for the given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName
     * @param feeder
     * @param site
     * @return true if it's okay to send, false otherwise
     */
    public static boolean isGeneratePayrollOkay(Component parentFrame, String clientName, String feeder, String site)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := IS_SENDING_OK ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER); // DYADD VARCHAR?
            ocs.setString(2, clientName);
            ocs.setString(3, feeder);
            ocs.setString(4, site);
            ocs.execute();
            String response = ocs.getString(1);
            output = response.substring(0, 1).equals("1");
            if (!output)
            {
                String message = response.substring(1);
                Misc.msgbox(parentFrame, message, "Payroll Generation Disabled", 1, 1, 1);
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check if payroll generation is okay.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if it's okay to import for the given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param clientName
     * @param feeder
     * @param site
     * @return true if it's okay to import, false otherwise
     */
    public static boolean isImportingOkay(Component parentFrame, String clientName, String feeder, String site)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := IS_IMPORTING_OK ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, clientName);
            ocs.setString(3, feeder);
            ocs.setString(4, site);
            ocs.execute();
            String response = ocs.getString(1);
            output = response.substring(0, 1).equals("1");
            if (!output)
            {
                String message = response.substring(1);
                Misc.msgbox(parentFrame, message, "Importing Disabled", 1, 1, 1);
            }
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check if importing is okay.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates TIME_ABSENCES_MASTER record, sets RECONCILED = -1 to indicate that the user wants to keep the minutes from IEX
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param reckey
     * @param sbcid
     * @return true if completed successfully, false otherwise
     */
    public static boolean setAbsenceReconciledFlag(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, int reckey, String sbcid)
    {
        boolean output = true;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_ABSENCE_RECONCILED_FLAG ( ?, ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setInt(6, reckey);
            ocs.setString(7, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Error setting reconciled flag for absence.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Updates TIME_ABSENCES_MASTER record, sets RECONCILED = -1 and updates the minute amount
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param reckey
     * @param minutes
     * @param sbcid
     * @return true if completed successfully, false otherwise
     */
    public static boolean setAbsenceReconciled(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, int reckey, int minutes, String sbcid)
    {
        boolean output = true;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL SET_ABSENCE_RECONCILED ( ?, ?, ?, ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setInt(6, reckey);
            ocs.setInt(7, minutes);
            ocs.setString(8, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Error reconciling absence.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Returns the date of the last time the Validate Allocations Button was pushed for given site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return date of last button push
     */
    public static Date getCFASButtonDate(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        Date output = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_CFAS_BUTTON_DATE (?, ?) }");
            ocs.registerOutParameter(1, java.sql.Types.DATE);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            output = Misc.sqlDateToDate(ocs.getDate(1));
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to GET_CFAS_BUTTON_DATE.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the site has at least one MU that needs to compute 3 day rule
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if the site does 3 day rule, false otherwise
     */
    public static boolean does3DayRule(Component parentFrame, String feeder, String site)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := DOES_THREE_DAY_RULE ( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check site 3 day rule usage.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the records to display for the EUROPE incidental open time excel report.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsIncidentalOT(Component parentFrame, String feeder, String site, Date reportingDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL RS_EXCEL_INCIDENTAL_OT(?, ?, ?, ?) }");
            ocs.setFetchSize(100);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.registerOutParameter(4, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(4);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting results for the Incidental Open Time Report.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
     /**
     * Checks of there are any payroll schedules or time codes not archived and archives them
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param attid
     * @param reportingDate
     * 
     * @return true it updated at least one payroll schedule or time code record
     */
    public static boolean resendToInfor(Component parentFrame, String feeder, String site, String mu, String attid, Date reportingDate)
    {
        boolean output = false;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := RESEND_TO_INFOR ( ?, ?, ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setString(4, mu);
            ocs.setString(5, attid);
            ocs.setDate(6, Misc.dateToSqlDate(reportingDate));
            ocs.execute();
            output = (ocs.getInt(1) == -1);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Failed to check site 3 day rule usage.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }  
       
    /**
     * Checks if any employees in the specified selection have have the new employee flag with no errors.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any employees in the selection are have the new employee flag with no errors, false otherwise
     */
    public static boolean areAnyNewEmployees(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * "
                             +    " FROM IEX_MU_ROSTER "
                             +        " WHERE FEEDER = ? "
                             +          " AND SITE = ? "
                             +          " AND SUBSTR(FLAG, 1, 2) = '00' "
                             +          " AND SUBSTR(FLAG, 6, 1) = '1' ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            
            output = rs.next();
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Returns a selected employee's history from IEX_MU_Roster.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empid
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper employeeHistory(Component parentFrame, String empid)
    {
        Connection c = getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
		            String sqlString = "SELECT CASE WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '1' THEN 'Broadband' "
                                                         +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '2' THEN 'Wireline Finance' "
                                                         +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '4' THEN 'Network' "
							 +    " WHEN TVIP = 'attmb2-nde.nicecloudsvc.com' AND CUSTNUM = '2' THEN 'Charlotte' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '3' THEN 'New Jersey' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '4' THEN 'CIS' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '6' THEN 'Wichita' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '7' THEN 'Teleconferencing' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '8' THEN 'Small Business' "
							 +    " WHEN TVIP = 'attmb1-nde.nicecloudsvc.com' AND CUSTNUM = '10' THEN 'GSA' "
							 +    " WHEN TVIP = 'attmb3-nde.nicecloudsvc.com' AND CUSTNUM = '1' THEN 'Mobility Consumer' "
							 +    " WHEN TVIP = 'attmb4-nde.nicecloudsvc.com' AND CUSTNUM = '2' THEN 'Mobility Business' "
							 +    " WHEN TVIP = 'attgtewfm-nde.nicecloudsvc.com' AND CUSTNUM = '1' THEN 'SVC Delivery' "
							 +    " ELSE 'Unknown Instance' "
							 +    " END AS IEX_INSTANCE, FEEDER, SITE, MU, EMPLOYEE, EMPID, AGENTID, TVIP, CUSTNUM, START_DATE, "
							 +    " CASE WHEN END_DATE = TO_DATE('01/01/3000', 'MM/DD/YYYY') THEN NULL ELSE END_DATE END AS END_DATE, STATUS, DO_NOT_IMPORT, FLAG "
                                                         +    " FROM IEX_MU_ROSTER "
							 +          " WHERE EMPID = ? "
                                                         +        " ORDER BY START_DATE DESC";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, empid);
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, true, "SQL Error getting site info.");
        }
        return new ResultSetWrapper(rs, ps);
    } 
        
    /**
     * Gets the total number of non-ignored import notifications for sites using MU Roster.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return total number of non-ignored import notifications for sites using MU Roster
     */
    public static int getNumRosterNotifications(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT COUNT(*) FROM LOAD_STATUS_ERRORS A "
                             + " INNER JOIN "
                             + " IEX_MU_ROSTER B "
                             + " ON A.FEEDER = B.FEEDER "
                             + " AND A.SITE = B.SITE "
                             + " AND A.MU = B.MU "
                             + " AND A.AGENTID = B.AGENTID "
                             + " AND A.EMPLOYEE = B.EMPLOYEE "
                             + " AND A.REPORTING_DATE >= B.START_DATE "
                             + " AND A.REPORTING_DATE <= B.END_DATE "
                             +    " WHERE A.FEEDER = ? "
                             +      " AND A.SITE = ? "
                             +      " AND A.MU = ? "
                             +      " AND A.REPORTING_DATE = ? "
                             +      " AND B.DO_NOT_IMPORT = 0 ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getInt("COUNT(*)");
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU Roster Import notifications.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
    /**
     * Gets the list of employees with load status errors for a schedule.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param reportingDate
     * @return ResultSetWrapper
     */
    public static ResultSetWrapper getResultsRosterNotifications(Component parentFrame, String feeder, String site, String mu, Date reportingDate)
    {
        Connection c = getConnection();
        String sqlString;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            sqlString = "SELECT A.FEEDER, A.SITE, A.MU, A.EMPID, A.AGENTID, A.EMPLOYEE, A.REPORTING_DATE, NVL(B.DO_NOT_IMPORT, 0) AS DO_NOT_IMPORT, "
                      +      " A.PROGRAM_START, A.PROGRAM_STOP, A.LOAD_STATUS, A.ERROR_TEXT, A.ERROR_STEPS_TO_CORRECT, A.TVI_USER "
                      +      " FROM LOAD_STATUS_ERRORS A "
                      +      " LEFT JOIN "
                      +      " IEX_MU_ROSTER B "
                      +      " ON A.FEEDER = B.FEEDER "
                      +      " AND A.SITE = B.SITE "
                      +      " AND A.MU = B.MU "
                      +      " AND A.AGENTID = B.AGENTID "
                      +      " AND A.EMPLOYEE = B.EMPLOYEE "
                      +      " AND A.REPORTING_DATE >= B.START_DATE "
                      +      " AND A.REPORTING_DATE <= B.END_DATE "
                      +          " WHERE A.FEEDER = ? "
                      +            " AND A.SITE = ? "
                      +            " AND A.MU = ? "
                      +            " AND A.REPORTING_DATE = ? "
                      +          " ORDER BY A.EMPLOYEE ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setString(3, mu);
            ps.setDate(4, Misc.dateToSqlDate(reportingDate));
            rs = ps.executeQuery();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting duplicate employees.");
        }
        return new ResultSetWrapper(rs, ps);
    }
       
    /**
     * Attempts to inactivate an employee on the given feeder, site, mu.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param agentid
     * @param employee
     * @param reportingDate
     * @param doNotImport
     * @param programStart
     * @param programStop
     * @param loadStatus
     * @param errorText
     * @param errorStepsToCorrect
     * @param tviUser AT&T UUID indicating the user submitting the change
     * @return true if successful, false otherwise
     */
    public static boolean updateRosterNotifications(Component parentFrame, String feeder, String site, String mu, String empid, String agentid, 
                                                    String employee, Date reportingDate, int doNotImport, Date programStart, Date programStop, 
                                                    int loadStatus, String errorText, String errorStepsToCorrect, String tviUser)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE IEX_MU_ROSTER "
                      + " SET DO_NOT_IMPORT = ? "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND MU = ? "
                      +       " AND AGENTID = ? "
                      +       " AND EMPLOYEE = ? "                    
                      +       " AND START_DATE <= ? "
                      +       " AND END_DATE >= ? ";
            ps = c.prepareStatement(sqlString);
            ps.setInt(1, doNotImport);
            ps.setString(2, feeder);
            ps.setString(3, site);
            ps.setString(4, mu);
            ps.setString(5, agentid);
            ps.setString(6, employee);
            ps.setDate(7, Misc.dateToSqlDate(reportingDate));
            ps.setDate(8, Misc.dateToSqlDate(reportingDate));
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error inactivating employee.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
    
    /**
     * Updates IEX_MU_ROSTER for the current site
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param sbcid
     * @return true if completed successfully, false otherwise
     */
    public static boolean updateIexMuRoster(Component parentFrame, String feeder, String site, String sbcid)
    {
        boolean output = true;
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL CREATE_MU_ROSTER_FILE ( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, true, "Error updating MU Roster.");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
            
    /**
     * Gets the total number of MUs requesting MU Roster Updates for Current Feeder and Site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return total number of MUs requesting updates to MU Roster
     */
    public static int getNumMURosterRequesting(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT COUNT(*) FROM IEX_MU_ROSTER_STATUS "
                             + " WHERE FEEDER = ? "
                             + " AND SITE = ? "
                             + " AND STATUS = 'Requesting' ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getInt("COUNT(*)");
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting MU Roster update count.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
     
    /**
     * Gets How Long Ago MU Roster was Last Updated
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return the hours and minutes of how long ago MU Roster was updated"
     */
    public static String getRosterTimeStamp(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        String lastUpdated = "0 Hours ago";
        try
        {
            ocs = c.prepareCall("{CALL ? := UPDATE_IEX_MU_ROSTER_TIMESTAMP( ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.execute();
            lastUpdated = ocs.getString(1);
            
        }
        catch (SQLException ex)
        {
            Misc.msgbox(parentFrame, "ERROR Retrieving last updated timestamp", "TVI Timestamp Update Error", 1, 1, 2);
            return lastUpdated;
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return lastUpdated;
    }
           
    /**
     * Checks if any employees in the specified selection have have the new error flag.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any employees in the selection have the new error flag, false otherwise
     */
    public static boolean areAnyNewErrorFlag(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        boolean output;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = "SELECT * FROM IEX_MU_ROSTER "
                             + " WHERE FEEDER = ? "
                             + " AND SITE = ? "
                             + " AND SUBSTR(FLAG, 6, 1) = '2' "
                             + " AND ((SUBSTR(FLAG, 1, 1) = '1' AND END_DATE > SYSDATE - 365) OR "
                             +  "      SUBSTR(FLAG, 1, 1) = '2' OR "
                             +  "      SUBSTR(FLAG, 1, 1) = '3' OR "
                             +  "      SUBSTR(FLAG, 2, 1) = '1') ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            rs = ps.executeQuery();
            
            output = rs.next();
        }
        catch (SQLException ex)
        {
            output = true;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking employee status.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
          
    /**
     * Removes the new error flag from selected feeder and site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return true if any employees in the selection have the new error flag, false otherwise
     */
    public static boolean updateNewErrorFlag(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        String sqlString;
        boolean output = true;
        PreparedStatement ps = null;
        try
        {
            sqlString = "UPDATE IEX_MU_ROSTER "
                      + " SET FLAG = SUBSTR(FLAG, 1, 5) || '0' "
                      +     " WHERE FEEDER = ? "
                      +       " AND SITE = ? "
                      +       " AND SUBSTR(FLAG, 6, 1) = '2' ";
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.executeUpdate();
            c.commit();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error removing new error flag.");
        }
        finally
        {
            closeCursors(parentFrame, ps, null);
        }
        return output;
    }
        
    /**
     * Updates the employees coaches to match the stored webphone supervisor value.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param empList list of empids; if null is passed, all employees on the given site and feeder will be updated
     * @return true if successful, false otherwise
     */
    public static boolean updateTVICoaches(Component parentFrame, String feeder, String site, ArrayList<String> empList)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        
        String empListCSV;
        if (empList == null)
        {
            empListCSV = "ALL";
        }
        else
        {
            empListCSV = Misc.listToStringCSV(empList);
        }
        
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_TVI_COACHES( ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, empListCSV);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error updating coaches.");
            output = false;
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Gets the total number of Schedules being requesting for Current Feeder and Site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @return total number of Schedules requesting for feeder and site
     */
    public static int getNumSchedulesRequesting(Component parentFrame, String feeder, String site)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT COUNT(*) FROM SCHEDULES "
                             + " WHERE FEEDER = ? "
                             + " AND SITE = ? "
                             + " AND STATUS = 'Requesting' ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getInt("COUNT(*)");
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting SCHEDULES Requesting count.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
    
     /**
     * Sets the RESEND_FLAG in TIME_TOTALS_MASTER
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param empid
     * @param reportingDate
     * @param changedBy
     */
     public static boolean setResendFlag(Component parentFrame, String feeder, String site, String mu, String empid, Date reportingDate, String changedBy)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        boolean output = false;
        try
        {
            ocs = c.prepareCall("{CALL TT_UPDATE_RESEND_FLAG( ?, ?, ?, ?, ?, ? ) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setString(3, mu);
            ocs.setString(4, empid);
            ocs.setDate(5, Misc.dateToSqlDate(reportingDate));
            ocs.setString(6, changedBy);
            ocs.execute();
            output=true;
            
        }
        
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error setting resend flag");
            output = false;
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }

     /**
     * Gets the next reckey from either total_absences_master or extra_payments_master
     * 
     * @param parentFrame the frame to center messages on
     * @param empid
     * @param reportingDate
     * @param table
     * @return next reckey for the specified empid and reporting date
     */
     public static int getNextReckey(Component parentFrame, String empid, Date reportingDate, String table)
    {
        Connection c = getConnection();
        int reckey = 1;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := GET_NEXT_RECKEY( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, empid);
            ocs.setDate(3, Misc.dateToSqlDate(reportingDate));
            ocs.setString(4, table);
            ocs.execute();
            reckey=ocs.getInt(1);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting the next reckey");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return reckey;
    }
     
     /**
     * Gets the last date that MWL_TIMECODE_AUDIT or MWL_TIMECODE_DATA got updated
     * 
     * @param parentFrame the frame to center messages on
     * @return the date that INFOR timecodes got updated"
     */
    public static String getInforTimecodeTimeStamp(Component parentFrame)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        String lastUpdated = "";
        try
        {
            ocs = c.prepareCall("{CALL ? := UPDATE_INFOR_TIMESTAMPS }");
            ocs.registerOutParameter(1, java.sql.Types.VARCHAR);
            ocs.execute();
            lastUpdated = ocs.getString(1);
            
        }
        catch (SQLException ex)
        {
            return "ERROR";
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
        return lastUpdated;
    }
    
    /**
     * Unlocks all records locked by an employee
     * 
     * @param parentFrame the frame to center messages on
     * @param empid 
     */
    public static void unlockRecordsByUser(Component parentFrame, String empid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL RS_UNLOCK_RECORDS( ?) }");
            ocs.setString(1, empid);
            ocs.execute();
            
        }
        
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error Unlocking Records");
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
        /**
     * Payroll close part-time overtime calculations for CZE
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payrollEndDate
     * @return true if successful, false otherwise
     */
    public static boolean calculateParttimeOT(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        boolean output = true;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL COMPUTE_PARTTIME_OT_CZE(?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(payrollEndDate));
            ocs.execute();
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to COMPUTE_PARTTIME_OT_CZE.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
    /**
     * Checks if the premium calculations package for MEXICO has been run.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site pass null to check for entire feeder
     * @param startDate payroll start
     * @param endDate payroll end
     * @return true if the partial abs package has been run for this period
     */
    public static boolean isParttimeOTCalculatedCZE(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        Connection c = getConnection();
        boolean output = false;
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{CALL ? := CHECK_CZE_PARTTIME_OT ( ?, ?, ? ) }");
            ocs.registerOutParameter(1, java.sql.Types.INTEGER);
            ocs.setString(2, feeder);
            ocs.setString(3, site);
            ocs.setDate(4, Misc.dateToSqlDate(payrollEndDate));
            ocs.execute();
            output = (ocs.getInt(1) == 0);
        }
        catch (SQLException ex)
        {
            output = false;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to CHECK_CZE_PARTTIME_OT.");
        }
        finally
        {
            output = output & closeCallableStatement(parentFrame, ocs);
        }
        return output;
    }
    
        /**
     * Gets the list of MUs for the specified feeder, site, and time frame
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return ArrayList<String> of MUs
     */
    public static ResultSetWrapper getFutureScheduleList(Component parentFrame, String feeder, String site, Date startDate, Date endDate)
    {
        Connection c = getConnection();
        ResultSet rs = null;
        CallableStatement ocs = null;
        
        try
        {
            ocs = c.prepareCall("{ CALL RS_FUTURE_SCHEDULE_LIST( ?, ?, ?, ?, ? ) }");
            ocs.setFetchSize(1000);
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.registerOutParameter(5, OracleTypes.CURSOR);
            
            ocs.execute();
            rs = (ResultSet)ocs.getObject(5);
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting future schedule list.");
        }
        return new ResultSetWrapper(rs, ocs);
    }
        
    /**
     * Reimports future schedules for the specified pay period
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param startDate first day in the date range
     * @param endDate last day in the date range; for a single day, identical to startDate
     * @param sbcid uuid of the current user
     */
    public static void requestFutureSchedule(Component parentFrame, String feeder, String site, Date startDate, Date endDate, String sbcid)
    {
        Connection c = getConnection();
        CallableStatement ocs = null;
        try
        {
            ocs = c.prepareCall("{ CALL UPDATE_FUTURE_SCHEDULES ( ?, ?, ?, ?, ?) }");
            ocs.setString(1, feeder);
            ocs.setString(2, site);
            ocs.setDate(3, Misc.dateToSqlDate(startDate));
            ocs.setDate(4, Misc.dateToSqlDate(endDate));
            ocs.setString(5, sbcid);
            ocs.execute();
        }
        catch (SQLException ex)
        {
            while (ex != null)
            {
                if (ex.getErrorCode() == 20001)
                {
                    String errorMsg = ex.getMessage().substring(11, ex.getMessage().indexOf("ORA-", 11) -1);
                    Misc.msgbox(parentFrame, errorMsg, "TVI Message", 1, 1, 1);
                }
                else
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error in call to SCHEDULE_1_REQUEST.");
                }
                ex = ex.getNextException();
            }
        }
        finally
        {
            closeCallableStatement(parentFrame, ocs);
        }
    }
    
    /**
     * Gets the total number of Schedules being requesting for Current Feeder and Site.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param payStartDate
     * @param payClose
     * @return total number of Locked Future Schedules for feeder and site
     */
    public static int getNumLockedFutureSchedules(Component parentFrame, String feeder, String site, Date payStartDate, Date payClose)
    {
        Connection c = getConnection();
        int output = -1;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            String sqlString = " SELECT COUNT(*) FROM SCHEDULES "
                             + " WHERE FEEDER = ? "
                             + " AND SITE = ? "
                             + " AND REPORTING_DATE >= ? "
                             + " AND REPORTING_DATE <= ? "
                             + " AND FUTURE_LOAD = '-1' "
                             + " AND IMPORT_LOCKED IS NOT NULL ";
            
            ps = c.prepareStatement(sqlString);
            ps.setString(1, feeder);
            ps.setString(2, site);
            ps.setDate(3, Misc.dateToSqlDate(payStartDate));
            ps.setDate(4, Misc.dateToSqlDate(payClose));
            
            rs = ps.executeQuery();
            rs.next();
            
            output = rs.getInt("COUNT(*)");
        }
        catch (SQLException ex)
        {
            output = -1;
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error getting Future SCHEDULES Locked count.");
        }
        finally
        {
            closeCursors(parentFrame, ps, rs);
        }
        return output;
    }
}