package tvicore.dao;

public class AbsenceCodeRecord
{
    private String sapCode;
    private String description;
    private String process1Trec;
    private String process2Trec;
    private String process3Trec;
    private boolean reasonCodeRequired;
    private boolean add2RegPlusAbs;
    private String unionFlags;
    
    public AbsenceCodeRecord(String sapCode, String description, String process1Trec, String process2Trec, String process3Trec, boolean reasonCodeRequired, boolean add2RegPlusAbs, String unionFlags)
    {
        this.sapCode = sapCode;
        this.description = description;
        this.process1Trec = process1Trec;
        this.process2Trec = process2Trec;
        this.process3Trec = process3Trec;
        this.reasonCodeRequired = reasonCodeRequired;
        this.add2RegPlusAbs = add2RegPlusAbs;
        this.unionFlags = unionFlags;
    }
    
    public String getSapCode()            { return sapCode; }
    public String getDescription()        { return description; }
    public String getProcess1Trec()       { return process1Trec; }
    public String getProcess2Trec()       { return process2Trec; }
    public String getProcess3Trec()       { return process3Trec; }
    public boolean isReasonCodeRequired() { return reasonCodeRequired; }
    public boolean isAdd2RegPlusAbs()     { return add2RegPlusAbs; }
    public String getUnionFlags()         { return unionFlags; }
    
    public void setSapCode(String value)             { sapCode = value; }
    public void setDescription(String value)         { description = value; }
    public void setProcess1Trec(String value)        { process1Trec = value; }
    public void setProcess2Trec(String value)        { process2Trec = value; }
    public void setProcess3Trec(String value)        { process3Trec = value; }
    public void setReasonCodeRequired(boolean value) { reasonCodeRequired = value; }
    public void setAdd2RegPlusAbs(boolean value)     { add2RegPlusAbs = value; }
    public void setUnionFlags(String value)          { unionFlags = value; }
    
    @Override
    public String toString() { return sapCode; }
}