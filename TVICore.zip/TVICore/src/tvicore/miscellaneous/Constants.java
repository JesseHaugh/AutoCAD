package tvicore.miscellaneous;

import java.awt.Color;
import java.awt.Cursor;
import javax.swing.JLabel;

public class Constants
{
    public static final String HOTLINE = "(619-258-8113)";
    public static final String EMAIL = "m16666@att.com";
    
    public static final Cursor HOURGLASS = new Cursor(Cursor.WAIT_CURSOR);
    public static final Cursor NORMAL = new Cursor(Cursor.DEFAULT_CURSOR);
    
    public static final int LEFT = JLabel.LEFT;
    public static final int RIGHT = JLabel.RIGHT;
    public static final int CENTER = JLabel.CENTER;
    
    public static final Color BLACK    = new Color(  0,   0,   0);
    public static final Color CYAN     = new Color(183, 255, 255);
    public static final Color DKGREY   = new Color(192, 192, 192);
    public static final Color SALMON   = new Color(255, 204, 153);
    public static final Color YELLOW   = new Color(255, 255, 128);
    public static final Color GREEN    = new Color(  0, 204, 153);
    public static final Color LTBLUE   = new Color(100, 200, 255);
    public static final Color LTORANGE = new Color(255, 200, 150);
    public static final Color LTGREEN  = new Color(200, 255, 200);
    public static final Color LTYELLOW = new Color(255, 255, 200);
    public static final Color LTRED    = new Color(255, 200, 200);
    public static final Color DKRED    = new Color(230,  60,  40);
    
    public static final String[] manualCompleteMessages = {
    "",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI! "
        + "<br><br>If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>Elink does not allow changes to Disabilities or Disability Annual Grants. "
        + "<br><br>You are  required to review and manually close these transactions. "
        + "<br><br>Manually close if you are sure eLink is correct</html>",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>For an employee who is inactive in eLink because they are on a Leave of Absence (LOAD) you have two options:"
        + "<br> 1. Manually close the record each day."
        + "<br>   OR"
        + "<br> 2. Inactivate the employee to prevent future imports"
        + "<br>    Delete the employee from this screen. "
        + "<br>    Activate the employee in TVI when they return to work to resume importing.</html>",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>"
        + "If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>Elink allows only the shift to be updated when an employee is on a full day of Disability (DISU)."
        + "<br>  -Click on the Resend-Shift Only button at the top of the time editing screen."
        + "<br>  -This will send the shift only to eLink.  "
        + "<br>  -The shift may be adding or removing a differential and is required to be updated through TVI."
        + "<br><br>  Once the update is complete you can manually close in TVI."
        + "<br>  If you are changing from an OFF day to a scheduled day or a scheduled day to an OFF day:"
        + "<br>  -Check eLink for correct schedule substitution and absence detail</html>",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>"
        + "If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>The record you are trying to change is greater than 365 days old.  "
        + "<br>This record cannot be changed via TVI or directly in eLink."
        + "<br>If the time change is pay affecting: "
        + "<br>  The GTR or Supervisor should complete the SBC30210 form including the pay affecting amount"
        + "<br>  and fax it to Payroll Services."
        + "<br>"
        + "<br>If the time change is not pay affecting: "
        + "<br>   The department should manually track the time change. "
        + "<br>   Additions or reductions to entitlements (vacation or personal days off) "
        + "<br>should be processed by completing, authorizing and submitting an *Update Leave Entitlement Form.</html>",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>"
        + "If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>If the time change is for a Work Reporting employee and the change is greater than 90 days old "
        + "<br> but less than 365 days:"
        + "<br>   1.  Check eLink"
        + "<br>      - If correct manually complete in TVI"
        + "<br>      - If not correct"
        + "<br>         --The department should issue a HROneStop on-line ticket by visiting the Payroll & Tax Information."
        + "<br>         --HROneStop will coordinate with Tier II in Payroll Services to make the change.  "
        + "<br>         --Payroll Services will validate the request and notify the GTR or Supervisor after the change has been made."
        + "<br>         --Manually complete in TVI</html>",
        "",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>"
        + "If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>Project closed for charges - any changes, other than to the hours charged to closed project, must be done directly in eLink."
        + "<br>"
        + "<br>   1.  Check eLink"
        + "<br>       - If correct manually complete in TVI"
        + "<br>       - If not correct"
        + "<br>          1. correct directly in eLink"
        + "<br>          2. manually complete in TVI</html>",
    "<html>By Manually Completing this employee you are indicating that ELINK is correct "
        + "<br> OR you will be making changes to this employee outside of TVI!"
        + "<br><br>"
        + "If this is NOT correct Hit CANCEL Now!"
        + "<br><br>------------------------------------------------------------------------------------------------"
        + "<br>Partial Disability or Disabilty Annual Grant:"
        + "<br>"
        + "<br>  If you have an absence in addition to a partial disability and you are trying to change "
        + "<br>  the shift to or from a differential shift eLink will not allow updating of the schedule substitution."
        + "<br>  You will need to call HROnestop to have the schedule substitution updated."
        + "<br>"
        + "<br>  If you are trying to add Absence, Attendance or Extra Payment detail, check eLink and "
        + "<br>  verify what is currently in eLink.  Try to update directly in eLink if needed. "
        + "<br>  If you cannot update eLink directly, call HROnestop to adjust any codes which could not be updated"
        + "<br>  by you directly in eLink, then manually complete this transaction in TVI.</html>"
    };
}
