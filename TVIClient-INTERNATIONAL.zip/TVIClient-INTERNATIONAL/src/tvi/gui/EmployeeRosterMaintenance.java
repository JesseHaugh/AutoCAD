/**
 * This form can be opened in several different ways.
 *   These are determined by the string editType, which can be the following values:
 *     NORMAL           - Displays all employees by feeder & site
 *     DETAIL           - Displays a detailed view on a single employee, set by passing a non-null attid value in the constructor
 */

package tvi.gui;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.objects.HoursEditor;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class EmployeeRosterMaintenance extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile EmployeeRosterMaintenance instance;
    
    private final String feeder;
    private final String site;
    String attid;
    private final Date curDate;
    String editType;
    
    JTable empTable = new JTable();
    JTable rosterTable = new JTable();
    CustomTableModel empData;
    CustomTableModel rosterData;
    TableSwingWorker empWorker;
    TableSwingWorker rosterWorker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    boolean formClosing = false;
    boolean changingEmployees = false;
    boolean changingRoster = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    boolean employeeUpdated = false;
    boolean rosterUpdated = false;
    int currentEmpRow = -1;
    int currentRosterRow = -1;
    int employeeCount = 0;
    int rosterCount = 0;
    
    boolean filterEnabled = true;
    int filterColumn = -1;
    private String employeeStatusFilterText = "^ACTIVE$";
    private String empidFilterText = ".*";
    private TableRowSorter<CustomTableModel> empSorter;
    private TableRowSorter<CustomTableModel> rosterSorter;
    
    JComboBox<String> bandCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> currentStatusCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> pendingStatusCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> currentDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> ncsDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> pendingDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
 
    // Define index variables to reference columns in the TVI_EMPLOYEES Table
    final static int idx_Emp_PARTTIME_FLAG          = 0;
    final static int idx_Emp_BILINGUAL_FLAG         = 1;
    final static int idx_Emp_HOURS_PER_WEEK         = 2;
    final static int idx_Emp_BAND                   = 3;
    final static int idx_Emp_MU                     = 4;
    final static int idx_Emp_EMPID                  = 5;
    final static int idx_Emp_OTHER_PAYROLL_ID       = 6;
    final static int idx_Emp_EMPLOYEE               = 7;
    final static int idx_Emp_COACH                  = 8;
    final static int idx_Emp_WEBPHONE_SUPERVISOR    = 9;
    final static int idx_Emp_NCS_DATE               = 10;
    final static int idx_Emp_CHILD_BIRTH_DATE       = 11;
    final static int idx_Emp_EXTRA_OFF_DAYS         = 12;
    final static int idx_Emp_STATUS                 = 13;
    final static int idx_Emp_EFFECTIVE_DATE         = 14;
    final static int idx_Emp_FOUR_DAY               = 15;
    final static int idx_Emp_SIX_DAY                = 16;
    
    // Define index variables to reference columns in the IEX_MU_ROSTER empTable
    final static int idx_Mu_IEX_INSTANCE            = 0;
    final static int idx_Mu_FEEDER                  = 1;
    final static int idx_Mu_SITE                    = 2;
    final static int idx_Mu_MU                      = 3;
    final static int idx_Mu_EMPLOYEE                = 4;
    final static int idx_Mu_EMPID                   = 5;
    final static int idx_Mu_AGENTID                 = 6;
    final static int idx_Mu_TVIP                    = 7;
    final static int idx_Mu_CUSTNUM                 = 8;
    final static int idx_Mu_START_DATE              = 9;
    final static int idx_Mu_END_DATE                = 10;
    final static int idx_Mu_STATUS                  = 11;
    final static int idx_Mu_DO_NOT_IMPORT           = 12;
    final static int idx_Mu_FLAG                    = 13;
    public synchronized static EmployeeRosterMaintenance getInstance(Component parentFrame, String feeder, String site, String attid)
    {
        if (instance != null)
        {
            if (Misc.objectEquals(instance.attid, attid))
            {
                instance.toFront();
            }
            else
            {
                instance.closeForm();
            }
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new EmployeeRosterMaintenance(feeder, site, attid);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private EmployeeRosterMaintenance(String feeder, String site, String attid)
    {
        this.feeder = feeder;
        this.site = site;
        this.attid = attid;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        if (attid != null)
        {
            editType = "DETAIL";
        }
        else
        {
            editType = "NORMAL";
        }
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        subtitleLabel2.setText("Employees marked in gray are active on another site. To modify them, email TVI at " + Constants.EMAIL + ".");
        
        powerUserOverrideCheckBox.setVisible(UserData.getUserType().equals("POWER"));
        deleteRecordButton.setVisible(false);
        updatePayrollIDsButton.setVisible(Arrays.asList("MEX", "POL", "SVK").contains(feeder));
        separatedEmployeesButton.setVisible(feeder.equals("MEX"));
        LOAEmployeesButton.setVisible(feeder.equals("MEX"));
        
        updateCoachButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        updateAllCoachesButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        
        bandCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "MGRA", "MGRB", "PROA4", "PROA5", "PROB"}));
        bandCombo.setEditable(true);
        currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"INACTIVE", "SEPARATED"}));
        currentStatusCombo.addItemListener(new ItemListener()
        {
            Object previousSelection = null;
            
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                int selectedRow = empTable.getSelectedRow();
                if (selectedRow != -1)
                {
                    if (e.getStateChange() == ItemEvent.DESELECTED)
                    {
                        previousSelection = e.getItem();
                    }
                    else if (currentStatusCombo.getSelectedItem().equals("SEPARATED"))
                    {
                        if (!UserData.getUserType().equals("POWER"))
                        {
                            //revert and give message
                            JComboBox combobox = (JComboBox)e.getSource();
                            combobox.setSelectedItem(previousSelection);
                            Misc.msgbox(getFormComponent(), "SEPARATED status is reserved for employees that are no longer in webphone.\nIf you wish to stop reporting for this employee, set them to DO NOT IMPORT \nor update their status in IEX and update MU Roster.", "Employee Status", 1, 1, 1);
                        }
                        
                    }
                    else if (currentStatusCombo.getSelectedItem().equals("INACTIVE"))
                    {
                        Misc.msgbox(getFormComponent(), "This employee was made separated because they were no longer in webphone.\nIf this is still the case they will be made separated again overnight. \nIf they are Active, update MU Roster to make them Active.", "Employee Status", 1, 1, 1);
                    }
                }
            }
        });
        
        filterTextField.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override public void insertUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void removeUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void changedUpdate(DocumentEvent e) { processFilter(); }
        });
        
        curDate = Misc.dateNoTime(Oracle.getCurTimeLocal(getFormComponent()));
        Calendar cal = Calendar.getInstance();
        cal.setTime(curDate);
        
        ncsDateCombo.removeAllItems();
        cal.setTime(curDate);
        ncsDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        for (int i = 0; i < 30; i++)
        {
            cal.add(Calendar.DAY_OF_YEAR, -1);
            ncsDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        }
        ncsDateCombo.setEditable(true);
        
        if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
        {
            filterColumnComboBox.addItem("PAYROLL ID");
            //minor fix to display, sets loading scroll pane to correct width for INT feeders (extra 100 for Payroll ID column)
            Dimension dim = employeesScrollPane.getMaximumSize();
            employeesScrollPane.setMaximumSize(new Dimension(dim.width + 100, dim.height));
        }
    }
    
    public String getATTID()
    {
        return attid;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        deleteRecordButton = new javax.swing.JButton();
        powerUserOverrideCheckBox = new javax.swing.JCheckBox();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        empidLabel = new javax.swing.JLabel();
        employeeLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        subtitleLabel1 = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        rosterScrollPane = new javax.swing.JScrollPane();
        loadingLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        employeesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        gridPanel = new javax.swing.JPanel();
        filterLabelsPanel = new javax.swing.JPanel();
        filterColumnTextLabel = new javax.swing.JLabel();
        filterTextLabel = new javax.swing.JLabel();
        filterEmployeeStatusLabel = new javax.swing.JLabel();
        filterEmployeeCoachLabel = new javax.swing.JLabel();
        filterClearLabel = new javax.swing.JLabel();
        filtersPanel = new javax.swing.JPanel();
        filterColumnComboBox = new javax.swing.JComboBox<>();
        filterTextField = new javax.swing.JTextField();
        filterEmployeeStatusComboBox = new javax.swing.JComboBox<>();
        filterEmployeeCoachComboBox = new javax.swing.JComboBox<>();
        filterClearButton = new javax.swing.JButton();
        UpdatesPanel = new javax.swing.JPanel();
        updatePayrollIDsButton = new javax.swing.JButton();
        LOAEmployeesButton = new javax.swing.JButton();
        updateAllCoachesButton = new javax.swing.JButton();
        updateCoachButton = new javax.swing.JButton();
        HistoryPanel = new javax.swing.JPanel();
        separatedEmployeesButton = new javax.swing.JButton();
        employeeHistoryButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Employee Maintenance");
        setBackground(new java.awt.Color(255, 204, 153));
        setMinimumSize(new java.awt.Dimension(850, 610));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(255, 204, 153));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(255, 204, 153));
        titlePanel.setName(""); // NOI18N
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        deleteRecordButton.setBackground(new java.awt.Color(255, 204, 153));
        deleteRecordButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        deleteRecordButton.setText("Delete Record");
        deleteRecordButton.setMaximumSize(new java.awt.Dimension(80, 25));
        deleteRecordButton.setMinimumSize(new java.awt.Dimension(80, 25));
        deleteRecordButton.setPreferredSize(new java.awt.Dimension(120, 30));
        deleteRecordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRecordButtonActionPerformed(evt);
            }
        });
        titlePanel.add(deleteRecordButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, -1, -1));

        powerUserOverrideCheckBox.setBackground(new java.awt.Color(255, 204, 153));
        powerUserOverrideCheckBox.setText("Power User Override");
        powerUserOverrideCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                powerUserOverrideCheckBoxActionPerformed(evt);
            }
        });
        titlePanel.add(powerUserOverrideCheckBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 50, -1, -1));

        feederSitePanel.setBackground(new java.awt.Color(255, 204, 153));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 70, -1));

        empidLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        empidLabel.setText("AT&T ID: ");
        feederSitePanel.add(empidLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 130, -1));

        employeeLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        employeeLabel.setText("Employee: ");
        feederSitePanel.add(employeeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 200, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 190, 80));

        exitButton.setBackground(new java.awt.Color(255, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(100, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, -1, -1));

        refreshButton.setBackground(new java.awt.Color(255, 204, 153));
        refreshButton.setText("Refresh Screen");
        refreshButton.setMargin(new java.awt.Insets(2, 5, 2, 5));
        refreshButton.setPreferredSize(new java.awt.Dimension(100, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        titlePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 40, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Employee Maintenance");
        titleLabel.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 850, -1));

        subtitleLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel1.setText("Double-click fields to edit.");
        subtitleLabel1.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 850, 20));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        subtitleLabel2.setText("Employees marked in grey are active on another site. To modify them, email TVI at [EMAIL].");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 640, 20));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(255, 204, 153));
        centerPanel.setMinimumSize(new java.awt.Dimension(590, 540));
        centerPanel.setPreferredSize(new java.awt.Dimension(590, 540));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        rosterScrollPane.setMaximumSize(new java.awt.Dimension(590, 200));
        rosterScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        rosterScrollPane.setPreferredSize(new java.awt.Dimension(590, 120));

        loadingLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel1.setText("LOADING...");
        loadingLabel1.setPreferredSize(new java.awt.Dimension(207, 25));
        rosterScrollPane.setViewportView(loadingLabel1);

        centerPanel.add(rosterScrollPane);

        jSeparator1.setBackground(new java.awt.Color(255, 204, 153));
        jSeparator1.setForeground(new java.awt.Color(255, 204, 153));
        jSeparator1.setMaximumSize(new java.awt.Dimension(590, 20));
        jSeparator1.setMinimumSize(new java.awt.Dimension(590, 20));
        jSeparator1.setPreferredSize(new java.awt.Dimension(50, 20));
        centerPanel.add(jSeparator1);

        employeesScrollPane.setMaximumSize(new java.awt.Dimension(590, 460));
        employeesScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        employeesScrollPane.setPreferredSize(new java.awt.Dimension(590, 200));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        employeesScrollPane.setViewportView(loadingLabel);

        centerPanel.add(employeesScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(255, 204, 153));
        bottomPanel.setMinimumSize(new java.awt.Dimension(850, 200));
        bottomPanel.setPreferredSize(new java.awt.Dimension(850, 200));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        gridPanel.setBackground(new java.awt.Color(255, 204, 153));
        gridPanel.setPreferredSize(new java.awt.Dimension(850, 200));
        gridPanel.setLayout(new java.awt.GridLayout(5, 0));

        filterLabelsPanel.setBackground(new java.awt.Color(255, 204, 153));
        filterLabelsPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        filterColumnTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterColumnTextLabel.setText("Column to search:");
        filterColumnTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterColumnTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterColumnTextLabel);

        filterTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterTextLabel.setText("Filter by text:");
        filterTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterTextLabel);

        filterEmployeeStatusLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeStatusLabel.setText("Employee Status:");
        filterEmployeeStatusLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeStatusLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeStatusLabel);

        filterEmployeeCoachLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeCoachLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeCoachLabel.setText("Employee Coach:");
        filterEmployeeCoachLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeCoachLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeCoachLabel);

        filterClearLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterClearLabel);

        gridPanel.add(filterLabelsPanel);

        filtersPanel.setBackground(new java.awt.Color(255, 204, 153));
        filtersPanel.setMinimumSize(new java.awt.Dimension(850, 30));
        filtersPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filtersPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        filterColumnComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "AT&T ID", "EMPLOYEE", "MU", "COACH", "SUPERVISOR", "CURRENT STATUS", "PARTTIME", "BILINGUAL", "HOURS PER WEEK", "NCS DATE", "CHILD BIRTH DATE", "PAYROLL ID" }));
        filterColumnComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterColumnComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterColumnComboBox);

        filterTextField.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextField.setMaximumSize(new java.awt.Dimension(150, 30));
        filterTextField.setMinimumSize(new java.awt.Dimension(150, 30));
        filterTextField.setPreferredSize(new java.awt.Dimension(150, 30));
        filtersPanel.add(filterTextField);

        filterEmployeeStatusComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show Active", "Show Inactive", "Show Separated" }));
        filterEmployeeStatusComboBox.setSelectedIndex(1);
        filterEmployeeStatusComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterEmployeeStatusComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterEmployeeStatusComboBox);

        filterEmployeeCoachComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeCoachComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show Discrepancies" }));
        filterEmployeeCoachComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterEmployeeCoachComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterEmployeeCoachComboBox);

        filterClearButton.setBackground(new java.awt.Color(255, 204, 153));
        filterClearButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearButton.setText("Clear Filters");
        filterClearButton.setMaximumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setMinimumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setPreferredSize(new java.awt.Dimension(150, 30));
        filterClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterClearButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(filterClearButton);

        gridPanel.add(filtersPanel);

        UpdatesPanel.setBackground(new java.awt.Color(255, 204, 153));
        UpdatesPanel.setMinimumSize(new java.awt.Dimension(850, 30));
        UpdatesPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        UpdatesPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        updatePayrollIDsButton.setBackground(new java.awt.Color(255, 204, 153));
        updatePayrollIDsButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updatePayrollIDsButton.setText("Update Payroll IDs");
        updatePayrollIDsButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatePayrollIDsButtonActionPerformed(evt);
            }
        });
        UpdatesPanel.add(updatePayrollIDsButton);

        LOAEmployeesButton.setBackground(new java.awt.Color(255, 204, 153));
        LOAEmployeesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        LOAEmployeesButton.setText("LOA Employees");
        LOAEmployeesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LOAEmployeesButtonActionPerformed(evt);
            }
        });
        UpdatesPanel.add(LOAEmployeesButton);

        updateAllCoachesButton.setBackground(new java.awt.Color(255, 204, 153));
        updateAllCoachesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateAllCoachesButton.setText("Update All Coaches");
        updateAllCoachesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAllCoachesButtonActionPerformed(evt);
            }
        });
        UpdatesPanel.add(updateAllCoachesButton);

        updateCoachButton.setBackground(new java.awt.Color(255, 204, 153));
        updateCoachButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateCoachButton.setText("Update Coach");
        updateCoachButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updateCoachButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updateCoachButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updateCoachButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateCoachButtonActionPerformed(evt);
            }
        });
        UpdatesPanel.add(updateCoachButton);

        gridPanel.add(UpdatesPanel);

        HistoryPanel.setBackground(new java.awt.Color(255, 204, 153));
        HistoryPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        HistoryPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        HistoryPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        separatedEmployeesButton.setBackground(new java.awt.Color(255, 204, 153));
        separatedEmployeesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        separatedEmployeesButton.setText("Separated Employees");
        separatedEmployeesButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        separatedEmployeesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                separatedEmployeesButtonActionPerformed(evt);
            }
        });
        HistoryPanel.add(separatedEmployeesButton);

        employeeHistoryButton.setBackground(new java.awt.Color(255, 204, 153));
        employeeHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeHistoryButton.setText("Employee History");
        employeeHistoryButton.setMaximumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setMinimumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setPreferredSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeHistoryButtonActionPerformed(evt);
            }
        });
        HistoryPanel.add(employeeHistoryButton);

        printButton.setBackground(new java.awt.Color(255, 204, 153));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setMaximumSize(new java.awt.Dimension(150, 30));
        printButton.setMinimumSize(new java.awt.Dimension(150, 30));
        printButton.setPreferredSize(new java.awt.Dimension(150, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        HistoryPanel.add(printButton);

        gridPanel.add(HistoryPanel);

        bottomPanel.add(gridPanel);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents
            
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
    
    private void filterColumnComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterColumnComboBoxActionPerformed
        String selection = filterColumnComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "ALL":
                filterColumn = -1;
                break;
            case "AT&T ID":
                filterColumn = idx_Emp_EMPID;
                break;
            case "EMPLOYEE":
                filterColumn = idx_Emp_EMPLOYEE;
                break;
            case "MU":
                filterColumn = idx_Emp_MU;
                break;
            case "COACH":
                filterColumn = idx_Emp_COACH;
                break;
            case "SUPERVISOR":
                filterColumn = idx_Emp_WEBPHONE_SUPERVISOR;
                break;
            case "CURRENT STATUS":
                filterColumn = idx_Emp_STATUS;
                break;
            case "EFFECTIVE DATE":
                filterColumn = idx_Emp_EFFECTIVE_DATE;
                break;
            case "PARTTIME":
                filterColumn = idx_Emp_PARTTIME_FLAG;
                break;
            case "BILINGUAL":
                filterColumn = idx_Emp_BILINGUAL_FLAG;
                break;
            case "NCS DATE":
                filterColumn = idx_Emp_NCS_DATE;
                break;
            case "CHILD BIRTH DATE":
                filterColumn = idx_Emp_CHILD_BIRTH_DATE;
                break;
            case "HOURS PER WEEK":
                filterColumn = idx_Emp_HOURS_PER_WEEK;
                break;
            case "PAYROLL ID":
                filterColumn = idx_Emp_OTHER_PAYROLL_ID;
                break;
            default:
                Misc.msgbox(getFormComponent(), "Unhandled filter selection, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
        }
        processFilter();
    }//GEN-LAST:event_filterColumnComboBoxActionPerformed

    private void filterEmployeeStatusComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterEmployeeStatusComboBoxActionPerformed
        String selection = filterEmployeeStatusComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "Show Active":
                employeeStatusFilterText = "^ACTIVE$";
                break;
            case "Show Inactive":
                employeeStatusFilterText = "INACTIVE";
                break;
            case "Show Separated":
                employeeStatusFilterText = "SEPARATED";
                break;
            default:
                employeeStatusFilterText = "";
                break;
        }
        processFilter();
    }//GEN-LAST:event_filterEmployeeStatusComboBoxActionPerformed

    private void filterClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterClearButtonActionPerformed
        clearFilter();
        processFilter();
        filterTextField.requestFocusInWindow();
    }//GEN-LAST:event_filterClearButtonActionPerformed

    private void filterEmployeeCoachComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterEmployeeCoachComboBoxActionPerformed
        String selection = filterEmployeeCoachComboBox.getSelectedItem().toString();
        processFilter();
    }//GEN-LAST:event_filterEmployeeCoachComboBoxActionPerformed

    private void updateCoachButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateCoachButtonActionPerformed
        int[] selectedRows = empTable.getSelectedRows();
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        if (Misc.msgbox(getFormComponent(), "<html>This will update all SELECTED ACTIVE employees so their coach matches the webphone supervisor.<br>Are you sure you want to continue?</html>", "Update All Coaches", 2, 2, 1))
        {
            ArrayList<String> empList = new ArrayList<>();
            for (int i = 0; i < selectedRows.length; i++)
            {
                String status = empTable.getValueAt(selectedRows[i], idx_Emp_STATUS).toString();
                String empid = Misc.objectToString(empTable.getValueAt(selectedRows[i], idx_Emp_EMPID));

                if (status.equals("ACTIVE"))
                {
                    empList.add(empid);
                }
            }
            if (Oracle.updateTVICoaches(getFormComponent(), feeder, site, empList))
            {
                refreshData();
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Error updating coaches.  Email TVI Support at: " + Constants.EMAIL, "Employee Maintenance", 1, 1, 1);
            }
        }
    }//GEN-LAST:event_updateCoachButtonActionPerformed

    private void updatePayrollIDsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatePayrollIDsButtonActionPerformed
        new Thread(new UpdatePayrollIDsThread()).start();
    }//GEN-LAST:event_updatePayrollIDsButtonActionPerformed
                    
    private void LOAEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LOAEmployeesButtonActionPerformed
        LOAMex.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_LOAEmployeesButtonActionPerformed
        
    private void updateAllCoachesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_updateAllCoachesButtonActionPerformed
    {//GEN-HEADEREND:event_updateAllCoachesButtonActionPerformed
        if (Misc.msgbox(getFormComponent(), "<html>This will update all ACTIVE employees so their coach matches the webphone supervisor.<br>Are you sure you want to continue?</html>", "Update All Coaches", 2, 2, 1))
        {
            if (Oracle.updateTVICoaches(getFormComponent(), feeder, site, null))
            {
                refreshData();
            }
        }
    }//GEN-LAST:event_updateAllCoachesButtonActionPerformed

    private void separatedEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_separatedEmployeesButtonActionPerformed
        PayrollGenerationMEXSeparated.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_separatedEmployeesButtonActionPerformed

    private void employeeHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeHistoryButtonActionPerformed
        int selectedRow = rosterTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        else
        {
            String empid = Misc.objectToString(rosterTable.getValueAt(selectedRow, idx_Mu_EMPID));
            if (empid.equals(""))
            {
                Misc.msgbox(getFormComponent(), "You cannot select an employee with a blank AT&T ID.", "Employee Maintenance", 1, 1, 1);
                return;
            }
            else
            {
                EmployeeHistory.getInstance(getFormComponent(), feeder, site, empid);
            }
        if (powerUserOverrideCheckBox.isSelected())
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE", "SEPARATED"}));
            }
            else
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE"}));
            }
        }
    }//GEN-LAST:event_employeeHistoryButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, empTable, "PORTRAIT", "Employee Maintenance");
    }//GEN-LAST:event_printButtonActionPerformed

    private void deleteRecordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRecordButtonActionPerformed
        if (!UserData.getUserType().equals("POWER"))
        {
            powerUserOverrideCheckBox.setSelected(false);
            powerUserOverrideCheckBox.setVisible(false);
            deleteRecordButton.setVisible(false);
            return;
        }
        if (!powerUserOverrideCheckBox.isSelected())
        {
            deleteRecordButton.setVisible(false);
            return;
        }

        int selectedRow = empTable.getSelectedRow();
        if (selectedRow < 0)
        {
            Misc.msgbox(getFormComponent(), "No row selected.", "Deleting Row", 1, 1, 1);
            return;
        }

        String mu = empTable.getValueAt(selectedRow, idx_Emp_MU).toString();
        String empid = empTable.getValueAt(selectedRow, idx_Emp_EMPID).toString();

        if (Misc.msgbox(getFormComponent(), "Are you sure you want to delete?", "Delete Employee", 2, 2, 1))
        {
            if (Oracle.deleteEmployeeRecord(getFormComponent(), feeder, site, mu, empid))
            {
                empData.removeRow(empTable.convertRowIndexToModel(selectedRow));
                employeeUpdated = false;
                if (selectedRow == empTable.getRowCount())
                {
                    selectedRow--;
                }
                if (empTable.getRowCount() > 0)
                {
                    empTable.changeSelection(selectedRow, 0, false, false);
                }
            }
        }
        empTable.requestFocusInWindow();
    }//GEN-LAST:event_deleteRecordButtonActionPerformed

    private void powerUserOverrideCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_powerUserOverrideCheckBoxActionPerformed
        if (!UserData.getUserType().equals("POWER"))
        {
            powerUserOverrideCheckBox.setSelected(false);
            powerUserOverrideCheckBox.setVisible(false);
            deleteRecordButton.setVisible(false);
        }
        else
        {
            if (powerUserOverrideCheckBox.isSelected())
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE", "SEPARATED"}));
            }
            else
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE"}));
            }
            deleteRecordButton.setVisible(powerUserOverrideCheckBox.isSelected());
        }
    }//GEN-LAST:event_powerUserOverrideCheckBoxActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed
                    
    private void refreshData()
    {
        if (empTable != null)
        {
            updateEmpData();
        }
        if (rosterTable != null)
        {
            updateRosterData();
        }
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        CountDownLatch latch;
        ResultSetWrapper results = null;
        boolean finishedEmployees = false;
        boolean finishedMURoster = false;
        boolean cancelRefresh = false;
        
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    empWorker = null;
                    rosterWorker = null;
                    
                    // initial code to run before starting the empWorker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    empData = new CustomTableModel(buildEmpColumnNames());
                    rosterData = new CustomTableModel(buildRosterColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing empWorker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethodEmployees = this::getResultsEmployees;
                    Supplier<ResultSetWrapper> getResultsMethodMURoster = this::getResultsMURoster;

                    Function<ResultSet, Object[]> processResultsFuncEmployees = this::processResultsEmployees;
                    Function<ResultSet, Object[]> processResultsFuncMURoster = this::processResultsMURoster;

                    Consumer<Boolean> finalizeRefreshMethodEmployees = this::finalizeRefreshEmployees;
                    Consumer<Boolean> finalizeRefreshMethodMURoster = this::finalizeRefreshMURoster;

                    // initialize a CountDownLatch with the number of workers to wait for
                    latch = new CountDownLatch(2);
                    
                    // initialize the custom swing worker
                    empWorker = new TableSwingWorker(getFormComponent(), empData, getResultsMethodEmployees, processResultsFuncEmployees, finalizeRefreshMethodEmployees, latch);
                    rosterWorker = new TableSwingWorker(getFormComponent(), rosterData, getResultsMethodMURoster, processResultsFuncMURoster, finalizeRefreshMethodMURoster, latch);
                    
                    if (cancelRefresh)
                    {
                        empWorker.cancel(true);
                        rosterWorker.cancel(true);
                    }
                    
                    if (!empWorker.isCancelled() && !rosterWorker.isCancelled())
                    {
                        getResults();
                    }  
                    
                    // start the empWorker.  it will get results from the database and add row to the empTable in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    empWorker.execute();
                    rosterWorker.execute();
                }
                finally
                {
                    if (empWorker == null || rosterWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading empTable, email TVI Support at: " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the empTable.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (empTable != null)
                        {
                            if (empTable.getSelectedRow() != -1)
                            {
                                changeTVIEmp(0);
                            }
                        }
                        if (rosterTable != null)
                        {
                            if (rosterTable.getSelectedRow() != -1)
                            {
                                changeRosterEmp(0);
                            }
                        }
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    employeesScrollPane.setViewportView(loadingLabel);
                    rosterScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildEmpColumnNames()
        * 
        * Builds the column names to use for the empTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildEmpColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("Part<br>Time"),             // idx_Emp_PARTTIME_FLAG
                Misc.centerHTML("Bi-<br>Lingual"),           // idx_Emp_BILINGUAL_FLAG
                Misc.centerHTML("Hrs Per<br>Week"),          // idx_Emp_HOURS_PER_WEEK
                "Band",                                      // idx_Emp_BAND                      CZE & SVK ONLY
                "MU",                                        // idx_Emp_MU
                "AT&T ID",                                   // idx_Emp_EMPID
                "Payroll ID",                                // idx_Emp_OTHER_PAYROLL_ID          MEX, CZE, SVK ONLY
                "Employee",                                  // idx_Emp_EMPLOYEE
                "Coach",                                     // idx_Emp_COACH
                Misc.centerHTML("Webphone<br>Supervisor"),   // idx_Emp_WEBPHONE_SUPERVISOR
                "NCS Date",                                  // idx_Emp_NCS_DATE                  EUR ONLY
                Misc.centerHTML("Child<br>Birth Date"),      // idx_Emp_CHILD_BIRTH_DATE          EUR ONLY
                Misc.centerHTML("Extra<br>Off Day<br>Hours"),// idx_Emp_EXTRA_OFF_DAYS            EUR ONLY
                Misc.centerHTML("Current<br>Status"),        // idx_Emp_STATUS
                Misc.centerHTML("Effective<br>Date"),        // idx_Emp_EFFECTIVE_DATE
                Misc.centerHTML("4/10<br>Emps"),             // idx_Emp_FOUR_DAY                  MEX ONLY
                Misc.centerHTML("Six<br>Day")                // idx_Emp_SIX_DAY                   MEX ONLY
            };
        }
        
        /**
        * buildRosterColumnNames()
        * 
        * Builds the column names to use for the rosterTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildRosterColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("IEX<br>Instance"),   //idx_Mu_IEX_INSTANCE
                "Feeder",                             //idx_Mu_FEEDER
                "Site",                               //idx_Mu_SITE
                "MU",                                 //idx_Mu_MU
                "Employee",                           //idx_Mu_EMPLOYEE
                "AT&T ID",                            //idx_Mu_EMPID
                "Agent ID",                           //idx_Mu_AGENTID
                "",                                   //idx_Mu_TVIP
                "",                                   //idx_Mu_CUSTNUM
                Misc.centerHTML("Start<br>Date"),     //idx_Mu_START_DATE
                Misc.centerHTML("End<br>Date"),       //idx_Mu_END_DATE
                "Status",                             //idx_Mu_STATUS
                Misc.centerHTML("Do Not<br>Import"),  //idx_Mu_DO_NOT_IMPORT
                ""                                    //idx_Mu_FLAG
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progress bar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private void getResults()
        {
            results = Oracle.getResultsMURosterMaintenance(getFormComponent(), feeder, site);
        }
        
        /**
        * getResultsEmployees()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the employees resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsEmployees()
        {
            return new ResultSetWrapper(results.getResultSetArray()[0]);
        }
        
        /**
        * getResultsMURoster()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the MURoster resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsMURoster()
        {
            return new ResultSetWrapper(results.getResultSetArray()[1]);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the empTable from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of empTable
        */
        private Object[] processResultsEmployees(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object []
                {
                    Misc.oracleToBoolean(rs.getObject("PARTTIME_FLAG")),          // idx_Emp_PARTTIME_FLAG
                    Misc.oracleToBoolean(rs.getObject("BILINGUAL_DAILY")),        // idx_Emp_BILINGUAL_FLAG
                    rs.getBigDecimal("HOURS_PER_WEEK"),                           // idx_Emp_HOURS_PER_WEEK
                    rs.getString("BAND"),                                         // idx_Emp_BAND
                    rs.getString("MU"),                                           // idx_Emp_MU
                    rs.getString("EMPID"),                                        // idx_Emp_EMPID
                    rs.getString("OTHER_PAYROLL_ID"),                             // idx_Emp_OTHER_PAYROLL_ID
                    rs.getString("EMPLOYEE"),                                     // idx_Emp_EMPLOYEE
                    rs.getString("COACH"),                                        // idx_Emp_COACH
                    rs.getString("WEBPHONE_SUPERVISOR"),                          // idx_Emp_WEBPHONE_SUPERVISOR
                    rs.getDate("NCS_DATE"),                                       // idx_Emp_NCS_DATE
                    rs.getDate("CHILD_BIRTH_DATE"),                               // idx_Emp_CHILD_BIRTH_DATE
                    rs.getBigDecimal("EXTRA_OFF_DAYS"),                           // idx_Emp_EXTRA_OFF_DAYS
                    rs.getString("STATUS"),                                       // idx_Emp_STATUS
                    rs.getDate("EFFECTIVE_DATE"),                                 // idx_Emp_EFFECTIVE_DATE
                    Misc.oracleToBoolean(rs.getObject("FOUR_DAY")),               // idx_Emp_FOUR_DAY
                    Misc.oracleToBoolean(rs.getObject("SIX_DAY"))                 // idx_Emp_SIX_DAY
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Employee Maintenance data.");
                empWorker.cancel(true);
            }
            employeeCount++;
            return data;
        }

        /**
        * processResultsMURoster
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the empTable from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of empTable
        */
        private Object[] processResultsMURoster(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object []
                {
                    rs.getString("IEX_INSTANCE"),                       //idx_Mu_IEX_INSTANCE
                    rs.getString("FEEDER"),                             //idx_Mu_FEEDER
                    rs.getString("SITE"),                               //idx_Mu_SITE
                    rs.getString("MU"),                                 //idx_Mu_MU
                    rs.getString("EMPLOYEE"),                           //idx_Mu_EMPLOYEE
                    rs.getString("EMPID"),                              //idx_Mu_EMPID
                    rs.getString("AGENTID"),                            //idx_Mu_AGENTID
                    rs.getString("TVIP"),                               //idx_Mu_TVIP
                    rs.getInt("CUSTNUM"),                               //idx_Mu_CUSTNUM
                    rs.getDate("START_DATE"),                           //idx_Mu_START_DATE
                    rs.getDate("END_DATE"),                             //idx_Mu_END_DATE
                    rs.getString("STATUS"),                             //idx_Mu_STATUS
                    Misc.oracleToBoolean(rs.getObject("DO_NOT_IMPORT")),//idx_Mu_DO_NOT_IMPORT
                    rs.getString("FLAG")                                //idx_Mu_FLAG
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Roster Employee Maintenance data.");
                rosterWorker.cancel(true);
            }
            rosterCount++;
            return data;
        }
                /**
        * finalizeRefreshEmployees
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the empTable - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the empTable is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshEmployees(Boolean cancelled)
        {
            if (!cancelled)
            {
                createEmpTable(); //defined below inside this thread
                configureEmpTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, empTable);
                employeesScrollPane.setViewportView(empTable);
                filterTextField.requestFocusInWindow();
            }
            
            finishedEmployees = true;
            if (finishedEmployees && finishedMURoster)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshMURoster
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the empTable - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the empTable is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshMURoster(Boolean cancelled)
        {
            if (!cancelled)
            {
                createRosterTable(); //defined below inside this thread
                configureRosterTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), rosterScrollPane, rosterTable);
                rosterScrollPane.setViewportView(rosterTable);
                filterTextField.requestFocusInWindow();
            }
            finishedMURoster = true;
            if (finishedEmployees && finishedMURoster)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefresh
        * 
        * Called once all four table workers are finished executing.
        * This closes the callable statement and releases the semaphore lock.
        * 
        * Once this code is executed, if not cancelled, the tables are finished and displayed, ready for the user.
        */
        private void finalizeRefresh()
        {
            try
            {
                // wait for all of the workers to properly finish and release their latches
                latch.await();
                if (results != null)
                {
                    results.close();
                }
            }
            catch (InterruptedException ex) { }
            if (!empWorker.isCancelled() && !rosterWorker.isCancelled())
            {
                changingEmployees = true;
                employeeUpdated = false;
                if (employeeCount > 0 && empSorter.getViewRowCount() != 0)
                {
                    empTable.setRowSelectionInterval(0, 0);
                    changeTVIEmp(0);
                }
                
                changingEmployees = false;
                
                changingRoster = true;
                rosterUpdated = false;
                if (rosterCount > 0 && employeeCount > 0 &&  empSorter.getViewRowCount() != 0)
                {
                    rosterTable.setRowSelectionInterval(0, 0);
                    changeRosterEmp(0);
                }
                
                changingRoster = false;
                
                RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                
                employeesScrollPane.setViewportView(empTable);
                employeesScrollPane.setVisible(true);
                empTable.setFillsViewportHeight(true);
                empTable.requestFocusInWindow();
                
                rosterScrollPane.setViewportView(rosterTable);
                rosterScrollPane.setVisible(true);
                rosterTable.setFillsViewportHeight(false);
                rosterTable.requestFocusInWindow();
                
                refreshButton.setEnabled(true);
                validate();
            }
            
            refreshTableLock.release();
        }
        
        private void createEmpTable()
        {
            empTable = new JTable(empData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (empTable.convertRowIndexToModel(row) != currentEmpRow ||
                        empTable.getSelectedRows().length > 1)
                    {
                        return false;
                    }
                    /*else if (UserData.getUserType().equals("POWER") && powerUserOverrideCheckBox.isSelected())
                    {
                        switch (column)
                        {
                            case idx_Emp_EMPID:
                                return false;
                            default:
                                return true;
                        }
                    }*/
                    else if (UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        return false;
                    }
                    else
                    {
                        /*if (!empTable.getValueAt(row, idx_Emp_STATUS).equals("ACTIVE"))
                        {
                            return false;
                        }*/

                        switch (column)
                        {
                            case idx_Emp_BAND:
                            case idx_Emp_OTHER_PAYROLL_ID:
                            case idx_Emp_COACH:
                            case idx_Emp_PARTTIME_FLAG:
                            case idx_Emp_BILINGUAL_FLAG:
                            case idx_Emp_HOURS_PER_WEEK:
                            case idx_Emp_FOUR_DAY:
                            case idx_Emp_SIX_DAY:
                            case idx_Emp_NCS_DATE:
                            case idx_Emp_CHILD_BIRTH_DATE:
                            case idx_Emp_EXTRA_OFF_DAYS:
                                return true;
                            case idx_Emp_STATUS:
                                String isSeparated = Misc.objectToString(empTable.getValueAt(row, idx_Emp_STATUS));
                                return (isSeparated.equals("SEPARATED"));
                            default:
                                return false;
                        }
                    }
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Emp_HOURS_PER_WEEK:
                        case idx_Emp_EXTRA_OFF_DAYS:
                            return BigDecimal.class;
                        case idx_Emp_PARTTIME_FLAG:
                        case idx_Emp_BILINGUAL_FLAG:
                        case idx_Emp_FOUR_DAY:
                        case idx_Emp_SIX_DAY:
                            return Boolean.class;
                        case idx_Emp_NCS_DATE:
                        case idx_Emp_CHILD_BIRTH_DATE:
                        case idx_Emp_EFFECTIVE_DATE:
                            return Date.class;
                        case idx_Emp_BAND:
                        case idx_Emp_MU:
                        case idx_Emp_EMPID:
                        case idx_Emp_OTHER_PAYROLL_ID:
                        case idx_Emp_EMPLOYEE:
                        case idx_Emp_COACH:
                        case idx_Emp_WEBPHONE_SUPERVISOR:
                        case idx_Emp_STATUS:
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (UserData.getUserAccessLevel().equals("READONLY"))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else if (!empTable.getValueAt(row, idx_Emp_STATUS).equals("ACTIVE"))
                        {
                                    c.setBackground(Color.LIGHT_GRAY);
                        }
                    }
                    return c;
                }
            };
        }

        private void configureEmpTable()
        {
            empData.addTableModelListener(new TableModelListener()
            {
                @Override
                public void tableChanged(TableModelEvent e)
                {
                    if (currentEmpRow != -1)
                    {
                        if (e.getColumn() == idx_Emp_FOUR_DAY && empData.getValueAt(currentEmpRow, idx_Emp_FOUR_DAY).equals(true) && empData.getValueAt(currentEmpRow, idx_Emp_SIX_DAY).equals(true))
                        {
                            empData.setValueAt(false, currentEmpRow, idx_Emp_SIX_DAY);
                        }
                        if (e.getColumn() == idx_Emp_SIX_DAY && empData.getValueAt(currentEmpRow, idx_Emp_SIX_DAY).equals(true) && empData.getValueAt(currentEmpRow, idx_Emp_FOUR_DAY).equals(true))
                        {
                            empData.setValueAt(false, currentEmpRow, idx_Emp_FOUR_DAY);
                        }
                    }
                }
            });
            
            Action employeeTableAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    int selectedRow = empTable.getSelectedRow();

                    employeeUpdated = true;
                    currentEmpRow = empTable.convertRowIndexToModel(selectedRow);
                }
            };
            empTable.addPropertyChangeListener(new TableCellListener(empTable, employeeTableAction));

            Misc.configureTable(empTable, false, true, false);

            empSorter = new TableRowSorter<>(empData);
            empTable.setRowSorter(empSorter);

            Misc.setTableSorterNumeralComparator(empTable);
            Misc.setHeaderRenderer(empTable, true, true, null);
            Misc.setColumnSettings(empTable, idx_Emp_PARTTIME_FLAG, 60, false);
            Misc.setColumnSettings(empTable, idx_Emp_BILINGUAL_FLAG, 60, false);
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(empTable, idx_Emp_HOURS_PER_WEEK, 60, true, Constants.CENTER);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_HOURS_PER_WEEK, 0, true, Constants.CENTER);
            }
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(empTable, idx_Emp_BAND, 60);
                DefaultCellEditor be = new DefaultCellEditor(bandCombo);
                be.setClickCountToStart(2);
                empTable.getColumnModel().getColumn(idx_Emp_BAND).setCellEditor(be);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_BAND, 0, false);
            }
            Misc.setColumnSettings(empTable, idx_Emp_MU, 40);
            Misc.setColumnSettings(empTable, idx_Emp_EMPID, 80);
            if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(empTable, idx_Emp_OTHER_PAYROLL_ID, 100);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_OTHER_PAYROLL_ID, 0, false);
            }
            Misc.setColumnSettings(empTable, idx_Emp_EMPLOYEE, 200, Constants.LEFT);
            Misc.setColumnSettings(empTable, idx_Emp_COACH, 80);
            Misc.setColumnSettings(empTable, idx_Emp_WEBPHONE_SUPERVISOR, 80);
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(empTable, idx_Emp_NCS_DATE, 80);
                Misc.setColumnSettings(empTable, idx_Emp_CHILD_BIRTH_DATE, 80);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_NCS_DATE, 0);
                Misc.setColumnSettings(empTable, idx_Emp_CHILD_BIRTH_DATE, 0);
            }
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(empTable, idx_Emp_EXTRA_OFF_DAYS, 60);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_EXTRA_OFF_DAYS, 0);
            }
            Misc.setColumnSettings(empTable, idx_Emp_STATUS, 80);
            Misc.setColumnSettings(empTable, idx_Emp_EFFECTIVE_DATE, 80);
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(empTable, idx_Emp_FOUR_DAY, 50, false);
                Misc.setColumnSettings(empTable, idx_Emp_SIX_DAY, 50, false);
            }
            else
            {
                Misc.setColumnSettings(empTable, idx_Emp_FOUR_DAY, 0, true);
                Misc.setColumnSettings(empTable, idx_Emp_SIX_DAY, 0, true);
            }
            
            DefaultCellEditor cse = new DefaultCellEditor(currentStatusCombo);
            cse.setClickCountToStart(2);
            empTable.getColumnModel().getColumn(idx_Emp_STATUS).setCellEditor(cse);

            empTable.getColumnModel().getColumn(idx_Emp_HOURS_PER_WEEK).setCellEditor(new HoursEditor(0.0, 99.0, true));
                        
            DefaultCellEditor ope = new DefaultCellEditor(new JFormattedTextField())
            {
                @Override
                public Component getTableCellEditorComponent(JTable empTable, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(empTable, Misc.objectToString(value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    return ftf.getText();
                }

                @Override
                public boolean stopCellEditing()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    ftf.setText(ftf.getText().replace(" ", ""));
                    int selectedRow = empTable.getSelectedRow();
                    String empid = Misc.objectToString(empTable.getValueAt(selectedRow, idx_Emp_EMPID));
                    String previousValue = Misc.objectToString(empTable.getValueAt(selectedRow, idx_Emp_OTHER_PAYROLL_ID));
                    String payrollID = ftf.getText();
                    if (!formClosing && payrollID != null && !payrollID.equals("") && Oracle.otherPayrollIDAlreadyExists(getFormComponent(), feeder, site, empid, payrollID))
                    {
                        if (!userSaysRevertPayrollID(ftf, previousValue))
                        {
                            return false;//continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            ope.setClickCountToStart(2);
            empTable.getColumnModel().getColumn(idx_Emp_OTHER_PAYROLL_ID).setCellEditor(ope);
            
            DefaultCellEditor eoe = new DefaultCellEditor(new JFormattedTextField())
            {
                @Override
                public Component getTableCellEditorComponent(JTable empTable, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(empTable, Misc.objectToString(value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    return ftf.getText();
                }

                @Override
                public boolean stopCellEditing()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    ftf.setText(ftf.getText().replace(" ", ""));
                    int selectedRow = empTable.getSelectedRow();
                    String empid = Misc.objectToString(empTable.getValueAt(selectedRow, idx_Emp_EMPID));
                    String previousValue = Misc.objectToString(empTable.getValueAt(selectedRow, idx_Emp_EXTRA_OFF_DAYS));
                    String extraOffEntered = ftf.getText();
                    if (!formClosing && !verifyExtraOff(empid, extraOffEntered))
                    {
                        if (!userSaysRevertExtraOff(ftf, previousValue))
                        {
                            return false; // continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            eoe.setClickCountToStart(2);
            empTable.getColumnModel().getColumn(idx_Emp_EXTRA_OFF_DAYS).setCellEditor(eoe);
            
            DefaultCellEditor ncsde = new DefaultCellEditor(ncsDateCombo)
            {
                @Override
                public Component getTableCellEditorComponent(JTable empTable, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(empTable, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JComboBox dateCombo = (JComboBox)getComponent();
                    Object value = dateCombo.getSelectedItem();
                    if (value instanceof Date)
                    {
                        return value;
                    }
                    else if (value instanceof String && !value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            ncsde.setClickCountToStart(2);
            empTable.getColumnModel().getColumn(idx_Emp_NCS_DATE).setCellEditor(ncsde);
            
            JTextField tfChildBirthDate = new JTextField();
            DefaultCellEditor cbde = new DefaultCellEditor(tfChildBirthDate)
            {
                @Override
                public Component getTableCellEditorComponent(JTable empTable, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(empTable, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JTextField tf = (JTextField)getComponent();
                    Object value = tf.getText();
                    if (!value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            cbde.setClickCountToStart(2);
            empTable.getColumnModel().getColumn(idx_Emp_CHILD_BIRTH_DATE).setCellEditor(cbde);
            
            empTable.setRowHeight(20);

            if (employeeCount > 0 && empSorter.getViewRowCount() != 0)
            {
                currentEmpRow = 0;
                empTable.setRowSelectionInterval(0, 0);
                changingEmployees = true;
                changeTVIEmp(0);
                changingEmployees = false;
            }

            empTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = empTable.getSelectedRow();
                        if (selectedRow != -1 && empTable.convertRowIndexToModel(selectedRow) != currentEmpRow)
                        {
                            if (!changingEmployees)
                            {
                                changingEmployees = true;
                                changeTVIEmp(selectedRow);
                                changingEmployees = false;
                            }
                        }
                    }
                }
            });
            processFilter();
        }
        
        private void createRosterTable()
        {
            rosterTable = new JTable(rosterData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    
                    if (rosterTable.convertRowIndexToModel(row) != currentRosterRow ||
                        rosterTable.getSelectedRows().length > 1)
                    {
                        return false;
                    }
                    else if (UserData.getUserAccessLevel().equals("READONLY") ||
                             !rosterTable.getValueAt(row, idx_Mu_FEEDER).toString().equals(feeder) ||
                             !rosterTable.getValueAt(row, idx_Mu_SITE).toString().equals(site) ||
                             !rosterTable.getValueAt(row, idx_Mu_EMPID).toString().equals(empTable.getValueAt(empTable.getSelectedRow(), idx_Emp_EMPID).toString()))
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_Mu_DO_NOT_IMPORT:
                                return true;
                            case idx_Mu_STATUS:
                                String isSeparated = Misc.objectToString(rosterTable.getValueAt(row, idx_Mu_STATUS));
                                return (isSeparated.equals("SEPARATED"));
                            default:
                                return false;
                        }
                    }
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Mu_DO_NOT_IMPORT:
                            return Boolean.class;
                        case idx_Mu_START_DATE:
                        case idx_Mu_END_DATE:
                            return Date.class;
                        case idx_Mu_IEX_INSTANCE:
                        case idx_Mu_FEEDER:
                        case idx_Mu_SITE:
                        case idx_Mu_MU:
                        case idx_Mu_EMPLOYEE:
                        case idx_Mu_EMPID:
                        case idx_Mu_AGENTID:
                        case idx_Mu_TVIP:
                        case idx_Mu_CUSTNUM:
                        case idx_Mu_STATUS:
                        case idx_Mu_FLAG: 
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (UserData.getUserAccessLevel().equals("READONLY") ||
                            !rosterTable.getValueAt(row, idx_Mu_FEEDER).toString().equals(feeder) ||
                            !rosterTable.getValueAt(row, idx_Mu_SITE).toString().equals(site))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                    }
                    return c;
                }
            };
        }

        private void configureRosterTable()
        {
            Action rosterTableAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener rtcl = (TableCellListener)e.getSource();
                    int selectedRow = rosterTable.getSelectedRow();

                    rosterUpdated = true;
                    currentRosterRow = rosterTable.convertRowIndexToModel(selectedRow);
                }
            };
            rosterTable.addPropertyChangeListener(new TableCellListener(rosterTable, rosterTableAction));
            
            Misc.configureTable(rosterTable, false, true, false);

            rosterSorter = new TableRowSorter<>(rosterData);
            rosterTable.setRowSorter(rosterSorter);

            Misc.setTableSorterNumeralComparator(rosterTable);
            Misc.setHeaderRenderer(rosterTable, true, true, null);
            Misc.setColumnSettings(rosterTable, idx_Mu_IEX_INSTANCE, 150);
            Misc.setColumnSettings(rosterTable, idx_Mu_FEEDER, 60);
            Misc.setColumnSettings(rosterTable, idx_Mu_SITE, 40);
            Misc.setColumnSettings(rosterTable, idx_Mu_MU, 60);
            Misc.setColumnSettings(rosterTable, idx_Mu_EMPLOYEE, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_EMPID, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_AGENTID, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_TVIP, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_CUSTNUM, 0);
            Misc.setColumnSettings(rosterTable, idx_Mu_START_DATE, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_END_DATE, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_STATUS, 80);
            Misc.setColumnSettings(rosterTable, idx_Mu_DO_NOT_IMPORT, 60, false);
            Misc.setColumnSettings(rosterTable, idx_Mu_FLAG, 0);
            
            DefaultCellEditor cse = new DefaultCellEditor(currentStatusCombo);
            cse.setClickCountToStart(2);
            rosterTable.getColumnModel().getColumn(idx_Mu_STATUS).setCellEditor(cse);
            
            rosterTable.setRowHeight(20);
            
            if (rosterCount > 0)
            {
                currentRosterRow = 0;
                rosterTable.setRowSelectionInterval(0, 0);
                changingRoster = true;
                changeRosterEmp(0);
                changingRoster = false;
            }

            rosterTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent r)
                {
                    if (!r.getValueIsAdjusting())
                    {
                        int selectedRow = rosterTable.getSelectedRow();
                        if (selectedRow != -1 && rosterTable.convertRowIndexToModel(selectedRow) != currentRosterRow)
                        //if (selectedRow != -1)
                        {
                            if (!changingRoster)
                            {
                                changingRoster = true;
                                changeRosterEmp(selectedRow);
                                changingRoster = false;
                            }
                        }
                    }
                }
            });
            processFilter();
        }
    }

    private class UpdatePayrollIDsThread implements Runnable
    {
        @Override
        @SuppressFBWarnings(value="RV_DONT_JUST_NULL_CHECK_READLINE", justification="We don't use the value returned from readLine() when counting lines.")
        public void run()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.HOURGLASS);
                        updatePayrollIDsButton.setEnabled(false);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showOpenDialog(getFormComponent());
            if (returnVal == JFileChooser.APPROVE_OPTION)
            {
                try
                {
                    // get the number of lines in the file
                    int lineCount = 0;
                    File payrollIDFile = fc.getSelectedFile();
                    BufferedReader file = new BufferedReader(new FileReader(payrollIDFile.getAbsolutePath()));
                    try
                    {
                        while (file.readLine() != null)
                        {
                            lineCount++;
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                    final int maxProgress = lineCount;
                    
                    // display the progress monitor
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            progressMonitor = new ProgressMonitor(getFormComponent(), "Updating Payroll IDs", null, 0, maxProgress);
                            progressMonitor.setProgress(0);
                        }
                    });
                    
                    // read the file, update each employee and increment the progress bar
                    payrollIDFile = fc.getSelectedFile();
                    file = new BufferedReader(new FileReader(payrollIDFile.getAbsolutePath()));
                    try
                    {
                        String line;
                        int currentLine = 0;
                        proceed = true;
                        cancel = false;
                        while ((line = file.readLine()) != null && proceed && !cancel)
                        {
                            currentLine++;
                            final int currentProgress = currentLine;
                            SwingUtilities.invokeLater(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    if (progressMonitor.isCanceled())
                                    {
                                        progressMonitor.close();
                                        cancel = true;
                                    }
                                    else
                                    {
                                        progressMonitor.setProgress(currentProgress);
                                    }
                                }
                            });
                            if (line.contains(","))
                            {
                                String values[] = line.split(",");
                                String payrollID = values[0].replace(" ", "");
                                String empid = values[1].toUpperCase(Locale.ENGLISH).replace(" ", "");
                                String message = "";
                                if (!Misc.isNumeric(payrollID))
                                {
                                    proceed = false;
                                    message = "Invalid payrollID.";
                                }
                                else if (empid.length() != 6)
                                {
                                    proceed = false;
                                    message = "Invalid empid.";
                                }
                                else if (payrollID.length() > 10)
                                {
                                    proceed = false;
                                    message = "Payroll ID is too long.";
                                }
                                else if (Oracle.otherPayrollIDAlreadyExists(getFormComponent(), feeder, site, empid, payrollID))
                                {
                                    proceed = false;
                                    message = "Payroll ID already exists for a different employee.";
                                }
                                if (proceed)
                                {
                                    Oracle.updateEmployeePayrollID(getFormComponent(), feeder, site, empid, payrollID);
                                }
                                else
                                {
                                    proceed = Misc.msgbox(getFormComponent(), "<html><font color = \"red\">Error on line " + currentLine + ".<br>Empid: " + empid + "&nbsp&nbsp&nbsp Payroll ID: " + payrollID + "</font><br><br><font color = \"blue\">" + message + "</font><br><br>This record will not be processed.<br>Click OK to continue, or Cancel to stop.", "Updating Payroll IDs", 2, 2, 1);
                                }
                                if (!proceed)
                                {
                                    progressMonitor.close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                }
                catch (IOException ex)
                {
                    proceed = false;
                    Misc.errorMsgDefault(getFormComponent(), ex, "Failed to read payroll ID file.");
                }
                
                refreshData();
                if (proceed && !cancel)
                {
                    Misc.msgbox(getFormComponent(), "Payroll IDs updated.", "Updating Payroll IDs", 1, 1, 1);
                }
            }
            
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.NORMAL);
                        updatePayrollIDsButton.setEnabled(true);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
        }
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @param ftf
     * @param previousValue
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertPayrollID(JFormattedTextField ftf, String previousValue)
    {
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "The payroll ID entered already exists for another employee on this site.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
            return true;
        }
        return false;
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @param ftf
     * @param previousValue
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertExtraOff(JFormattedTextField ftf, String previousValue)
    {
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "The amount entered is less than the employee has already taken,\n"
                + "or the format entered is invalid.",
            "Invalid Amount Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
            return true;
        }
        return false;
    }
    
    private boolean verifyExtraOff(String empid, String value)
    {
        boolean output;
        Calendar cal = Calendar.getInstance();
        cal.setTime(RegionData.getPayClose());
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        Date startDate = cal.getTime();
        cal.set(Calendar.MONTH, Calendar.DECEMBER);
        cal.set(Calendar.DAY_OF_MONTH, 31);
        Date endDate = cal.getTime();
        
        try
        {
            double amountEntered = Double.parseDouble(value);
            output = (Oracle.getExtraOffTaken(getFormComponent(), feeder, empid, startDate, endDate) <= amountEntered);
        }
        catch (NumberFormatException ex)
        {
            output = false;    
        }
        return output;
    }
    
    public void changeTVIEmp(int selectedRow)
    {
        updateRosterData();
        updateEmpData();
        currentEmpRow = empTable.convertRowIndexToModel(selectedRow);
        empidFilterText = Misc.objectToString(empTable.getValueAt(selectedRow, idx_Emp_EMPID));
        rosterFilter();
        rosterTable.changeSelection(0, 0, false, false);

        empidLabel.setText("AT&T ID: " + empTable.getValueAt(selectedRow, idx_Emp_EMPID).toString());
        employeeLabel.setText("Employee: " + empTable.getValueAt(selectedRow, idx_Emp_EMPLOYEE).toString());
    }
    
    public void changeRosterEmp(int selectedRow)
    {
            updateRosterData();
            currentRosterRow = rosterTable.convertRowIndexToModel(selectedRow);
    }
    
    private void clearFilter()
    {
        filterEnabled = false;
        filterColumnComboBox.setSelectedIndex(0);
        filterTextField.setText("");
        filterEmployeeCoachComboBox.setSelectedIndex(0);
        filterEnabled = true;
    }
    
    private void processFilter()
    {
        if (empTable == null || !empWorker.isDone() || !filterEnabled)
        {
            return;
        }
        if (empTable.isEditing())
        {
            empTable.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> textFilter;
        RowFilter<CustomTableModel, Object> dateFilter = null;
        RowFilter<CustomTableModel, Object> inputFilter;
        RowFilter<CustomTableModel, Object> employeeStatusFilter;
        
        try
        {
            if (filterColumn == -1)
            {
                if (editType.equals("DETAIL"))    
                {
                    filterEnabled = false;
                    filterColumnComboBox.setSelectedIndex(1);
                    filterTextField.setText(attid);
                    editType = "NORMAL";
                    filterEnabled = true;
                }
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
                }
            }
            else
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText(), filterColumn);
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()), filterColumn);
                }
            }
            employeeStatusFilter = RowFilter.regexFilter(employeeStatusFilterText, idx_Emp_STATUS);
            
            inputFilters.add(textFilter);
            if (dateFilter != null)
            {
                inputFilters.add(dateFilter);
            }
            inputFilter = RowFilter.orFilter(inputFilters);
            
            filters.add(inputFilter);
            filters.add(employeeStatusFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        
        if (empSorter != null)
        {
            empSorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, empTable);
            
            if (employeeCount > 0 &&  empSorter.getViewRowCount() != 0)
            {
                empTable.changeSelection(0, 0, false, false);
                empidLabel.setText("AT&T ID: " + empTable.getValueAt(empTable.getSelectedRow(), idx_Emp_EMPID).toString());
                employeeLabel.setText("Employee: " + empTable.getValueAt(empTable.getSelectedRow(), idx_Emp_EMPLOYEE).toString());
            }
            else
            {
                empTable.clearSelection();
                rosterTable.clearSelection();
                empidLabel.setText("AT&T ID: ");
                employeeLabel.setText("Employee: ");
            }
        }
        rosterFilter();
    }
           private void rosterFilter()
    {
        if (rosterTable == null || !rosterWorker.isDone() || empTable == null || !empWorker.isDone() || !filterEnabled)
        {
            return;
        }
        
        if (rosterTable.isEditing())
        {
            rosterTable.getCellEditor().stopCellEditing();
        }

        List<RowFilter<CustomTableModel, Object>> filtersRoster = new ArrayList<>();
        RowFilter<CustomTableModel, Object> empidFilterRoster;
        if (empSorter != null)
        {
            if(empSorter.getViewRowCount() != 0)
            {    
                empidFilterRoster = RowFilter.regexFilter(empidFilterText, idx_Mu_EMPID);
                filtersRoster.add(empidFilterRoster);
            }
            else
            {
                empidFilterRoster = RowFilter.regexFilter("xxxxxx", idx_Mu_EMPID);
                filtersRoster.add(empidFilterRoster);
            }
        }
        if (rosterSorter != null)
        {
            rosterSorter.setRowFilter(RowFilter.andFilter(filtersRoster));
                    //Misc.scaleScrollPaneToTable(getFormComponent(), rosterScrollPane, rosterTable);
            int maxWidth = 20;
            for (int i = 0; i < rosterTable.getColumnModel().getColumnCount(); i++)
            {
                maxWidth += rosterTable.getColumnModel().getColumn(i).getPreferredWidth();
            }
            int rowHeight = rosterTable.getRowHeight();
            int rowCount = rosterTable.getRowCount();
            int headerHeight = rosterTable.getTableHeader().getPreferredSize().height;
            int maxHeight = rowHeight * (rowCount) + headerHeight + 20;
        
            rosterScrollPane.setMaximumSize(new Dimension(maxWidth, maxHeight));
            rosterScrollPane.setPreferredSize(new Dimension(maxWidth, maxHeight));
            if (rowCount > 3){
                maxHeight = rowHeight * (4) + headerHeight + 20;
            }
            rosterScrollPane.setMinimumSize(new Dimension(maxWidth, maxHeight));

            if (rosterSorter.getViewRowCount() != 0)
            {
                rosterTable.changeSelection(0, 0, false, false);
            }
        }
        getFormComponent().validate();
        
    }
           
    private void updateEmpData()
    {
        if (empTable == null)
        {
            return;
        }
        if (empTable.isEditing())
        {
            empTable.getCellEditor().stopCellEditing();
        }
        int selectedRow = empTable.getSelectedRow();
        if (selectedRow < 0)
        {
            return;
        }
        if (employeeUpdated)
        {
            setCursor(Constants.HOURGLASS);
            Oracle.updateTVIEmployeeTable(getFormComponent(),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_EMPID)),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_EMPLOYEE)),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_COACH)).toUpperCase(Locale.ENGLISH),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_WEBPHONE_SUPERVISOR)).toUpperCase(Locale.ENGLISH),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_STATUS)),
                (Date)empData.getValueAt(currentEmpRow, idx_Emp_NCS_DATE),
                (Date)empData.getValueAt(currentEmpRow, idx_Emp_CHILD_BIRTH_DATE),
                Misc.objectToDouble(empData.getValueAt(currentEmpRow, idx_Emp_EXTRA_OFF_DAYS)),
                Misc.booleanToOracle(empData.getValueAt(currentEmpRow, idx_Emp_PARTTIME_FLAG)),
                Misc.objectToDouble(empData.getValueAt(currentEmpRow, idx_Emp_HOURS_PER_WEEK)),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_OTHER_PAYROLL_ID)),
                Misc.objectToString(empData.getValueAt(currentEmpRow, idx_Emp_BAND)),
                Misc.booleanToOracle(empData.getValueAt(currentEmpRow, idx_Emp_BILINGUAL_FLAG)),
                Misc.booleanToOracle(empData.getValueAt(currentEmpRow, idx_Emp_FOUR_DAY)),
                Misc.booleanToOracle(empData.getValueAt(currentEmpRow, idx_Emp_SIX_DAY)),
                UserData.getUUID(),
                null,          // idx_NCS_DATE
                null           // idx_CHILD_BIRTH_DATE
            );
            setCursor(Constants.NORMAL);
            employeeUpdated = false;
            currentEmpRow = empTable.convertRowIndexToModel(selectedRow);
        }
    }
    
    private void updateRosterData()
    {
        if (rosterTable == null)
        {
            return;
        }

        if (rosterTable.isEditing())
        {
            rosterTable.getCellEditor().stopCellEditing();
        }

        int selectedRosterRow = rosterTable.getSelectedRow();
        if (rosterUpdated)
        {
            setCursor(Constants.HOURGLASS);
            Oracle.updateMURosterTableINFOR(getFormComponent(),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_EMPID)),    
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_FEEDER)),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_SITE)),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_MU)),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_AGENTID)),
                (Date)rosterData.getValueAt(currentRosterRow, idx_Mu_START_DATE),
                (Date)rosterData.getValueAt(currentRosterRow, idx_Mu_END_DATE),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_STATUS)),
                Misc.booleanToOracle(rosterData.getValueAt(currentRosterRow, idx_Mu_DO_NOT_IMPORT)),
                Misc.objectToString(rosterData.getValueAt(currentRosterRow, idx_Mu_FLAG))
            );
            setCursor(Constants.NORMAL);
            rosterUpdated = false;
            currentRosterRow = rosterTable.convertRowIndexToModel(selectedRosterRow);
        }
    }
    
    private void closeForm()
    {
        if (empWorker != null)
        {
            empWorker.cancel(true);
        }
        if (rosterWorker != null)
        {
            rosterWorker.cancel(true);
        }
        formClosing = true;
        if (empTable != null && empTable.isEditing())
        {
            empTable.getCellEditor().stopCellEditing();
        }
        if (rosterTable != null && rosterTable.isEditing())
        {
            rosterTable.getCellEditor().stopCellEditing();
        }
        updateEmpData();
        updateRosterData();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel HistoryPanel;
    private javax.swing.JButton LOAEmployeesButton;
    private javax.swing.JPanel UpdatesPanel;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton deleteRecordButton;
    private javax.swing.JLabel empidLabel;
    private javax.swing.JButton employeeHistoryButton;
    private javax.swing.JLabel employeeLabel;
    private javax.swing.JScrollPane employeesScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JButton filterClearButton;
    private javax.swing.JLabel filterClearLabel;
    private javax.swing.JComboBox<String> filterColumnComboBox;
    private javax.swing.JLabel filterColumnTextLabel;
    private javax.swing.JComboBox<String> filterEmployeeCoachComboBox;
    private javax.swing.JLabel filterEmployeeCoachLabel;
    private javax.swing.JComboBox<String> filterEmployeeStatusComboBox;
    private javax.swing.JLabel filterEmployeeStatusLabel;
    private javax.swing.JPanel filterLabelsPanel;
    private javax.swing.JTextField filterTextField;
    private javax.swing.JLabel filterTextLabel;
    private javax.swing.JPanel filtersPanel;
    private javax.swing.JPanel gridPanel;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JLabel loadingLabel1;
    private javax.swing.JCheckBox powerUserOverrideCheckBox;
    private javax.swing.JButton printButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JScrollPane rosterScrollPane;
    private javax.swing.JButton separatedEmployeesButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel1;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton updateAllCoachesButton;
    private javax.swing.JButton updateCoachButton;
    private javax.swing.JButton updatePayrollIDsButton;
    // End of variables declaration//GEN-END:variables
}
