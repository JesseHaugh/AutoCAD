package tvicore.dao;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ResultSetWrapper
{
    private ResultSet rs = null;
    private ResultSet[] rsArray = null;
    private CallableStatement ocs;
    private PreparedStatement ps = null;

    public ResultSetWrapper(ResultSet rs, CallableStatement ocs)
    {
        this.rs = rs;
        this.ocs = ocs;
    }
    
    public ResultSetWrapper(ResultSet[] rsArray, CallableStatement ocs)
    {
        this.rsArray = rsArray;
        this.ocs = ocs;
    }
    
    public ResultSetWrapper(ResultSet rs, PreparedStatement ps)
    {
        this.rs = rs;
        this.ps = ps;
    }
    
    public ResultSetWrapper(ResultSet rs) // used when it's necessary to pass sub-resultsets to a TableSwingWorker without closing the connection once processed. (see TimeReporting)
    {
        this.rs = rs;
    }
    
    public ResultSet getResultSet() { return rs; }
    @SuppressFBWarnings(value="EI_EXPOSE_REP", justification="intentionally returning rsArray reference")
    public ResultSet[] getResultSetArray() { return rsArray; }
    public CallableStatement getCallableStatement() { return ocs; }
    public PreparedStatement getPreparedStatement() { return ps; }
    
    public void close()
    {
        Oracle.closeCursors(null, ps, rs);
        Oracle.closeCallableStatement(null, ocs);
        if (rsArray != null)
        {
            for (ResultSet rsCur : rsArray)
            {
                Oracle.closeCursors(null, null, rsCur);
            }
        }
    }
}