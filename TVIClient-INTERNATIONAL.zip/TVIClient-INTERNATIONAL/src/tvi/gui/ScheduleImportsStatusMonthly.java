package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Semaphore;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import tvicore.objects.CalendarCell;
import tvicore.objects.CalendarTableModel;
import tvicore.objects.CalendarTableRenderer;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.reports.ExcelReports;
import tvicore.resources.Resources;

public final class ScheduleImportsStatusMonthly extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ScheduleImportsStatusMonthly instance;
    
    private final String feeder;
    private final String site;
    
    private String mu;
    Date endDate = null;
    Date startDateCalendar = null;
    Date endDateCalendar = null;
    int curMonth;
    
    JTable calendarTable = new JTable();
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    CalendarTableModel calendarData;
    boolean refreshingCalendar = false;
    boolean disableRefreshing = false;
    boolean preventClose = false;
    
    Calendar cal = Calendar.getInstance();
    
    public synchronized static ScheduleImportsStatusMonthly getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ScheduleImportsStatusMonthly(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ScheduleImportsStatusMonthly(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        Oracle.setupPickEndDate(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getNextPayClose(), 52);
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            modelr.addElement(s);
        }
        muList.setModel(modelr);
        if (muList.getModel().getSize() > 0)
        {
            muList.setSelectedIndex(0);
        }
        mu = muList.getSelectedValue();
    }
    
    private void refreshData()
    {
        setCursor(Constants.HOURGLASS);
        pickDate.setEnabled(false);
        muList.setEnabled(false);
        new Thread(new RefreshCalendarThread()).start();
    }
    
    private class RefreshCalendarThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    refreshingCalendar = true;
                    initializeRefreshScheduleData();
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    createCalendarData();
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    createCalendarTable();
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    configureCalendarTable();
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    finalizeRefreshCalendar();
                }
                finally
                {
                    refreshTableLock.release();
                    refreshingCalendar = false;
                    muList.setEnabled(true);
                    pickDate.setEnabled(true);
                    setCursor(Constants.NORMAL);
                    if (disableRefreshing && !preventClose)
                    {
                        closeForm();
                    }
                    else
                    {
                        disableRefreshing = false;
                        preventClose = false;
                    }
                }
            }
        }
    }
    
    private void initializeRefreshScheduleData()
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            {
                @Override
                public void run()
                {
                    endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                }
            });
        }
        catch (InterruptedException | InvocationTargetException ex) {}
        
        if (endDate == null)
        {
            disableRefreshing = true;
            preventClose = true;
            return;
        }
        cal.setTime(endDate);
        curMonth = cal.get(Calendar.MONTH);
        Date startOfMonth = Misc.getFirstDayOfMonth(endDate);
        startDateCalendar = Misc.dateAddDays(Misc.getNextDayOfWeek(startOfMonth, RegionData.getFirstDayOfWeek(), false), -7);//first day of the Calendar (top left cell)
        endDateCalendar = Misc.dateAddDays(startDateCalendar, 41);
        
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                loadingLabel.setText("LOADING...");
                calendarScrollPane.setViewportView(loadingLabel);
            }
        });
    }
    
    private void createCalendarData()
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            {
                @Override
                public void run()
                {
                    ResultSetWrapper results = Oracle.getResultsSchedulesImportedMonthly(getFormComponent(), feeder, site, mu, startDateCalendar, endDateCalendar);
                    ResultSet rs = results.getResultSet();
                    try
                    {
                        Date curCalendarDate = startDateCalendar;
                        CalendarCell[][] data = new CalendarCell[6][7];
                        for (int i = 0; i < 6; i++)
                        {
                            for (int j = 0; j < 7; j++)
                            {
                                rs.next();
                                cal.setTime(curCalendarDate);
                                int month = cal.get(Calendar.MONTH);
                                String dayOfMonth = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
                                String employeeCount = rs.getString("EMP_COUNT");
                                boolean inCurMonth = month == curMonth;
                                data[i][j] = new CalendarCell(dayOfMonth, employeeCount, inCurMonth);
                                curCalendarDate = Misc.dateAddDays(curCalendarDate, 1);
                            }
                        }
                        calendarData = new CalendarTableModel(data, RegionData.getFirstDayOfWeek());
                    }
                    catch (SQLException ex)
                    {
                        Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error refreshing schedules imported table.");
                        refreshingCalendar = false;
                    }
                    finally
                    {
                        results.close();
                    }
                }
            });
        }
        catch (InterruptedException | InvocationTargetException ex) {}
    }
    
    private void createCalendarTable()
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            {
                @Override
                public void run()
                {
                    calendarTable = new JTable(calendarData)
                    {
                        @Override
                        public boolean isCellEditable(int row, int column)
                        {
                            return false;
                        }
                        
                        @Override
                        public Class getColumnClass(int column)
                        {
                            return CalendarCell.class;
                        }
                    };
                }
            });
        }
        catch (InterruptedException | InvocationTargetException ex) {}
    }
    
    private void configureCalendarTable()
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            {
                @Override
                public void run()
                {
                    calendarTable.addMouseListener(new java.awt.event.MouseAdapter()
                    {
                        @Override
                        public void mouseClicked(java.awt.event.MouseEvent e)
                        {
                            if (e.getButton() != MouseEvent.BUTTON1) // only handle left clicks
                            {
                                return;
                            }
                            int row = calendarTable.rowAtPoint(e.getPoint());
                            int col = calendarTable.columnAtPoint(e.getPoint());
                            if (row >= 0 && col >= 0)
                            {
                                CalendarCell cell = (CalendarCell)calendarTable.getValueAt(row, col);
                                if (cell.inCurMonth && cell.text != null)
                                {
                                    cal.setTime(endDate);
                                    cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(cell.day));
                                    Date reportingDate = cal.getTime();

                                    ScheduleNewGone.getInstance(getFormComponent(), feeder, site, mu, reportingDate);
                                }
                            }
                        }

                        @Override
                        public void mouseReleased(MouseEvent e)
                        {
                            if (e.getButton() != MouseEvent.BUTTON3) // only handle right clicks
                            {
                                return;
                            }
                            int row = calendarTable.rowAtPoint(e.getPoint());
                            int col = calendarTable.columnAtPoint(e.getPoint());
                            if (row < 0 || col < 0 || !e.isPopupTrigger())
                            {
                                return;
                            }

                            CalendarCell cell = (CalendarCell)calendarTable.getValueAt(row, col);
                            if (cell.inCurMonth && cell.text != null)
                            {
                                JPopupMenu popup = new JPopupMenu();
                                JMenuItem viewHistoryOption = new JMenuItem("Schedule Import History");

                                viewHistoryOption.addActionListener(new java.awt.event.ActionListener()
                                {
                                    @Override
                                    public void actionPerformed(java.awt.event.ActionEvent evt)
                                    {
                                        cal.setTime(endDate);
                                        cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(cell.day));
                                        Date reportingDate = cal.getTime();

                                        ScheduleImportHistory.getInstance(getFormComponent(), feeder, site, mu, reportingDate, reportingDate);
                                    }
                                });

                                popup.add(viewHistoryOption);
                                popup.show(e.getComponent(), e.getX(), e.getY());
                            }
                        }
                    });
                    calendarTable.setDefaultRenderer(CalendarCell.class, new CalendarTableRenderer());
                    calendarTable.setFillsViewportHeight(true);
                    calendarTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                    calendarTable.getTableHeader().setReorderingAllowed(false);
                    calendarTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
                    Misc.setHeaderRenderer(calendarTable, true, true, null);
                    for (int i = 0; i < 7; i++)
                    {
                        Misc.setColumnSettings(calendarTable, i, 100, false);
                    }
                    calendarTable.setRowHeight(72);
                    calendarTable.setSelectionBackground(Constants.SALMON);
                    calendarTable.setSelectionForeground(Color.BLACK);
                }
            });
        }
        catch (InterruptedException | InvocationTargetException ex) {}
    }
    
    private void finalizeRefreshCalendar()
    {
        try
        {
            SwingUtilities.invokeAndWait(new Runnable()
            {
                @Override
                public void run()
                {
                    Misc.scaleScrollPaneToTable(getFormComponent(), calendarScrollPane, calendarTable);
                    calendarScrollPane.setViewportView(calendarTable);
                    getFormComponent().validate();
                    muList.setEnabled(true);
                    pickDate.setEnabled(true);
                    muList.requestFocusInWindow();
                    setCursor(Constants.NORMAL);
                }
            });
        }
        catch (InterruptedException | InvocationTargetException ex) {}
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        siteLabel = new javax.swing.JLabel();
        feederLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        exitButton = new javax.swing.JButton();
        subtitleLabel = new javax.swing.JLabel();
        subtitleLabel1 = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        calendarPanel = new javax.swing.JPanel();
        muScrollPane = new javax.swing.JScrollPane();
        muList = new javax.swing.JList<>();
        calendarScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        scheduleImportHistoryButton = new javax.swing.JButton();
        employeeMovementReportButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Schedule Import Check");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(980, 720));
        setPreferredSize(new java.awt.Dimension(980, 720));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setPreferredSize(new java.awt.Dimension(970, 105));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setPreferredSize(new java.awt.Dimension(900, 105));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 80, -1));

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 100, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setText("Schedule Import Check by Pay Period");
        titleLabel.setPreferredSize(new java.awt.Dimension(339, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        pickDateLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pickDateLabel.setText("Payroll Ending:");
        pickDateLabel.setPreferredSize(new java.awt.Dimension(95, 30));
        titlePanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 100, -1));

        pickDate.setPreferredSize(new java.awt.Dimension(140, 30));
        pickDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickDateActionPerformed(evt);
            }
        });
        titlePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 20, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(70, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 20, -1, -1));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("MU:");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(361, 20));
        titlePanel.add(subtitleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 100, -1));

        subtitleLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel1.setText("Displays the number of employees on each schedule.");
        subtitleLabel1.setPreferredSize(new java.awt.Dimension(361, 20));
        titlePanel.add(subtitleLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 720, -1));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("Click on a day to see employee movement.");
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 85, 720, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(900, 200));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        calendarPanel.setBackground(new java.awt.Color(120, 200, 200));
        calendarPanel.setMinimumSize(new java.awt.Dimension(980, 472));
        calendarPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 0));

        muScrollPane.setMaximumSize(new java.awt.Dimension(32767, 472));
        muScrollPane.setPreferredSize(new java.awt.Dimension(100, 472));

        muList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                muListValueChanged(evt);
            }
        });
        muScrollPane.setViewportView(muList);

        calendarPanel.add(muScrollPane);

        calendarScrollPane.setAlignmentY(0.0F);
        calendarScrollPane.setMaximumSize(new java.awt.Dimension(720, 472));
        calendarScrollPane.setMinimumSize(new java.awt.Dimension(600, 200));
        calendarScrollPane.setPreferredSize(new java.awt.Dimension(720, 472));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        calendarScrollPane.setViewportView(loadingLabel);

        calendarPanel.add(calendarScrollPane);

        centerPanel.add(calendarPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(980, 60));
        bottomPanel.setPreferredSize(new java.awt.Dimension(980, 60));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 15));

        scheduleImportHistoryButton.setBackground(new java.awt.Color(120, 200, 200));
        scheduleImportHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        scheduleImportHistoryButton.setText("Schedule Import History");
        scheduleImportHistoryButton.setPreferredSize(new java.awt.Dimension(180, 30));
        scheduleImportHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleImportHistoryButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(scheduleImportHistoryButton);

        employeeMovementReportButton.setBackground(new java.awt.Color(120, 200, 200));
        employeeMovementReportButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeMovementReportButton.setText("Employee Movement");
        employeeMovementReportButton.setPreferredSize(new java.awt.Dimension(180, 30));
        employeeMovementReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMovementReportButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(employeeMovementReportButton);

        printButton.setBackground(new java.awt.Color(120, 200, 200));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setPreferredSize(new java.awt.Dimension(120, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(printButton);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, mu, calendarTable, "LANDSCAPE", "Schedule Import Check - " + Misc.getNameOfMonth(getFormComponent(), curMonth).substring(0, 3));
    }//GEN-LAST:event_printButtonActionPerformed

    private void muListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_muListValueChanged
        mu = muList.getSelectedValue();
        refreshData();
    }//GEN-LAST:event_muListValueChanged

    private void pickDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pickDateActionPerformed
        refreshData();
    }//GEN-LAST:event_pickDateActionPerformed

    private void employeeMovementReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMovementReportButtonActionPerformed
        if (feeder.equals("MEX"))
        {
            Misc.msgbox(getFormComponent(), "This report is being reworked and is unavailable at this time.", "Employee Movement", 1, 1, 1);
            return;
        }
        new Thread(new GenerateEmployeeMovementReportThread()).start();
    }//GEN-LAST:event_employeeMovementReportButtonActionPerformed

    private void scheduleImportHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleImportHistoryButtonActionPerformed
        int choice = JOptionPane.showOptionDialog
        (
            null,
            "This will show the schedule import history for the selected payroll period.\nDo you want to view a SINGLE MU, or ALL MUS?",
            "Schedule Import History",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new String[]{"SINGLE MU", "ALL MUS", "CANCEL"},
            "SINGLE MU"
        );
        switch (choice)
        {
            case 0: // SINGLE MU
                // labels
                JLabel muLabel = new JLabel("Select MU to review:");
                muLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
                muLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                muLabel.setPreferredSize(new Dimension(260, 20));
                
                // mu selection list
                JScrollPane muSelectionScrollPane = new JScrollPane();
                muSelectionScrollPane.setPreferredSize(new Dimension(100, 250));
                JList<String> muSelectionList = new JList<>();
                muSelectionList.setFont(new java.awt.Font("Tahoma", 0, 14));
                muSelectionScrollPane.setViewportView(muSelectionList);
                DefaultListModel<String> muModel = new DefaultListModel<>();
                
                // populate mulist
                for (String s : RegionData.getMuList())
                {
                    if (!Misc.isAlpha(s.substring(0, 1)))
                    {
                        muModel.addElement(s);
                    }
                }
                muSelectionList.setModel(muModel);
                if (mu != null)
                {
                    for (int i = 0; i < muSelectionList.getModel().getSize(); i++)
                    {
                        if (mu.equals(muSelectionList.getModel().getElementAt(i)))
                        {
                            muSelectionList.setSelectedIndex(i);
                            break;
                        }
                    }
                }
                else
                {
                    muSelectionList.setSelectedIndex(0);
                }
                
                // panel
                JPanel panel = new JPanel();
                panel.setPreferredSize(new Dimension(300, 330));
                FlowLayout layout = new FlowLayout();
                layout.setVgap(10);
                panel.setLayout(layout);
                panel.add(muLabel);
                panel.add(muSelectionScrollPane);
                
                int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Schedule Import History", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (rc != 0) // cancelled
                {
                    return;
                }
                
                mu = muSelectionList.getSelectedValue();
                break;
            case 1: // ALL MUS
                mu = "ALL";
                break;
            default: // user cancel
                return;
        }
        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
        ScheduleImportHistory.getInstance(getFormComponent(), feeder, site, mu, startDate, endDate);
    }//GEN-LAST:event_scheduleImportHistoryButtonActionPerformed
    
    private class GenerateEmployeeMovementReportThread implements Runnable
    {
        // this thread exists in 3 locations: ExcelReportsMenu, ScheduleImportsStatus, & ScheduleImportsStatusMonthly.
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                employeeMovementReportButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JPanel panel = new JPanel();
                    GridLayout gridLayout = new GridLayout(2, 0);
                    gridLayout.setVgap(10);
                    panel.setLayout(gridLayout);
                    
                    JLabel startDateLabel = new JLabel("Start Date:");
                    JComboBox<String> startDateCombo = new JComboBox<>();
                    startDateCombo.setEditable(true);
                    
                    JLabel endDateLabel = new JLabel("End Date:");
                    JComboBox<String> endDateCombo = new JComboBox<>();
                    endDateCombo.setEditable(true);
                    
                    Date selectedPayClose = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                    Date nextPayClose = Oracle.getNextPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose);
                    Date prevPayStart = Oracle.getPreviousPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(nextPayClose);
                    int daysBack = Misc.daysBetween(nextPayClose, prevPayStart);
                    for (int i = 0; i <= daysBack; i++)
                    {
                        startDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
                        endDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
                        cal.add(Calendar.DAY_OF_YEAR, -1);
                    }
                    
                    startDateCombo.setSelectedItem(Misc.dateToStringMDY(Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), selectedPayClose)));
                    endDateCombo.setSelectedItem(Misc.dateToStringMDY(selectedPayClose));
                    
                    panel.add(startDateLabel);
                    panel.add(startDateCombo);
                    panel.add(endDateLabel);
                    panel.add(endDateCombo);
                    
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Select a start and end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    Date startDate = Misc.stringToDateMDY(getFormComponent(), startDateCombo.getSelectedItem().toString());
                    Date endDate = Misc.stringToDateMDY(getFormComponent(), endDateCombo.getSelectedItem().toString());
                    
                    if (rc == 0) // OK was selected
                    {
                        ExcelReports.fillEmployeeMovementReport(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                employeeMovementReportButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private void closeForm()
    {
        if (refreshingCalendar)
        {
            disableRefreshing = true;
            return;
        }
        
        ScheduleNewGone.closeInstance();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel calendarPanel;
    private javax.swing.JScrollPane calendarScrollPane;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton employeeMovementReportButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JList<String> muList;
    private javax.swing.JScrollPane muScrollPane;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JButton printButton;
    private javax.swing.JButton scheduleImportHistoryButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JLabel subtitleLabel1;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
