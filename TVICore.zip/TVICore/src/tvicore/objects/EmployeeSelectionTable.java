package tvicore.objects;

import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

/**
 * EmployeeSelectionTable
 * 
 * Generic employee selection table used by multiple forms.
 */
public class EmployeeSelectionTable extends JTable
{
    final Component parentFrame;
    final String feeder;
    final String site;
    final String mu;
    final Date startDate;
    final Date endDate;
    Semaphore lock;
    JScrollPane scrollPane;
    
    CustomTableModel model;
    TableSwingWorker worker;
    
    final static int idx_EMPID    = 0;
    final static int idx_EMPLOYEE = 1;
    final static int idx_LASTDATE = 2;
    
    /**
     * EmployeeSelectionTable
     * 
     * On creation, will populate via TableSwingWorker and then auto-configure.
     * The passed variables feeder, site, mu, startDate and endDate are used to call Oracle.getEmpList.
     * The passed Semaphore lock variable is used to maintain the specific lock for the relevant form.
     * The passed scrollPane will have its ViewportView set to this table once it's finished.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param mu
     * @param startDate
     * @param endDate
     * @param lock
     * @param scrollPane 
     */
    public EmployeeSelectionTable(Component parentFrame, String feeder, String site, String mu, Date startDate, Date endDate, Semaphore lock, JScrollPane scrollPane)
    {
        this.parentFrame = parentFrame;
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.startDate = startDate;
        this.endDate = endDate;
        this.lock = lock;
        this.scrollPane = scrollPane;
        
        createTable();
    }
    
    @Override
    public boolean isCellEditable(int row, int column)
    {
        return false;
    }
    
    @Override
    public Class getColumnClass(int column)
    {
        switch (column)
        {
            case idx_LASTDATE:
                return Date.class;
            case idx_EMPID:
            case idx_EMPLOYEE:
            default:
                return String.class;
        }
    }
    
    private void createTable()
    {
        if (lock.tryAcquire())
        {
            try
            {
                worker = null;
                // builds the column names and create the data model - buildColumnNames is defined below
                model = new CustomTableModel(buildColumnNames());
                
                // create reference methods (defined below) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                
                // initialize the custom swing worker
                worker = new TableSwingWorker(parentFrame, model, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                
                // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                worker.execute();
            }
            finally
            {
                if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                {
                    Misc.msgbox(parentFrame, "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    lock.release();
                }
            }
        }
    }
    
    /**
    * buildColumnNames()
    * 
    * Builds the column names to use for the table, in index order.
    * Hidden columns still need to be listed, but can be empty Strings.
    * 
    * @return String[] column headers
    */
    private String[] buildColumnNames()
    {
        return new String[]
        {
            "AT&T ID",           // idx_EMPID
            "Name",              // idx_EMPLOYEE
            "Last Report Date"   // idx_LASTDATE
        };
    }
    
    /**
    * getResults
    * 
    * A reference to this method is passed to the TableSwingWorker as a Supplier.
    * This Supplier queries the database for results.
    * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
    * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
    * 
    * @return ResultSetWrapper
    */
    private ResultSetWrapper getResults()
    {
        return Oracle.getEmpList(parentFrame, feeder, site, mu, startDate, endDate);
    }
    
    /**
    * processResults
    * 
    * A reference to this method is passed to the TableSwingWorker as a Function.
    * This Function gets values for the current row of the table from the resultset.
    * If there is a progress bar the progress will be updated here.
    * 
    * @param rs
    * @return Object[] single row of table
    */
    private Object[] processResults(ResultSet rs)
    {
        Object[] data = null;
        try
        {
            data = new Object[]
            {
                rs.getString("EMPID"),       // idx_EMPID
                rs.getString("EMPLOYEE"),    // idx_EMPLOYEE
                rs.getDate("LASTDATE")       // idx_LASTDATE
            };
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error loading employee selection table.");
            worker.cancel(true);
        }
        return data;
    }
    
    /**
    * finalizeRefresh
    * 
    * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
    * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
    * All code here will be run on the Event Dispatch Thread.
    * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
    * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
    * Once this code is executed, the table is finished and displayed, ready for the user.
    * 
    * @param cancelled true if the TableSwingWorker was cancelled
    */
    private void finalizeRefresh(Boolean cancelled)
    {
        if (!cancelled)
        {
            this.setModel(model);
            configureTable(); //defined below
            scrollPane.setViewportView(this);
        }
        lock.release();
    }
    
    private void configureTable()
    {
        Misc.configureTable(this, true, true, false);
        Misc.setHeaderRenderer(this, true, true, null);
        Misc.setColumnSettings(this, idx_EMPID, 80);
        Misc.setColumnSettings(this, idx_EMPLOYEE, 160, Constants.LEFT);
        Misc.setColumnSettings(this, idx_LASTDATE, 110);
    }
    
    public void cancel()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
    }
}
