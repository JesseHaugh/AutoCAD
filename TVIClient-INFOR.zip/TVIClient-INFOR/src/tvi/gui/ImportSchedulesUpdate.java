package tvi.gui;

import java.awt.Component;
import java.util.Calendar;
import java.util.Date;
import javax.swing.DefaultListModel;
import tvi.client_main.Main;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportSchedulesUpdate extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ImportSchedulesUpdate instance;
    
    private final String feeder;
    private final String site;
    
    Date beforeLastStartDate;
    Date lastStartDate;
    Date thisStartDate;
    Date nextStartDate;
    Date afterNextStartDate;
    
    Date beforeLastEndDate;
    Date lastEndDate;
    Date thisEndDate;
    Date nextEndDate;
    Date afterNextEndDate;
    
    Date startDate;
    Date endDate;
    
    public synchronized static ImportSchedulesUpdate getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportSchedulesUpdate(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportSchedulesUpdate(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        updateSelection();
        
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            if (!Misc.isAlpha(s.substring(0, 1)))
            {
                modelr.addElement(s);
            }
        }
        importSchedules.setModel(modelr);
        if (importSchedules.getModel().getSize() > 0)
        {
            importSchedules.setSelectedIndex(0);
        }
        
        /***********************************************************************
        * Initialize dates & labels
        ***********************************************************************/
        thisEndDate = Misc.getNextDayOfWeek(Oracle.getCurTimeLocal(getFormComponent()), RegionData.getLastDayOfWeek(), true);
        nextEndDate = Misc.dateAddDays(thisEndDate, 7);
        afterNextEndDate = Misc.dateAddDays(thisEndDate, 14);
        lastEndDate = Misc.dateAddDays(thisEndDate, -7);
        beforeLastEndDate = Misc.dateAddDays(thisEndDate, -14);
        
        thisStartDate = Misc.dateAddDays(thisEndDate, -6);
        nextStartDate = Misc.dateAddDays(nextEndDate, -6);
        afterNextStartDate = Misc.dateAddDays(afterNextEndDate, -6);
        lastStartDate = Misc.dateAddDays(lastEndDate, -6);
        beforeLastStartDate = Misc.dateAddDays(beforeLastEndDate, -6);
        
        startDate = thisStartDate;
        endDate = thisEndDate;
        
        weekBeforeLastLabel.setText("(" + Misc.dateToStringMDY(beforeLastStartDate) + " - " + Misc.dateToStringMDY(beforeLastEndDate) + ")");
        lastWeekLabel.setText("(" + Misc.dateToStringMDY(lastStartDate) + " - " + Misc.dateToStringMDY(lastEndDate) + ")");
        thisWeekLabel.setText("(" + Misc.dateToStringMDY(thisStartDate) + " - " + Misc.dateToStringMDY(thisEndDate) + ")");
        nextWeekLabel.setText("(" + Misc.dateToStringMDY(nextStartDate) + " - " + Misc.dateToStringMDY(nextEndDate) + ")");
        afterNextWeeksLabel.setText("(" + Misc.dateToStringMDY(afterNextStartDate) + " - " + Misc.dateToStringMDY(afterNextEndDate) + ")");
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Date curDate = Misc.dateAddCustom(Misc.dateNoTime(RegionData.getPayClose()), Calendar.MONTH, 1);
        for (int i = 0; i < 70; i++)
        {
            pickDateStart.addItem(Misc.dateToStringMDY(curDate));
            pickDateEnd.addItem(Misc.dateToStringMDY(curDate));
            curDate = Misc.dateAddDays(curDate, -1);
        }
        
        Date startDateCurrent = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
        
        pickDateStart.setSelectedItem(Misc.dateToStringMDY(startDateCurrent));
        pickDateEnd.setSelectedItem(Misc.dateToStringMDY(endDate));
        pickDateStart.setEditable(true);
        pickDateEnd.setEditable(true);
    }
    
    private void closeForm()
    {
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        reportSelectionGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        subtitltePanel = new javax.swing.JPanel();
        subtitleLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        muSelectionPanel = new javax.swing.JPanel();
        muSelectionLabel = new javax.swing.JLabel();
        importSchedulesPane = new javax.swing.JScrollPane();
        importSchedules = new javax.swing.JList<>();
        datePanel = new javax.swing.JPanel();
        selectionPanel = new javax.swing.JPanel();
        importSelectionPanel = new javax.swing.JPanel();
        weekBeforeLastRadial = new javax.swing.JRadioButton();
        lastWeekRadial = new javax.swing.JRadioButton();
        thisWeekRadial = new javax.swing.JRadioButton();
        nextWeekRadial = new javax.swing.JRadioButton();
        weekAfterNextRadial = new javax.swing.JRadioButton();
        customDateRadial = new javax.swing.JRadioButton();
        importLabelPanel = new javax.swing.JPanel();
        weekBeforeLastLabel = new javax.swing.JLabel();
        lastWeekLabel = new javax.swing.JLabel();
        thisWeekLabel = new javax.swing.JLabel();
        nextWeekLabel = new javax.swing.JLabel();
        afterNextWeeksLabel = new javax.swing.JLabel();
        customDateLabel = new javax.swing.JLabel();
        customDatePanel = new javax.swing.JPanel();
        pickDateStart = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        pickDateEnd = new javax.swing.JComboBox<>();
        exitPanel = new javax.swing.JPanel();
        importSchedulesButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Import Recent Changes");
        setMinimumSize(new java.awt.Dimension(600, 500));
        setPreferredSize(new java.awt.Dimension(520, 500));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(100, 80));
        topPanel.setPreferredSize(new java.awt.Dimension(100, 120));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Import IEX Updates");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        topPanel.add(titleLabel);

        subtitltePanel.setBackground(new java.awt.Color(120, 200, 200));
        subtitltePanel.setPreferredSize(new java.awt.Dimension(600, 50));
        subtitltePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 10));

        subtitleLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel.setText("This will import only the updates in IEX for the selected schedules.");
        subtitleLabel.setPreferredSize(new java.awt.Dimension(400, 15));
        subtitltePanel.add(subtitleLabel);

        topPanel.add(subtitltePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(485, 200));
        centerPanel.setPreferredSize(new java.awt.Dimension(520, 200));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 0));

        muSelectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        muSelectionPanel.setPreferredSize(new java.awt.Dimension(60, 240));
        muSelectionPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        muSelectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        muSelectionLabel.setText("MU:");
        muSelectionLabel.setPreferredSize(new java.awt.Dimension(60, 20));
        muSelectionPanel.add(muSelectionLabel);

        importSchedulesPane.setPreferredSize(new java.awt.Dimension(60, 150));

        importSchedules.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        importSchedulesPane.setViewportView(importSchedules);

        muSelectionPanel.add(importSchedulesPane);

        centerPanel.add(muSelectionPanel);

        datePanel.setBackground(new java.awt.Color(120, 200, 200));
        datePanel.setPreferredSize(new java.awt.Dimension(400, 240));
        datePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        selectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        selectionPanel.setPreferredSize(new java.awt.Dimension(400, 200));
        selectionPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        importSelectionPanel.setBackground(new java.awt.Color(120, 200, 200));
        importSelectionPanel.setPreferredSize(new java.awt.Dimension(240, 200));
        importSelectionPanel.setLayout(new java.awt.GridLayout(6, 0));

        weekBeforeLastRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(weekBeforeLastRadial);
        weekBeforeLastRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weekBeforeLastRadial.setText("Import Week Before Last");
        weekBeforeLastRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        weekBeforeLastRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        weekBeforeLastRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        weekBeforeLastRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekBeforeLastRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(weekBeforeLastRadial);

        lastWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(lastWeekRadial);
        lastWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lastWeekRadial.setText("Import Last Week");
        lastWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        lastWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        lastWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        lastWeekRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastWeekRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(lastWeekRadial);

        thisWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(thisWeekRadial);
        thisWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        thisWeekRadial.setSelected(true);
        thisWeekRadial.setText("Import Current Week");
        thisWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        thisWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        thisWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        thisWeekRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisWeekRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(thisWeekRadial);

        nextWeekRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(nextWeekRadial);
        nextWeekRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nextWeekRadial.setText("Import Next Week");
        nextWeekRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        nextWeekRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        nextWeekRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        nextWeekRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextWeekRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(nextWeekRadial);

        weekAfterNextRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(weekAfterNextRadial);
        weekAfterNextRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weekAfterNextRadial.setText("Import Week After Next");
        weekAfterNextRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        weekAfterNextRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        weekAfterNextRadial.setPreferredSize(new java.awt.Dimension(120, 30));
        weekAfterNextRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekAfterNextRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(weekAfterNextRadial);

        customDateRadial.setBackground(new java.awt.Color(120, 200, 200));
        reportSelectionGroup.add(customDateRadial);
        customDateRadial.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        customDateRadial.setText("Custom Date Range:");
        customDateRadial.setMaximumSize(new java.awt.Dimension(120, 30));
        customDateRadial.setMinimumSize(new java.awt.Dimension(120, 30));
        customDateRadial.setPreferredSize(new java.awt.Dimension(160, 30));
        customDateRadial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customDateRadialActionPerformed(evt);
            }
        });
        importSelectionPanel.add(customDateRadial);

        selectionPanel.add(importSelectionPanel);

        importLabelPanel.setBackground(new java.awt.Color(120, 200, 200));
        importLabelPanel.setPreferredSize(new java.awt.Dimension(160, 200));
        importLabelPanel.setLayout(new java.awt.GridLayout(6, 0));

        weekBeforeLastLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weekBeforeLastLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        weekBeforeLastLabel.setText("(01/18/2015 - 01/24/2015)");
        importLabelPanel.add(weekBeforeLastLabel);

        lastWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lastWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lastWeekLabel.setText("(01/25/2015 - 01/31/2015)");
        importLabelPanel.add(lastWeekLabel);

        thisWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        thisWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        thisWeekLabel.setText("(02/01/2015 - 02/07/2015)");
        importLabelPanel.add(thisWeekLabel);

        nextWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        nextWeekLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nextWeekLabel.setText("(02/08/2015 - 02/14/2015)");
        importLabelPanel.add(nextWeekLabel);

        afterNextWeeksLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        afterNextWeeksLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        afterNextWeeksLabel.setText("(02/15/2015 - 02/21/2015)");
        importLabelPanel.add(afterNextWeeksLabel);

        customDateLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        customDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        customDateLabel.setText("(Must be 15 days or less)");
        importLabelPanel.add(customDateLabel);

        selectionPanel.add(importLabelPanel);

        datePanel.add(selectionPanel);

        customDatePanel.setBackground(new java.awt.Color(120, 200, 200));
        customDatePanel.setPreferredSize(new java.awt.Dimension(400, 40));

        pickDateStart.setPreferredSize(new java.awt.Dimension(110, 25));
        customDatePanel.add(pickDateStart);

        jLabel2.setText("-");
        customDatePanel.add(jLabel2);

        pickDateEnd.setPreferredSize(new java.awt.Dimension(110, 25));
        customDatePanel.add(pickDateEnd);

        datePanel.add(customDatePanel);

        centerPanel.add(datePanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setMinimumSize(new java.awt.Dimension(100, 100));
        exitPanel.setPreferredSize(new java.awt.Dimension(100, 100));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 20));

        importSchedulesButton.setBackground(new java.awt.Color(120, 200, 200));
        importSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        importSchedulesButton.setText("Import Updates");
        importSchedulesButton.setPreferredSize(new java.awt.Dimension(150, 60));
        importSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importSchedulesButtonActionPerformed(evt);
            }
        });
        exitPanel.add(importSchedulesButton);

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(150, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitPanel.add(exitButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void importSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importSchedulesButtonActionPerformed
        String mu = importSchedules.getSelectedValue();
        boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
        if (!okToImport)
        {
            return;
        }
        
        if (importSchedules.getSelectedValue() == null)
        {
            Misc.msgbox(getFormComponent(), "You must select an MU from the list!", "Import Schedules", 1, 1, 1);
            return;
        }
        if (Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site) != 0 && RegionData.getNewFeature())
        {
            Misc.msgbox(getFormComponent(), "Cannot import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
            return;
        }
        if (weekBeforeLastRadial.isSelected())
        {
            startDate = beforeLastStartDate;
            endDate = beforeLastEndDate;
        }
        else if (lastWeekRadial.isSelected())
        {
            startDate = lastStartDate;
            endDate = lastEndDate;
        }
        else if (thisWeekRadial.isSelected())
        {
            startDate = thisStartDate;
            endDate = thisEndDate;
        }
        else if (nextWeekRadial.isSelected())
        {
            startDate = nextStartDate;
            endDate = nextEndDate;
        }
        else if (weekAfterNextRadial.isSelected())
        {
            startDate = afterNextStartDate;
            endDate = afterNextEndDate;
        }
        else if (customDateRadial.isSelected())
        {
            startDate = Misc.stringToDateMDY(getFormComponent(), pickDateStart.getSelectedItem().toString());
            endDate = Misc.stringToDateMDY(getFormComponent(), pickDateEnd.getSelectedItem().toString());
            if (startDate == null || endDate == null)
            {
                return;
            }
            if (endDate.getTime() - startDate.getTime() > (14 * 24 * 60 * 60 * 1000))
            {
                Misc.msgbox(getFormComponent(), "Cannot import changes, date range must be 15 days or less.", "Cannot retrieve records.", 1, 1, 1);
                return;
            }
        }
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(Misc.dateNoTime(Oracle.getCurTimeLocal(this)));
        cal.add(Calendar.YEAR, -1);
        Date lastYear = cal.getTime();
        if (startDate.compareTo(lastYear) < 0)
        {
            Misc.msgbox(getFormComponent(), "Cannot import changes, start date is more than a year old.", "Cannot retrieve records.", 1, 1, 1);
            return;
        }
        
        if (Oracle.areAnySchedulesRestricted(getFormComponent(), feeder, site, mu, startDate, endDate))
        {
            Misc.msgbox(getFormComponent(), "Cannot import changes, at least one of the schedules in the current or previous pay period has locked records.", "Cannot retrieve all records.", 1, 1, 1);
            return;
        }
        else if (Oracle.areAnyRecordsLocked(getFormComponent(), feeder, site, mu, "ALL", startDate, endDate))
        {
            Misc.msgbox(getFormComponent(), "Cannot import changes, at least one of the records in the current or previous pay period is currently in use.", "Cannot retrieve all records.", 1, 1, 1);
            return;
        }
        
        if (!Misc.isImportAllowedInforTransition(getFormComponent(), Main.CLIENTNAME, feeder, site, startDate, endDate))
        {
            return;
        }
        Oracle.requestSchedule(getFormComponent(), feeder, site, mu, startDate, endDate, "UPDATE", UserData.getUUID());
        Schedules.refreshInstance();
    }//GEN-LAST:event_importSchedulesButtonActionPerformed

    private void weekBeforeLastRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekBeforeLastRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_weekBeforeLastRadialActionPerformed

    private void lastWeekRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastWeekRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_lastWeekRadialActionPerformed

    private void thisWeekRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thisWeekRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_thisWeekRadialActionPerformed

    private void nextWeekRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextWeekRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_nextWeekRadialActionPerformed

    private void weekAfterNextRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekAfterNextRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_weekAfterNextRadialActionPerformed

    private void customDateRadialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customDateRadialActionPerformed
        updateSelection();
    }//GEN-LAST:event_customDateRadialActionPerformed
    
    private void updateSelection()
    {
        pickDateStart.setEnabled(customDateRadial.isSelected());
        pickDateEnd.setEnabled(customDateRadial.isSelected());
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel afterNextWeeksLabel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JLabel customDateLabel;
    private javax.swing.JPanel customDatePanel;
    private javax.swing.JRadioButton customDateRadial;
    private javax.swing.JPanel datePanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JPanel importLabelPanel;
    private javax.swing.JList<String> importSchedules;
    private javax.swing.JButton importSchedulesButton;
    private javax.swing.JScrollPane importSchedulesPane;
    private javax.swing.JPanel importSelectionPanel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lastWeekLabel;
    private javax.swing.JRadioButton lastWeekRadial;
    private javax.swing.JLabel muSelectionLabel;
    private javax.swing.JPanel muSelectionPanel;
    private javax.swing.JLabel nextWeekLabel;
    private javax.swing.JRadioButton nextWeekRadial;
    private javax.swing.JComboBox<String> pickDateEnd;
    private javax.swing.JComboBox<String> pickDateStart;
    private javax.swing.ButtonGroup reportSelectionGroup;
    private javax.swing.JPanel selectionPanel;
    private javax.swing.JLabel subtitleLabel;
    private javax.swing.JPanel subtitltePanel;
    private javax.swing.JLabel thisWeekLabel;
    private javax.swing.JRadioButton thisWeekRadial;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JRadioButton weekAfterNextRadial;
    private javax.swing.JLabel weekBeforeLastLabel;
    private javax.swing.JRadioButton weekBeforeLastRadial;
    // End of variables declaration//GEN-END:variables
}