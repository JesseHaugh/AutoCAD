package tvicore.dao;

import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;

public class UserData
{
    // user info
    private static String userid = "";
    private static String userIP = "";
    private static String userType = "";
    private static String userStatus = "";
    private static String userAccessLevel = "";
    
    // user permissions
    private static final ArrayList<String> feederList = new ArrayList<>();
    private static final ArrayList<String> siteList   = new ArrayList<>();
    private static final ArrayList<String> siteAccess = new ArrayList<>();
    
    // user options
    private static String defaultValidation = "";
    private static String defaultFeeder = "";
    private static String defaultSite = "";
    private static boolean preferFullscreen = true;
    
    public static String getUUID()            { return userid; }
    public static String getUserIP()          { return userIP; }
    public static String getUserType()        { return userType; }
    public static String getUserStatus()      { return userStatus; }
    public static String getUserAccessLevel() { return userAccessLevel; }
    public static void setUUID(String value)            { userid = value; }
    public static void setUserIP(String value)          { userIP = value; }
    public static void setUserAccessLevel(String value) { userAccessLevel = value; }
    
    public static ArrayList<String> getFeederList() { return feederList; }
    public static ArrayList<String> getSiteList()   { return siteList; }
    public static ArrayList<String> getSiteAccess() { return siteAccess; }
    
    public static String getDefaultValidation() { return defaultValidation; }
    public static String getDefaultFeeder()     { return defaultFeeder; }
    public static String getDefaultSite()       { return defaultSite; }
    public static boolean getPreferFullscreen() { return preferFullscreen; }
    public static void setDefaultValidation(String value) { defaultValidation = value; }
    public static void setDefaultFeeder(String value)     { defaultFeeder = value; }
    public static void setDefaultSite(String value)       { defaultSite = value; }
    public static void setPreferFullscreen(boolean value) { preferFullscreen = value; }
    
    public static void updateUserFeederPermissions(Component parentFrame, String clientName, Config config)
    {
        ResultSetWrapper results = Oracle.getUserPermissions(parentFrame, getUUID());
        ResultSet rs = results.getResultSet();
        try
        {
            String feeder = "";
            feederList.clear();
            boolean hasInfor = false;
            
            while (rs.next())
            {
                if (rs.getString("CLIENT_NAME").equals("INFOR"))
                {
                    hasInfor = true;
                }
                if (rs.getString("CLIENT_NAME").equals(clientName))
                {
                    String newFeeder = rs.getString("FEEDER");
                    if (!feederList.contains(newFeeder))
                    {
                        feederList.add(newFeeder);
                    }
                }
            }
            
            if (clientName.equals("ELINK") && hasInfor && config.getClientVersion("INFOR").equals("0"))
            {
                String message = "At least one site you have access to has been activated on the new INFOR client.\n" +
                                 "To access the INFOR client, click on the 'Open TVI Launcher' button located at the top left of the Startup or Main Menu.";
                Misc.msgbox(parentFrame, message, "INFOR client available", 1, 1, 1);
            }
            
            if (feederList.size() > 0)
            {
                if (!defaultFeeder.equals(""))
                {
                    if (feederList.contains(defaultFeeder))
                    {
                        feeder = defaultFeeder;
                    }
                    else
                    {
                        defaultValidation = "";
                        Oracle.setDefaultFeeder(parentFrame, userid, null);
                        feeder = feederList.get(0);
                    }
                }
                else
                {
                    feeder = feederList.get(0);
                }
            }
            
            if (feeder.equals(""))
            {
                config.setDefaultClient("NONE");
                config.writeToFile();
                Misc.msgbox(parentFrame, "You do not have access for this client.\nReturn to the TVI Launcher to run another client, or for access email " + Constants.EMAIL, "", 1, 1, 2);
                Misc.exit(parentFrame, "NO ACCESS");
            }
            else
            {
                RegionData.setFeeder(feeder);
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing user permissions.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void loadPermissions(Component parentFrame, String clientName, String feeder)
    {
        siteList.clear();
        siteAccess.clear();
        ResultSetWrapper results = Oracle.getUserPermissions(parentFrame, userid);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                if (rs.getString("CLIENT_NAME").equals(clientName) &&
                    rs.getString("FEEDER").equals(feeder))
                {
                    String newSite = rs.getString("SITE");
                    if (!siteList.contains(newSite))
                    {
                        siteList.add(newSite);
                        siteAccess.add(rs.getString("ACCESS_LEVEL"));
                    }
                }
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing site permissions.");
        }
        finally
        {
            results.close();
        }
        if (siteList.isEmpty())
        {
            if (userType.equals("POWER"))
            {
                Misc.msgbox(parentFrame, "No active sites for feeder: " + feeder + ", exiting...", "", 1, 1, 2);
            }
            else
            {
                Misc.msgbox(parentFrame, "You do not have access to any active sites for feeder: " + feeder + ".  For access email " + Constants.EMAIL, "", 1, 1, 2);
            }
            Misc.exit(parentFrame, "NO ACCESS");
        }
        else
        {
            if (RegionData.getSite().equals("") &&
                defaultFeeder != null && !defaultFeeder.equals("") &&
                defaultSite != null && !defaultSite.equals("") && siteList.contains(defaultSite))
            {
                RegionData.setSite(defaultSite);
                int index = siteList.indexOf(defaultSite);
                userAccessLevel = siteAccess.get(index);
            }
            else
            {
                defaultSite = "";
                int siteIndex = 0;
                RegionData.setSite(siteList.get(siteIndex));
                userAccessLevel = siteAccess.get(siteIndex);
            }
        }
    }
    
    public static void updateUserAccessLevel(String site)
    {
        for (int i = 0; i < siteList.size(); i++)
        {
            if (site.equals(siteList.get(i)))
            {
                userAccessLevel = siteAccess.get(i);
            }
        }
    }
    
    public static void updateUserInfo(Component parentFrame, String sbcid)
    {
        ResultSetWrapper results = Oracle.getUserInfo(parentFrame, sbcid);
        ResultSet rs = results.getResultSet();
        try
        {
            if (rs.next())
            {
                defaultValidation = rs.getString("DEFAULT_VALIDATION");
                userType = rs.getString("USER_TYPE");
                userStatus = rs.getString("STATUS");
            }
            else
            {
                Misc.msgbox(parentFrame, "You are not authorized to use TVI.  For access email " + Constants.EMAIL, "TVI LOG IN Security", 1, 1, 2);
                Misc.exit(parentFrame, "NO ACCESS");
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error processing user info.");
        }
        finally
        {
            results.close();
        }
        if (userStatus == null)
        {
            Misc.msgbox(parentFrame, "TVI Access is NULL. Email TVI Support at " + Constants.EMAIL, "TVI LOG IN", 1, 1, 1);
            Misc.exit(parentFrame, "NO ACCESS");
        }
        else if (userStatus.equals("LOCKED"))
        {
            Misc.msgbox(parentFrame, "<html>Your user ID has been LOCKED in TVI. To unlock it, email TVI Support: " + Constants.EMAIL, "TVI LOG IN Security", 1, 1, 2);
            Misc.exit(parentFrame, "NO ACCESS");
        }
        else if (!userStatus.equals("ACTIVE"))
        {
            Misc.msgbox(parentFrame, "Your TVI Access is INACTIVE. Email TVI Support at " + Constants.EMAIL, "TVI LOG IN Security", 1, 1, 2);
            Misc.exit(parentFrame, "NO ACCESS");
        }
        
        defaultFeeder = Oracle.getDefaultFeeder(parentFrame, userid);
        defaultSite = Oracle.getDefaultSite(parentFrame, userid);
        preferFullscreen = !Oracle.getNoFullscreen(parentFrame, userid);
    }
}
