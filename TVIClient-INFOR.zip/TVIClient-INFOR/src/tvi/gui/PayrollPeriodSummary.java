package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class PayrollPeriodSummary extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile PayrollPeriodSummary instance;
    
    private final String feeder;
    private final String site;
    String union;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    DefaultListModel<String> muList = new DefaultListModel<>();
    DefaultListModel<String> coachList = new DefaultListModel<>();
    Dimension loadingPanelDimensions = new Dimension(900, 250);
    
    Date endDate = null;
    Date startDate = null;
    java.sql.Date endDateSQL;
    java.sql.Date startDateSQL;
    Date endDateLoaded = null;
    Date startDateLoaded = null;
    List<Integer> hiddenColumns = new ArrayList<>();
    
    String muFilterText = "ALL";
    String coachFilterText = "ALL";
    TableRowSorter<CustomTableModel> sorter;
    
    final static int idx_ALL_APPROVED          = 0;
    final static int idx_ALL_COMPLETED         = 1;
    final static int idx_IN_USE                = 2;
    final static int idx_COACH                 = 3;
    final static int idx_MU                    = 4;
    final static int idx_EMPID                 = 5;
    final static int idx_EMPLOYEE              = 6;
    final static int idx_TOTAL_SHIFT           = 7;
    final static int idx_TOTAL_REG             = 8;
    final static int idx_TOTAL_EXT             = 9;
    final static int idx_TOTAL_CALL_OUT        = 10;
    final static int idx_TOTAL_PR05            = 11;
    final static int idx_FLEX_HRS              = 12;
    final static int idx_DIFE                  = 13;
    final static int idx_DIFN                  = 14;
    final static int idx_TOTAL_SUND            = 15;
    final static int idx_HOLIDAY_WORKED        = 16;
    final static int idx_TOTAL_NIGHT_DIFFS     = 17;
    final static int idx_RD_7CD3               = 18;
    final static int idx_MA_7MLA               = 19;
    final static int idx_DIFR                  = 20;
    final static int idx_DIFO                  = 21;
    final static int idx_BILINGUAL_EXP         = 22;
    final static int idx_BILINGUAL_HRS         = 23;
    final static int idx_CATR                  = 24;
    final static int idx_ATTEND_OTHER          = 25;
    final static int idx_TOTAL_TOL_COUNT       = 26;
    final static int idx_TOTAL_TOL_MINUTES     = 27;
    final static int idx_TOTAL_TARDY_COUNT     = 28;
    final static int idx_TOTAL_TARDY_MINUTES   = 29;
    final static int idx_MEAL_VOUCHERS         = 30;
    final static int idx_DISU_LOA_HOURS        = 31;
    final static int idx_VACATION_HOURS        = 32;
    final static int idx_ABS_PAID_HOURS        = 33;
    final static int idx_ABS_UNPAID_HOURS      = 34;
    final static int idx_TOTAL_ABS_HOURS       = 35;
    final static int idx_REGTOTAL              = 36;
    final static int idx_CARFARE_EXP           = 37;
    final static int idx_TOTAL_CARFARE_DWS     = 38;
    final static int idx_TOTAL_DIFF_060        = 39;
    final static int idx_TOTAL_DIFF_150        = 40;
    final static int idx_TOTAL_DIFF_185        = 41;
    final static int idx_TOTAL_DIFF_200        = 42;
    final static int idx_TOTAL_DIFF_220        = 43;
    final static int idx_TOTAL_DIFF_270        = 44;
    final static int idx_TOTAL_DIFF_300        = 45;
    final static int idx_TOTAL_DIFF_600_CAR    = 46;
    final static int idx_TOTAL_DIFF_800_CAR    = 47;
    final static int idx_DIFF_1_PERCENT        = 48;
    final static int idx_DIFF_1_5_PERCENT      = 49;
    final static int idx_DIFF_2_PERCENT        = 50;
    final static int idx_DIFF_2_5_PERCENT      = 51;
    final static int idx_DIFF_3_PERCENT        = 52;
    final static int idx_TOTAL_DIFF_900        = 53;
    final static int idx_GAP                   = 54;
    final static int idx_TOTAL_SIXTHDAY        = 55;
    final static int idx_MILEAGE_EXP           = 56;
    final static int idx_OTHER_DOLLAR_PAYMENTS = 57;
    
    public static boolean focusInstance()
    {
        if (instance != null)
        {
            instance.toFront();
        }
        return instance != null;
    }
    
    public synchronized static PayrollPeriodSummary getInstance(Component parentFrame, String feeder, String site, Date payrollEndDate)
    {
        if (instance != null)
        {
            if (payrollEndDate != null)
            {
                instance.loadPayrollEndDate(payrollEndDate);
            }
        }
        else
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new PayrollPeriodSummary(feeder, site, payrollEndDate);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private PayrollPeriodSummary(String feeder, String site, Date payrollEndDate)
    {
        this.feeder = feeder;
        this.site = site;
        union = RegionData.getSiteUnion();
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        Oracle.setupPickEndDate(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getNextPayClose(), 52);
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        unionLabel.setText("Union: " + union);
        
        setControlsEnabled(false);
        
        loadingLabel.setVisible(false);
        progressBar.setVisible(false);
        
        loadPayrollEndDate(payrollEndDate);
    }
    
    public static boolean exists()
    {
        return instance != null;
    }
    
    private void loadPayrollEndDate(Date payrollEndDate)
    {
        String payEndDate = Misc.dateToStringMDY(payrollEndDate);
        if (payrollEndDate != null && ((DefaultComboBoxModel)pickDate.getModel()).getIndexOf(payEndDate) != -1) // combobox contains payroll end date
        {
            pickDate.setSelectedItem(payEndDate);
            refreshData();
        }
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    retrieveButton.setEnabled(false);
                    progressBar.setValue(0);
                    progressBar.setMaximum(1);
                    progressBar.setVisible(true);
                    loadingLabel.setVisible(true);
                    payrollSummaryScrollPane.setMaximumSize(loadingPanelDimensions);
                    payrollSummaryScrollPane.setPreferredSize(loadingPanelDimensions);
                    payrollSummaryScrollPane.setViewportView(loadingPanel);
                    validate();
                }
            });
            
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            if (endDate == null)
            {
                if (worker != null)
                {
                    worker.cancel(true);
                }
                return;
            }
            startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
            
            setControlsEnabled(false);
            muList.clear();
            coachList.clear();
            startDateLoaded = startDate;
            endDateLoaded = endDate;
            
            setHiddenColumns();
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            String[] colNames = new String[]
            {
                Misc.centerHTML("Empl<br>All<br>Appr"),          // idx_ALL_APPROVED
                Misc.centerHTML("Empl<br>All<br>Comp"),          // idx_ALL_COMPLETED
                Misc.centerHTML("In<br>Use"),                    // idx_IN_USE
                "Coach",                                         // idx_COACH
                "MU",                                            // idx_MU
                Misc.centerHTML("AT&T<br>ID"),                   // idx_EMPID
                "NAME",                                          // idx_EMPLOYEE
                "Shift",                                         // idx_TOTAL_SHIFT
                "REG",                                           // idx_TOTAL_REG
                "EXT",                                           // idx_TOTAL_EXT
                Misc.centerHTML("Call<br>Out"),                  // idx_TOTAL_CALL_OUT
                "Prem",                                          // idx_TOTAL_PR05
                Misc.centerHTML("Comp<br>Time<br>Earned"),       // idx_FLEX_HRS
                Misc.centerHTML("Evening<br>Hours"),             // idx_DIFE
                Misc.centerHTML("Diff<br>Shift<br>Hours"),       // idx_DIFN
                "SUND",                                          // idx_TOTAL_SUND
                Misc.centerHTML("HLDY<br>Worked"),               // idx_HOLIDAY_WORKED
                Misc.centerHTML("# of<br>Diff<br>Shfts"),        // idx_TOTAL_NIGHT_DIFFS
                Misc.centerHTML("RD<br>WL $"),                   // idx_RD_7CD3
                "MA $",                                          // idx_MA_7MLA
                Misc.centerHTML("RD<br>Reg"),                    // idx_DIFR
                Misc.centerHTML("RD<br>Ext"),                    // idx_DIFO
                Misc.centerHTML("Mult<br>$"),                    // idx_BILINGUAL_EXP
                Misc.centerHTML("Mult<br>Hours"),                // idx_BILINGUAL_HRS
                "CATR",                                          // idx_CATR
                Misc.centerHTML("Other<br>Attend"),              // idx_ATTEND_OTHER
                Misc.centerHTML("# of<br>Tol"),                  // idx_TOTAL_TOL_COUNT
                Misc.centerHTML("TOL<br>Mins"),                  // idx_TOTAL_TOL_MINUTES
                Misc.centerHTML("# of<br>MTDY"),                 // idx_TOTAL_TARDY_COUNT
                Misc.centerHTML("MTDY<br>Mins"),                 // idx_TOTAL_TARDY_MINUTES
                Misc.centerHTML("Meal<br>Vouchers"),             // idx_MEAL_VOUCHERS
                Misc.centerHTML("DIS/<br>LOA<br>Hrs"),           // idx_DISU_LOA_HOURS
                Misc.centerHTML("Paid<br>PDO/<br>Vac"),          // idx_VACATION_HOURS
                Misc.centerHTML("Other<br>Abs<br>Paid"),         // idx_ABS_PAID_HOURS
                Misc.centerHTML("Other<br>Abs<br>Unpaid"),       // idx_ABS_UNPAID_HOURS
                Misc.centerHTML("Abs<br>Tot"),                   // idx_TOTAL_ABS_HOURS
                Misc.centerHTML("Reg<br>+<br>Abs"),              // idx_REGTOTAL
                Misc.centerHTML("Car<br>Fare<br>$"),             // idx_CARFARE_EXP
                Misc.centerHTML("Car<br>Fare<br>DWS"),           // idx_TOTAL_CARFARE_DWS
                "0.60",                                          // idx_TOTAL_DIFF_060
                Misc.centerHTML("Sat<br>1.50"),                  // idx_TOTAL_DIFF_150
                "1.85",                                          // idx_TOTAL_DIFF_185
                "2.00",                                          // idx_TOTAL_DIFF_200
                "2.20",                                          // idx_TOTAL_DIFF_220
                "2.70",                                          // idx_TOTAL_DIFF_270
                "3.00",                                          // idx_TOTAL_DIFF_300
                Misc.centerHTML("Split<br>6.00"),                // idx_TOTAL_DIFF_600_CAR
                Misc.centerHTML("Split<br>8.00"),                // idx_TOTAL_DIFF_800_CAR
                "9.00",                                          // idx_DIFF_1_PERCENT
                "1%",                                            // idx_DIFF_1_5_PERCENT
                "1.5%",                                          // idx_DIFF_2_PERCENT
                "2%",                                            // idx_DIFF_2_5_PERCENT
                "2.5%",                                          // idx_DIFF_3_PERCENT
                "3%",                                            // idx_TOTAL_DIFF_900
                "Split",                                         // idx_GAP
                Misc.centerHTML("6th<br>Day"),                   // idx_TOTAL_SIXTHDAY
                "Miles",                                         // idx_MILEAGE_EXP
                Misc.centerHTML("$<br>Other")                    // idx_OTHER_DOLLAR_PAYMENTS
            };
            
            if (feeder.equals("ETI"))
            {
                colNames[idx_TOTAL_NIGHT_DIFFS] = Misc.centerHTML("# of<br>RNA<br>Shfts");
            }
            return colNames;
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            // Total row count for progressBar
            progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, null, null, startDate, endDate, "APPROVALS"));
            
            return Oracle.getResultsPayrollApproval(getFormComponent(), feeder, site, "ALL", startDate, endDate, UserData.getUUID());
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress will be updated here in an invokeLater() in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String coach = rs.getString("COACH");
                if (coach != null && !coachList.contains(coach))
                {
                    coachList.addElement(coach);
                }
                String mu = rs.getString("MU");
                if (!muList.contains(mu))
                {
                    muList.addElement(mu);
                }
                
                data = new Object[]
                {
                    rs.getString("All_APPROVED"),                       // idx_ALL_APPROVED
                    rs.getString("ALL_COMPLETED"),                      // idx_ALL_COMPLETED
                    rs.getString("IN_USE"),                             // idx_IN_USE
                    coach,                                              // idx_COACH
                    mu,                                                 // idx_MU
                    rs.getString("EMPID"),                              // idx_EMPID
                    rs.getString("EMPLOYEE"),                           // idx_EMPLOYEE
                    rs.getBigDecimal("TOTAL_SHIFT"),                    // idx_TOTAL_SHIFT
                    rs.getBigDecimal("TOTAL_REG"),                      // idx_TOTAL_REG
                    rs.getBigDecimal("TOTAL_EXT"),                      // idx_TOTAL_EXT
                    rs.getBigDecimal("TOTAL_CALL_OUT"),                 // idx_TOTAL_CALL_OUT
                    rs.getBigDecimal("TOTAL_PR05"),                     // idx_TOTAL_PR05
                    rs.getBigDecimal("TOTAL_FLEX"),                     // idx_FLEX_HRS
                    rs.getBigDecimal("DIFE"),                           // idx_DIFE
                    rs.getBigDecimal("DIFN"),                           // idx_DIFN
                    rs.getBigDecimal("TOTAL_SUND"),                     // idx_TOTAL_SUND
                    rs.getBigDecimal("HOLIDAY_WORKED"),                 // idx_HOLIDAY_WORKED
                    rs.getInt("TOTAL_NIGHT_DIFFS"),                     // idx_TOTAL_NIGHT_DIFFS
                    rs.getBigDecimal("RD_7CD3"),                        // idx_RD_7CD3
                    rs.getBigDecimal("MA_7MLA"),                        // idx_MA_7MLA
                    rs.getBigDecimal("DIFR"),                           // idx_DIFR
                    rs.getBigDecimal("DIFO"),                           // idx_DIFO
                    rs.getBigDecimal("BILINGUAL_EXP"),                  // idx_BILINGUAL_EXP
                    rs.getBigDecimal("BILINGUAL_HRS"),                  // idx_BILINGUAL_HRS
                    rs.getBigDecimal("CATR"),                           // idx_CATR
                    Misc.oracleToBoolean(rs.getObject("ATTEND_OTHER")), // idx_ATTEND_OTHER
                    rs.getInt("TOTAL_TOL_COUNT"),                       // idx_TOTAL_TOL_COUNT
                    rs.getInt("TOTAL_TOL_MINUTES"),                     // idx_TOTAL_TOL_MINUTES
                    rs.getInt("TOTAL_TARDY_COUNT"),                     // idx_TOTAL_TARDY_COUNT
                    rs.getInt("TOTAL_TARDY_MINUTES"),                   // idx_TOTAL_TARDY_MINUTES
                    rs.getInt("TOTAL_MA"),                              // idx_MEAL_VOUCHERS
                    rs.getBigDecimal("DISU_LOA_HOURS"),                 // idx_DISU_LOA_HOURS
                    rs.getBigDecimal("VACATION_HOURS"),                 // idx_VACATION_HOURS
                    rs.getBigDecimal("ABS_PAID_HOURS"),                 // idx_ABS_PAID_HOURS
                    rs.getBigDecimal("ABS_UNPAID_HOURS"),               // idx_ABS_UNPAID_HOURS
                    rs.getBigDecimal("TOTAL_ABS_HOURS"),                // idx_TOTAL_ABS_HOURS
                    rs.getBigDecimal("REGTOTAL"),                       // idx_REGTOTAL
                    rs.getBigDecimal("CARFARE_EXP"),                    // idx_CARFARE_EXP
                    rs.getInt("TOTAL_CARFARE_DWS"),                     // idx_TOTAL_CARFARE_DWS
                    rs.getInt("TOTAL_DIFF_060"),                        // idx_TOTAL_DIFF_060
                    rs.getInt("TOTAL_DIFF_150"),                        // idx_TOTAL_DIFF_150
                    rs.getInt("TOTAL_DIFF_185"),                        // idx_TOTAL_DIFF_185
                    rs.getInt("TOTAL_DIFF_200"),                        // idx_TOTAL_DIFF_200
                    rs.getInt("TOTAL_DIFF_220"),                        // idx_TOTAL_DIFF_220
                    rs.getInt("TOTAL_DIFF_270"),                        // idx_TOTAL_DIFF_270
                    rs.getInt("TOTAL_DIFF_300"),                        // idx_TOTAL_DIFF_300
                    rs.getInt("TOTAL_DIFF_600_CAR"),                    // idx_TOTAL_DIFF_600_CAR
                    rs.getInt("TOTAL_DIFF_800_CAR"),                    // idx_TOTAL_DIFF_800_CAR
                    rs.getInt("TOTAL_DIFF_900"),                        // idx_DIFF_1_PERCENT
                    rs.getInt("TOTAL_DIFF_1_PERCENT"),                  // idx_DIFF_1_5_PERCENT
                    rs.getInt("TOTAL_DIFF_1_5_PERCENT"),                // idx_DIFF_2_PERCENT
                    rs.getInt("TOTAL_DIFF_2_PERCENT"),                  // idx_DIFF_2_5_PERCENT
                    rs.getInt("TOTAL_DIFF_2_5_PERCENT"),                // idx_DIFF_3_PERCENT
                    rs.getInt("TOTAL_DIFF_3_PERCENT"),                  // idx_TOTAL_DIFF_900
                    rs.getInt("TOTAL_GAP"),                             // idx_GAP
                    rs.getInt("TOTAL_SIXTHDAY"),                        // idx_TOTAL_SIXTHDAY
                    rs.getInt("MILEAGE_EXP"),                           // idx_MILEAGE_EXP
                    rs.getBigDecimal("OTHER_DOLLAR_PAYMENTS")           // idx_OTHER_DOLLAR_PAYMENTS
                };
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        progressBar.setValue(progressBar.getValue() + 1);
                    }
                });
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Payroll Period Summary data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), payrollSummaryScrollPane, table);
                payrollSummaryScrollPane.setViewportView(table);
            }
            else
            {
                clearTable();
            }
            refreshFilterComboBoxes();
            setControlsEnabled(true);
            retrieveButton.setEnabled(true);
            setCursor(Constants.NORMAL);
            getFormComponent().validate();
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_TOTAL_SHIFT:
                        case idx_TOTAL_REG:
                        case idx_TOTAL_EXT:
                        case idx_TOTAL_CALL_OUT:
                        case idx_TOTAL_PR05:
                        case idx_FLEX_HRS:
                        case idx_DIFE:
                        case idx_DIFN:
                        case idx_TOTAL_SUND:
                        case idx_HOLIDAY_WORKED:
                        case idx_RD_7CD3:
                        case idx_MA_7MLA:
                        case idx_DIFR:
                        case idx_DIFO:
                        case idx_BILINGUAL_EXP:
                        case idx_BILINGUAL_HRS:
                        case idx_CATR:
                        case idx_DISU_LOA_HOURS:
                        case idx_VACATION_HOURS:
                        case idx_ABS_PAID_HOURS:
                        case idx_ABS_UNPAID_HOURS:
                        case idx_TOTAL_ABS_HOURS:
                        case idx_REGTOTAL:
                        case idx_CARFARE_EXP:
                        case idx_OTHER_DOLLAR_PAYMENTS:
                            return BigDecimal.class;
                        case idx_ATTEND_OTHER:
                            return Boolean.class;
                        case idx_TOTAL_NIGHT_DIFFS:
                        case idx_TOTAL_TOL_COUNT:
                        case idx_TOTAL_TOL_MINUTES:
                        case idx_TOTAL_TARDY_COUNT:
                        case idx_TOTAL_TARDY_MINUTES:
                        case idx_MEAL_VOUCHERS:
                        case idx_TOTAL_CARFARE_DWS:
                        case idx_TOTAL_DIFF_060:
                        case idx_TOTAL_DIFF_150:
                        case idx_TOTAL_DIFF_185:
                        case idx_TOTAL_DIFF_200:
                        case idx_TOTAL_DIFF_220:
                        case idx_TOTAL_DIFF_270:
                        case idx_TOTAL_DIFF_300:
                        case idx_TOTAL_DIFF_600_CAR:
                        case idx_TOTAL_DIFF_800_CAR:
                        case idx_TOTAL_DIFF_900:
                        case idx_DIFF_1_PERCENT:
                        case idx_DIFF_1_5_PERCENT:
                        case idx_DIFF_2_PERCENT:
                        case idx_DIFF_2_5_PERCENT:
                        case idx_DIFF_3_PERCENT:
                        case idx_GAP:
                        case idx_TOTAL_SIXTHDAY:
                        case idx_MILEAGE_EXP:
                            return Integer.class;
                        case idx_ALL_APPROVED:
                        case idx_ALL_COMPLETED:
                        case idx_IN_USE:
                        case idx_MU:
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (table.getValueAt(row, idx_IN_USE).equals("Yes"))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, false, false, false);
            
            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);
            
            Misc.setTableSorterNumeralComparator(table);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_ALL_APPROVED, 0);
            Misc.setColumnSettings(table, idx_ALL_COMPLETED, 40);
            Misc.setColumnSettings(table, idx_IN_USE, 40);
            Misc.setColumnSettings(table, idx_COACH, 60);
            Misc.setColumnSettings(table, idx_MU, 60);
            Misc.setColumnSettings(table, idx_EMPID, 60);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 130, Constants.LEFT);
            Misc.setColumnSettings(table, idx_TOTAL_SHIFT, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_REG, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_EXT, 45, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_CALL_OUT, 50, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_PR05, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_FLEX_HRS, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_DIFE, 65, true, Constants.RIGHT);                    // NOT USED
            Misc.setColumnSettings(table, idx_DIFN, 40, true, Constants.RIGHT);                    // NOT USED
            Misc.setColumnSettings(table, idx_TOTAL_SUND, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_HOLIDAY_WORKED, 50, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_NIGHT_DIFFS, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_RD_7CD3, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_MA_7MLA, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_DIFR, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_DIFO, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_BILINGUAL_EXP, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_BILINGUAL_HRS, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_CATR, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_ATTEND_OTHER, 45, false);
            Misc.setColumnSettings(table, idx_TOTAL_TOL_COUNT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_TOL_MINUTES, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_TARDY_COUNT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_TARDY_MINUTES, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_MEAL_VOUCHERS, 60, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DISU_LOA_HOURS, 45, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_VACATION_HOURS, 50, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_ABS_PAID_HOURS, 50, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_ABS_UNPAID_HOURS, 50, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_ABS_HOURS, 45, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_REGTOTAL, 45, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_CARFARE_EXP, 40, true, Constants.RIGHT);
            Misc.setColumnSettings(table, idx_TOTAL_CARFARE_DWS, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_060, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_150, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_185, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_200, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_220, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_270, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_300, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_600_CAR, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_800_CAR, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_DIFF_900, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DIFF_1_PERCENT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DIFF_1_5_PERCENT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DIFF_2_PERCENT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DIFF_2_5_PERCENT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_DIFF_3_PERCENT, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_GAP, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_TOTAL_SIXTHDAY, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_MILEAGE_EXP, 40, true, Constants.CENTER);
            Misc.setColumnSettings(table, idx_OTHER_DOLLAR_PAYMENTS, 40, true, Constants.RIGHT);
            for (int columnIndex2Hide : hiddenColumns)
            {
                Misc.setColumnSettings(table, columnIndex2Hide, 0, false);
            }
            table.setSelectionBackground(Constants.SALMON);
            table.setSelectionForeground(Color.BLACK);
            
            processFilter();
        }
    }
    
    /***************************************************************************
    * setHiddenColumns
    * Called by the constructor when the form is first generated.
    * Determines which columns to display in the table - depends on the feeder and union
    **************************************************************************/
    private void setHiddenColumns()
    {
        // Create a list of all columns
        List<Integer> allColumns = new ArrayList<>();
        for (int i = idx_ALL_APPROVED; i <= idx_OTHER_DOLLAR_PAYMENTS; i++)
        {
            allColumns.add(i);
        }
        // Create a list of columns visible for all feeders/unions
        List<Integer> columnsToShow = new ArrayList<>(Arrays.asList
        (
            idx_ALL_APPROVED, idx_ALL_COMPLETED, idx_IN_USE, idx_COACH, idx_MU, idx_EMPID, idx_EMPLOYEE, idx_TOTAL_SHIFT, idx_TOTAL_REG, idx_TOTAL_EXT,
            idx_TOTAL_TARDY_COUNT, idx_TOTAL_TARDY_MINUTES, idx_DISU_LOA_HOURS, idx_VACATION_HOURS,
            idx_ABS_PAID_HOURS, idx_ABS_UNPAID_HOURS, idx_TOTAL_ABS_HOURS, idx_REGTOTAL
        ));
        // Add conditional columns for their respective feeders/unions
        switch (feeder)
        {
            case "ATI":
                switch (union)
                {
                    case "ATI_CWA_4":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_CATR, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "ATI_CWA_4_F":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_CATR, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "ATI_IBEW_4_5":
                    case "ATI_IBEW_AIS":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_DIFO, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "ATI_IBEW_1_3":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_CATR, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    default:
                        Misc.msgbox(getFormComponent(), "Unhandled union flag, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                }
                break;
            case "BTI":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_DIFO, idx_BILINGUAL_EXP,
                    idx_CATR, idx_ATTEND_OTHER, idx_CARFARE_EXP, idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                ));
                break;
            case "ETI":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_DIFN, idx_RD_7CD3, idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_CATR, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                ));
                break;
            case "GTI":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_TOTAL_PR05, idx_TOTAL_SUND, idx_RD_7CD3, idx_TOTAL_NIGHT_DIFFS, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                ));
                break;
            case "STI":
                switch (union)
                {
                    case "STI-CWA":
                    case "STI-CCC":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_DIFN, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_DIFO, idx_BILINGUAL_HRS, idx_CATR,
                            idx_ATTEND_OTHER, idx_TOTAL_CARFARE_DWS, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    default:
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_TOTAL_NIGHT_DIFFS, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                }
                break;
            case "TTI":
                switch (union)
                {
                    case "TTI-37":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_BILINGUAL_EXP, idx_CATR, idx_ATTEND_OTHER,
                            idx_TOTAL_DIFF_060, idx_TOTAL_DIFF_200, idx_TOTAL_DIFF_600_CAR, idx_TOTAL_DIFF_900,
                            idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "TTI-39":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_BILINGUAL_EXP, idx_CATR, idx_ATTEND_OTHER,
                            idx_TOTAL_DIFF_200, idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "TTI-TRA":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_CATR, idx_ATTEND_OTHER,
                            idx_TOTAL_DIFF_150, idx_TOTAL_DIFF_185, idx_TOTAL_DIFF_220, idx_TOTAL_DIFF_270, idx_TOTAL_DIFF_800_CAR,
                            idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "TTI-44":
                    case "TTI-45":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_DIFN, idx_RD_7CD3, idx_TOTAL_CALL_OUT, idx_BILINGUAL_EXP, idx_CATR, idx_ATTEND_OTHER,
                            idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    case "TTI-35":
                    case "TTI-36":
                    case "TTI-41":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_DIFR, idx_BILINGUAL_EXP, idx_CATR, idx_ATTEND_OTHER,
                            idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    default:
                        Misc.msgbox(getFormComponent(), "Unhandled union flag, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                }
                break;
            case "TVI":
                switch (union)
                {
                    case "TVI-OPER":
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_CATR, idx_ATTEND_OTHER,
                            idx_DIFF_1_PERCENT, idx_DIFF_1_5_PERCENT, idx_DIFF_2_PERCENT, idx_DIFF_2_5_PERCENT, idx_DIFF_3_PERCENT,
                            idx_GAP, idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                    default:
                        columnsToShow.addAll(Arrays.asList
                        (
                            idx_RD_7CD3, idx_MA_7MLA, idx_TOTAL_CALL_OUT, idx_TOTAL_NIGHT_DIFFS, idx_CATR, idx_ATTEND_OTHER, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                        ));
                        break;
                }
                break;
            default:
                columnsToShow.addAll(Arrays.asList
                (
                    idx_FLEX_HRS, idx_HOLIDAY_WORKED, idx_TOTAL_CALL_OUT, idx_ATTEND_OTHER, idx_TOTAL_TOL_COUNT,
                    idx_TOTAL_TOL_MINUTES, idx_MEAL_VOUCHERS, idx_CARFARE_EXP, idx_TOTAL_CARFARE_DWS,
                    idx_TOTAL_DIFF_060, idx_TOTAL_DIFF_150, idx_TOTAL_DIFF_185, idx_TOTAL_DIFF_200, idx_TOTAL_DIFF_220,
                    idx_TOTAL_DIFF_270, idx_TOTAL_DIFF_300, idx_TOTAL_DIFF_600_CAR, idx_TOTAL_DIFF_800_CAR, idx_TOTAL_DIFF_900,
                    idx_TOTAL_SIXTHDAY, idx_MILEAGE_EXP, idx_OTHER_DOLLAR_PAYMENTS
                ));
                break;
        }
        hiddenColumns = Misc.getHiddenColumns(allColumns, columnsToShow);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        siteLabel = new javax.swing.JLabel();
        feederLabel = new javax.swing.JLabel();
        formTitlePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        controlPanel = new javax.swing.JPanel();
        employeeDetailButton = new javax.swing.JButton();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        retrieveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        unionLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        payrollSummaryScrollPane = new javax.swing.JScrollPane();
        loadingPanel = new javax.swing.JPanel();
        loadingItems = new javax.swing.JPanel();
        loadingLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        bottomPanel = new javax.swing.JPanel();
        gridPanel = new javax.swing.JPanel();
        filterLabelsPanel = new javax.swing.JPanel();
        muFilterLabel = new javax.swing.JLabel();
        coachFilterLabel = new javax.swing.JLabel();
        filtersPanel = new javax.swing.JPanel();
        filterMuComboBox = new javax.swing.JComboBox<>();
        filterCoachComboBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Payroll Period Summary");
        setBackground(new java.awt.Color(120, 200, 200));
        setMinimumSize(new java.awt.Dimension(1025, 520));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        siteLabel.setPreferredSize(new java.awt.Dimension(70, 16));
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederLabel.setPreferredSize(new java.awt.Dimension(90, 16));
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        formTitlePanel.setBackground(new java.awt.Color(120, 200, 200));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setText("Payroll Period Summary");
        formTitlePanel.add(titleLabel);

        titlePanel.add(formTitlePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 540, 40));

        controlPanel.setBackground(new java.awt.Color(120, 200, 200));

        employeeDetailButton.setBackground(new java.awt.Color(120, 200, 200));
        employeeDetailButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        employeeDetailButton.setText("Emp Detail");
        employeeDetailButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeDetailButtonActionPerformed(evt);
            }
        });
        controlPanel.add(employeeDetailButton);

        titlePanel.add(controlPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 540, 40));

        pickDateLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pickDateLabel.setText("Payroll Ending:");
        pickDateLabel.setMaximumSize(new java.awt.Dimension(100, 30));
        pickDateLabel.setMinimumSize(new java.awt.Dimension(100, 30));
        pickDateLabel.setPreferredSize(new java.awt.Dimension(100, 30));
        titlePanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 50, 100, -1));

        pickDate.setPreferredSize(new java.awt.Dimension(140, 30));
        pickDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickDateActionPerformed(evt);
            }
        });
        titlePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 50, -1, -1));

        retrieveButton.setBackground(new java.awt.Color(120, 200, 200));
        retrieveButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        retrieveButton.setText("Retrieve Data");
        retrieveButton.setPreferredSize(new java.awt.Dimension(130, 30));
        retrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retrieveButtonActionPerformed(evt);
            }
        });
        titlePanel.add(retrieveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 50, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(70, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(934, 5, -1, -1));

        unionLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        unionLabel.setText("Union: ");
        unionLabel.setPreferredSize(new java.awt.Dimension(180, 16));
        titlePanel.add(unionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 20, -1, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMaximumSize(new java.awt.Dimension(900, 390));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        payrollSummaryScrollPane.setAlignmentY(0.0F);
        payrollSummaryScrollPane.setMaximumSize(new java.awt.Dimension(900, 250));
        payrollSummaryScrollPane.setMinimumSize(new java.awt.Dimension(900, 250));
        payrollSummaryScrollPane.setName(""); // NOI18N
        payrollSummaryScrollPane.setPreferredSize(new java.awt.Dimension(900, 250));

        loadingPanel.setMaximumSize(new java.awt.Dimension(898, 248));
        loadingPanel.setMinimumSize(new java.awt.Dimension(898, 248));
        loadingPanel.setPreferredSize(new java.awt.Dimension(898, 248));
        loadingPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 50));

        loadingItems.setPreferredSize(new java.awt.Dimension(740, 100));
        loadingItems.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(200, 25));
        loadingItems.add(loadingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, -1));

        progressBar.setPreferredSize(new java.awt.Dimension(740, 25));
        progressBar.setStringPainted(true);
        loadingItems.add(progressBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        loadingPanel.add(loadingItems);

        payrollSummaryScrollPane.setViewportView(loadingPanel);

        centerPanel.add(payrollSummaryScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(980, 60));
        bottomPanel.setPreferredSize(new java.awt.Dimension(980, 140));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        gridPanel.setBackground(new java.awt.Color(120, 200, 200));
        gridPanel.setMinimumSize(new java.awt.Dimension(850, 80));
        gridPanel.setPreferredSize(new java.awt.Dimension(850, 80));
        gridPanel.setLayout(new java.awt.GridLayout(2, 0));

        filterLabelsPanel.setBackground(new java.awt.Color(120, 200, 200));
        filterLabelsPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        muFilterLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        muFilterLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        muFilterLabel.setText("Filter by MU:");
        muFilterLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        muFilterLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(muFilterLabel);

        coachFilterLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        coachFilterLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        coachFilterLabel.setText("Filter by Coach:");
        coachFilterLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        coachFilterLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(coachFilterLabel);

        gridPanel.add(filterLabelsPanel);

        filtersPanel.setBackground(new java.awt.Color(120, 200, 200));
        filtersPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        filtersPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filtersPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        filterMuComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterMuComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All" }));
        filterMuComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterMuComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterMuComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterMuComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterMuComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterMuComboBox);

        filterCoachComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterCoachComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All" }));
        filterCoachComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterCoachComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterCoachComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterCoachComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterCoachComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterCoachComboBox);

        gridPanel.add(filtersPanel);

        bottomPanel.add(gridPanel);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void retrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retrieveButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_retrieveButtonActionPerformed
    
    private void employeeDetailButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeDetailButtonActionPerformed
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select an employee.", "Employee Detail", 1, 1, 1);
            return;
        }
        
        String empid = table.getValueAt(selectedRow, idx_EMPID).toString();
        Date startDateSched = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
        TimeReporting.getInstance(getFormComponent(), feeder, site, null, empid, startDateSched, endDate, union, "APPR READ ONLY");
    }//GEN-LAST:event_employeeDetailButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void pickDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pickDateActionPerformed
        setCursor(Constants.HOURGLASS);
        if (worker != null)
        {
            worker.cancel(true);
        }
        clearTable();
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_pickDateActionPerformed

    private void filterMuComboBoxActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_filterMuComboBoxActionPerformed
    {//GEN-HEADEREND:event_filterMuComboBoxActionPerformed
        muFilterText = Misc.objectToString(filterMuComboBox.getSelectedItem());
        if (Arrays.asList("", "Show All").contains(muFilterText))
        {
            muFilterText = "ALL";
        }
        processFilter();
    }//GEN-LAST:event_filterMuComboBoxActionPerformed

    private void filterCoachComboBoxActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_filterCoachComboBoxActionPerformed
    {//GEN-HEADEREND:event_filterCoachComboBoxActionPerformed
        coachFilterText = Misc.objectToString(filterCoachComboBox.getSelectedItem());
        if (Arrays.asList("", "Show All").contains(coachFilterText))
        {
            coachFilterText = "ALL";
        }
        if (coachFilterText.length() >= 15 && coachFilterText.substring(0, 9).equals("<html><b>"))
        {
            coachFilterText = coachFilterText.substring(9, 15);
        }
        processFilter();
    }//GEN-LAST:event_filterCoachComboBoxActionPerformed
    
    private void processFilter()
    {
        if (table == null || !worker.isDone())
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> muFilter;
        RowFilter<CustomTableModel, Object> coachFilter;
        
        if (muFilterText.equals("ALL"))
        {
            muFilter = RowFilter.regexFilter(".*", idx_MU);
        }
        else
        {
            muFilter = RowFilter.regexFilter(muFilterText, idx_MU);
        }
        
        if (coachFilterText.equals("ALL"))
        {
            coachFilter = RowFilter.regexFilter(".*", idx_COACH);
        }
        else
        {
            coachFilter = RowFilter.regexFilter("^" + coachFilterText + "$", idx_COACH);
        }
        
        filters.add(muFilter);
        filters.add(coachFilter);
        
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), payrollSummaryScrollPane, table);
        }
    }
    
    private void refreshFilterComboBoxes()
    {
        // sort the lists alphabetically
        Misc.sortListModel(muList);
        Misc.sortListModel(coachList);
        
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                //get the previous selection
                String previousMUSelection = null;
                String previousCoachSelection = null;
                if (filterMuComboBox.getSelectedIndex() > -1)
                {
                    previousMUSelection = filterMuComboBox.getSelectedItem().toString();
                }
                if (filterCoachComboBox.getSelectedIndex() > -1)
                {
                    previousCoachSelection = filterCoachComboBox.getSelectedItem().toString();

                }
                
                //rebuild the comboboxes
                filterMuComboBox.removeAllItems();
                filterMuComboBox.addItem("Show All");
                for (int i = 0; i < muList.size(); i++)
                {
                    filterMuComboBox.addItem(muList.get(i));
                }

                filterCoachComboBox.removeAllItems();
                filterCoachComboBox.addItem("Show All");
                if (coachList.contains(UserData.getUUID()))
                {
                    filterCoachComboBox.addItem("<html><b>" + UserData.getUUID() + "</b></html>");
                }
                for (int i = 0; i < coachList.size(); i++)
                {
                    filterCoachComboBox.addItem(coachList.get(i));
                }
                
                //re-select the previous value if it's available
                DefaultComboBoxModel muModel = (DefaultComboBoxModel) filterMuComboBox.getModel();
                DefaultComboBoxModel coachModel = (DefaultComboBoxModel) filterCoachComboBox.getModel();
                if (previousMUSelection != null && muModel.getIndexOf(previousMUSelection) > -1)
                {
                    filterMuComboBox.setSelectedItem(previousMUSelection);
                }
                if (previousCoachSelection != null && coachModel.getIndexOf(previousCoachSelection) > -1)
                {
                    filterCoachComboBox.setSelectedItem(previousCoachSelection);
                }
            }
        });
    }
    
    private void clearTable()
    {
        loadingLabel.setVisible(false);
        progressBar.setVisible(false);
        payrollSummaryScrollPane.setMaximumSize(loadingPanelDimensions);
        payrollSummaryScrollPane.setPreferredSize(loadingPanelDimensions);
        payrollSummaryScrollPane.setViewportView(loadingPanel);
        validate();
        
        setControlsEnabled(false);
        table = null;
    }
    
    public static void closeInstance()
    {
        if (instance != null)
        {
            instance.closeForm();
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        if (TimeReporting.exists() && Misc.objectEquals(TimeReporting.getEditType(), "APPR READ ONLY"))
        {
            TimeReporting.closeInstance();
        }
        
        Schedules.refreshInstance();
        BeginNewPayPeriod.refreshInstance();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private void setControlsEnabled(boolean enabled)
    {
        employeeDetailButton.setEnabled(enabled);
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JLabel coachFilterLabel;
    private javax.swing.JPanel controlPanel;
    private javax.swing.JButton employeeDetailButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JComboBox<String> filterCoachComboBox;
    private javax.swing.JPanel filterLabelsPanel;
    private javax.swing.JComboBox<String> filterMuComboBox;
    private javax.swing.JPanel filtersPanel;
    private javax.swing.JPanel formTitlePanel;
    private javax.swing.JPanel gridPanel;
    private javax.swing.JPanel loadingItems;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel loadingPanel;
    private javax.swing.JLabel muFilterLabel;
    private javax.swing.JScrollPane payrollSummaryScrollPane;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JButton retrieveButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JLabel unionLabel;
    // End of variables declaration//GEN-END:variables
}
