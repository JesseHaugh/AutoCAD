package tvi.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import tvi.client_main.Main;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.reports.ExcelReports;
import tvicore.reports.PdfReports;
import tvicore.resources.Resources;

public final class PayrollGeneration extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile PayrollGeneration instance;
    
    private final String feeder;
    private final String site;
    
    public synchronized static PayrollGeneration getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new PayrollGeneration(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private PayrollGeneration(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        switch (feeder)
        {
            case "CZE":
                thresholdCalculationsButton.setVisible(false);
                premiumCalculationsButton.setVisible(false);
                sevenDaysWorkedCheckButton.setVisible(false);
                offDaysComputedButton.setVisible(false);
                priorButton.setVisible(false);
                extraButton.setVisible(false);
                extraButton2.setVisible(false);
                
                buttonPanel.setPreferredSize(new Dimension(400, buttonPanel.getHeight() + 20));
                changesButton.setPreferredSize(new Dimension(400, changesButton.getHeight()));
                currentButton.setPreferredSize(new Dimension(400, currentButton.getHeight()));
                parttimeOTButton.setPreferredSize(new Dimension(400, currentButton.getHeight()));
                break;
            case "MEX":
                shiftPlanButton.setVisible(false);
                offDaysComputedButton.setVisible(false);
                parttimeOTButton.setVisible(false);
                extraButton.setText("Payroll Report");
                extraButton2.setVisible(false);
                
                buttonPanel.setPreferredSize(new Dimension(700, buttonPanel.getHeight()));
                changesButton.setPreferredSize(new Dimension(340, changesButton.getHeight()));
                currentButton.setPreferredSize(new Dimension(340, currentButton.getHeight()));
                priorButton.setPreferredSize(new Dimension(340, priorButton.getHeight()));
                thresholdCalculationsButton.setPreferredSize(new Dimension(340, thresholdCalculationsButton.getHeight()));
                premiumCalculationsButton.setPreferredSize(new Dimension(340, premiumCalculationsButton.getHeight()));
                sevenDaysWorkedCheckButton.setPreferredSize(new Dimension(340, sevenDaysWorkedCheckButton.getHeight()));
                break;
            case "POL":
                thresholdCalculationsButton.setVisible(false);
                premiumCalculationsButton.setVisible(false);
                sevenDaysWorkedCheckButton.setVisible(false);
                parttimeOTButton.setVisible(false);
                extraButton.setText("Payroll Summary");
                extraButton2.setVisible(false);
                
                buttonPanel.setPreferredSize(new Dimension(700, buttonPanel.getHeight()));
                changesButton.setPreferredSize(new Dimension(340, changesButton.getHeight()));
                currentButton.setPreferredSize(new Dimension(340, currentButton.getHeight()));
                priorButton.setPreferredSize(new Dimension(340, priorButton.getHeight()));
                offDaysComputedButton.setPreferredSize(new Dimension(340, offDaysComputedButton.getHeight()));
                break;
            case "SVK":
                extraButton.setText("Generate Meal Vouchers");
                extraButton2.setText("Meal Vouchers Report");
                thresholdCalculationsButton.setVisible(false);
                premiumCalculationsButton.setVisible(false);
                sevenDaysWorkedCheckButton.setVisible(false);
                offDaysComputedButton.setVisible(false);
                parttimeOTButton.setVisible(false);
                
                buttonPanel.setPreferredSize(new Dimension(400, buttonPanel.getHeight() + 20));
                changesButton.setPreferredSize(new Dimension(400, changesButton.getHeight()));
                currentButton.setPreferredSize(new Dimension(400, currentButton.getHeight()));
                priorButton.setPreferredSize(new Dimension(400, priorButton.getHeight()));
                break;
            default:
                Misc.msgbox(getFormComponent(), "Payroll Generation is not available for this feeder, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                closeForm();
        }
    }
    
    private void closeForm()
    {
        Schedules.refreshInstance();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();
        noteScrollPane = new javax.swing.JScrollPane();
        noteTextArea = new javax.swing.JTextArea();
        scheduleCountScrollPane = new javax.swing.JScrollPane();
        scheduleCountTextPane = new javax.swing.JTextPane();
        centerPanel = new javax.swing.JPanel();
        buttonPanel = new javax.swing.JPanel();
        changesButton = new javax.swing.JButton();
        currentButton = new javax.swing.JButton();
        priorButton = new javax.swing.JButton();
        thresholdCalculationsButton = new javax.swing.JButton();
        premiumCalculationsButton = new javax.swing.JButton();
        sevenDaysWorkedCheckButton = new javax.swing.JButton();
        offDaysComputedButton = new javax.swing.JButton();
        parttimeOTButton = new javax.swing.JButton();
        bottomPanel = new javax.swing.JPanel();
        payrollPreviewButton = new javax.swing.JButton();
        extraButton2 = new javax.swing.JButton();
        generatePayrollButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        extraButtonsPanel = new javax.swing.JPanel();
        shiftPlanButton = new javax.swing.JButton();
        extraButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Payroll Generation");
        setMinimumSize(new java.awt.Dimension(700, 600));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(680, 230));
        topPanel.setName(""); // NOI18N
        topPanel.setPreferredSize(new java.awt.Dimension(680, 220));
        topPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titlePanel.setBackground(new java.awt.Color(120, 200, 200));
        titlePanel.setPreferredSize(new java.awt.Dimension(600, 40));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(120, 200, 200));
        feederSitePanel.setMinimumSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Payroll Generation");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 5, 400, -1));

        topPanel.add(titlePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 15, 680, -1));

        refreshButton.setBackground(new java.awt.Color(120, 200, 200));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        topPanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(438, 60, -1, -1));

        noteScrollPane.setBorder(null);
        noteScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        noteScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        noteScrollPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        noteScrollPane.setPreferredSize(new java.awt.Dimension(400, 40));

        noteTextArea.setEditable(false);
        noteTextArea.setBackground(new java.awt.Color(120, 200, 200));
        noteTextArea.setColumns(20);
        noteTextArea.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        noteTextArea.setRows(2);
        noteTextArea.setTabSize(4);
        noteTextArea.setText("Unchecked items below require attention.\nYou may generate payroll once all items are checked.");
        noteTextArea.setMinimumSize(new java.awt.Dimension(400, 40));
        noteTextArea.setPreferredSize(new java.awt.Dimension(400, 40));
        noteScrollPane.setViewportView(noteTextArea);

        topPanel.add(noteScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 90, -1, -1));

        scheduleCountScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scheduleCountScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        scheduleCountScrollPane.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        scheduleCountScrollPane.setPreferredSize(new java.awt.Dimension(400, 90));

        scheduleCountTextPane.setEditable(false);
        scheduleCountTextPane.setBackground(new java.awt.Color(255, 255, 153));
        scheduleCountTextPane.setContentType("text/html"); // NOI18N
        scheduleCountTextPane.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        scheduleCountTextPane.setText("<html><div align='center' width='100%'><b>Make sure the entire pay period has been imported first!</b></div>Number of schedules per MU in the current pay period:</html>");
        scheduleCountTextPane.setMinimumSize(new java.awt.Dimension(400, 90));
        scheduleCountTextPane.setPreferredSize(new java.awt.Dimension(400, 90));
        scheduleCountScrollPane.setViewportView(scheduleCountTextPane);

        topPanel.add(scheduleCountScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 130, -1, -1));

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(680, 180));
        centerPanel.setPreferredSize(new java.awt.Dimension(680, 180));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        buttonPanel.setBackground(new java.awt.Color(120, 200, 200));
        buttonPanel.setMinimumSize(new java.awt.Dimension(680, 180));
        buttonPanel.setPreferredSize(new java.awt.Dimension(680, 180));

        changesButton.setBackground(new java.awt.Color(120, 200, 200));
        changesButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        changesButton.setText("Approve TVI Changes");
        changesButton.setEnabled(false);
        changesButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        changesButton.setIconTextGap(10);
        changesButton.setPreferredSize(new java.awt.Dimension(320, 55));
        changesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changesButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(changesButton);

        currentButton.setBackground(new java.awt.Color(120, 200, 200));
        currentButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        currentButton.setText("Approve Current Payroll Period");
        currentButton.setEnabled(false);
        currentButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        currentButton.setIconTextGap(10);
        currentButton.setPreferredSize(new java.awt.Dimension(320, 55));
        currentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                currentButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(currentButton);

        priorButton.setBackground(new java.awt.Color(120, 200, 200));
        priorButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        priorButton.setText("Approve Prior Payroll Periods");
        priorButton.setEnabled(false);
        priorButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        priorButton.setIconTextGap(10);
        priorButton.setPreferredSize(new java.awt.Dimension(320, 55));
        priorButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priorButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(priorButton);

        thresholdCalculationsButton.setBackground(new java.awt.Color(120, 200, 200));
        thresholdCalculationsButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        thresholdCalculationsButton.setText("Threshold Calculations");
        thresholdCalculationsButton.setEnabled(false);
        thresholdCalculationsButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        thresholdCalculationsButton.setIconTextGap(10);
        thresholdCalculationsButton.setPreferredSize(new java.awt.Dimension(320, 55));
        thresholdCalculationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thresholdCalculationsButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(thresholdCalculationsButton);

        premiumCalculationsButton.setBackground(new java.awt.Color(120, 200, 200));
        premiumCalculationsButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        premiumCalculationsButton.setText("OT Premium Calculations");
        premiumCalculationsButton.setEnabled(false);
        premiumCalculationsButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        premiumCalculationsButton.setIconTextGap(10);
        premiumCalculationsButton.setPreferredSize(new java.awt.Dimension(320, 55));
        premiumCalculationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                premiumCalculationsButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(premiumCalculationsButton);

        sevenDaysWorkedCheckButton.setBackground(new java.awt.Color(120, 200, 200));
        sevenDaysWorkedCheckButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        sevenDaysWorkedCheckButton.setText("No Rest Day Calculations");
        sevenDaysWorkedCheckButton.setEnabled(false);
        sevenDaysWorkedCheckButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sevenDaysWorkedCheckButton.setIconTextGap(10);
        sevenDaysWorkedCheckButton.setPreferredSize(new java.awt.Dimension(320, 55));
        sevenDaysWorkedCheckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sevenDaysWorkedCheckButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(sevenDaysWorkedCheckButton);

        offDaysComputedButton.setBackground(new java.awt.Color(120, 200, 200));
        offDaysComputedButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        offDaysComputedButton.setText("Off Days Computed");
        offDaysComputedButton.setEnabled(false);
        offDaysComputedButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        offDaysComputedButton.setIconTextGap(10);
        offDaysComputedButton.setPreferredSize(new java.awt.Dimension(320, 55));
        offDaysComputedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offDaysComputedButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(offDaysComputedButton);

        parttimeOTButton.setBackground(new java.awt.Color(120, 200, 200));
        parttimeOTButton.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        parttimeOTButton.setText("Part-time Overtime Calculations");
        parttimeOTButton.setEnabled(false);
        parttimeOTButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        parttimeOTButton.setIconTextGap(10);
        parttimeOTButton.setPreferredSize(new java.awt.Dimension(320, 55));
        parttimeOTButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parttimeOTButtonActionPerformed(evt);
            }
        });
        buttonPanel.add(parttimeOTButton);

        centerPanel.add(buttonPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(120, 200, 200));
        bottomPanel.setMinimumSize(new java.awt.Dimension(680, 130));
        bottomPanel.setPreferredSize(new java.awt.Dimension(680, 170));
        bottomPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        payrollPreviewButton.setBackground(new java.awt.Color(120, 200, 200));
        payrollPreviewButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        payrollPreviewButton.setText("Payroll Preview");
        payrollPreviewButton.setPreferredSize(new java.awt.Dimension(180, 30));
        payrollPreviewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payrollPreviewButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(payrollPreviewButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 10, -1, -1));

        extraButton2.setBackground(new java.awt.Color(120, 200, 200));
        extraButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        extraButton2.setText("Meal Vouchers Report");
        extraButton2.setPreferredSize(new java.awt.Dimension(180, 30));
        extraButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                extraButton2ActionPerformed(evt);
            }
        });
        bottomPanel.add(extraButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 10, -1, -1));

        generatePayrollButton.setBackground(new java.awt.Color(120, 200, 200));
        generatePayrollButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        generatePayrollButton.setText("Generate Payroll");
        generatePayrollButton.setEnabled(false);
        generatePayrollButton.setPreferredSize(new java.awt.Dimension(180, 60));
        generatePayrollButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generatePayrollButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(generatePayrollButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 90, -1, -1));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(180, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        bottomPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 90, -1, -1));

        extraButtonsPanel.setBackground(new java.awt.Color(120, 200, 200));
        extraButtonsPanel.setMinimumSize(new java.awt.Dimension(450, 30));
        extraButtonsPanel.setPreferredSize(new java.awt.Dimension(450, 30));
        extraButtonsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 40, 0));

        shiftPlanButton.setBackground(new java.awt.Color(120, 200, 200));
        shiftPlanButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        shiftPlanButton.setText("Generate Shift Plan");
        shiftPlanButton.setPreferredSize(new java.awt.Dimension(180, 30));
        shiftPlanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shiftPlanButtonActionPerformed(evt);
            }
        });
        extraButtonsPanel.add(shiftPlanButton);

        extraButton.setBackground(new java.awt.Color(120, 200, 200));
        extraButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        extraButton.setText("Generate Meal Allowance");
        extraButton.setPreferredSize(new java.awt.Dimension(180, 30));
        extraButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                extraButtonActionPerformed(evt);
            }
        });
        extraButtonsPanel.add(extraButton);

        bottomPanel.add(extraButtonsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 50, -1, -1));

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void changesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changesButtonActionPerformed
        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        TimeReporting.getInstance(getFormComponent(), feeder, site, null, null, startDate, RegionData.getPayClose(), RegionData.getSiteUnion(), "CHANGES");
    }//GEN-LAST:event_changesButtonActionPerformed

    private void currentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_currentButtonActionPerformed
        PayrollPeriodApproval.getInstance(getFormComponent(), feeder, site, RegionData.getPayClose());
    }//GEN-LAST:event_currentButtonActionPerformed

    private void priorButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priorButtonActionPerformed
        Date endDate = Oracle.getPreviousPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        Date startDate = Misc.dateAddDays(endDate, -372);
        TimeReporting.getInstance(getFormComponent(), feeder, site, null, null, startDate, endDate, RegionData.getSiteUnion(), "PRIOR");
    }//GEN-LAST:event_priorButtonActionPerformed

    private void generatePayrollButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generatePayrollButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        generatePayrollButton.setEnabled(false);
        
        if (Arrays.asList("MEX", "SVK").contains(feeder))
        {
            Date payEndDate = RegionData.getPayClose();
            Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), payEndDate);
            
            boolean feederChangesApproved;
            boolean feederCurrentApproved;
            boolean feederPriorApproved;
            boolean feederThresholdsCalculated = true;
            boolean feederPremiumsCalculated = true;
            boolean feederSevenDaysWorkedChecked = true;
            
            String sites;
            if (Arrays.asList("MEX", "SVK").contains(feeder) && Arrays.asList("1", "2").contains(site))
            {
                sites = "ALL";
            }
            else // MEX or SVK site 3
            {
                sites = site;
            }
            if (feeder.equals("SVK"))
            {
                feederChangesApproved = Oracle.checkAllChangesApproved(getFormComponent(), feeder, sites, payStartDate, payEndDate);
                feederCurrentApproved = Oracle.checkCurrentApproved(getFormComponent(), feeder, sites, payStartDate, payEndDate);
                feederPriorApproved = Oracle.checkPriorApproved(getFormComponent(), feeder, sites, payStartDate);
            }
            else // MEX
            {
                feederChangesApproved = Oracle.checkAllChangesApproved(getFormComponent(), feeder, sites, payStartDate, payEndDate);
                feederCurrentApproved = Oracle.checkCurrentApproved(getFormComponent(), feeder, sites, payStartDate, payEndDate);
                feederPriorApproved = Oracle.checkPriorApproved(getFormComponent(), feeder, sites, payStartDate);
                feederThresholdsCalculated = Oracle.areThresholdCalculationsDone(getFormComponent(), feeder, sites, payEndDate);
                feederPremiumsCalculated = Oracle.arePremiumsCalculatedMEX(getFormComponent(), feeder, sites, payStartDate, payEndDate);
                feederSevenDaysWorkedChecked = Oracle.areSevenDaysWorkedChecked(getFormComponent(), feeder, sites, payStartDate, payEndDate);
            }
            
            if (!feederChangesApproved || !feederCurrentApproved || !feederPriorApproved || !feederThresholdsCalculated || !feederPremiumsCalculated || !feederSevenDaysWorkedChecked)
            {
                Misc.msgbox(getFormComponent(), "The payroll ending functions haven't been completed for all sites.\nCheck the other sites in order to generate payroll.", "Payroll Generation", 1, 1, 1);
                setCursor(Constants.NORMAL);
                generatePayrollButton.setEnabled(true);
                return;
            }
        }
        
        
        if (Oracle.isGeneratePayrollOkay(getFormComponent(), Main.CLIENTNAME, feeder, site))
        {
            new Thread(new GeneratePayrollThread(false)).start();
        }
        else
        {
            setCursor(Constants.NORMAL);
            generatePayrollButton.setEnabled(true);
        }
    }//GEN-LAST:event_generatePayrollButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void payrollPreviewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payrollPreviewButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        payrollPreviewButton.setEnabled(false);
        new Thread(new GeneratePayrollThread(true)).start();
    }//GEN-LAST:event_payrollPreviewButtonActionPerformed

    private void extraButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_extraButtonActionPerformed
        switch (feeder)
        {
            case "MEX":
                new Thread(new GeneratePayrollReportMEXThread()).start();
                break;
            case "POL":
                new Thread(new GeneratePayrollSummaryReportPOLThread()).start();
                break;
            case "SVK":
                new Thread(new GenerateMealVouchersThread()).start();
                break;
            default:
                Misc.msgbox(getFormComponent(), "This operation is not available for this feeder, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                closeForm();
        }
    }//GEN-LAST:event_extraButtonActionPerformed

    private void thresholdCalculationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thresholdCalculationsButtonActionPerformed
        if (Misc.msgbox(getFormComponent(), "Are you sure you want to calculate thresholds?", "Threshold Calculations", 2, 2, 1))
        {
            setCursor(Constants.HOURGLASS);
            Oracle.thresholdCalculationsMEX(getFormComponent(), feeder, site, RegionData.getPayClose(), "TVPART", Oracle.getCurTime(getFormComponent()));
            refreshData();
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Completed Calculations.", "Threshold Calculations", 1, 1, 1);
        }
    }//GEN-LAST:event_thresholdCalculationsButtonActionPerformed

    private void premiumCalculationsButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_premiumCalculationsButtonActionPerformed
    {//GEN-HEADEREND:event_premiumCalculationsButtonActionPerformed
        boolean proceed = Misc.msgbox(getFormComponent(), "Are you sure you want to calculate premiums?", "Premium Calculations", 2, 2, 1);
        Date payrollEndDate = RegionData.getPayClose();
        setCursor(Constants.HOURGLASS);
        if (proceed)
        {
            proceed = Oracle.calculatePremiumsMEX(getFormComponent(), feeder, site, payrollEndDate);
        }
        if (proceed)
        {
            refreshData();
            setCursor(Constants.NORMAL);
            OTPremiumsMEX.getInstance(getFormComponent(), feeder, site, payrollEndDate, "PROCESS48");
        }
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_premiumCalculationsButtonActionPerformed

    private void sevenDaysWorkedCheckButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_sevenDaysWorkedCheckButtonActionPerformed
    {//GEN-HEADEREND:event_sevenDaysWorkedCheckButtonActionPerformed
        boolean proceed = Misc.msgbox(getFormComponent(), "Are you sure you want to run the seven day worked check?", "Premium Calculations", 2, 2, 1);
        setCursor(Constants.HOURGLASS);
        if (proceed)
        {
            proceed = Oracle.sevenDayWorkedCheckMEX(getFormComponent(), feeder, site, RegionData.getPayClose());
        }
        if (proceed)
        {
            refreshData();
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Completed.", "Seven Day Worked Check", 1, 1, 1);
        }
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_sevenDaysWorkedCheckButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_refreshButtonActionPerformed
    {//GEN-HEADEREND:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void shiftPlanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shiftPlanButtonActionPerformed
        switch (feeder)
        {
            case "CZE":
            case "POL":
            case "SVK":
                new Thread(new GenerateShiftPlanThread()).start();
                break;
            default:
                Misc.msgbox(getFormComponent(), "Shift Plan Generation is not available for this feeder, email TVI Support at" + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                closeForm();
        }
    }//GEN-LAST:event_shiftPlanButtonActionPerformed

    private void extraButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_extraButton2ActionPerformed
        switch (feeder)
        {
            case "SVK":
                new Thread(new GenerateMealVouchersReportThread()).start();
                break;
            case "MEX":
            case "POL":
            default:
                Misc.msgbox(getFormComponent(), "This operation is not available for this feeder, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                closeForm();
        }
    }//GEN-LAST:event_extraButton2ActionPerformed

    private void offDaysComputedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offDaysComputedButtonActionPerformed
        JComboBox<String> pickDate = new JComboBox<>();
        Oracle.setupPickMonth(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getPayClose(), true);
        int rc = JOptionPane.showConfirmDialog(getFormComponent(), pickDate, "Select a month end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        Date selectedMonthEndDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (rc == 0) //OK was selected
        {
            setCursor(Constants.HOURGLASS);
            Date endDate = selectedMonthEndDate;
            Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
            if (Oracle.areAnySchedulesRestricted(getFormComponent(), feeder, site, "ALL", startDate, endDate))
            {
                setCursor(Constants.NORMAL);
                Misc.msgbox(getFormComponent(), "Cannot compute, at least one of the schedules in the selected period has locked records.", "Cannot retrieve all records.", 1, 1, 1);
                return;
            }
            else if (Oracle.areAnyRecordsLocked(getFormComponent(), feeder, site, "ALL", "ALL", startDate, endDate))
            {
                setCursor(Constants.NORMAL);
                Misc.msgbox(getFormComponent(), "Cannot compute, at least one of the records in the selected period is currently in use.", "Cannot retrieve all records.", 1, 1, 1);
                return;
            }
            RegionData.setSiteLocked(getFormComponent(), "Compute OFFA");
            if (Oracle.computeOFFAbsPOL(getFormComponent(), feeder, site, startDate, endDate))
            {
                OFFAbsRemainingReportPOL.getInstance(getFormComponent(), feeder, site, startDate, endDate);
            }
            RegionData.setSiteUnlocked(getFormComponent());
            setCursor(Constants.NORMAL);
        }
    }//GEN-LAST:event_offDaysComputedButtonActionPerformed

    private void parttimeOTButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parttimeOTButtonActionPerformed
        boolean proceed = Misc.msgbox(getFormComponent(), "Are you sure you want to calculate part-time overtime?", "Part-time Overtime", 2, 2, 1);
        Date payrollEndDate = RegionData.getPayClose();
        setCursor(Constants.HOURGLASS);
        if (proceed)
        {
            proceed = Oracle.calculateParttimeOT(getFormComponent(), feeder, site, payrollEndDate);
        }
        if (proceed)
        {
            refreshData();
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Completed.", "Part-time Overtime Check", 1, 1, 1);
        }
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_parttimeOTButtonActionPerformed
    
    public static void refreshInstance()
    {
        if (instance != null)
        {
            instance.refreshData();
        }
    }
    
    private void refreshData()
    {
        new Thread(new RefreshPayrollGenerationThread()).start();
    }
    
    private class RefreshPayrollGenerationThread implements Runnable
    {
        @Override
        public void run()
        {
            setCursor(Constants.HOURGLASS);
            Date payEndDate = RegionData.getPayClose();
            Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), payEndDate);
            
            // refresh schedule count text pane
            String muScheduleCountList = Oracle.getMUScheduleCountList(getFormComponent(), feeder, site, payStartDate, payEndDate);
            String htmlString = "<html><div align='center' width='100%'>"
                              + "<b>Make sure the entire pay period has been imported first!</b></div>"
                              + "Number of schedules per MU in the current pay period:<br>"
                              + muScheduleCountList + "</html>";
            scheduleCountTextPane.setText(htmlString);
            
            // refresh approve changes button
            boolean changesApproved = Oracle.checkAllChangesApproved(getFormComponent(), feeder, site, payStartDate, payEndDate);
            changesButton.setEnabled(!changesApproved);
            if (changesApproved)
            {
                changesButton.setIcon(Resources.getIconChecked45());
            }
            else
            {
                changesButton.setIcon(Resources.getIconUnchecked45());
            }
            
            // refresh current approval button
            boolean currentApproved = Oracle.checkCurrentApproved(getFormComponent(), feeder, site, payStartDate, payEndDate);
            currentButton.setEnabled(!currentApproved);
            if (currentApproved)
            {
                currentButton.setIcon(Resources.getIconChecked45());
            }
            else
            {
                currentButton.setIcon(Resources.getIconUnchecked45());
            }
            
            // refresh prior approval button
            boolean priorApproved;
            if (feeder.equals("CZE"))
            {
                priorApproved = true;
            }
            else
            {
                priorApproved = Oracle.checkPriorApproved(getFormComponent(), feeder, site, payStartDate);
                priorButton.setEnabled(!priorApproved);
                if (priorApproved)
                {
                    priorButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    priorButton.setIcon(Resources.getIconUnchecked45());
                }
            }
            
            // refresh threshold calculation button
            boolean thresholdsCalculated = true;
            if (feeder.equals("MEX"))
            {
                thresholdsCalculated = Oracle.areThresholdCalculationsDone(getFormComponent(), feeder, site, payEndDate);
                if (thresholdsCalculated)
                {
                    thresholdCalculationsButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    thresholdCalculationsButton.setIcon(Resources.getIconUnchecked45());
                }
                if (changesApproved && currentApproved && priorApproved && !thresholdsCalculated && Oracle.getCurTimeLocal(getFormComponent()).compareTo(payEndDate) >= 0) // today is >= pay close
                {
                    thresholdCalculationsButton.setEnabled(true);
                    thresholdCalculationsButton.setToolTipText(null);
                }
                else
                {
                    thresholdCalculationsButton.setEnabled(false);
                    if (!thresholdsCalculated)
                    {
                        thresholdCalculationsButton.setToolTipText("All approvals must be completed before calculations can be performed.");
                    }
                    else
                    {
                        thresholdCalculationsButton.setToolTipText(null);
                    }
                }
            }
            
            // refresh premium calculations button
            boolean premiumsCalculated = true;
            if (feeder.equals("MEX"))
            {
                premiumsCalculated = Oracle.arePremiumsCalculatedMEX(getFormComponent(), feeder, site, payStartDate, payEndDate);
                if (premiumsCalculated)
                {
                    premiumCalculationsButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    premiumCalculationsButton.setIcon(Resources.getIconUnchecked45());
                }
                if (changesApproved && currentApproved && priorApproved && !premiumsCalculated && Oracle.getCurTimeLocal(getFormComponent()).compareTo(payEndDate) >= 0) // today is >= pay close
                {
                    premiumCalculationsButton.setEnabled(true);
                    premiumCalculationsButton.setToolTipText(null);
                }
                else
                {
                    premiumCalculationsButton.setEnabled(false);
                    if (!premiumsCalculated)
                    {
                        premiumCalculationsButton.setToolTipText("All approvals must be completed before calculations can be performed.");
                    }
                    else
                    {
                        premiumCalculationsButton.setToolTipText(null);
                    }
                }
            }
            
            // refresh seven days worked check button
            boolean sevenDaysWorkedChecked = true;
            if (feeder.equals("MEX"))
            {
                sevenDaysWorkedChecked = Oracle.areSevenDaysWorkedChecked(getFormComponent(), feeder, site, payStartDate, payEndDate);
                if (sevenDaysWorkedChecked)
                {
                    sevenDaysWorkedCheckButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    sevenDaysWorkedCheckButton.setIcon(Resources.getIconUnchecked45());
                }
                if (changesApproved && currentApproved && priorApproved && !sevenDaysWorkedChecked && Oracle.getCurTimeLocal(getFormComponent()).compareTo(payEndDate) >= 0) // today is >= pay close
                {
                    sevenDaysWorkedCheckButton.setEnabled(true);
                    sevenDaysWorkedCheckButton.setToolTipText(null);
                }
                else
                {
                    sevenDaysWorkedCheckButton.setEnabled(false);
                    if (!sevenDaysWorkedChecked)
                    {
                        sevenDaysWorkedCheckButton.setToolTipText("All approvals must be completed before calculations can be performed.");
                    }
                    else
                    {
                        sevenDaysWorkedCheckButton.setToolTipText(null);
                    }
                }
            }
            
            // refresh OFF Days Computed button
            boolean offDaysComputed = true;
            if (feeder.equals("POL"))
            {
                offDaysComputed = Oracle.areOffDaysComputedPOL(getFormComponent(), feeder, site, payStartDate, payEndDate);
                offDaysComputedButton.setEnabled(!offDaysComputed);
                if (offDaysComputed)
                {
                    offDaysComputedButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    offDaysComputedButton.setIcon(Resources.getIconUnchecked45());
                }
            }
            
            // refresh part-time overtime button
            boolean parttimeOTChecked = true;
            if (feeder.equals("CZE"))
            {
                parttimeOTChecked = Oracle.isParttimeOTCalculatedCZE(getFormComponent(), feeder, site, payEndDate);
                parttimeOTButton.setEnabled(!parttimeOTChecked);
                if (parttimeOTChecked)
                {
                    parttimeOTButton.setIcon(Resources.getIconChecked45());
                }
                else
                {
                    parttimeOTButton.setIcon(Resources.getIconUnchecked45());
                }
            }
            
            // refresh generate payroll button
            if (changesApproved && currentApproved && priorApproved && thresholdsCalculated && premiumsCalculated && sevenDaysWorkedChecked && offDaysComputed && parttimeOTChecked)
            {
                generatePayrollButton.setEnabled(true);
            }
            else
            {
                generatePayrollButton.setEnabled(false);
            }
            setCursor(Constants.NORMAL);
        }
    }
    
    private class GeneratePayrollThread implements Runnable
    {
        boolean preview = false;
        public GeneratePayrollThread(boolean preview)
        {
            this.preview = preview;
        }
        
        @Override
        public void run()
        {
            try
            {
                if (ExcelReports.openingXLSReportLock.tryAcquire())
                {
                    Date endDate = RegionData.getPayClose();
                    Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
                    if (feeder.equals("MEX"))
                    {
                        startDate = Misc.dateAddDays(endDate, -380);
                    }

                    boolean proceed = true;
                    if (!preview && Oracle.getCurTimeLocal(getFormComponent()).compareTo(RegionData.getPayClose()) <= 0) // if the current date is <= pay close
                    {
                        proceed = false;
                        Misc.msgbox(getFormComponent(), "You must wait until after the payroll close date before generating payroll.\nIf you need to re-generate payroll, email TVI Support at " + Constants.EMAIL, "Generate Payroll", 1, 1, 1);
                    }
                    if (Arrays.asList("MEX", "SVK").contains(feeder))
                    {
                        if (Oracle.areAnyEmployeesMissingPayrollID(getFormComponent(), feeder, site))
                        {
                            int choice = JOptionPane.showOptionDialog(
                                    null,
                                    "Not all employees have been assigned a payroll ID;\nTVI will show *ATTUUID for these employees.\nDo you want to continue?",
                                    "Payroll Generation",
                                    JOptionPane.YES_NO_OPTION,
                                    JOptionPane.INFORMATION_MESSAGE,
                                    null,
                                    new String[]
                                    {
                                        "YES", "NO"
                                    },
                                    "NO"
                            );
                            switch (choice)
                            {
                                case 0:
                                    proceed = true;
                                    break;
                                default: // NO or user cancel
                                    proceed = false;
                            }
                        }
                    }
                    if (proceed)
                    {
                        switch (feeder)
                        {
                            case "CZE":
                                ExcelReports.fillPayrollReportCZE(getFormComponent(), feeder, site, startDate, endDate, preview, false);
                                break;
                            case "MEX":
                                ExcelReports.fillPayrollReportMEX(getFormComponent(), feeder, site, "ALL", preview);
                                break;
                            case "POL":
                                ExcelReports.fillPayrollReportPOL(getFormComponent(), feeder, site, startDate, endDate, preview);
                                break;
                            case "SVK":
                                ExcelReports.fillPayrollReportSVK(getFormComponent(), feeder, site, startDate, endDate, preview);
                                break;
                            default:
                                Misc.msgbox(getFormComponent(), "Payroll Generation is not available for this feeder, email TVI Support at" + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                                closeForm();
                        }

                        if (!preview)
                        {
                            if (Misc.msgbox(getFormComponent(), "Have you saved the payroll generation file?\nIf so, click OK.  If you click cancel, you must generate payroll again.", "Payroll Generation", 1, 2, 0))
                            {
                                Date payrollGenerationDate = Oracle.getCurTime(getFormComponent());
                                Oracle.updatePayrollRunDate(getFormComponent(), feeder, site, startDate, endDate, payrollGenerationDate, UserData.getUUID(), true);
                                Oracle.insertHistoryInternational(getFormComponent(), feeder, site, startDate, endDate, payrollGenerationDate, "ALL");
                                if (Oracle.updatePayClose(getFormComponent(), feeder, site, RegionData.getNextPayClose()))
                                {
                                    RegionData.updatePayClose(getFormComponent());
                                    Schedules.refreshInstance();
                                }
                            }
                            else
                            {
                                Misc.msgbox(getFormComponent(), "Payroll has been stopped; you must generate payroll again to move forward.", "Payroll Generation", 1, 1, 0);
                            }
                        }
                        closeForm();
                    }
                }
            }
            finally
            {
                ExcelReports.openingXLSReportLock.release();
                try
                {
                    SwingUtilities.invokeAndWait(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            if (preview)
                            {
                                payrollPreviewButton.setEnabled(true);
                            }
                            else
                            {
                                generatePayrollButton.setEnabled(true);
                            }
                            setCursor(Constants.NORMAL);
                        }
                    });
                }
                catch (InterruptedException | InvocationTargetException ex) {}
            }
        }
    }
    
    private class GenerateShiftPlanThread implements Runnable
    {
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                extraButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JPanel panel = new JPanel();
                    GridLayout gridLayout = new GridLayout(2, 0);
                    gridLayout.setVgap(10);
                    panel.setLayout(gridLayout);
                    
                    JLabel startDateLabel = new JLabel("Start Date:");
                    JComboBox<String> startDateCombo = new JComboBox<>();
                    startDateCombo.setEditable(true);
                    Oracle.setupPickMonthStart(getFormComponent(), startDateCombo, RegionData.getPayCycle(), RegionData.getPayClose(), false);
                    
                    JLabel endDateLabel = new JLabel("End Date:");
                    JComboBox<String> endDateCombo = new JComboBox<>();
                    endDateCombo.setEditable(true);
                    Oracle.setupPickMonth(getFormComponent(), endDateCombo, RegionData.getPayCycle(), RegionData.getPayClose(), true);
                    
                    panel.add(startDateLabel);
                    panel.add(startDateCombo);
                    panel.add(endDateLabel);
                    panel.add(endDateCombo);
                    
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Select a start and end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (rc == 0) //OK was selected
                    {
                        Date endDate = Misc.stringToDateMDY(getFormComponent(), endDateCombo.getSelectedItem().toString());
                        Date startDate = Misc.stringToDateMDY(getFormComponent(), startDateCombo.getSelectedItem().toString());
                        ExcelReports.fillShiftPlan(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                extraButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private class GeneratePayrollReportMEXThread implements Runnable
    {
        @Override
        public void run()
        {
            if (PdfReports.openingPDFReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                extraButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    if (Oracle.areAnyEmployeesMissingPayrollID(getFormComponent(), feeder, site))
                    {
                        Misc.msgbox(getFormComponent(), "Not all employees have been assigned a payroll ID, email TVI Support at " + Constants.EMAIL, "Generate Payroll", 1, 1, 1);
                    }
                    else
                    {
                        PdfReports.createPayrollPeriodSummaryReportMEX(getFormComponent(), feeder, site, "ALL");
                    }
                }
                finally
                {
                    PdfReports.openingPDFReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                extraButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private class GenerateMealVouchersThread implements Runnable
    {
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                extraButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JComboBox<String> pickDate = new JComboBox<>();
                    Oracle.setupPickMonth(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getPayClose(), true);
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), pickDate, "Select a month end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (rc == 0) // OK was selected
                    {
                        Date endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
                        ExcelReports.fillMealVouchersSVK(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                extraButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private class GenerateMealVouchersReportThread implements Runnable
    {
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                extraButton2.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JComboBox<String> pickDate = new JComboBox<>();
                    Oracle.setupPickMonth(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getPayClose(), true);
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), pickDate, "Select a month end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (rc == 0) // OK was selected
                    {
                        Date endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
                        ExcelReports.fillMealVouchersReportSVK(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                extraButton2.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private class GeneratePayrollSummaryReportPOLThread implements Runnable
    {
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                extraButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    JComboBox<String> pickDate = new JComboBox<>();
                    Oracle.setupPickMonth(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getPayClose(), true);
                    int rc = JOptionPane.showConfirmDialog(getFormComponent(), pickDate, "Select a month end date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (rc == 0) //OK was selected
                    {
                        Date endDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
                        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
                        ExcelReports.fillPayrollSummaryPOL(getFormComponent(), feeder, site, startDate, endDate);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                extraButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton changesButton;
    private javax.swing.JButton currentButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton extraButton;
    private javax.swing.JButton extraButton2;
    private javax.swing.JPanel extraButtonsPanel;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JButton generatePayrollButton;
    private javax.swing.JScrollPane noteScrollPane;
    private javax.swing.JTextArea noteTextArea;
    private javax.swing.JButton offDaysComputedButton;
    private javax.swing.JButton parttimeOTButton;
    private javax.swing.JButton payrollPreviewButton;
    private javax.swing.JButton premiumCalculationsButton;
    private javax.swing.JButton priorButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JScrollPane scheduleCountScrollPane;
    private javax.swing.JTextPane scheduleCountTextPane;
    private javax.swing.JButton sevenDaysWorkedCheckButton;
    private javax.swing.JButton shiftPlanButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JButton thresholdCalculationsButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}