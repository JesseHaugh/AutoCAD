package tvicore.objects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class CustomTableModel extends AbstractTableModel
{
    private List<Object[]> data;
    private final String[] columnNames;
    
    public CustomTableModel(String[] colNames)
    {
        columnNames = colNames;
        data = new ArrayList<>();
    }
    
    @Override
    public String getColumnName(int col)
    {
        return columnNames[col];
    }
    
    @Override
    public int getColumnCount()
    {
        return columnNames.length;
    }
    
    @Override
    public int getRowCount()
    {
        return data.size();
    }
    
    @Override
    public Object getValueAt(int row, int col)
    {
        return data.get(row)[col];
    }
    
    @Override
    public void setValueAt(Object value, int row, int col)
    {
        Object[] values = data.get(row);
        values[col] = value;
        data.set(row, values);
        fireTableCellUpdated(row, col);
    }
    
    public void addRow(Object[] value)
    {
        int rowCount = getRowCount();
        data.add(value);
        fireTableRowsInserted(rowCount, rowCount);
    }
    
    public void addRows(Object[]... value)
    {
        addRows(Arrays.asList(value));
    }
    
    public void addRows(List<Object[]> rows)
    {
        int rowCount = getRowCount();
        data.addAll(rows);
        fireTableRowsInserted(rowCount, getRowCount() - 1);
    }
    
    public void removeRow(int row)
    {
        data.remove(row);
        fireTableRowsDeleted(row, row);
    }
    
    /**
    * Moves the rows from <code>startIndex</code> to <code>endIndex</code> (inclusive) to the specified row.
    * 
    * @param startIndex the start row.
    * @param endIndex the end row.
    * @param toIndex the row to move to.
    */
    public void moveRow(int startIndex, int endIndex, int toIndex)
    {
        List<Object[]> newData = new ArrayList<>();
        List<Object[]> removed = new ArrayList<>();
        for (int i = 0; i < endIndex - startIndex + 1; i++)
        {
            removed.add(data.remove(startIndex));
        }
        for (int i = 0; i < toIndex; i++)
        {
            newData.add(data.remove(i));
        }
        newData.addAll(removed);
        newData.addAll(data);
        data = newData;
        int firstRow = Math.min(startIndex, toIndex);
        int lastRow = Math.max(endIndex, toIndex + (endIndex - startIndex));
        fireTableRowsUpdated(firstRow, lastRow);
    }
}
