package tvi.gui;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.DefaultListModel;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.ProgressMonitor;
import javax.swing.RowSorter.SortKey;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.TableCellRenderer;
import tvi.client_main.Main;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.reports.PdfReports;
import tvicore.resources.Resources;

public final class Schedules extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile Schedules instance;
    
    private final String feeder;
    private final String site;
    
    private static final Semaphore openingScheduleLock = new Semaphore(1, true);
    private static final Semaphore refreshWorkingSchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshCompletedSchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshApprovedSchedulesLock = new Semaphore(1, true);
    private static final Semaphore refreshPayCloseLock = new Semaphore(1, true);
    private static final Semaphore refreshMURosterLock = new Semaphore(1, true);
    
    JTable workingSchedulesTable;
    JTable completedSchedulesTable;
    JTable approvedSchedulesTable;
    CustomTableModel workingSchedulesData;
    CustomTableModel completedSchedulesData;
    CustomTableModel approvedSchedulesData;
    TableSwingWorker workingSchedulesWorker;
    TableSwingWorker completedSchedulesWorker;
    TableSwingWorker approvedSchedulesWorker;
    
    public Timer paycloseTimer;
    public Timer workingTimer;
    public Timer completedTimer;
    public Timer approvedTimer;
    public Timer muRosterTimer;
    
    Date todaysDate = Misc.dateNoTime(Oracle.getCurTimeLocal(this));
    int numberOfOffDays = 0;
    int numberOfInactiveEmps = 0;
    int numberOfDuplicateEmps = 0;
    int numberOf3DayNightDiffEmps = 0;
    int numberOfTransferEmps = 0;
    int numberOfRosterRequesting = 0;
    
    private int workingSelectedRow;
    private int completedSelectedRow;
    private int approvedSelectedRow;
    private int workingRowCount;
    private int completedRowCount;
    private int approvedRowCount;
    private int workingScrollPosition = 0;
    private int completedScrollPosition = 0;
    private int approvedScrollPosition = 0;
    private String workingSelectedMu;
    private String workingSelectedDate;
    private String completedSelectedMu;
    private String completedSelectedDate;
    private String approvedSelectedMu;
    private String approvedSelectedDate;
    private List<? extends SortKey> workingSortKeys = null;
    private List<? extends SortKey> completedSortKeys = null;
    private List<? extends SortKey> approvedSortKeys = null;
    
    boolean refreshingPayClose = false;
    boolean disableRefreshing = false;//DYADD change thread to swing worker?
    boolean gotSending = false;
    boolean gotImporting = false;
    boolean updatingMuRoster = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    final static int idx_MU             = 0;
    final static int idx_REPORTING_DATE = 1;
    final static int idx_STATUS         = 2;
    final static int idx_TOTALVIEWID    = 3;
    final static int idx_UNION_FLAG     = 4;
    final static int idx_FUTURE_LOAD    = 5;
    final static int idx_IMPORT_LOCKED  = 6;
    
    public synchronized static Schedules getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new Schedules(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private Schedules(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            testDBLabel.setVisible(true);
        }
        else
        {
            testDBLabel.setVisible(false);
        }
        
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            if (!Misc.isAlpha(s.substring(0, 1)))
            {
                modelr.addElement(s);
            }
        }
        importSchedules.setModel(modelr);
        if (importSchedules.getModel().getSize() > 0)
        {
            importSchedules.setSelectedIndex(0);
        }
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Calendar cal = Calendar.getInstance();
        Date curDate = Misc.dateNoTime(cal.getTime());
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, 20);
        for (int i = 0; i < 60; i++)
        {
            pickDate.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, -1);
        pickDate.setSelectedItem(Misc.dateToStringMDY(cal.getTime()));
        
        /***********************************************************************
        * setup Timers for refreshing data
        ***********************************************************************/
        ActionListener paycloseRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshPayCloseThread()).start();
            }
        };
        ActionListener workingRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshWorkingSchedulesThread()).start();
            }
        };
        ActionListener completedRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshCompletedSchedulesThread()).start();
            }
        };
        ActionListener approvedRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshApprovedSchedulesThread()).start();
            }
        };
        if (RegionData.getNewFeature())
        {
            ActionListener muRosterRefresh = new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent evt)
                {
                    new Thread(new RefreshMURosterThread()).start();
                }
            };
            muRosterTimer = new Timer(60*1000, muRosterRefresh);
            muRosterTimer.setRepeats(true);
            muRosterTimer.setInitialDelay(60*1000);
            muRosterTimer.start();
        }
        
        paycloseTimer = new Timer(60*1000, paycloseRefresh);
        paycloseTimer.setRepeats(true);
        paycloseTimer.setInitialDelay(60*1000);
        paycloseTimer.start();
        
        workingTimer = new Timer(60*1000, workingRefresh);
        workingTimer.setRepeats(true);
        workingTimer.setInitialDelay(60*1000);
        workingTimer.start();
        
        completedTimer = new Timer(60*1000, completedRefresh);
        completedTimer.setRepeats(true);
        completedTimer.setInitialDelay(60*1000);
        completedTimer.start();
        
        approvedTimer = new Timer(60*1000, approvedRefresh);
        approvedTimer.setRepeats(true);
        approvedTimer.setInitialDelay(60*1000);
        approvedTimer.start();
        
        messageArea.setVisible(false);
        displayGroup.setSelected(display30Days.getModel(), true);
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        payCycleLabel.setText("Pay Cycle: " + RegionData.getPayCycle());
        officeLabel.setText("Office: " + RegionData.getSiteDescription());
        payrollPeriodLabel.setText("Current Payroll Period Ends: " + Misc.dateToStringMDY(RegionData.getPayClose()));
        rosterUpdatedLabel.setText("MU Roster Updated: " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
        payrollCloseCalculationsButton.setEnabled(false);
        
        uploadFMLAButton.setVisible(RegionData.getNewFeature2());
        
        /***********************************************************************
        * International feeder screen changes
        ***********************************************************************/
        if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))//DYADD switch completed/approved tables
        {
            importFutureSchedulesButton.setVisible(false);
            completedSchedulesLabel.setText("<html><u>Approved Schedules</u></html>");
            approvedSchedulesLabel.setText("<html><u>Completed Schedules</u></html>");
        }
        if (!Arrays.asList("CZE", "SVK", "POL").contains(feeder))
        {
            previousPayrollCorrectionsButton.setVisible(false);
        }
        if (!feeder.equals("MEX"))
        {
            LOAButton.setVisible(false);
            separatedEmployeesMEXButton.setVisible(false);
        }
        if (!Arrays.asList("MEX", "POL", "CZE").contains(feeder))
        {
            payrollCloseCalculationsButton.setVisible(false);
        }
        
        String userAccessLevel = UserData.getUserAccessLevel();
        importIEXUpdatesButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importFutureSchedulesButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importButton.setEnabled(!userAccessLevel.equals("READONLY"));
        importOptionsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        commentMaintenanceButton.setEnabled(!userAccessLevel.equals("READONLY"));
        holdButton.setEnabled(!userAccessLevel.equals("READONLY"));
        releaseButton.setEnabled(!userAccessLevel.equals("READONLY"));
        addRecordsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        payrollGenerationButton.setEnabled(!userAccessLevel.equals("READONLY"));
        separatedEmployeesMEXButton.setEnabled(!userAccessLevel.equals("READONLY"));
        previousPayrollCorrectionsButton.setEnabled(!userAccessLevel.equals("READONLY"));
        if (!RegionData.getNewFeature())
        {
            updateMURosterButton.setVisible(false);
            muRosterMaintenanceButton.setVisible(false);
            EmpRosterMaintenanceButton.setVisible(false);
            rosterUpdatedLabel.setVisible(false);
            
            importIEXUpdatesButton.setText("Import IEX Updates");
            importIEXUpdatesButton.setPreferredSize(new java.awt.Dimension(160, 40));
            
            importFutureSchedulesButton.setText("Import Future Schedules");
            importFutureSchedulesButton.setPreferredSize(new java.awt.Dimension(160, 40));
            
            reviewUpdatesButton.setText("Review Updates");
            reviewUpdatesButton.setPreferredSize(new java.awt.Dimension(160, 40));
        }   
        else
        {
            numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
            if (numberOfRosterRequesting > 0)
            {
                updatingMuRoster = true;
                updateMURosterButton.setText("<html><div align='center' width='100%'>Requesting<br>Please Wait</div></html>");
                updateMURosterButton.setEnabled(false);
            }
        }
    }
    
    public static void refreshInstance()
    {
        if (instance != null)
        {
            instance.refreshData();
        }
    }
    
    private void refreshData()
    {
        if (!refreshingPayClose)
        {
            paycloseTimer.setInitialDelay(0);
            paycloseTimer.restart();
        }
        if (workingSchedulesWorker == null || workingSchedulesWorker.isDone())
        {
            workingTimer.setInitialDelay(0);
            workingTimer.restart();
        }
        if (completedSchedulesWorker == null || completedSchedulesWorker.isDone())
        {
            completedTimer.setInitialDelay(0);
            completedTimer.restart();
        }
        if (approvedSchedulesWorker == null || approvedSchedulesWorker.isDone())
        {
            approvedTimer.setInitialDelay(0);
            approvedTimer.restart();
        }
        if (RegionData.getNewFeature())
        {
            if (updatingMuRoster)
            {
                numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
                if (numberOfRosterRequesting == 0)
                {
                    Misc.msgbox(getFormComponent(), "MU Roster successfully updated", "MU Roster Update", 1, 1, 1);
                    updatingMuRoster = false;
                    updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
                    updateMURosterButton.setEnabled(true);
                }
                muRosterTimer.setInitialDelay(0);
                muRosterTimer.restart();
            }
            if (Oracle.areAnyNewErrorFlag(getFormComponent(), feeder, site))
            {
                MURosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
            }
            rosterUpdatedLabel.setText("MU Roster Updated:  " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        displayGroup = new javax.swing.ButtonGroup();
        schedulePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        payCycleLabel = new javax.swing.JLabel();
        officeLabel = new javax.swing.JLabel();
        payrollPeriodLabel = new javax.swing.JLabel();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        display30Days = new javax.swing.JRadioButton();
        display1year = new javax.swing.JRadioButton();
        scheduleColumnsPanel = new javax.swing.JPanel();
        importColumnPane = new javax.swing.JPanel();
        importSchedulesLabel = new javax.swing.JLabel();
        importSchedulesPane = new javax.swing.JScrollPane();
        importSchedules = new javax.swing.JList<>();
        importButton = new javax.swing.JButton();
        importOptionsButton = new javax.swing.JButton();
        actualVsSchedButton = new javax.swing.JButton();
        workingColumnPanel = new javax.swing.JPanel();
        workingSchedulesTitlePanel = new javax.swing.JPanel();
        workingSchedulesLabel = new javax.swing.JLabel();
        futureScheduleFlagLabel = new javax.swing.JLabel();
        workingSchedulesPane = new javax.swing.JScrollPane();
        loadingWorkingLabel = new javax.swing.JLabel();
        workingSchedulesControlPanel = new javax.swing.JPanel();
        holdButton = new javax.swing.JButton();
        workingScheduleOpenButton = new javax.swing.JButton();
        releaseButton = new javax.swing.JButton();
        elinkOperationsPanel = new javax.swing.JPanel();
        LOAButton = new javax.swing.JButton();
        completedColumnPanel = new javax.swing.JPanel();
        completedSchedulesLabel = new javax.swing.JLabel();
        completedSchedulesPane = new javax.swing.JScrollPane();
        loadingCompletedLabel = new javax.swing.JLabel();
        completedScheduleOpenButton = new javax.swing.JButton();
        scheduleImportsCheckButton = new javax.swing.JButton();
        approvedColumnPanel = new javax.swing.JPanel();
        approvedSchedulesLabel = new javax.swing.JLabel();
        approvedSchedulesPane = new javax.swing.JScrollPane();
        loadingApprovedLabel = new javax.swing.JLabel();
        approvedScheduleOpenButton = new javax.swing.JButton();
        payrollGenerationButton = new javax.swing.JButton();
        previousPayrollCorrectionsButton = new javax.swing.JButton();
        separatedEmployeesMEXButton = new javax.swing.JButton();
        menuPane = new javax.swing.JPanel();
        weeklyFunctionsLabel = new javax.swing.JLabel();
        weeklyHoursCheckButton = new javax.swing.JButton();
        payrollEndingLabel = new javax.swing.JLabel();
        approvalReportsButton = new javax.swing.JButton();
        payrollPeriodApprovalButton = new javax.swing.JButton();
        approveChangesButton = new javax.swing.JButton();
        priorApprovalButton = new javax.swing.JButton();
        payrollCloseCalculationsButton = new javax.swing.JButton();
        lookupByEmployeeLabel = new javax.swing.JLabel();
        employeeDetailButton = new javax.swing.JButton();
        otherLabel = new javax.swing.JLabel();
        employeeMaintenanceButton = new javax.swing.JButton();
        EmpRosterMaintenanceButton = new javax.swing.JButton();
        muRosterMaintenanceButton = new javax.swing.JButton();
        commentMaintenanceButton = new javax.swing.JButton();
        addRecordsButton = new javax.swing.JButton();
        uploadFMLAButton = new javax.swing.JButton();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        messageArea = new javax.swing.JTextField();
        testDBLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        updateMURosterButton = new javax.swing.JButton();
        importIEXUpdatesButton = new javax.swing.JButton();
        importFutureSchedulesButton = new javax.swing.JButton();
        reviewUpdatesButton = new javax.swing.JButton();
        rosterUpdatedLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Schedules");
        setBackground(new java.awt.Color(0, 204, 153));
        setMinimumSize(new java.awt.Dimension(1061, 639));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0);
        flowLayout1.setAlignOnBaseline(true);
        getContentPane().setLayout(flowLayout1);

        schedulePanel.setBackground(new java.awt.Color(0, 204, 153));
        schedulePanel.setMinimumSize(new java.awt.Dimension(1045, 640));
        schedulePanel.setPreferredSize(new java.awt.Dimension(1045, 640));
        schedulePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setText("TVI Time Reporting");
        schedulePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, -1, -1));

        exitButton.setBackground(new java.awt.Color(0, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(140, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        schedulePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, -1, -1));

        refreshButton.setBackground(new java.awt.Color(0, 204, 153));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        schedulePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 40, -1, -1));

        payCycleLabel.setText("Pay Cycle:");
        payCycleLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        schedulePanel.add(payCycleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, -1, -1));

        officeLabel.setText("Office:");
        officeLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        schedulePanel.add(officeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 15, -1, -1));

        payrollPeriodLabel.setText("Current Payroll Period Ends:");
        payrollPeriodLabel.setPreferredSize(new java.awt.Dimension(260, 30));
        schedulePanel.add(payrollPeriodLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pickDateLabel.setText("Pick Date: ");
        pickDateLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setPreferredSize(new java.awt.Dimension(100, 20));
        schedulePanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, -1));

        pickDate.setEditable(true);
        pickDate.setMaximumRowCount(14);
        pickDate.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDate.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDate.setName(""); // NOI18N
        pickDate.setPreferredSize(new java.awt.Dimension(100, 20));
        schedulePanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        display30Days.setBackground(new java.awt.Color(0, 204, 153));
        displayGroup.add(display30Days);
        display30Days.setText("Display 30 Days");
        display30Days.setPreferredSize(new java.awt.Dimension(110, 20));
        display30Days.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display30DaysActionPerformed(evt);
            }
        });
        schedulePanel.add(display30Days, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 100, -1, -1));

        display1year.setBackground(new java.awt.Color(0, 204, 153));
        displayGroup.add(display1year);
        display1year.setText("Display 1 Year");
        display1year.setPreferredSize(new java.awt.Dimension(110, 20));
        display1year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display1yearActionPerformed(evt);
            }
        });
        schedulePanel.add(display1year, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 120, -1, -1));

        scheduleColumnsPanel.setBackground(new java.awt.Color(0, 204, 153));
        scheduleColumnsPanel.setMinimumSize(new java.awt.Dimension(835, 433));
        scheduleColumnsPanel.setPreferredSize(new java.awt.Dimension(835, 460));
        scheduleColumnsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 0));

        importColumnPane.setBackground(new java.awt.Color(0, 204, 153));
        importColumnPane.setMinimumSize(new java.awt.Dimension(100, 500));
        importColumnPane.setPreferredSize(new java.awt.Dimension(100, 500));

        importSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        importSchedulesLabel.setText("<html><u>Import Schedules</u></html>");
        importSchedulesLabel.setPreferredSize(new java.awt.Dimension(100, 15));
        importColumnPane.add(importSchedulesLabel);

        importSchedulesPane.setPreferredSize(new java.awt.Dimension(100, 350));

        importSchedulesPane.setViewportView(importSchedules);

        importColumnPane.add(importSchedulesPane);

        importButton.setBackground(new java.awt.Color(0, 204, 153));
        importButton.setText("Import MU");
        importButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(importButton);

        importOptionsButton.setBackground(new java.awt.Color(0, 204, 153));
        importOptionsButton.setText("Import Options");
        importOptionsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        importOptionsButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importOptionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importOptionsButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(importOptionsButton);

        actualVsSchedButton.setBackground(new java.awt.Color(0, 204, 153));
        actualVsSchedButton.setText("Actual vs Sched");
        actualVsSchedButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        actualVsSchedButton.setPreferredSize(new java.awt.Dimension(100, 30));
        actualVsSchedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualVsSchedButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(actualVsSchedButton);

        scheduleColumnsPanel.add(importColumnPane);

        workingColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        workingColumnPanel.setMinimumSize(new java.awt.Dimension(285, 500));
        workingColumnPanel.setPreferredSize(new java.awt.Dimension(285, 500));

        workingSchedulesTitlePanel.setBackground(new java.awt.Color(0, 204, 153));
        workingSchedulesTitlePanel.setPreferredSize(new java.awt.Dimension(285, 15));
        workingSchedulesTitlePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 0));

        workingSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        workingSchedulesLabel.setText("<html><u>Working Schedules</u></html>");
        workingSchedulesLabel.setMaximumSize(new java.awt.Dimension(2147483647, 15));
        workingSchedulesLabel.setMinimumSize(new java.awt.Dimension(120, 15));
        workingSchedulesLabel.setPreferredSize(new java.awt.Dimension(120, 15));
        workingSchedulesTitlePanel.add(workingSchedulesLabel);

        futureScheduleFlagLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        futureScheduleFlagLabel.setText("F = Future Sched");
        futureScheduleFlagLabel.setPreferredSize(new java.awt.Dimension(100, 15));
        workingSchedulesTitlePanel.add(futureScheduleFlagLabel);

        workingColumnPanel.add(workingSchedulesTitlePanel);

        workingSchedulesPane.setPreferredSize(new java.awt.Dimension(285, 350));

        loadingWorkingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingWorkingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingWorkingLabel.setText("LOADING...");
        workingSchedulesPane.setViewportView(loadingWorkingLabel);

        workingColumnPanel.add(workingSchedulesPane);

        workingSchedulesControlPanel.setBackground(new java.awt.Color(0, 204, 153));
        workingSchedulesControlPanel.setPreferredSize(new java.awt.Dimension(285, 30));
        workingSchedulesControlPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        holdButton.setBackground(new java.awt.Color(0, 204, 153));
        holdButton.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        holdButton.setText("Hold");
        holdButton.setPreferredSize(new java.awt.Dimension(65, 25));
        holdButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                holdButtonActionPerformed(evt);
            }
        });
        workingSchedulesControlPanel.add(holdButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        workingScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        workingScheduleOpenButton.setText("Open Selected");
        workingScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                workingScheduleOpenButtonActionPerformed(evt);
            }
        });
        workingSchedulesControlPanel.add(workingScheduleOpenButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(87, 0, -1, -1));

        releaseButton.setBackground(new java.awt.Color(0, 204, 153));
        releaseButton.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        releaseButton.setText("Release");
        releaseButton.setPreferredSize(new java.awt.Dimension(65, 25));
        releaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                releaseButtonActionPerformed(evt);
            }
        });
        workingSchedulesControlPanel.add(releaseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, -1, -1));

        workingColumnPanel.add(workingSchedulesControlPanel);

        elinkOperationsPanel.setBackground(new java.awt.Color(0, 204, 153));
        elinkOperationsPanel.setPreferredSize(new java.awt.Dimension(285, 30));
        elinkOperationsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LOAButton.setBackground(new java.awt.Color(0, 204, 153));
        LOAButton.setText("Leave of Absence");
        LOAButton.setMaximumSize(new java.awt.Dimension(110, 30));
        LOAButton.setMinimumSize(new java.awt.Dimension(110, 30));
        LOAButton.setPreferredSize(new java.awt.Dimension(130, 30));
        LOAButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LOAButtonActionPerformed(evt);
            }
        });
        elinkOperationsPanel.add(LOAButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(155, 0, -1, -1));

        workingColumnPanel.add(elinkOperationsPanel);

        scheduleColumnsPanel.add(workingColumnPanel);

        completedColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        completedColumnPanel.setMinimumSize(new java.awt.Dimension(175, 500));
        completedColumnPanel.setPreferredSize(new java.awt.Dimension(175, 500));

        completedSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        completedSchedulesLabel.setText("<html><u>Completed Schedules</u></html>");
        completedSchedulesLabel.setPreferredSize(new java.awt.Dimension(180, 15));
        completedColumnPanel.add(completedSchedulesLabel);

        completedSchedulesPane.setPreferredSize(new java.awt.Dimension(175, 350));

        loadingCompletedLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingCompletedLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingCompletedLabel.setText("LOADING...");
        completedSchedulesPane.setViewportView(loadingCompletedLabel);

        completedColumnPanel.add(completedSchedulesPane);

        completedScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        completedScheduleOpenButton.setText("Open Selected");
        completedScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        completedScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completedScheduleOpenButtonActionPerformed(evt);
            }
        });
        completedColumnPanel.add(completedScheduleOpenButton);

        scheduleImportsCheckButton.setBackground(new java.awt.Color(0, 204, 153));
        scheduleImportsCheckButton.setText("Schedule Imports Check");
        scheduleImportsCheckButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        scheduleImportsCheckButton.setMaximumSize(new java.awt.Dimension(110, 30));
        scheduleImportsCheckButton.setMinimumSize(new java.awt.Dimension(110, 30));
        scheduleImportsCheckButton.setPreferredSize(new java.awt.Dimension(140, 30));
        scheduleImportsCheckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleImportsCheckButtonActionPerformed(evt);
            }
        });
        completedColumnPanel.add(scheduleImportsCheckButton);

        scheduleColumnsPanel.add(completedColumnPanel);

        approvedColumnPanel.setBackground(new java.awt.Color(0, 204, 153));
        approvedColumnPanel.setMinimumSize(new java.awt.Dimension(175, 500));
        approvedColumnPanel.setPreferredSize(new java.awt.Dimension(175, 500));

        approvedSchedulesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        approvedSchedulesLabel.setText("<html><u>Approved Schedules</u></html>");
        approvedSchedulesLabel.setPreferredSize(new java.awt.Dimension(175, 15));
        approvedColumnPanel.add(approvedSchedulesLabel);

        approvedSchedulesPane.setPreferredSize(new java.awt.Dimension(175, 350));

        loadingApprovedLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingApprovedLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingApprovedLabel.setText("LOADING...");
        approvedSchedulesPane.setViewportView(loadingApprovedLabel);

        approvedColumnPanel.add(approvedSchedulesPane);

        approvedScheduleOpenButton.setBackground(new java.awt.Color(0, 204, 153));
        approvedScheduleOpenButton.setText("Open Selected");
        approvedScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        approvedScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        approvedScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        approvedScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approvedScheduleOpenButtonActionPerformed(evt);
            }
        });
        approvedColumnPanel.add(approvedScheduleOpenButton);

        payrollGenerationButton.setBackground(new java.awt.Color(0, 204, 153));
        payrollGenerationButton.setText("Payroll Generation");
        payrollGenerationButton.setMaximumSize(new java.awt.Dimension(110, 30));
        payrollGenerationButton.setMinimumSize(new java.awt.Dimension(110, 30));
        payrollGenerationButton.setPreferredSize(new java.awt.Dimension(130, 30));
        payrollGenerationButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payrollGenerationButtonActionPerformed(evt);
            }
        });
        approvedColumnPanel.add(payrollGenerationButton);

        previousPayrollCorrectionsButton.setBackground(new java.awt.Color(0, 204, 153));
        previousPayrollCorrectionsButton.setText("Previous Corrections");
        previousPayrollCorrectionsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        previousPayrollCorrectionsButton.setMaximumSize(new java.awt.Dimension(110, 30));
        previousPayrollCorrectionsButton.setMinimumSize(new java.awt.Dimension(110, 30));
        previousPayrollCorrectionsButton.setPreferredSize(new java.awt.Dimension(130, 30));
        previousPayrollCorrectionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousPayrollCorrectionsButtonActionPerformed(evt);
            }
        });
        approvedColumnPanel.add(previousPayrollCorrectionsButton);

        separatedEmployeesMEXButton.setBackground(new java.awt.Color(0, 204, 153));
        separatedEmployeesMEXButton.setText("Separated Employees");
        separatedEmployeesMEXButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        separatedEmployeesMEXButton.setMaximumSize(new java.awt.Dimension(110, 30));
        separatedEmployeesMEXButton.setMinimumSize(new java.awt.Dimension(110, 30));
        separatedEmployeesMEXButton.setPreferredSize(new java.awt.Dimension(130, 30));
        separatedEmployeesMEXButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                separatedEmployeesMEXButtonActionPerformed(evt);
            }
        });
        approvedColumnPanel.add(separatedEmployeesMEXButton);

        scheduleColumnsPanel.add(approvedColumnPanel);

        schedulePanel.add(scheduleColumnsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 835, 480));

        menuPane.setBackground(new java.awt.Color(0, 204, 153));
        menuPane.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        weeklyFunctionsLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        weeklyFunctionsLabel.setText("<html><u>Weekly Functions</u></html>");
        weeklyFunctionsLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        weeklyFunctionsLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(weeklyFunctionsLabel);

        weeklyHoursCheckButton.setBackground(new java.awt.Color(0, 204, 153));
        weeklyHoursCheckButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        weeklyHoursCheckButton.setText("<html><div align='center' width='100%'>Weekly Scheduled<br>Hours Check</div></html>");
        weeklyHoursCheckButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        weeklyHoursCheckButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        weeklyHoursCheckButton.setPreferredSize(new java.awt.Dimension(190, 40));
        weeklyHoursCheckButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weeklyHoursCheckButtonActionPerformed(evt);
            }
        });
        menuPane.add(weeklyHoursCheckButton);

        payrollEndingLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        payrollEndingLabel.setText("<html><u>Payroll Ending Functions</u></html>");
        payrollEndingLabel.setToolTipText("Functions to be preformed before the end of payroll. Verification and approvals.");
        payrollEndingLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        payrollEndingLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(payrollEndingLabel);

        approvalReportsButton.setBackground(new java.awt.Color(0, 204, 153));
        approvalReportsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        approvalReportsButton.setText("<html><div align='center' width='100%'>Approval/Verif<br>Reports</div></html>");
        approvalReportsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        approvalReportsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        approvalReportsButton.setPreferredSize(new java.awt.Dimension(190, 40));
        approvalReportsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approvalReportsButtonActionPerformed(evt);
            }
        });
        menuPane.add(approvalReportsButton);

        payrollPeriodApprovalButton.setBackground(new java.awt.Color(0, 204, 153));
        payrollPeriodApprovalButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        payrollPeriodApprovalButton.setText("<html><div align='center' width='100%'>Payroll Period Approval</div></html>");
        payrollPeriodApprovalButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        payrollPeriodApprovalButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        payrollPeriodApprovalButton.setPreferredSize(new java.awt.Dimension(190, 40));
        payrollPeriodApprovalButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payrollPeriodApprovalButtonActionPerformed(evt);
            }
        });
        menuPane.add(payrollPeriodApprovalButton);

        approveChangesButton.setBackground(new java.awt.Color(0, 204, 153));
        approveChangesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        approveChangesButton.setText("<html><div align='center' width='100%'>Approve TVI Changes<br>In Current Pay Period</div></html>");
        approveChangesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        approveChangesButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        approveChangesButton.setPreferredSize(new java.awt.Dimension(190, 40));
        approveChangesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approveChangesButtonActionPerformed(evt);
            }
        });
        menuPane.add(approveChangesButton);

        priorApprovalButton.setBackground(new java.awt.Color(0, 204, 153));
        priorApprovalButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        priorApprovalButton.setText("<html><div align='center' width='100%'>Prior Payroll Period<br>Approval</div></html>");
        priorApprovalButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        priorApprovalButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        priorApprovalButton.setPreferredSize(new java.awt.Dimension(190, 40));
        priorApprovalButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priorApprovalButtonActionPerformed(evt);
            }
        });
        menuPane.add(priorApprovalButton);

        payrollCloseCalculationsButton.setBackground(new java.awt.Color(0, 204, 153));
        payrollCloseCalculationsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        payrollCloseCalculationsButton.setText("<html><div align='center' width='100%'>Payroll Close<br>Calculations</div></html>");
        payrollCloseCalculationsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        payrollCloseCalculationsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        payrollCloseCalculationsButton.setPreferredSize(new java.awt.Dimension(190, 40));
        payrollCloseCalculationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payrollCloseCalculationsButtonActionPerformed(evt);
            }
        });
        menuPane.add(payrollCloseCalculationsButton);

        lookupByEmployeeLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lookupByEmployeeLabel.setText("<html><u>Lookup By Employee</u></html>");
        lookupByEmployeeLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        lookupByEmployeeLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(lookupByEmployeeLabel);

        employeeDetailButton.setBackground(new java.awt.Color(0, 204, 153));
        employeeDetailButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        employeeDetailButton.setText("<html><div align='center' width='100%'>Time Reporting Data<br>By Employee</div></html>");
        employeeDetailButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        employeeDetailButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeDetailButton.setPreferredSize(new java.awt.Dimension(190, 40));
        employeeDetailButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeDetailButtonActionPerformed(evt);
            }
        });
        menuPane.add(employeeDetailButton);

        otherLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        otherLabel.setText("<html><u>Other Functions</u></html>");
        otherLabel.setPreferredSize(new java.awt.Dimension(190, 15));
        otherLabel.setVerifyInputWhenFocusTarget(false);
        menuPane.add(otherLabel);

        employeeMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        employeeMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        employeeMaintenanceButton.setText("Employee Maintenance");
        employeeMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        employeeMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 23));
        employeeMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(employeeMaintenanceButton);

        EmpRosterMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        EmpRosterMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        EmpRosterMaintenanceButton.setText("Emp Roster Maintenance");
        EmpRosterMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EmpRosterMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        EmpRosterMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 23));
        EmpRosterMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpRosterMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(EmpRosterMaintenanceButton);

        muRosterMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        muRosterMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        muRosterMaintenanceButton.setText("MU Roster Maintenance");
        muRosterMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        muRosterMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        muRosterMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 23));
        muRosterMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muRosterMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(muRosterMaintenanceButton);

        commentMaintenanceButton.setBackground(new java.awt.Color(0, 204, 153));
        commentMaintenanceButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        commentMaintenanceButton.setText("Comment Maintenance");
        commentMaintenanceButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        commentMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        commentMaintenanceButton.setPreferredSize(new java.awt.Dimension(190, 23));
        commentMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                commentMaintenanceButtonActionPerformed(evt);
            }
        });
        menuPane.add(commentMaintenanceButton);

        addRecordsButton.setBackground(new java.awt.Color(0, 204, 153));
        addRecordsButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        addRecordsButton.setText("Add Records for Employee");
        addRecordsButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        addRecordsButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        addRecordsButton.setPreferredSize(new java.awt.Dimension(190, 23));
        addRecordsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRecordsButtonActionPerformed(evt);
            }
        });
        menuPane.add(addRecordsButton);

        uploadFMLAButton.setBackground(new java.awt.Color(0, 204, 153));
        uploadFMLAButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        uploadFMLAButton.setText("<html><div align='center' width='100%'>Upload FMLA Approvals</div></html>");
        uploadFMLAButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        uploadFMLAButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        uploadFMLAButton.setPreferredSize(new java.awt.Dimension(190, 23));
        uploadFMLAButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadFMLAButtonActionPerformed(evt);
            }
        });
        menuPane.add(uploadFMLAButton);

        schedulePanel.add(menuPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 45, 190, 575));

        feederSitePanel.setBackground(new java.awt.Color(0, 204, 153));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 40));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederLabel.setPreferredSize(new java.awt.Dimension(90, 16));
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        siteLabel.setPreferredSize(new java.awt.Dimension(70, 16));
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        schedulePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        messageArea.setEditable(false);
        messageArea.setBackground(new java.awt.Color(255, 255, 51));
        messageArea.setText("message");
        messageArea.setMargin(new java.awt.Insets(2, 5, 2, 2));
        messageArea.setPreferredSize(new java.awt.Dimension(500, 20));
        messageArea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                messageAreaActionPerformed(evt);
            }
        });
        schedulePanel.add(messageArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 75, 500, -1));

        testDBLabel.setBackground(new java.awt.Color(255, 51, 51));
        testDBLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        testDBLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        testDBLabel.setText("TEST DATABASE");
        testDBLabel.setName(""); // NOI18N
        schedulePanel.add(testDBLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, -1, -1));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 0));

        updateMURosterButton.setBackground(new java.awt.Color(0, 204, 153));
        updateMURosterButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
        updateMURosterButton.setToolTipText("");
        updateMURosterButton.setMargin(new java.awt.Insets(2, 4, 2, 4));
        updateMURosterButton.setPreferredSize(new java.awt.Dimension(110, 40));
        updateMURosterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateMURosterButtonActionPerformed(evt);
            }
        });
        jPanel1.add(updateMURosterButton);

        importIEXUpdatesButton.setBackground(new java.awt.Color(0, 204, 153));
        importIEXUpdatesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        importIEXUpdatesButton.setText("<html><div align='center' width='100%'>Import IEX<br>Updates</div></html>");
        importIEXUpdatesButton.setMargin(new java.awt.Insets(2, 4, 2, 4));
        importIEXUpdatesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        importIEXUpdatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importIEXUpdatesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(importIEXUpdatesButton);

        importFutureSchedulesButton.setBackground(new java.awt.Color(0, 204, 153));
        importFutureSchedulesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        importFutureSchedulesButton.setText("<html><div align='center' width='100%'>Import Future<br>Schedules</div></html>");
        importFutureSchedulesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        importFutureSchedulesButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        importFutureSchedulesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        importFutureSchedulesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importFutureSchedulesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(importFutureSchedulesButton);

        reviewUpdatesButton.setBackground(new java.awt.Color(0, 204, 153));
        reviewUpdatesButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        reviewUpdatesButton.setText("<html><div align='center' width='100%'>Review<br>Updates</div></html>");
        reviewUpdatesButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        reviewUpdatesButton.setPreferredSize(new java.awt.Dimension(110, 40));
        reviewUpdatesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewUpdatesButtonActionPerformed(evt);
            }
        });
        jPanel1.add(reviewUpdatesButton);

        schedulePanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 560, 40));

        rosterUpdatedLabel.setText("MU Roster Last Updated: ");
        rosterUpdatedLabel.setPreferredSize(new java.awt.Dimension(260, 30));
        schedulePanel.add(rosterUpdatedLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, 20));

        getContentPane().add(schedulePanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void holdButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_holdButtonActionPerformed
        int selectedRow = workingSchedulesTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "Select a schedule from the Working Schedules column and try again", "FYI Messages", 1, 1, 1);
        }
        else if (!Oracle.getScheduleStatus(getFormComponent(), feeder, site, workingSchedulesTable.getValueAt(selectedRow, idx_MU).toString(), (Date) workingSchedulesTable.getValueAt(selectedRow, idx_REPORTING_DATE)).equals("Ready to Send"))
        {
            if (workingSchedulesTable.getValueAt(selectedRow, idx_STATUS).equals("Ready to Send"))
            {
                refreshData();
            }
            Misc.msgbox(getFormComponent(), "STATUS Must be: Ready to Send", "FYI Messages", 1, 1, 1);
        }
        else
        {
            String scheduleMu = workingSchedulesTable.getValueAt(selectedRow, idx_MU).toString();
            Date scheduleDate = (Date) workingSchedulesTable.getValueAt(selectedRow, idx_REPORTING_DATE);
            Oracle.setScheduleHoldRelease(getFormComponent(), feeder, site, scheduleMu, scheduleDate, "Hold");
            String newStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, scheduleMu, scheduleDate);
            workingSchedulesData.setValueAt(newStatus, workingSchedulesTable.convertRowIndexToModel(selectedRow), idx_STATUS);
        }
        workingSchedulesTable.requestFocusInWindow();
    }//GEN-LAST:event_holdButtonActionPerformed

    private void releaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_releaseButtonActionPerformed
        int selectedRow = workingSchedulesTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "Select a schedule from the Working Schedules column and try again", "FYI Messages", 1, 1, 1);
        }
        else if (!Oracle.getScheduleStatus(getFormComponent(), feeder, site, workingSchedulesTable.getValueAt(selectedRow, idx_MU).toString(), (Date) workingSchedulesTable.getValueAt(selectedRow, idx_REPORTING_DATE)).equals("Hold"))
        {
            if (workingSchedulesTable.getValueAt(selectedRow, idx_STATUS).equals("Hold"))
            {
                refreshData();
            }
            Misc.msgbox(getFormComponent(), "STATUS Must be: Hold", "FYI Messages", 1, 1, 1);
        }
        else
        {
            String scheduleMu = workingSchedulesTable.getValueAt(selectedRow, idx_MU).toString();
            Date scheduleDate = (Date) workingSchedulesTable.getValueAt(selectedRow, idx_REPORTING_DATE);
            Oracle.setScheduleHoldRelease(getFormComponent(), feeder, site, scheduleMu, scheduleDate, "Release");
            String newStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, scheduleMu, scheduleDate);
            workingSchedulesData.setValueAt(newStatus, workingSchedulesTable.convertRowIndexToModel(selectedRow), idx_STATUS);
        }
        workingSchedulesTable.requestFocusInWindow();
    }//GEN-LAST:event_releaseButtonActionPerformed

    private void weeklyHoursCheckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weeklyHoursCheckButtonActionPerformed
        WeeklyScheduledHoursCheck.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_weeklyHoursCheckButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void importButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        List selectedMUs = importSchedules.getSelectedValuesList();
        boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
        if (okToImport)
        {
            RegionData.updateSiteInfo(getFormComponent(), feeder, site);
            okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
        }
        if (!okToImport)
        {
            setCursor(Constants.NORMAL);
            return;
        }
        if (updatingMuRoster)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "Cannot import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
            return;
        }
        Date importDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (importDate == null)
        {
            setCursor(Constants.NORMAL);
            return;
        }
        if (importSchedules.getSelectedValue() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must select an MU from the list!", "Import Schedules", 1, 1, 1);
            return;
        }
        if (pickDate.getSelectedItem() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must Pick or Enter a Date!", "Import Schedules", 1, 1, 1);
            return;
        }
        else if (!Misc.isDate(pickDate.getSelectedItem().toString()))
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must first Pick or Enter a valid Date", "Importing Schedules", 1, 1, 1);
            return;
        }
        else
        {
            Calendar cal = Calendar.getInstance();
            cal.setTime(todaysDate);
            cal.add(Calendar.YEAR, -1);
            Date lastYear = cal.getTime();
            Date selectedDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
            setCursor(Constants.NORMAL);
            if (selectedDate == null)
            {
                return;
            }
            if (selectedDate.compareTo(lastYear) < 0)
            {
                Misc.msgbox(getFormComponent(), "Selected date must be in the last year.", "Importing Schedules", 1, 1, 1);
                return;
            }
        }
        
        String importType = "REPLACE";
        String lockedBy;
        String scheduleStatus;
        boolean includesReimport = false;
        int choice;
        if (selectedMUs.size() > 0)
        {
            for (Object mu : selectedMUs)
            {
                lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu.toString(), importDate);
                scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu.toString(), importDate);
                if (scheduleStatus == null)
                {
                    //normal import
                }
                else if (scheduleStatus.equals("Sent Waiting Results"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has been Sent to Elink - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("In Use"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has some or all records locked by another user - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("Load Failed"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "Last import attempt failed on the schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " - You cannot import. Email TVI Support: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (Arrays.asList("Requesting", "Loading").contains(scheduleStatus))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " is currently processing an import request - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (scheduleStatus.equals("Imported"))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " has status of Imported - open the schedule to update status.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else if (lockedBy != null)
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "The schedule for MU " + mu.toString() + " on " + Misc.dateToStringMDY(importDate) + " is LOCKED by: " + lockedBy + " - You cannot import.", "Import Schedules", 1, 1, 1);
                    return;
                }
                else
                {
                    includesReimport = true;
                }
            }
            if (includesReimport)
            {
                setCursor(Constants.NORMAL);
                choice = JOptionPane.showOptionDialog
                (
                    null,
                    "At least one of the selected schedules already exists.",
                    "Re-Importing Schedule",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    new String[]{"UPDATE", "CANCEL"},
                    "UPDATE"
                );
                switch (choice)
                {
                    case 0: // UPDATE
                        importType = "UPDATE";
                        break;
                    default: // user cancel
                        return;
                }
            }
        }
        setCursor(Constants.HOURGLASS);
        for (Object mu : selectedMUs)
        {
            Oracle.requestSchedule(getFormComponent(), feeder, site, mu.toString(), importDate, importDate, importType, UserData.getUUID());
        }
        setCursor(Constants.NORMAL);
        refreshData();
    }//GEN-LAST:event_importButtonActionPerformed
    
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed
    
    private void employeeDetailButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeDetailButtonActionPerformed
        TimeReportingByEmployee.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_employeeDetailButtonActionPerformed

    private void payrollPeriodApprovalButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payrollPeriodApprovalButtonActionPerformed
        PayrollPeriodApproval.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_payrollPeriodApprovalButtonActionPerformed

    private void approvalReportsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approvalReportsButtonActionPerformed
        VerificationReportsMenu.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_approvalReportsButtonActionPerformed

    private void priorApprovalButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priorApprovalButtonActionPerformed
        Date endDate = Oracle.getPreviousPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        Date startDate = Misc.dateAddDays(endDate, -372);
        TimeReporting.getInstance(getFormComponent(), feeder, site, null, null, startDate, endDate, RegionData.getSiteUnion(), "PRIOR");
    }//GEN-LAST:event_priorApprovalButtonActionPerformed

    private void display1yearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display1yearActionPerformed
        approvedTimer.setInitialDelay(0);
        approvedTimer.setDelay(5*60*1000);
        if (approvedTimer.isRunning())
        {
            approvedTimer.restart();
        }
        else
        {
            approvedTimer.start();
        }
    }//GEN-LAST:event_display1yearActionPerformed

    private void display30DaysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display30DaysActionPerformed
        approvedTimer.setInitialDelay(0);
        approvedTimer.setDelay(60*1000);
        if (approvedTimer.isRunning())
        {
            approvedTimer.restart();
        }
        else
        {
            approvedTimer.start();
        }
    }//GEN-LAST:event_display30DaysActionPerformed

    private void importOptionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importOptionsButtonActionPerformed
        ImportOptions.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_importOptionsButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void workingScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_workingScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(workingSchedulesTable)).start();
    }//GEN-LAST:event_workingScheduleOpenButtonActionPerformed

    private void completedScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_completedScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(completedSchedulesTable)).start();
    }//GEN-LAST:event_completedScheduleOpenButtonActionPerformed

    private void approvedScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approvedScheduleOpenButtonActionPerformed
        new Thread(new OpenScheduleThread(approvedSchedulesTable)).start();
    }//GEN-LAST:event_approvedScheduleOpenButtonActionPerformed

    private void employeeMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMaintenanceButtonActionPerformed
        EmployeeMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_employeeMaintenanceButtonActionPerformed

    private void commentMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_commentMaintenanceButtonActionPerformed
        CommentList.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_commentMaintenanceButtonActionPerformed

    private void approveChangesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approveChangesButtonActionPerformed
        Date startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        TimeReporting.getInstance(getFormComponent(), feeder, site, null, null, startDate, RegionData.getPayClose(), RegionData.getSiteUnion(), "CHANGES");
    }//GEN-LAST:event_approveChangesButtonActionPerformed

    private void addRecordsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRecordsButtonActionPerformed
        AddRecords.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_addRecordsButtonActionPerformed

    private void payrollGenerationButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payrollGenerationButtonActionPerformed
        PayrollGeneration.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_payrollGenerationButtonActionPerformed

    private void separatedEmployeesMEXButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_separatedEmployeesMEXButtonActionPerformed
        PayrollGenerationMEXSeparated.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_separatedEmployeesMEXButtonActionPerformed

    private void LOAButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LOAButtonActionPerformed
        LOAMex.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_LOAButtonActionPerformed

    private void scheduleImportsCheckButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleImportsCheckButtonActionPerformed
        if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
        {
            ScheduleImportsStatusMonthly.getInstance(getFormComponent(), feeder, site);
        }
        else
        {
            ScheduleImportsStatus.getInstance(getFormComponent(), feeder, site);
        }
    }//GEN-LAST:event_scheduleImportsCheckButtonActionPerformed

    private void previousPayrollCorrectionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousPayrollCorrectionsButtonActionPerformed
        PreviousPayrollCorrections.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_previousPayrollCorrectionsButtonActionPerformed

    private void actualVsSchedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualVsSchedButtonActionPerformed
        ActualSchedules.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_actualVsSchedButtonActionPerformed

    private void uploadFMLAButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_uploadFMLAButtonActionPerformed
    {//GEN-HEADEREND:event_uploadFMLAButtonActionPerformed
        new Thread(new UpdateFMLAThread()).start();
    }//GEN-LAST:event_uploadFMLAButtonActionPerformed

    private void payrollCloseCalculationsButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_payrollCloseCalculationsButtonActionPerformed
    {//GEN-HEADEREND:event_payrollCloseCalculationsButtonActionPerformed
        PayrollCloseCalculations.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_payrollCloseCalculationsButtonActionPerformed

    private void messageAreaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_messageAreaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_messageAreaActionPerformed

    private void EmpRosterMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpRosterMaintenanceButtonActionPerformed
        EmployeeRosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_EmpRosterMaintenanceButtonActionPerformed

    private void muRosterMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muRosterMaintenanceButtonActionPerformed
        MURosterMaintenance.getInstance(getFormComponent(), feeder, site, null);
    }//GEN-LAST:event_muRosterMaintenanceButtonActionPerformed

    private void updateMURosterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateMURosterButtonActionPerformed
        if (Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site))
        {
            if (Oracle.getNumSchedulesRequesting(getFormComponent(), feeder, site) == 0)
            {
                updatingMuRoster = true;
                updateMURosterButton.setText("<html><div align='center' width='100%'>Requesting<br>Please Wait</div></html>");
                updateMURosterButton.setEnabled(false);
                Oracle.updateIexMuRoster(getFormComponent(), feeder, site, UserData.getUUID());
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Cannot update MU Roster while schedules are being requested.", "MU Roster Update Locked", 1, 1, 1);
            }
        }
        else
        {
            Misc.msgbox(getFormComponent(), "Cannot update MU Roster while importing is locked", "MU Roster Update Locked", 1, 1, 1);
        }
    }//GEN-LAST:event_updateMURosterButtonActionPerformed

    private void importIEXUpdatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importIEXUpdatesButtonActionPerformed
        if (feeder.equals("MEX"))
        {
            ImportSchedulesUpdateMEX.getInstance(getFormComponent(), feeder, site);
        }
        else if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
        {
            ImportSchedulesUpdateMonthly.getInstance(getFormComponent(), feeder, site);
        }
    }//GEN-LAST:event_importIEXUpdatesButtonActionPerformed

    private void importFutureSchedulesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importFutureSchedulesButtonActionPerformed
        ImportSchedulesFuture.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_importFutureSchedulesButtonActionPerformed

    private void reviewUpdatesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewUpdatesButtonActionPerformed
        String mu = "ALL";
        if (RegionData.getReviewByMU())
        {
            // labels
            JLabel muLabel = new JLabel("Select MUs to review updates for:");
            muLabel.setFont(new java.awt.Font("Tahoma", 1, 14));
            muLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            muLabel.setPreferredSize(new Dimension(260, 20));

            JLabel selectionLabel = new JLabel("(To select multiple MUs, Ctrl + Click)");
            selectionLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
            selectionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            selectionLabel.setPreferredSize(new Dimension(260, 20));

            // mu selection list
            JScrollPane muScrollPane = new JScrollPane();
            muScrollPane.setPreferredSize(new Dimension(100, 250));
            JList<String> muList = new JList<>();
            muList.setFont(new java.awt.Font("Tahoma", 0, 14));
            muList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            muScrollPane.setViewportView(muList);
            DefaultListModel<String> muModel = new DefaultListModel<>();

            // checkbox
            JCheckBox rememberSelectionsCheckBox = new JCheckBox();
            rememberSelectionsCheckBox.setFont(new java.awt.Font("Tahoma", 0, 14));
            rememberSelectionsCheckBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            rememberSelectionsCheckBox.setPreferredSize(new Dimension(260, 20));
            rememberSelectionsCheckBox.setText("Remember my current selections");

            // populate mulist
            for (String s : RegionData.getMuList())
            {
                if (!Misc.isAlpha(s.substring(0, 1)))
                {
                    muModel.addElement(s);
                }
            }
            muList.setModel(muModel);

            String userMuList = Oracle.getUserSetting(getFormComponent(), feeder, site, UserData.getUUID(), "REVIEW_UPDATES");
            if (userMuList == null || userMuList.isEmpty())
            {
                muList.setSelectedIndex(0);
            }
            else
            {
                rememberSelectionsCheckBox.setSelected(true);
                List<String> musToSelect = Misc.stringCSVToList(userMuList);
                List<Integer> indicesToSelect = new ArrayList<>();
                for (String muString : musToSelect)
                {
                    for (int i = 0; i < muList.getModel().getSize(); i++)
                    {
                        if (muString.equals(muList.getModel().getElementAt(i)))
                        {
                            indicesToSelect.add(i);
                        }
                    }
                }
                muList.setSelectedIndices(indicesToSelect.stream().mapToInt(i->i).toArray());
            }

            // panel
            JPanel panel = new JPanel();
            panel.setPreferredSize(new Dimension(300, 370));
            FlowLayout layout = new FlowLayout();
            layout.setVgap(10);
            panel.setLayout(layout);
            panel.add(muLabel);
            panel.add(selectionLabel);
            panel.add(muScrollPane);
            panel.add(rememberSelectionsCheckBox);

            int rc = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Review Updates", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (rc != 0) // cancelled
            {
                return;
            }

            List<String> selectedMUs = muList.getSelectedValuesList();
            mu = String.join(",", selectedMUs);
            boolean rememberSelections = rememberSelectionsCheckBox.isSelected();

            if (rememberSelections)
            {
                Oracle.setUserSetting(getFormComponent(), feeder, site, UserData.getUUID(), "REVIEW_UPDATES", mu);
            }
        }

        TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, null, null, RegionData.getSiteUnion(), "REVIEW UPDATES");
    }//GEN-LAST:event_reviewUpdatesButtonActionPerformed
    
    private class OpenScheduleThread implements Runnable
    {
        JTable table;
        
        public OpenScheduleThread(JTable table)
        {
            this.table = table;
        }
        
        @Override
        public void run()
        {
            if (this.table == null)
            {
                return;
            }
            if (openingScheduleLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setControlsEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    int selectedRow = this.table.getSelectedRow();
                    if (selectedRow == -1)
                    {
                        Misc.msgbox(getFormComponent(), "You must select a schedule first.", "", 1, 1, 1);
                        return;
                    }
                    String selectedMU = this.table.getValueAt(selectedRow, idx_MU).toString();
                    Date selectedDate = (Date) this.table.getValueAt(selectedRow, idx_REPORTING_DATE);
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, selectedMU, selectedDate);
                    if (Arrays.asList("Requesting", "Loading", "Load Failed", "Sent Waiting Results", "Send Failed").contains(scheduleStatus))
                    {
                        String message = "Cannot open schedule with status of \"" + scheduleStatus + "\".";
                        if (scheduleStatus.equals("Load Failed") || scheduleStatus.equals("Send Failed"))
                        {
                            message += "\nEmail TVI Support: " + Constants.EMAIL;
                        }
                        Misc.msgbox(getFormComponent(), message, "Schedule Locked", 1, 1, 1);
                    }
                    else if (Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, selectedMU, selectedDate) != null)
                    {
                        String lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, selectedMU, selectedDate);
                        Misc.msgbox(getFormComponent(), "Cannot open schedule at this time, it is currently locked by: " + lockedBy, "Schedule Locked", 1, 1, 1);
                    }
                    else
                    {
                        final String mu = selectedMU;
                        final Date reportingDate = selectedDate;
                        final String union = this.table.getValueAt(selectedRow, idx_UNION_FLAG).toString();
                        if (scheduleStatus.equals("Imported"))
                        {
                            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "IMPORTED");
                        }
                        else
                        {
                            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
                        }
                    }
                }
                finally
                {
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            openingScheduleLock.release();
                            setControlsEnabled(true);
                        }
                    });
                }
            }
        }
    }
    
    private class RefreshWorkingSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshWorkingSchedulesLock.tryAcquire())
            {
                try
                {
                    workingSchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    workingSchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    workingSchedulesWorker = new TableSwingWorker(getFormComponent(), workingSchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    workingSchedulesWorker.execute();
                }
                finally
                {
                    if (workingSchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingWorkingLabel.setText("ERROR");
                            }
                        });
                        refreshWorkingSchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (workingSchedulesTable != null)
                    {
                        workingRowCount = workingSchedulesTable.getRowCount();
                        workingScrollPosition = workingSchedulesPane.getVerticalScrollBar().getValue();
                        workingSortKeys = workingSchedulesTable.getRowSorter().getSortKeys();
                        workingSelectedRow = workingSchedulesTable.getSelectedRow();
                        if (workingSelectedRow >= 0)
                        {
                            workingSelectedMu = workingSchedulesTable.getValueAt(workingSelectedRow, idx_MU).toString();
                            workingSelectedDate = workingSchedulesTable.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    workingSchedulesPane.setViewportView(loadingWorkingLabel);
                    gotSending = false;
                    gotImporting = false;
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsSchedules(getFormComponent(), feeder, site, 365, "Working");
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                
                data = new Object[]
                {
                    rs.getString("MU"),            // idx_MU
                    rs.getDate("REPORTING_DATE"),  // idx_REPORTING_DATE
                    rs.getString("STATUS"),        // idx_STATUS
                    rs.getString("TOTALVIEWID"),   // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),    // idx_UNION_FLAG
                    futureFlag,                    // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")  // idx_IMPORT_LOCKED
                };
                
                String status = rs.getString("STATUS");
                if (Arrays.asList("Importing", "Loading", "Requesting").contains(status))
                {
                    gotImporting = true;
                }
                if (status.equals("Sent Waiting Results"))
                {
                    gotSending = true;
                }
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Working Schedules data.");
                workingSchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                workingSchedulesTable.setPreferredScrollableViewportSize(workingSchedulesTable.getPreferredSize());
                if (workingSelectedRow >= 0 && workingSelectedMu != null && workingSelectedDate != null && workingSelectedRow <= workingSchedulesTable.getRowCount() - 1)
                {
                    if (workingSchedulesTable.getValueAt(workingSelectedRow, idx_MU).equals(workingSelectedMu) &&
                        workingSchedulesTable.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString().equals(workingSelectedDate))
                    {
                        workingSchedulesTable.changeSelection(workingSelectedRow, 0, false, false);
                    }
                }
                workingSchedulesPane.setViewportView(workingSchedulesTable);
                revalidate();
                int position = workingScrollPosition + (workingSchedulesTable.getRowCount() - workingRowCount) * 16;
                if (workingScrollPosition != 0 && position > 0)
                {
                    workingSchedulesPane.getVerticalScrollBar().setValue(position);
                }
                
                if (gotSending)
                {
                    if (completedTimer.getDelay() != 30*1000)
                    {
                        completedTimer.setDelay(30*1000);
                        completedTimer.setInitialDelay(30*1000);
                        completedTimer.restart();
                    }
                    if (workingTimer.getDelay() != 30*1000)
                    {
                        workingTimer.setDelay(30*1000);
                        workingTimer.setInitialDelay(30*1000);
                        workingTimer.restart();
                    }
                }
                else
                {
                    if (completedTimer.getDelay() != 60*1000)
                    {
                        completedTimer.setDelay(60*1000);
                        completedTimer.setInitialDelay(60*1000);
                        completedTimer.restart();
                    }
                    if (gotImporting)
                    {
                        if (workingTimer.getDelay() != 30*1000)
                        {
                            workingTimer.setDelay(30*1000);
                            workingTimer.setInitialDelay(30*1000);
                            workingTimer.restart();
                        }
                    }
                    else if (workingTimer.getDelay() != 60*1000)
                    {
                        workingTimer.setDelay(60*1000);
                        workingTimer.setInitialDelay(60*1000);
                        workingTimer.restart();
                    }
                }
            }
            refreshWorkingSchedulesLock.release();
        }
        
        private void createTable()
        {
            workingSchedulesTable = new JTable(workingSchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (workingSchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            workingSchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(workingSchedulesTable)).start();
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            Misc.configureTable(workingSchedulesTable, true, false, false);
            if (workingSortKeys != null)
            {
                workingSchedulesTable.getRowSorter().setSortKeys(workingSortKeys);
            }
            Misc.setHeaderRenderer(workingSchedulesTable, true, true, null);
            Misc.setColumnSettings(workingSchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(workingSchedulesTable, idx_REPORTING_DATE, 75);
            Misc.setColumnSettings(workingSchedulesTable, idx_STATUS, 120);
            Misc.setColumnSettings(workingSchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(workingSchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(workingSchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(workingSchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private class RefreshCompletedSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshCompletedSchedulesLock.tryAcquire())
            {
                try
                {
                    completedSchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    completedSchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    completedSchedulesWorker = new TableSwingWorker(getFormComponent(), completedSchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    completedSchedulesWorker.execute();
                }
                finally
                {
                    if (completedSchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingCompletedLabel.setText("ERROR");
                            }
                        });
                        refreshCompletedSchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (completedSchedulesTable != null)
                    {
                        completedRowCount = completedSchedulesTable.getRowCount();
                        completedScrollPosition = completedSchedulesPane.getVerticalScrollBar().getValue();
                        completedSortKeys = completedSchedulesTable.getRowSorter().getSortKeys();
                        completedSelectedRow = completedSchedulesTable.getSelectedRow();
                        if (completedSelectedRow >= 0)
                        {
                            completedSelectedMu = completedSchedulesTable.getValueAt(completedSelectedRow, idx_MU).toString();
                            completedSelectedDate = completedSchedulesTable.getValueAt(completedSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    completedSchedulesPane.setViewportView(loadingCompletedLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progress bar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            String scheduleStatus;
            if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
            {
                scheduleStatus = "Approved";
            }
            else
            {
                scheduleStatus = "Completed";
            }
            return Oracle.getResultsSchedules(getFormComponent(), feeder, site, 365, scheduleStatus);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                data = new Object[]
                {
                    rs.getString("MU"),            // idx_MU
                    rs.getDate("REPORTING_DATE"),  // idx_REPORTING_DATE
                    rs.getString("STATUS"),        // idx_STATUS
                    rs.getString("TOTALVIEWID"),   // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),    // idx_UNION_FLAG
                    futureFlag,                    // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")  // idx_IMPORT_LOCKED
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Coompleted Schedules data.");
                completedSchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                if (completedSelectedRow >= 0 && completedSelectedMu != null && completedSelectedDate != null && completedSelectedRow <= completedSchedulesTable.getRowCount() - 1)
                {
                    if (completedSchedulesTable.getValueAt(completedSelectedRow, idx_MU).equals(completedSelectedMu) &&
                        completedSchedulesTable.getValueAt(completedSelectedRow, idx_REPORTING_DATE).toString().equals(completedSelectedDate))
                    {
                        completedSchedulesTable.changeSelection(completedSelectedRow, 0, false, false);
                    }
                }
                completedSchedulesPane.setViewportView(completedSchedulesTable);
                revalidate();
                int position = completedScrollPosition + (completedSchedulesTable.getRowCount() - completedRowCount) * 16;
                if (completedScrollPosition != 0 && position > 0)
                {
                    completedSchedulesPane.getVerticalScrollBar().setValue(position);
                }
            }
            refreshCompletedSchedulesLock.release();
        }
        
        private void createTable()
        {
            completedSchedulesTable = new JTable(completedSchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (completedSchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            completedSchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(completedSchedulesTable)).start();
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            
            Misc.configureTable(completedSchedulesTable, true, false, false);
            if (completedSortKeys != null)
            {
                completedSchedulesTable.getRowSorter().setSortKeys(completedSortKeys);
            }
            Misc.setHeaderRenderer(completedSchedulesTable, true, true, null);
            Misc.setColumnSettings(completedSchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(completedSchedulesTable, idx_REPORTING_DATE, 85);
            Misc.setColumnSettings(completedSchedulesTable, idx_STATUS, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(completedSchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(completedSchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private class RefreshApprovedSchedulesThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshApprovedSchedulesLock.tryAcquire())
            {
                try
                {
                    approvedSchedulesWorker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    approvedSchedulesData = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    approvedSchedulesWorker = new TableSwingWorker(getFormComponent(), approvedSchedulesData, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    approvedSchedulesWorker.execute();
                }
                finally
                {
                    if (approvedSchedulesWorker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingApprovedLabel.setText("ERROR");
                            }
                        });
                        refreshApprovedSchedulesLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (approvedSchedulesTable != null)
                    {
                        approvedRowCount = approvedSchedulesTable.getRowCount();
                        approvedScrollPosition = approvedSchedulesPane.getVerticalScrollBar().getValue();
                        approvedSortKeys = approvedSchedulesTable.getRowSorter().getSortKeys();
                        approvedSelectedRow = approvedSchedulesTable.getSelectedRow();
                        if (approvedSelectedRow >= 0)
                        {
                            approvedSelectedMu = approvedSchedulesTable.getValueAt(approvedSelectedRow, idx_MU).toString();
                            approvedSelectedDate = approvedSchedulesTable.getValueAt(approvedSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    approvedSchedulesPane.setViewportView(loadingApprovedLabel);
                    display30Days.setEnabled(false);
                    display1year.setEnabled(false);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status",    // idx_STATUS
                "",          // idx_TOTALVIEWID
                "",          // idx_UNION_FLAG
                "F",         // idx_FUTURE_LOAD
                ""           // idx_IMPORT_LOCKED
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            String scheduleStatus;
            int days = 30;
            if (!displayGroup.getSelection().equals(display30Days.getModel()))
            {
                days = 365;
            }
            if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
            {
                scheduleStatus = "Completed";
            }
            else
            {
                scheduleStatus = "Approved";
            }
            return Oracle.getResultsSchedules(getFormComponent(), feeder, site, days, scheduleStatus);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String futureFlag = "";
                if (Misc.oracleToBoolean(rs.getInt("FUTURE_LOAD")))
                {
                    futureFlag = "●";
                }
                data = new Object[]
                {
                    rs.getString("MU"),             // idx_MU
                    rs.getDate("REPORTING_DATE"),   // idx_REPORTING_DATE
                    rs.getString("STATUS"),         // idx_STATUS
                    rs.getString("TOTALVIEWID"),    // idx_TOTALVIEWID
                    rs.getString("UNION_FLAG"),     // idx_UNION_FLAG
                    futureFlag,                     // idx_FUTURE_LOAD
                    rs.getString("IMPORT_LOCKED")   // idx_IMPORT_LOCKED
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Approved Schedules data.");
                approvedSchedulesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                if (approvedSelectedRow >= 0 && approvedSelectedMu != null && approvedSelectedDate != null && approvedSelectedRow <= approvedSchedulesTable.getRowCount() - 1)
                {
                    if (approvedSchedulesTable.getValueAt(approvedSelectedRow, idx_MU).equals(approvedSelectedMu) &&
                        approvedSchedulesTable.getValueAt(approvedSelectedRow, idx_REPORTING_DATE).toString().equals(approvedSelectedDate))
                    {
                        approvedSchedulesTable.changeSelection(approvedSelectedRow, 0, false, false);
                    }
                }
                approvedSchedulesPane.setViewportView(approvedSchedulesTable);
                revalidate();
                int position = approvedScrollPosition + (approvedSchedulesTable.getRowCount() - approvedRowCount) * 16;
                if (approvedScrollPosition != 0 && position > 0)
                {
                    approvedSchedulesPane.getVerticalScrollBar().setValue(position);
                }

                display30Days.setEnabled(true);
                display1year.setEnabled(true);
            }
            refreshApprovedSchedulesLock.release();
        }
        
        private void createTable()
        {
            approvedSchedulesTable = new JTable(approvedSchedulesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        case idx_TOTALVIEWID:
                        case idx_UNION_FLAG:
                        case idx_FUTURE_LOAD:
                        case idx_IMPORT_LOCKED:
                        default:
                            return String.class;
                    }
                }
                
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row))
                    {
                        if (approvedSchedulesTable.getValueAt(row, idx_IMPORT_LOCKED) != null)
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
            };
        }
        
        private void configureTable()
        {
            approvedSchedulesTable.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        new Thread(new OpenScheduleThread(approvedSchedulesTable)).start();
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            
            Misc.configureTable(approvedSchedulesTable, true, false, false);
            if (approvedSortKeys != null)
            {
                approvedSchedulesTable.getRowSorter().setSortKeys(approvedSortKeys);
            }
            Misc.setHeaderRenderer(approvedSchedulesTable, true, true, null);
            Misc.setColumnSettings(approvedSchedulesTable, idx_MU, 50);
            Misc.setColumnSettings(approvedSchedulesTable, idx_REPORTING_DATE, 85);
            Misc.setColumnSettings(approvedSchedulesTable, idx_STATUS, 0, false);
            Misc.setColumnSettings(approvedSchedulesTable, idx_TOTALVIEWID, 0, false);
            Misc.setColumnSettings(approvedSchedulesTable, idx_UNION_FLAG, 0, false);
            Misc.setColumnSettings(approvedSchedulesTable, idx_FUTURE_LOAD, 20);
            Misc.setColumnSettings(approvedSchedulesTable, idx_IMPORT_LOCKED, 0);
        }
    }
    
    private void createSchedulePopup(MouseEvent e)
    {
        final JTable table = (JTable) e.getComponent();
        final int row = table.rowAtPoint(e.getPoint());
        if (row >= 0 && row < table.getRowCount())
        {
            table.setRowSelectionInterval(row, row);
        }
        else
        {
            table.clearSelection();
        }
        
        int rowindex = table.getSelectedRow();
        if (rowindex < 0)
        {
            return;
        }
        if (e.isPopupTrigger() && e.getComponent() instanceof JTable)
        {
            JPopupMenu popup = new JPopupMenu();
            JMenuItem openScheduleOption = new JMenuItem("Open Schedule");
            JMenuItem importUpdatesOption = new JMenuItem("Re-Import Schedule");
            JMenuItem lockImportingOption = new JMenuItem("Toggle Importing Lock");
            JMenuItem viewHistoryOption = new JMenuItem("Schedule Import History");
            JMenuItem deleteScheduleOption = new JMenuItem("Delete Schedule");
            openScheduleOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    new Thread(new OpenScheduleThread(table)).start();
                }
            });
            importUpdatesOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    final String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    if (Misc.isAlpha(mu.substring(0, 1)))
                    {
                        Misc.msgbox(getFormComponent(), "Cannot re-import NON-TV schedules", "Re-Importing Schedule", 1, 1, 1);
                        return;
                    }
                    boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
                    if (okToImport)
                    {
                        RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                        okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
                    }
                    if (!okToImport)
                    {
                        return;
                    }
                    if (updatingMuRoster)
                    {
                        setCursor(Constants.NORMAL);
                        Misc.msgbox(getFormComponent(), "Cannot re-import while MU Roster is being updated.", "Import Schedules", 1, 1, 1);
                        return;
                    }
                    String importType = "UPDATE";
                    
                    final Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String lockedBy = Oracle.getScheduleLockedBy(getFormComponent(), feeder, site, mu, reportingDate);
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate);
                    if (scheduleStatus.equals("In Use"))
                    {
                        Misc.msgbox(getFormComponent(), "Schedule has some or all records locked by another user - You cannot import.", "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (scheduleStatus.equals("Load Failed"))
                    {
                        Misc.msgbox(getFormComponent(), "Last import attempt failed - You cannot import. Email TVI Support: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (Arrays.asList("Requesting", "Loading").contains(scheduleStatus))
                    {
                        Misc.msgbox(getFormComponent(), "Currently processing an import request - You cannot import. If this status persists email: " + Constants.EMAIL, "Import Schedules", 1, 1, 1);
                        return;
                    }
                    else if (lockedBy != null)
                    {
                        Misc.msgbox(getFormComponent(), "Schedule is LOCKED by: " + lockedBy + " - You cannot import.", "Import Schedules", 1, 1, 1);
                        return;
                    }
                    
                    refreshData();
                    setCursor(Constants.HOURGLASS);
                    Oracle.requestSchedule(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, importType, UserData.getUUID());
                    setCursor(Constants.NORMAL);
                }
            });
            lockImportingOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    final String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    final Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String lockedBy = "";
                    if (Misc.objectToString(table.getValueAt(row, idx_IMPORT_LOCKED)).equals(""))
                    {
                        lockedBy = UserData.getUUID();
                    }
                    setCursor(Constants.HOURGLASS);
                    Oracle.updateScheduleImportLock(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, lockedBy);
                    setCursor(Constants.NORMAL);
                    refreshData();
                }
            });
            viewHistoryOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    String mu = Misc.objectToString(table.getValueAt(rowindex, idx_MU));
                    Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    ScheduleImportHistory.getInstance(getFormComponent(), feeder, site, mu, reportingDate, reportingDate);
                }
            });
            deleteScheduleOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    if (!UserData.getUserType().equals("POWER"))
                    {
                        return;
                    }
                    
                    String mu = Misc.objectToString(table.getValueAt(row, idx_MU));
                    Date reportingDate = new Date(((Date)table.getValueAt(row, idx_REPORTING_DATE)).getTime());
                    String scheduleStatus = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate);
                    switch (scheduleStatus)
                    {
                        case "Sent Waiting Results":
                            Misc.msgbox(getFormComponent(), "Schedule is Sent Waiting Results - You cannot delete.", "Delete Schedule", 1, 1, 1);
                            return;
                        case "Requesting":
                        case "Loading":
                            Misc.msgbox(getFormComponent(), "Currently processing an import request - You cannot delete.", "Delete Schedule", 1, 1, 1);
                            return;
                    }
                    
                    if (!Misc.msgbox(getFormComponent(), "Are you sure you want to delete?", "Delete Schedule", 1, 2, 1))
                    {
                        return;
                    }
                    
                    setCursor(Constants.HOURGLASS);
                    Oracle.deleteSchedule(getFormComponent(), feeder, site, mu, reportingDate);
                    refreshData();
                    setCursor(Constants.NORMAL);
                }
            });
            popup.add(openScheduleOption);
            popup.add(importUpdatesOption);
            popup.add(lockImportingOption);
            popup.add(viewHistoryOption);
            if (UserData.getUserType().equals("POWER"))
            {
                popup.add(deleteScheduleOption);
            }
            popup.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    
    private void setControlsEnabled(boolean enabled)
    {
        workingScheduleOpenButton.setEnabled(enabled);
        completedScheduleOpenButton.setEnabled(enabled);
        approvedScheduleOpenButton.setEnabled(enabled);
    }
    
    private void closeForm()
    {
        // stop the refresh timers if they haven't been already
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                if (paycloseTimer.isRunning())
                {
                    paycloseTimer.stop();
                }
                if (workingTimer.isRunning())
                {
                    workingTimer.stop();
                }
                if (completedTimer.isRunning())
                {
                    completedTimer.stop();
                }
                if (approvedTimer.isRunning())
                {
                    approvedTimer.stop();
                }
                if (RegionData.getNewFeature())
                {
                    if (muRosterTimer.isRunning())
                    {
                        muRosterTimer.stop();
                    }
                }
            }
        });
        
        // if the refresh schedules threads are currently working
        if (refreshingPayClose)
        {
            // flag the threads to close & return
            disableRefreshing = true;
            refreshButton.setEnabled(false);
            return;
        }
        
        if (workingSchedulesWorker != null)
        {
            workingSchedulesWorker.cancel(true);
        }
        if (completedSchedulesWorker != null)
        {
            completedSchedulesWorker.cancel(true);
        }
        if (approvedSchedulesWorker != null)
        {
            approvedSchedulesWorker.cancel(true);
        }
        
        // close the form
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private class RefreshPayCloseThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshPayCloseLock.tryAcquire())
            {
                try
                {
                    refreshingPayClose = true;
                    RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                    
                    // refresh payroll period end date label
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            payrollPeriodLabel.setText("Current Payroll Period Ends: " + Misc.dateToStringMDY(RegionData.getPayClose()));
                        }
                    });
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    // Set approve changes reminder
                    Date payEndDate = RegionData.getPayClose();
                    Date payStartDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), payEndDate);
                    boolean approveChanges = !Oracle.checkAllChangesApproved(getFormComponent(), feeder, site, payStartDate, payEndDate);
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            if (approveChanges)
                            {
                                approveChangesButton.setBackground(Color.RED);
                            }
                            else
                            {
                                approveChangesButton.setBackground(Constants.GREEN);
                            }
                        }
                    });
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    String siteLock = RegionData.getSiteLock();
                    if (siteLock != null && !siteLock.isEmpty())
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                switch (siteLock)
                                {
                                    case "PAY PERIOD":
                                        messageArea.setText("Site is locked, you must begin new payroll period.");
                                        break;
                                    case "COMPUTE 40":
                                        messageArea.setText("Site is temporarily locked by Compute 40 Hr check, call TVI Support if you have any questions.");
                                        break;
                                    case "COMPUTE FUTURE":
                                        messageArea.setText("Site is temporarily locked by Compute future exceptions, call TVI Support if you have any questions.");
                                        break;
                                    default:
                                        messageArea.setText("Site is currently locked, email TVI Support at " + Constants.EMAIL + " if you have any questions.");
                                        break;
                                }
                                messageArea.setVisible(true);
                            }
                        });
                    }
                    else if (todaysDate.compareTo(RegionData.getHotDay()) == 0)
                    {
                        // Set update future schedules reminder
                        boolean futureSchedulesNeedApproval = !Oracle.checkFutureSchedulesUpdated(getFormComponent(), feeder, site, payStartDate, payEndDate);
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                if (futureSchedulesNeedApproval)
                                {
                                    messageArea.setText("Reminder: Future schedules - Import updates for future schedules before payroll close.");
                                    messageArea.setVisible(true);
                                }
                                else
                                {
                                    messageArea.setVisible(false);
                                }
                            }
                        });
                    }
                    else
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                messageArea.setVisible(false);
                            }
                        });
                    }
                    
                    if (disableRefreshing)
                    {
                        return;
                    }
                    
                    // MEX Payroll Close Calculations
                    if (feeder.equals("MEX") && todaysDate.compareTo(payEndDate) >= 0) // today is >= pay close
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                payrollCloseCalculationsButton.setEnabled(true);
                            }
                        });
                    }
                    
                    // POL Payroll Close Calculations
                    if (feeder.equals("POL"))
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                payrollCloseCalculationsButton.setEnabled(true);
                            }
                        });
                    }
                    // CZE Payroll Close Calculations
                    if (feeder.equals("CZE"))
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                payrollCloseCalculationsButton.setEnabled(true);
                            }
                        });
                    }
                }
                finally
                {
                    refreshingPayClose = false;
                    refreshPayCloseLock.release();
                    if (disableRefreshing)
                    {
                        closeForm();
                    }
                }
            }
        }
    }
    
    private class UpdateFMLAThread implements Runnable
    {
        @Override
        @SuppressFBWarnings(value="RV_DONT_JUST_NULL_CHECK_READLINE", justification="We don't use the value returned from readLine() when counting lines.")
        public void run()
        {
            String filename = null;
            String[] values;
            //String MU;
            String empid;
            String status;
            String FMLAType;
            Double llHours;
            Double iexHours;
            Date reportingDate;
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.HOURGLASS);
                        setControlsEnabled(false);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showOpenDialog(getFormComponent());
            if (returnVal == JFileChooser.APPROVE_OPTION)
            {
                try
                {
                    // get the number of lines in the file
                    int lineCount = 0;
                    File FMLAFile = fc.getSelectedFile();
                    filename = FMLAFile.getName();
                    BufferedReader file = new BufferedReader(new FileReader(FMLAFile.getAbsolutePath()));
                    try
                    {
                        while (file.readLine() != null)
                        {
                            lineCount++;
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                    final int maxProgress = lineCount;
                    
                    // display the progress monitor
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            progressMonitor = new ProgressMonitor(getFormComponent(), "Uploading FMLA Approvals", null, 0, maxProgress);
                            progressMonitor.setProgress(0);
                        }
                    });
                    
                    // read the file, update each employee and increment the progress bar
                    file = new BufferedReader(new FileReader(FMLAFile.getAbsolutePath()));
                    try
                    {
                        String line;
                        int currentLine = 0;
                        proceed = true;
                        cancel = false;

                        // delete all records first
                        Oracle.deleteGTT_UPLOADED_FMLA_APPROVALSRecs(getFormComponent());

                        // check header line formatting
                        Integer headerType = -1;
                        String header = file.readLine();
                        if (header == null)
                        {
                            proceed = false;
                            Misc.msgbox(getFormComponent(), "Failed to read file; file is empty.", "", 1, 1, 1);
                        }
                        else
                        {
                            String[] headers = header.split("\t");
                            if (headers.length > 2)
                            {
                                switch (headers[0].replace(" ", ""))
                                {
                                    case "Manager":
                                        headerType = 1;
                                        break;
                                    case "cc":
                                        headerType = 2;
                                        break;
                                    default:
                                        proceed = false;
                                        Misc.msgbox(getFormComponent(), "Column header line missing in file, process terminated.", "FMLA Updates", 1, 1, 1);
                                        break;
                                }
                            }
                            else
                            {
                                proceed = false;
                                Misc.msgbox(getFormComponent(), "Column header line missing in file, process terminated.", "FMLA Updates", 1, 1, 1);
                            }

                            // loop to insert records
                            while ((line = file.readLine()) != null && proceed && !cancel)
                            {
                                currentLine++;
                                final int currentProgress = currentLine;
                                SwingUtilities.invokeLater(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        if (progressMonitor.isCanceled())
                                        {
                                            progressMonitor.close();
                                            cancel = true;
                                        }
                                        else
                                        {
                                            progressMonitor.setProgress(currentProgress);
                                        }
                                    }
                                });

                                // PROCESS THE LINE
                                if (line.contains("\t") && !line.replace("\t", "").equals(""))
                                {
                                    values = line.split("\t", -1);
                                    switch (headerType)
                                    {
                                        case 1:
                                            //MU = values[4];
                                            empid = values[3].toUpperCase(Locale.ENGLISH).replace(" ", "");
                                            status = values[12].replace(" ", "");
                                            FMLAType = null;
                                            llHours = Misc.minutesToHours(Misc.objectToInt(values[8].replace(" ", "")), true).doubleValue();
                                            iexHours = 0.0;
                                            reportingDate = Misc.stringToDateMDY(getFormComponent(), values[5].replace(" ", ""), true);
                                            break;
                                        case 2:
                                            //MU = values[1];
                                            empid = values[2].toUpperCase(Locale.ENGLISH).replace(" ", "");
                                            status = values[4].replace(" ", "");
                                            FMLAType = values[6].replace(" ", "");
                                            llHours = Misc.objectToDouble(values[7].replace(" ", ""));
                                            iexHours = Misc.objectToDouble(values[8].replace(" ", ""));
                                            reportingDate = Misc.stringToDateMDY(getFormComponent(), values[9].replace(" ", ""), true);
                                            break;
                                        default:
                                            progressMonitor.close();
                                            Misc.msgbox(getFormComponent(), "Unexpected formatting error, process terminated.", "FMLA Updates", 1, 1, 1);
                                            return;
                                    }
                                    
                                    String message = "";
                                    if (reportingDate == null)
                                    {
                                        proceed = false;
                                        message = "Invalid date format.";
                                    }
                                    else if (empid.length() != 6)
                                    {
                                        proceed = false;
                                        message = "Invalid Empid.";
                                    }
                                    
                                    if ((proceed))
                                    {
                                        if ((headerType == 2 && status.equals("Approved")) || (headerType == 1 && status.length() < 1))
                                        {
                                            Oracle.insertFMLAApprovals(getFormComponent(), empid, reportingDate, FMLAType, llHours, iexHours);
                                        }
                                    }
                                    else
                                    {
                                        proceed = Misc.msgbox(getFormComponent(), "<html><font color = \"red\">Error on line " + currentLine + ".<br>Empid: " + empid + "</font><br><br><font color = \"blue\">" + message + "</font><br><br>This record will not be processed.<br>Click OK to continue, or Cancel to stop.", "FMLA Updates", 2, 2, 1);
                                    }
                                    if (!proceed)
                                    {
                                        progressMonitor.close();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                }
                catch (IOException ex)
                {
                    proceed = false;
                    Misc.errorMsgDefault(getFormComponent(), ex, "Failed to read FMLA file.");
                }
                
                if (proceed && !cancel)
                {
                    Oracle.updateFMLA(getFormComponent(), UserData.getUUID());
                    progressMonitor.close();
                    
                    PdfReports.createFMLAUpdatesReport(getFormComponent(), filename, "FMLA Updates Report.pdf", true);
                }
            }
            
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.NORMAL);
                        setControlsEnabled(true);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
        }
    }
    
    private class RefreshMURosterThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshMURosterLock.tryAcquire())
            {
                try
                {
                    if (updatingMuRoster)
                    {
                        numberOfRosterRequesting = Oracle.getNumMURosterRequesting(getFormComponent(), feeder, site);
                        if (numberOfRosterRequesting == 0)
                        {
                            Misc.msgbox(getFormComponent(), "MU Roster successfully updated", "MU Roster Update", 1, 1, 1);
                            updatingMuRoster = false;
                            updateMURosterButton.setText("<html><div align='center' width='100%'>Update<br>MU Roster</div></html>");
                            updateMURosterButton.setEnabled(true);
                        }
                    }
                }
                finally
                {
                    rosterUpdatedLabel.setText("MU Roster Updated:  " + Oracle.getRosterTimeStamp(getFormComponent(), feeder, site));
                    refreshMURosterLock.release();
                }
            }
        }
    }
        
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EmpRosterMaintenanceButton;
    private javax.swing.JButton LOAButton;
    private javax.swing.JButton actualVsSchedButton;
    private javax.swing.JButton addRecordsButton;
    private javax.swing.JButton approvalReportsButton;
    private javax.swing.JButton approveChangesButton;
    private javax.swing.JPanel approvedColumnPanel;
    private javax.swing.JButton approvedScheduleOpenButton;
    private javax.swing.JLabel approvedSchedulesLabel;
    private javax.swing.JScrollPane approvedSchedulesPane;
    private javax.swing.JButton commentMaintenanceButton;
    private javax.swing.JPanel completedColumnPanel;
    private javax.swing.JButton completedScheduleOpenButton;
    private javax.swing.JLabel completedSchedulesLabel;
    private javax.swing.JScrollPane completedSchedulesPane;
    private javax.swing.JRadioButton display1year;
    private javax.swing.JRadioButton display30Days;
    private javax.swing.ButtonGroup displayGroup;
    private javax.swing.JPanel elinkOperationsPanel;
    private javax.swing.JButton employeeDetailButton;
    private javax.swing.JButton employeeMaintenanceButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel futureScheduleFlagLabel;
    private javax.swing.JButton holdButton;
    private javax.swing.JButton importButton;
    private javax.swing.JPanel importColumnPane;
    private javax.swing.JButton importFutureSchedulesButton;
    private javax.swing.JButton importIEXUpdatesButton;
    private javax.swing.JButton importOptionsButton;
    private javax.swing.JList<String> importSchedules;
    private javax.swing.JLabel importSchedulesLabel;
    private javax.swing.JScrollPane importSchedulesPane;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel loadingApprovedLabel;
    private javax.swing.JLabel loadingCompletedLabel;
    private javax.swing.JLabel loadingWorkingLabel;
    private javax.swing.JLabel lookupByEmployeeLabel;
    private javax.swing.JPanel menuPane;
    private javax.swing.JTextField messageArea;
    private javax.swing.JButton muRosterMaintenanceButton;
    private javax.swing.JLabel officeLabel;
    private javax.swing.JLabel otherLabel;
    private javax.swing.JLabel payCycleLabel;
    private javax.swing.JButton payrollCloseCalculationsButton;
    private javax.swing.JLabel payrollEndingLabel;
    private javax.swing.JButton payrollGenerationButton;
    private javax.swing.JButton payrollPeriodApprovalButton;
    private javax.swing.JLabel payrollPeriodLabel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JButton previousPayrollCorrectionsButton;
    private javax.swing.JButton priorApprovalButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton releaseButton;
    private javax.swing.JButton reviewUpdatesButton;
    private javax.swing.JLabel rosterUpdatedLabel;
    private javax.swing.JPanel scheduleColumnsPanel;
    private javax.swing.JButton scheduleImportsCheckButton;
    private javax.swing.JPanel schedulePanel;
    private javax.swing.JButton separatedEmployeesMEXButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel testDBLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JButton updateMURosterButton;
    private javax.swing.JButton uploadFMLAButton;
    private javax.swing.JLabel weeklyFunctionsLabel;
    private javax.swing.JButton weeklyHoursCheckButton;
    private javax.swing.JPanel workingColumnPanel;
    private javax.swing.JButton workingScheduleOpenButton;
    private javax.swing.JPanel workingSchedulesControlPanel;
    private javax.swing.JLabel workingSchedulesLabel;
    private javax.swing.JScrollPane workingSchedulesPane;
    private javax.swing.JPanel workingSchedulesTitlePanel;
    // End of variables declaration//GEN-END:variables
}
