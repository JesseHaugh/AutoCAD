/**
 * This form can be opened in several different ways.
 *   These are determined by the string editType, which can be the following values:
 *     NORMAL           - Displays all employees by feeder & site
 *     DETAIL           - Displays a detailed view on a single employee, set by passing a non-null attid value in the constructor
 */

package tvi.gui;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.objects.HoursEditor;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class EmployeeMaintenance extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile EmployeeMaintenance instance;
    
    private final String feeder;
    private final String site;
    String attid;
    private final Date curDate;
    String editType;
    
    JTable table;
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    boolean formClosing = false;
    boolean changingEmployees = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    boolean employeeUpdated = false;
    int currentRow = -1;
    int employeeCount = 0;
    
    boolean filterEnabled = true;
    int filterColumn = -1;
    String employeeStatusFilterText = "^ACTIVE$";
    boolean filterCoachDiscrepancies = false;
    TableRowSorter<CustomTableModel> sorter;
    
    JComboBox<String> bandCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> currentStatusCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> pendingStatusCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> currentDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> ncsDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> pendingDateCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    
    final static int idx_PARTTIME_FLAG          = 0;
    final static int idx_BILINGUAL_FLAG         = 1;
    final static int idx_HOURS_PER_WEEK         = 2;
    final static int idx_FEEDER                 = 3;
    final static int idx_SITE                   = 4;
    final static int idx_BAND                   = 5;
    final static int idx_MU                     = 6;
    final static int idx_AGENTID                = 7;
    final static int idx_EMPID                  = 8;
    final static int idx_OTHER_PAYROLL_ID       = 9;
    final static int idx_EMPLOYEE               = 10;
    final static int idx_COACH                  = 11;
    final static int idx_WEBPHONE_SUPERVISOR    = 12;
    final static int idx_COACHES_MATCH          = 13;
    final static int idx_NCS_DATE               = 14;
    final static int idx_CHILD_BIRTH_DATE       = 15;
    final static int idx_EXTRA_OFF_DAYS         = 16;
    final static int idx_CURRENT_STATUS         = 17;
    final static int idx_CURRENT_EFFECTIVE_DATE = 18;
    final static int idx_STOP_PAYROLL_REPORTING = 19;
    final static int idx_STOP_PAYROLL_CHGD_BY   = 20;
    final static int idx_STOP_PAYROLL_CHGD_DATE = 21;
    final static int idx_FOUR_DAY               = 22;
    final static int idx_SIX_DAY                = 23;
    final static int idx_BEGIN_DATE             = 24;
    final static int idx_LAST_DATE              = 25;
    final static int idx_PENDING_STATUS         = 26;
    final static int idx_PENDING_EFFECTIVE_DATE = 27;
    final static int idx_SHIFT                  = 28;
    final static int idx_ACTIVE_ON              = 29;
    
    public synchronized static EmployeeMaintenance getInstance(Component parentFrame, String feeder, String site, String attid)
    {
        if (instance != null)
        {
            if (Misc.objectEquals(instance.attid, attid))
            {
                instance.toFront();
            }
            else
            {
                instance.closeForm();
            }
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new EmployeeMaintenance(feeder, site, attid);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private EmployeeMaintenance(String feeder, String site, String attid)
    {
        this.feeder = feeder;
        this.site = site;
        this.attid = attid;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        if (attid != null)
        {
            editType = "DETAIL";
            employeeHistoryButton.setText("View All Employees");
            filterEmployeeStatusComboBox.setSelectedIndex(0);
        }
        else
        {
            editType = "NORMAL";
            employeeHistoryButton.setText("Employee History");
            filterEmployeeStatusComboBox.setSelectedIndex(1);
        }
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        subtitleLabel2.setText("Employees marked in gray are active on another site. To modify them, email TVI Support at " + Constants.EMAIL + ".");
        
        powerUserOverrideCheckBox.setVisible(UserData.getUserType().equals("POWER"));
        deleteRecordButton.setVisible(false);
        updatePayrollIDsButton.setVisible(Arrays.asList("MEX", "POL", "SVK").contains(feeder));
        separatedEmployeesButton.setVisible(feeder.equals("MEX"));
        LOAEmployeesButton.setVisible(feeder.equals("MEX"));
        
        updateCoachButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        updateAllCoachesButton.setEnabled(!UserData.getUserAccessLevel().equals("READONLY"));
        
        bandCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "MGRA", "MGRB", "PROA4", "PROA5", "PROB"}));
        bandCombo.setEditable(true);
        currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE", "SEPARATED"}));
        currentStatusCombo.addItemListener(new ItemListener()
        {
            Object previousSelection = null;
            
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1)
                {
                    if (e.getStateChange() == ItemEvent.DESELECTED)
                    {
                        previousSelection = e.getItem();
                    }
                    else if (currentStatusCombo.getSelectedItem().equals("SEPARATED"))
                    {
                        if (!UserData.getUserType().equals("POWER"))
                        {
                            //revert and give message
                            JComboBox combobox = (JComboBox)e.getSource();
                            combobox.setSelectedItem(previousSelection);
                            Misc.msgbox(getFormComponent(), "SEPARATED status is reserved for employees that are no longer in webphone.\nIf you wish to stop reporting for this employee, make them INACTIVE instead.", "Employee Status", 1, 1, 1);
                        }
                    }
                    else if (currentStatusCombo.getSelectedItem().equals("ACTIVE"))
                    {
                        if (!verifyCurrentStatus())
                        {
                            //revert and give message
                            JComboBox combobox = (JComboBox)e.getSource();
                            combobox.setSelectedItem(previousSelection);
                            Misc.msgbox(getFormComponent(), "This employee is already active elsewhere.\nCheck the Employee History to see more information.\nIf you have any questions email TVI support at " + Constants.EMAIL, "Employee Status", 1, 1, 1);
                        }
                        else if (table.getValueAt(selectedRow, idx_CURRENT_STATUS).equals("SEPARATED"))
                        {
                            Misc.msgbox(getFormComponent(), "This employee was made separated because they were no longer in webphone.\nIf this is still the case they will be made separated again overnight.", "Employee Status", 1, 1, 1);
                        }
                    }
                }
            }
        });
        
        pendingStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "ACTIVE", "INACTIVE"}));
        
        filterTextField.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override public void insertUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void removeUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void changedUpdate(DocumentEvent e) { processFilter(); }
        });
        
        curDate = Misc.dateNoTime(Oracle.getCurTimeLocal(getFormComponent()));
        Calendar cal = Calendar.getInstance();
        cal.setTime(curDate);
        
        currentDateCombo.removeAllItems();
        currentDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        for (int i = 0; i < 30; i++)
        {
            cal.add(Calendar.DAY_OF_YEAR, -1);
            currentDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        }
        currentDateCombo.setEditable(true);
        
        pendingDateCombo.removeAllItems();
        cal.setTime(Misc.dateAddDays(curDate, -5));
        for (int i = 0; i < 35; i++)
        {
            cal.add(Calendar.DAY_OF_YEAR, 1);
            pendingDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        }
        pendingDateCombo.setEditable(true);
        
        ncsDateCombo.removeAllItems();
        cal.setTime(curDate);
        ncsDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        for (int i = 0; i < 30; i++)
        {
            cal.add(Calendar.DAY_OF_YEAR, -1);
            ncsDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
        }
        ncsDateCombo.setEditable(true);
        
        if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
        {
            filterColumnComboBox.addItem("PAYROLL ID");
            //minor fix to display, sets loading scroll pane to correct width for INT feeders (extra 100 for Payroll ID column)
            Dimension dim = employeesScrollPane.getMaximumSize();
            employeesScrollPane.setMaximumSize(new Dimension(dim.width + 100, dim.height));
        }
    }
    
    public String getATTID()
    {
        return attid;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        deleteRecordButton = new javax.swing.JButton();
        powerUserOverrideCheckBox = new javax.swing.JCheckBox();
        exitButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        subtitleLabel1 = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        employeesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        gridPanel = new javax.swing.JPanel();
        filterLabelsPanel = new javax.swing.JPanel();
        filterColumnTextLabel = new javax.swing.JLabel();
        filterTextLabel = new javax.swing.JLabel();
        filterEmployeeStatusLabel = new javax.swing.JLabel();
        filterEmployeeCoachLabel = new javax.swing.JLabel();
        filterClearLabel = new javax.swing.JLabel();
        filtersPanel = new javax.swing.JPanel();
        filterColumnComboBox = new javax.swing.JComboBox<>();
        filterTextField = new javax.swing.JTextField();
        filterEmployeeStatusComboBox = new javax.swing.JComboBox<>();
        filterEmployeeCoachComboBox = new javax.swing.JComboBox<>();
        filterClearButton = new javax.swing.JButton();
        multiSelectPanel = new javax.swing.JPanel();
        fillerClearLabel2 = new javax.swing.JLabel();
        highlightPanel = new javax.swing.JPanel();
        multiSelectLabel = new javax.swing.JLabel();
        helpButton = new javax.swing.JButton();
        controlPanel = new javax.swing.JPanel();
        normalPanel = new javax.swing.JPanel();
        updateAllCoachesButton = new javax.swing.JButton();
        highlightPanel2 = new javax.swing.JPanel();
        updateCoachButton = new javax.swing.JButton();
        updateStatusButton = new javax.swing.JButton();
        clearPendingButton = new javax.swing.JButton();
        transferEmployeesButton = new javax.swing.JButton();
        controlPanel2 = new javax.swing.JPanel();
        printButton = new javax.swing.JButton();
        updatePayrollIDsButton = new javax.swing.JButton();
        separatedEmployeesButton = new javax.swing.JButton();
        LOAEmployeesButton = new javax.swing.JButton();
        employeeHistoryButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Employee Maintenance");
        setBackground(new java.awt.Color(255, 204, 153));
        setMinimumSize(new java.awt.Dimension(850, 610));
        setPreferredSize(new java.awt.Dimension(850, 480));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(255, 204, 153));
        topPanel.setMinimumSize(new java.awt.Dimension(850, 90));
        topPanel.setPreferredSize(new java.awt.Dimension(850, 90));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(255, 204, 153));
        titlePanel.setMinimumSize(new java.awt.Dimension(850, 90));
        titlePanel.setName(""); // NOI18N
        titlePanel.setPreferredSize(new java.awt.Dimension(850, 90));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(255, 204, 153));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        deleteRecordButton.setBackground(new java.awt.Color(255, 204, 153));
        deleteRecordButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        deleteRecordButton.setText("Delete Record");
        deleteRecordButton.setMaximumSize(new java.awt.Dimension(80, 25));
        deleteRecordButton.setMinimumSize(new java.awt.Dimension(80, 25));
        deleteRecordButton.setPreferredSize(new java.awt.Dimension(120, 30));
        deleteRecordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRecordButtonActionPerformed(evt);
            }
        });
        titlePanel.add(deleteRecordButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, -1, -1));

        powerUserOverrideCheckBox.setBackground(new java.awt.Color(255, 204, 153));
        powerUserOverrideCheckBox.setText("Power User Override");
        powerUserOverrideCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                powerUserOverrideCheckBoxActionPerformed(evt);
            }
        });
        titlePanel.add(powerUserOverrideCheckBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, -1, -1));

        exitButton.setBackground(new java.awt.Color(255, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(100, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, -1, -1));

        refreshButton.setBackground(new java.awt.Color(255, 204, 153));
        refreshButton.setText("Refresh Screen");
        refreshButton.setMargin(new java.awt.Insets(2, 5, 2, 5));
        refreshButton.setPreferredSize(new java.awt.Dimension(100, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        titlePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 40, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Employee Maintenance");
        titleLabel.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 850, -1));

        subtitleLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel1.setText("Double-click fields to edit.");
        subtitleLabel1.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 850, 20));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("Employees marked in grey are active on another site. To modify them, email TVI Support at [EMAIL].");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 850, 20));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(255, 204, 153));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        employeesScrollPane.setAlignmentY(0.0F);
        employeesScrollPane.setMaximumSize(new java.awt.Dimension(590, 460));
        employeesScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        employeesScrollPane.setPreferredSize(new java.awt.Dimension(590, 200));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        employeesScrollPane.setViewportView(loadingLabel);

        centerPanel.add(employeesScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(255, 204, 153));
        bottomPanel.setMinimumSize(new java.awt.Dimension(850, 200));
        bottomPanel.setPreferredSize(new java.awt.Dimension(850, 220));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        gridPanel.setBackground(new java.awt.Color(255, 204, 153));
        gridPanel.setPreferredSize(new java.awt.Dimension(850, 200));
        gridPanel.setLayout(new java.awt.GridLayout(5, 0));

        filterLabelsPanel.setBackground(new java.awt.Color(255, 204, 153));
        filterLabelsPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filterLabelsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        filterColumnTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterColumnTextLabel.setText("Column to search:");
        filterColumnTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterColumnTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterColumnTextLabel);

        filterTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterTextLabel.setText("Filter by text:");
        filterTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterTextLabel);

        filterEmployeeStatusLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeStatusLabel.setText("Employee Status:");
        filterEmployeeStatusLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeStatusLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeStatusLabel);

        filterEmployeeCoachLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeCoachLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeCoachLabel.setText("Employee Coach:");
        filterEmployeeCoachLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeCoachLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeCoachLabel);

        filterClearLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterClearLabel);

        gridPanel.add(filterLabelsPanel);

        filtersPanel.setBackground(new java.awt.Color(255, 204, 153));
        filtersPanel.setMinimumSize(new java.awt.Dimension(850, 30));
        filtersPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        filtersPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        filterColumnComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "FEEDER", "SITE", "MU", "AGENTID", "AT&T ID", "EMPLOYEE", "COACH", "SUPERVISOR", "CURRENT STATUS", "CURRENT EFF. DATE", "PAYROLL COMPLETED", "BEGIN DATE", "LAST DATE", "PENDING STATUS", "PENDING EFF. DATE", "PARTTIME", "SHIFT", "HOURS PER WEEK", "BILINGUAL" }));
        filterColumnComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterColumnComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterColumnComboBox);

        filterTextField.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextField.setMaximumSize(new java.awt.Dimension(150, 30));
        filterTextField.setMinimumSize(new java.awt.Dimension(150, 30));
        filterTextField.setPreferredSize(new java.awt.Dimension(150, 30));
        filtersPanel.add(filterTextField);

        filterEmployeeStatusComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show Active", "Show Inactive", "Show Separated" }));
        filterEmployeeStatusComboBox.setSelectedIndex(1);
        filterEmployeeStatusComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterEmployeeStatusComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterEmployeeStatusComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterEmployeeStatusComboBox);

        filterEmployeeCoachComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeCoachComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Show Discrepancies" }));
        filterEmployeeCoachComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterEmployeeCoachComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterEmployeeCoachComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterEmployeeCoachComboBox);

        filterClearButton.setBackground(new java.awt.Color(255, 204, 153));
        filterClearButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearButton.setText("Clear Filters");
        filterClearButton.setMaximumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setMinimumSize(new java.awt.Dimension(150, 30));
        filterClearButton.setPreferredSize(new java.awt.Dimension(150, 30));
        filterClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterClearButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(filterClearButton);

        gridPanel.add(filtersPanel);

        multiSelectPanel.setBackground(new java.awt.Color(255, 204, 153));
        multiSelectPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        multiSelectPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        multiSelectPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        fillerClearLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        fillerClearLabel2.setMaximumSize(new java.awt.Dimension(150, 30));
        fillerClearLabel2.setMinimumSize(new java.awt.Dimension(150, 30));
        fillerClearLabel2.setPreferredSize(new java.awt.Dimension(150, 30));
        multiSelectPanel.add(fillerClearLabel2);

        highlightPanel.setBackground(new java.awt.Color(150, 210, 170));
        highlightPanel.setPreferredSize(new java.awt.Dimension(640, 40));
        highlightPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        multiSelectLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        multiSelectLabel.setText("These controls support multiple selections.");
        multiSelectLabel.setMaximumSize(new java.awt.Dimension(220, 30));
        multiSelectLabel.setMinimumSize(new java.awt.Dimension(220, 30));
        multiSelectLabel.setPreferredSize(new java.awt.Dimension(270, 30));
        highlightPanel.add(multiSelectLabel);

        helpButton.setBackground(new java.awt.Color(150, 210, 170));
        helpButton.setText("Help");
        helpButton.setMaximumSize(new java.awt.Dimension(60, 25));
        helpButton.setMinimumSize(new java.awt.Dimension(60, 25));
        helpButton.setPreferredSize(new java.awt.Dimension(60, 25));
        helpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpButtonActionPerformed(evt);
            }
        });
        highlightPanel.add(helpButton);

        multiSelectPanel.add(highlightPanel);

        gridPanel.add(multiSelectPanel);

        controlPanel.setBackground(new java.awt.Color(255, 204, 153));
        controlPanel.setMinimumSize(new java.awt.Dimension(850, 40));
        controlPanel.setName(""); // NOI18N
        controlPanel.setPreferredSize(new java.awt.Dimension(850, 40));
        controlPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        normalPanel.setBackground(new java.awt.Color(255, 204, 153));
        normalPanel.setPreferredSize(new java.awt.Dimension(160, 35));
        normalPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        updateAllCoachesButton.setBackground(new java.awt.Color(255, 204, 153));
        updateAllCoachesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateAllCoachesButton.setText("Update All Coaches");
        updateAllCoachesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updateAllCoachesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAllCoachesButtonActionPerformed(evt);
            }
        });
        normalPanel.add(updateAllCoachesButton);

        controlPanel.add(normalPanel);

        highlightPanel2.setBackground(new java.awt.Color(150, 210, 170));
        highlightPanel2.setPreferredSize(new java.awt.Dimension(640, 35));
        highlightPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        updateCoachButton.setBackground(new java.awt.Color(150, 210, 170));
        updateCoachButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateCoachButton.setText("Update Coach");
        updateCoachButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updateCoachButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updateCoachButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updateCoachButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateCoachButtonActionPerformed(evt);
            }
        });
        highlightPanel2.add(updateCoachButton);

        updateStatusButton.setBackground(new java.awt.Color(150, 210, 170));
        updateStatusButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updateStatusButton.setText("Update Status");
        updateStatusButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updateStatusButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updateStatusButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updateStatusButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateStatusButtonActionPerformed(evt);
            }
        });
        highlightPanel2.add(updateStatusButton);

        clearPendingButton.setBackground(new java.awt.Color(150, 210, 170));
        clearPendingButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        clearPendingButton.setText("Clear Pending");
        clearPendingButton.setMaximumSize(new java.awt.Dimension(150, 30));
        clearPendingButton.setMinimumSize(new java.awt.Dimension(150, 30));
        clearPendingButton.setPreferredSize(new java.awt.Dimension(150, 30));
        clearPendingButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearPendingButtonActionPerformed(evt);
            }
        });
        highlightPanel2.add(clearPendingButton);

        transferEmployeesButton.setBackground(new java.awt.Color(150, 210, 170));
        transferEmployeesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        transferEmployeesButton.setText("Transfer Emps");
        transferEmployeesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        transferEmployeesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        transferEmployeesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        transferEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferEmployeesButtonActionPerformed(evt);
            }
        });
        highlightPanel2.add(transferEmployeesButton);

        controlPanel.add(highlightPanel2);

        gridPanel.add(controlPanel);

        controlPanel2.setBackground(new java.awt.Color(255, 204, 153));
        controlPanel2.setMinimumSize(new java.awt.Dimension(850, 40));
        controlPanel2.setPreferredSize(new java.awt.Dimension(850, 40));
        controlPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        printButton.setBackground(new java.awt.Color(255, 204, 153));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setMaximumSize(new java.awt.Dimension(150, 30));
        printButton.setMinimumSize(new java.awt.Dimension(150, 30));
        printButton.setPreferredSize(new java.awt.Dimension(150, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(printButton);

        updatePayrollIDsButton.setBackground(new java.awt.Color(255, 204, 153));
        updatePayrollIDsButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        updatePayrollIDsButton.setText("Update Payroll IDs");
        updatePayrollIDsButton.setMaximumSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.setMinimumSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.setPreferredSize(new java.awt.Dimension(150, 30));
        updatePayrollIDsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatePayrollIDsButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(updatePayrollIDsButton);

        separatedEmployeesButton.setBackground(new java.awt.Color(255, 204, 153));
        separatedEmployeesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        separatedEmployeesButton.setText("Separated Employees");
        separatedEmployeesButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        separatedEmployeesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        separatedEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                separatedEmployeesButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(separatedEmployeesButton);

        LOAEmployeesButton.setBackground(new java.awt.Color(255, 204, 153));
        LOAEmployeesButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        LOAEmployeesButton.setText("LOA Employees");
        LOAEmployeesButton.setMaximumSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.setMinimumSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.setPreferredSize(new java.awt.Dimension(150, 30));
        LOAEmployeesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LOAEmployeesButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(LOAEmployeesButton);

        employeeHistoryButton.setBackground(new java.awt.Color(255, 204, 153));
        employeeHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeHistoryButton.setText("Employee History");
        employeeHistoryButton.setMaximumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setMinimumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setPreferredSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeHistoryButtonActionPerformed(evt);
            }
        });
        controlPanel2.add(employeeHistoryButton);

        gridPanel.add(controlPanel2);

        bottomPanel.add(gridPanel);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
        
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
    
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void filterColumnComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterColumnComboBoxActionPerformed
        String selection = filterColumnComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "ALL":
                filterColumn = -1;
                break;
            case "FEEDER":
                filterColumn = idx_FEEDER;
                break;
            case "SITE":
                filterColumn = idx_SITE;
                break;
            case "MU":
                filterColumn = idx_MU;
                break;
            case "AGENTID":
                filterColumn = idx_AGENTID;
                break;
            case "AT&T ID":
                filterColumn = idx_EMPID;
                break;
            case "EMPLOYEE":
                filterColumn = idx_EMPLOYEE;
                break;
            case "COACH":
                filterColumn = idx_COACH;
                break;
            case "SUPERVISOR":
                filterColumn = idx_WEBPHONE_SUPERVISOR;
                break;
            case "CURRENT STATUS":
                filterColumn = idx_CURRENT_STATUS;
                break;
            case "CURRENT EFF. DATE":
                filterColumn = idx_CURRENT_EFFECTIVE_DATE;
                break;
            case "PAYROLL COMPLETED":
                filterColumn = idx_STOP_PAYROLL_REPORTING;
                break;
            case "NCS DATE":
                filterColumn = idx_NCS_DATE;
                break;
            case "CHILD BIRTH DATE":
                filterColumn = idx_CHILD_BIRTH_DATE;
                break;
            case "BEGIN DATE":
                filterColumn = idx_BEGIN_DATE;
                break;
            case "LAST DATE":
                filterColumn = idx_LAST_DATE;
                break;
            case "PENDING STATUS":
                filterColumn = idx_PENDING_STATUS;
                break;
            case "PENDING EFF. DATE":
                filterColumn = idx_PENDING_EFFECTIVE_DATE;
                break;
            case "PARTTIME":
                filterColumn = idx_PARTTIME_FLAG;
                break;
            case "BILINGUAL":
                filterColumn = idx_BILINGUAL_FLAG;
                break;
            case "SHIFT":
                filterColumn = idx_SHIFT;
                break;
            case "HOURS PER WEEK":
                filterColumn = idx_HOURS_PER_WEEK;
                break;
            case "PAYROLL ID":
                filterColumn = idx_OTHER_PAYROLL_ID;
                break;
            default:
                Misc.msgbox(getFormComponent(), "Unhandled filter selection, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
        }
        processFilter();
    }//GEN-LAST:event_filterColumnComboBoxActionPerformed

    private void filterEmployeeStatusComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterEmployeeStatusComboBoxActionPerformed
        String selection = filterEmployeeStatusComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "Show Active":
                employeeStatusFilterText = "^ACTIVE$";
                break;
            case "Show Inactive":
                employeeStatusFilterText = "INACTIVE";
                break;
            case "Show Separated":
                employeeStatusFilterText = "SEPARATED";
                break;
            default:
                employeeStatusFilterText = "";
                break;
        }
        processFilter();
    }//GEN-LAST:event_filterEmployeeStatusComboBoxActionPerformed

    private void filterClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterClearButtonActionPerformed
        clearFilter();
        processFilter();
        filterTextField.requestFocusInWindow();
    }//GEN-LAST:event_filterClearButtonActionPerformed

    private void filterEmployeeCoachComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterEmployeeCoachComboBoxActionPerformed
        String selection = filterEmployeeCoachComboBox.getSelectedItem().toString();
        filterCoachDiscrepancies = selection.equals("Show Discrepancies");
        processFilter();
    }//GEN-LAST:event_filterEmployeeCoachComboBoxActionPerformed

    private void updateCoachButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateCoachButtonActionPerformed
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        if (Misc.msgbox(getFormComponent(), "<html>This will update all SELECTED ACTIVE employees so their coach matches the webphone supervisor.<br>Are you sure you want to continue?</html>", "Update All Coaches", 2, 2, 1))
        {
            ArrayList<String> empList = new ArrayList<>();
            for (int i = 0; i < selectedRows.length; i++)
            {
                String status = table.getValueAt(selectedRows[i], idx_CURRENT_STATUS).toString();
                String empid = Misc.objectToString(table.getValueAt(selectedRows[i], idx_EMPID));

                if (status.equals("ACTIVE"))
                {
                    empList.add(empid);
                }
            }
            if (Oracle.updateCoaches(getFormComponent(), feeder, site, empList))
            {
                refreshData();
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Error updating coaches.  Email TVI Support at " + Constants.EMAIL, "Employee Maintenance", 1, 1, 1);
            }
        }
    }//GEN-LAST:event_updateCoachButtonActionPerformed

    private void updatePayrollIDsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatePayrollIDsButtonActionPerformed
        new Thread(new UpdatePayrollIDsThread()).start();
    }//GEN-LAST:event_updatePayrollIDsButtonActionPerformed
    
    private void powerUserOverrideCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_powerUserOverrideCheckBoxActionPerformed
        if (!UserData.getUserType().equals("POWER"))
        {
            powerUserOverrideCheckBox.setSelected(false);
            powerUserOverrideCheckBox.setVisible(false);
            deleteRecordButton.setVisible(false);
        }
        else
        {
            if (powerUserOverrideCheckBox.isSelected() || feeder.equals("MEX"))
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE", "SEPARATED"}));
            }
            else
            {
                currentStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE"}));
            }
            deleteRecordButton.setVisible(powerUserOverrideCheckBox.isSelected());
        }
    }//GEN-LAST:event_powerUserOverrideCheckBoxActionPerformed
    
    private void employeeHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeHistoryButtonActionPerformed
        if (editType.equals("NORMAL"))
        {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1)
            {
                Misc.msgbox(getFormComponent(), "You must select an employee.", "Employee Maintenance", 1, 1, 1);
                return;
            }
            attid = table.getValueAt(selectedRow, idx_EMPID).toString();
            editType = "DETAIL";
            clearFilter();
            refreshData();
            employeeHistoryButton.setText("View All Employees");
        }
        else //editType.equals("DETAIL")
        {
            attid = null;
            editType = "NORMAL";
            clearFilter();
            refreshData();
            employeeHistoryButton.setText("Employee History");
        }
    }//GEN-LAST:event_employeeHistoryButtonActionPerformed
    
    private void deleteRecordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRecordButtonActionPerformed
        if (!UserData.getUserType().equals("POWER"))
        {
            powerUserOverrideCheckBox.setSelected(false);
            powerUserOverrideCheckBox.setVisible(false);
            deleteRecordButton.setVisible(false);
            return;
        }
        if (!powerUserOverrideCheckBox.isSelected())
        {
            deleteRecordButton.setVisible(false);
            return;
        }
        
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0)
        {
            Misc.msgbox(getFormComponent(), "No row selected.", "Deleting Row", 1, 1, 1);
            return;
        }
        
        String mu = table.getValueAt(selectedRow, idx_MU).toString();
        String empid = table.getValueAt(selectedRow, idx_EMPID).toString();
        
        if (Misc.msgbox(getFormComponent(), "Are you sure you want to delete?", "Delete Employee", 2, 2, 1))
        {
            if (Oracle.deleteEmployeeRecord(getFormComponent(), feeder, site, mu, empid))
            {
                dataModel.removeRow(table.convertRowIndexToModel(selectedRow));
                employeeUpdated = false;
                if (selectedRow == table.getRowCount())
                {
                    selectedRow--;
                }
                if (table.getRowCount() > 0)
                {
                    table.changeSelection(selectedRow, 0, false, false);
                }
            }
        }
        table.requestFocusInWindow();
    }//GEN-LAST:event_deleteRecordButtonActionPerformed
    
    private void separatedEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_separatedEmployeesButtonActionPerformed
        PayrollGenerationMEXSeparated.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_separatedEmployeesButtonActionPerformed
    
    private void LOAEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LOAEmployeesButtonActionPerformed
        LOAMex.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_LOAEmployeesButtonActionPerformed
    
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", "Employee Maintenance");
    }//GEN-LAST:event_printButtonActionPerformed
    
    private void updateAllCoachesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_updateAllCoachesButtonActionPerformed
    {//GEN-HEADEREND:event_updateAllCoachesButtonActionPerformed
        if (Misc.msgbox(getFormComponent(), "<html>This will update all ACTIVE employees so their coach matches the webphone supervisor.<br>Are you sure you want to continue?</html>", "Update All Coaches", 2, 2, 1))
        {
            if (Oracle.updateCoaches(getFormComponent(), feeder, site, null))
            {
                refreshData();
            }
        }
    }//GEN-LAST:event_updateAllCoachesButtonActionPerformed
    
    private void updateStatusButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_updateStatusButtonActionPerformed
    {//GEN-HEADEREND:event_updateStatusButtonActionPerformed
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        ArrayList<String> empList = new ArrayList<>();
        ArrayList<String> duplicateEmps = new ArrayList<>();
        for (int i = 0; i < selectedRows.length; i++)
        {
            //add selected employees that aren't SEPARATED to the list
            if (!Misc.objectToString(table.getValueAt(selectedRows[i], idx_CURRENT_STATUS)).equals("SEPARATED"))
            {
                String empid = Misc.objectToString(table.getValueAt(selectedRows[i], idx_EMPID));
                String mu = Misc.objectToString(table.getValueAt(selectedRows[i], idx_MU));
                for (String empidMU : empList)
                {
                    if (empidMU.substring(0, 6).equals(empid))
                    {
                        duplicateEmps.add(empid);
                    }
                }
                empList.add(empid + mu);
            }
        }
        if (empList.size() < 1)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee that isn't SEPARATED.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        // get the desired status
        JComboBox<String> statusCombo = new JComboBox<>();
        statusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"ACTIVE", "INACTIVE"}));
        int rc = JOptionPane.showConfirmDialog(getFormComponent(), statusCombo, "Select the new status", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        String newStatus = statusCombo.getSelectedItem().toString();
        if (rc != 0) // user cancelled
        {
            return;
        }
        
        // get the desired effective date
        JComboBox<String> effectiveDateCombo = new JComboBox<>();
        effectiveDateCombo.setEditable(true);
        Calendar cal = Calendar.getInstance();
        String currentDate = Misc.dateToStringMDY(cal.getTime());
        cal.add(Calendar.DAY_OF_YEAR, 30);
        for (int i = 0; i <= 60; i++)
        {
            effectiveDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        effectiveDateCombo.setSelectedItem(currentDate);
        
        rc = JOptionPane.showConfirmDialog(getFormComponent(), effectiveDateCombo, "Select or enter an effective date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        Date effectiveDate = Misc.stringToDateMDY(getFormComponent(), effectiveDateCombo.getSelectedItem().toString());
        if (rc != 0 || effectiveDate == null) // user cancelled or error parsing date
        {
            return;
        }
        
        // if making ACTIVE, check the following
        if (newStatus.equals("ACTIVE"))
        {
            // remove duplicates to prevent making any employees active in multiple mus
            if (duplicateEmps.size() > 0)
            {
                duplicateEmps = Misc.removeDuplicates(duplicateEmps);
                Collections.sort(duplicateEmps);
                
                JPanel panel = new JPanel();
                panel.setPreferredSize(new Dimension(300, 340));
                FlowLayout layout = new FlowLayout();
                layout.setVgap(10);
                panel.setLayout(layout);
                
                JLabel topLabel = new JLabel("<html><font color=\"Red\">Employees can't be made ACTIVE in multiple MU's.<br>The following employees are selected multiple times:</font></html>");
                
                JTextArea empTextArea = new JTextArea();
                empTextArea.setEditable(false);
                for (String empid : duplicateEmps)
                {
                    // remove the employee from the list
                    for (int i = empList.size() - 1; i >= 0; i--)
                    {
                        if (empList.get(i).substring(0, 6).equals(empid))
                        {
                            empList.remove(i);
                        }
                    }
                    empTextArea.append(empid + "\n");
                }
                empTextArea.setCaretPosition(0);
                JScrollPane empScrollPane = new JScrollPane();
                empScrollPane.setPreferredSize(new Dimension(240, 240));
                empScrollPane.setViewportView(empTextArea);
                
                JLabel botLabel;
                if (empList.size() < 1)
                {
                    botLabel = new JLabel("<html>These employees will not be updated.</html>");
                }
                else
                {
                    botLabel = new JLabel("<html>These employees will not be updated.<br>Press okay to proceed for remaining employees, or cancel.</html>");
                }
                
                panel.add(topLabel);
                panel.add(empScrollPane);
                panel.add(botLabel);
                
                int rc2 = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Employee Maintenance", JOptionPane.OK_CANCEL_OPTION, JOptionPane.CLOSED_OPTION);
                if (rc2 != 0)
                {
                    return; // if the user cancels; otherwise proceed
                }
            }
            
            // check if any employees are ACTIVE elsewhere
            ArrayList<ArrayList<String>> activeEmployees = Oracle.areAnyEmployeesActiveElsewhere(getFormComponent(), feeder, site, empList);
            if (activeEmployees == null)
            {
                return;
            }
            else if (activeEmployees.size() > 0)
            {
                activeEmployees = Misc.removeDuplicates(activeEmployees);
                JPanel panel = new JPanel();
                panel.setPreferredSize(new Dimension(420, 330));
                FlowLayout layout = new FlowLayout();
                layout.setVgap(10);
                panel.setLayout(layout);
                
                JLabel topLabel = new JLabel("<html><font color=\"Red\">The following employees are already active elsewhere:</font></html>");
                
                JTextArea empTextArea = new JTextArea();
                empTextArea.setEditable(false);
                for (ArrayList<String> employeeRecord : activeEmployees)
                {
                    String empEmpid = employeeRecord.get(0);
                    String empFeeder = employeeRecord.get(1);
                    String empSite = employeeRecord.get(2);
                    String empMU = employeeRecord.get(3);
                    
                    // remove the employee from the list
                    for (String empidMU : empList)
                    {
                        if (empidMU.substring(0, 6).equals(empEmpid))
                        {
                            empList.remove(empidMU);
                            break;
                        }
                    }
                    
                    empTextArea.append(empEmpid + " - Active on: " + empFeeder + " site " + empSite + ", MU: " + empMU + "\n");
                }
                empTextArea.setCaretPosition(0);
                JScrollPane empScrollPane = new JScrollPane();
                empScrollPane.setPreferredSize(new Dimension(360, 240));
                empScrollPane.setViewportView(empTextArea);
                
                JLabel botLabel;
                if (empList.size() < 1)
                {
                    botLabel = new JLabel("<html>These employees will not be updated.</html>");
                }
                else
                {
                    botLabel = new JLabel("<html>These employees will not be updated.<br>Press okay to proceed for remaining employees, or cancel.</html>");
                }
                
                panel.add(topLabel);
                panel.add(empScrollPane);
                panel.add(botLabel);
                
                int rc2 = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Employee Maintenance", JOptionPane.OK_CANCEL_OPTION, JOptionPane.CLOSED_OPTION);
                if (rc2 != 0)
                {
                    return; // if the user cancels; otherwise proceed
                }
            }
        }
        
        // update statuses
        if (Oracle.updateEmployeeStatuses(getFormComponent(), feeder, site, empList, newStatus, effectiveDate, UserData.getUUID()))
        {
            refreshData();
        }
        else
        {
            Misc.msgbox(getFormComponent(), "Error updating employee statuses.  Email TVI Support " + Constants.EMAIL, "Employee Maintenance", 1, 1, 1);
        }
    }//GEN-LAST:event_updateStatusButtonActionPerformed
    
    private void clearPendingButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_clearPendingButtonActionPerformed
    {//GEN-HEADEREND:event_clearPendingButtonActionPerformed
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        if (!Misc.msgbox(getFormComponent(), "This will clear the pending statuses for all selected employees.\nAre you sure you want to continue?", "Employee Maintenance", 2, 2, 1))
        {
            return; // if the user cancels; otherwise proceed
        }
        
        ArrayList<String> empList = new ArrayList<>();
        for (int i = 0; i < selectedRows.length; i++)
        {
            String empid = Misc.objectToString(table.getValueAt(selectedRows[i], idx_EMPID));
            String mu = Misc.objectToString(table.getValueAt(selectedRows[i], idx_MU));
            empList.add(empid + mu);
        }
        
        if (Oracle.clearEmployeesPendingStatuses(getFormComponent(), feeder, site, empList, UserData.getUUID()))
        {
            refreshData();
        }
        else
        {
            Misc.msgbox(getFormComponent(), "Error clearing pending statuses.  Email TVI Support " + Constants.EMAIL, "Employee Maintenance", 1, 1, 1);
        }
        refreshData();
    }//GEN-LAST:event_clearPendingButtonActionPerformed
    
    private void helpButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_helpButtonActionPerformed
    {//GEN-HEADEREND:event_helpButtonActionPerformed
        String message = "You can select multiple rows on the table for these controls to perform mass updates.\n"
                       + "Select adjacent rows by drag selecting with the mouse, or by holding shift and selecting a range of rows.\n"
                       + "You can add individual selections by holding control and clicking each desired row.";
        Misc.msgbox(getFormComponent(), message, "Employee Maintenance", 1, 1, 0);
    }//GEN-LAST:event_helpButtonActionPerformed
    
    private void transferEmployeesButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_transferEmployeesButtonActionPerformed
    {//GEN-HEADEREND:event_transferEmployeesButtonActionPerformed
        int[] selectedRows = table.getSelectedRows();
        if (selectedRows.length <= 0)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        // get the selected ACTIVE employees
        ArrayList<String> empList = new ArrayList<>();
        for (int i = 0; i < selectedRows.length; i++)
        {
            if (Misc.objectToString(table.getValueAt(selectedRows[i], idx_CURRENT_STATUS)).equals("ACTIVE"))
            {
                empList.add(Misc.objectToString(table.getValueAt(selectedRows[i], idx_EMPID)));
            }
        }
        if (empList.size() < 1)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one ACTIVE employee.", "Employee Maintenance", 1, 1, 1);
            return;
        }
        
        if (!Misc.msgbox(getFormComponent(), "Make sure you have finished importing for the old MU(s) before transferring.", "Employee Maintenance", 1, 2, 1))
        {
            return;
        }
        
        // get the new mu
        JComboBox<String> muCombo = new JComboBox<>();
        ArrayList<String> muList = RegionData.getMuList();
        for (int i = 0; i <= muList.size() - 1; i++)
        {
            muCombo.addItem(muList.get(i));
        }
        
        int rc = JOptionPane.showConfirmDialog(getFormComponent(), muCombo, "Select the MU to transfer to", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        String newMU = Misc.objectToString(muCombo.getSelectedItem());
        if (rc != 0 || newMU.equals("")) // user cancelled or error getting MU
        {
            return;
        }
        
        // get the desired effective date
        JComboBox<String> effectiveDateCombo = new JComboBox<>();
        effectiveDateCombo.setEditable(true);
        Calendar cal = Calendar.getInstance();
        String currentDate = Misc.dateToStringMDY(cal.getTime());
        cal.add(Calendar.DAY_OF_YEAR, 30);
        for (int j = 0; j <= 60; j++)
        {
            effectiveDateCombo.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        effectiveDateCombo.setSelectedItem(currentDate);
        
        rc = JOptionPane.showConfirmDialog(getFormComponent(), effectiveDateCombo, "Select or enter an effective date", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        Date effectiveDate = Misc.stringToDateMDY(getFormComponent(), effectiveDateCombo.getSelectedItem().toString());
        if (rc != 0 || effectiveDate == null) // user cancelled or error parsing date
        {
            return;
        }
        
        // remove employees that are on any schedule for a different FEEDER||SITE||MU on or after the chosen effective date
        ArrayList<ArrayList<String>> scheduledEmployees = Oracle.areAnyEmployeesOnOtherSchedules(getFormComponent(), feeder, site, newMU, effectiveDate, empList);
        if (scheduledEmployees == null)
        {
            return;
        }
        else if (scheduledEmployees.size() > 0)
        {
            scheduledEmployees = Misc.removeDuplicates(scheduledEmployees);
            JPanel panel = new JPanel();
            panel.setPreferredSize(new Dimension(420, 340));
            FlowLayout layout = new FlowLayout();
            layout.setVgap(10);
            panel.setLayout(layout);
            
            JLabel topLabel = new JLabel("<html><font color=\"Red\">The following employees have records for a different MU<br>on or after the chosen effective date:</font></html>");
            
            JTextArea empTextArea = new JTextArea();
            empTextArea.setEditable(false);
            for (ArrayList<String> employeeRecord : scheduledEmployees)
            {
                String empEmpid = employeeRecord.get(0);
                String empFeeder = employeeRecord.get(1);
                String empSite = employeeRecord.get(2);
                String empMU = employeeRecord.get(3);
                
                // remove the employee from the list
                for (String empid : empList)
                {
                    if (empid.equals(empEmpid))
                    {
                        empList.remove(empid);
                        break;
                    }
                }
                
                empTextArea.append(empEmpid + " - on " + empFeeder + " site " + empSite + ", MU: " + empMU + "\n");
            }
            empTextArea.setCaretPosition(0);
            JScrollPane empScrollPane = new JScrollPane();
            empScrollPane.setPreferredSize(new Dimension(360, 240));
            empScrollPane.setViewportView(empTextArea);
            
            JLabel botLabel;
            if (empList.size() < 1)
            {
                botLabel = new JLabel("<html>These employees will not be updated.</html>");
            }
            else
            {
                botLabel = new JLabel("<html>These employees will not be updated.<br>Press okay to proceed for remaining employees, or cancel.</html>");
            }
            
            panel.add(topLabel);
            panel.add(empScrollPane);
            panel.add(botLabel);
            
            int rc2 = JOptionPane.showConfirmDialog(getFormComponent(), panel, "Employee Maintenance", JOptionPane.OK_CANCEL_OPTION, JOptionPane.CLOSED_OPTION);
            if (rc2 != 0)
            {
                return; // if the user cancels; otherwise proceed
            }
        }
        
        // transfer employees
        if (Oracle.transferEmployees(getFormComponent(), feeder, site, newMU, effectiveDate, empList, UserData.getUUID()))
        {
            Misc.msgbox(getFormComponent(), "Employees Transferred.", "Employee Maintenance", 1, 1, 0);
        }
        else
        {
            return;
        }
        
        // if schedules exist for the new MU >= effective date, give message to import updates for these days
        if (Oracle.doSchedulesExist(getFormComponent(), feeder, site, newMU, effectiveDate))
        {
            Misc.msgbox(getFormComponent(), "Some schedules past the transfer effective date have already been imported.\nMake sure to import updates for these days to bring in the transfered employees correctly.", "Employee Maintenance", 1, 1, 1);
        }
        
        refreshData();
    }//GEN-LAST:event_transferEmployeesButtonActionPerformed
    
    private void refreshData()
    {
        if (table != null)
        {
            updateDatabase();
        }
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (table != null)
                        {
                            if (table.getSelectedRow() != -1)
                            {
                                changeEmployee(0);
                            }
                        }
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    employeesScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                Misc.centerHTML("Part<br>Time"),             // idx_PARTTIME_FLAG
                Misc.centerHTML("Bi-<br>Lingual"),           // idx_BILINGUAL
                Misc.centerHTML("Hrs Per<br>Week"),          // idx_HOURS_PER_WEEK
                "FEEDER",                                    // idx_FEEDER
                "SITE",                                      // idx_SITE
                "Band",                                      // idx_BAND                      CZE & SVK ONLY
                "MU",                                        // idx_MU
                "Agent ID",                                  // idx_AGENTID
                "AT&T ID",                                   // idx_EMPID
                "Payroll ID",                                // idx_OTHER_PAYROLL_ID          MEX, CZE, SVK ONLY
                "Employee",                                  // idx_EMPLOYEE
                "Coach",                                     // idx_COACH
                Misc.centerHTML("Webphone<br>Supervisor"),   // idx_WEBPHONE_SUPERVISOR
                "",                                          // idx_COACHES_MATCH
                "NCS Date",                                  // idx_NCS_DATE                  EUR ONLY
                Misc.centerHTML("Child<br>Birth Date"),         // idx_CHILD_BIRTH_DATE          EUR ONLY
                Misc.centerHTML("Extra<br>Off Day<br>Hours"),// idx_EXTRA_OFF_DAYS            EUR ONLY
                Misc.centerHTML("Current<br>Status"),        // idx_CURRENT_STATUS
                Misc.centerHTML("Current<br>Eff. Date"),     // idx_CURRENT_EFFECTIVE_DATE
                Misc.centerHTML("Payroll<br>Completed"),     // idx_STOP_PAYROLL_REPORTING    MEX ONLY
                "",                                          // idx_STOP_PAYROLL_CHGD_BY
                "",                                          // idx_STOP_PAYROLL_CHGD_DATE
                Misc.centerHTML("4/10<br>Emps"),             // idx_FOUR_DAY                  MEX ONLY
                Misc.centerHTML("Six<br>Day"),               // idx_SIX_DAY                   MEX ONLY
                "Begin Date",                                // idx_BEGIN_DATE
                "Last Date",                                 // idx_LAST_DATE
                Misc.centerHTML("Pending<br>Status"),        // idx_PENDING_STATUS
                Misc.centerHTML("Pending<br>Eff. Date"),     // idx_PENDING_EFFECTIVE_DATE
                "Shift",                                     // idx_SHIFT
                ""                                           // idx_ACTIVE_ON
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsEmployeeMaintenance(getFormComponent(), feeder, site, attid);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                Date stopPayrollChgdDate = Misc.timestampToDate(rs.getTimestamp("STOP_PAYROLL_CHGD_DATE"));
                data = new Object []
                {
                    Misc.oracleToBoolean(rs.getObject("PARTTIME_FLAG")),          // idx_PARTTIME_FLAG
                    Misc.oracleToBoolean(rs.getObject("BILINGUAL_DAILY")),         // idx_BILINGUAL
                    rs.getBigDecimal("HOURS_PER_WEEK"),                           // idx_HOURS_PER_WEEK
                    rs.getString("FEEDER"),                                       // idx_FEEDER
                    rs.getString("SITE"),                                         // idx_SITE
                    rs.getString("BAND"),                                         // idx_BAND
                    rs.getString("MU"),                                           // idx_MU
                    rs.getString("AGENTID"),                                      // idx_AGENTID
                    rs.getString("EMPID"),                                        // idx_EMPID
                    rs.getString("OTHER_PAYROLL_ID"),                             // idx_OTHER_PAYROLL_ID
                    rs.getString("EMPLOYEE"),                                     // idx_EMPLOYEE
                    rs.getString("COACH"),                                        // idx_COACH
                    rs.getString("WEBPHONE_SUPERVISOR"),                          // idx_WEBPHONE_SUPERVISOR
                    Misc.oracleToBoolean(rs.getObject("COACHES_MATCH")),          // idx_COACHES_MATCH
                    rs.getDate("NCS_DATE"),                                       // idx_NCS_DATE
                    rs.getDate("CHILD_BIRTH_DATE"),                               // idx_CHILD_BIRTH_DATE
                    rs.getBigDecimal("EXTRA_OFF_DAYS"),                           // idx_EXTRA_OFF_DAYS
                    rs.getString("TVI_STATUS"),                                   // idx_CURRENT_STATUS
                    rs.getDate("STATUS_EFFECTIVE_DATE"),                          // idx_CURRENT_EFFECTIVE_DATE
                    Misc.oracleToBoolean(rs.getObject("STOP_PAYROLL_REPORTING")), // idx_STOP_PAYROLL_REPORTING
                    rs.getString("STOP_PAYROLL_CHGD_BY"),                         // idx_STOP_PAYROLL_CHGD_BY
                    stopPayrollChgdDate,                                          // idx_STOP_PAYROLL_CHGD_DATE
                    Misc.oracleToBoolean(rs.getObject("FOUR_DAY")),               // idx_FOUR_DAY
                    Misc.oracleToBoolean(rs.getObject("SIX_DAY")),                // idx_SIX_DAY
                    rs.getDate("BEGIN_DATE"),                                     // idx_BEGIN_DATE
                    rs.getDate("LAST_DATE"),                                      // idx_LAST_DATE
                    rs.getString("PENDING_STATUS"),                               // idx_PENDING_STATUS
                    rs.getDate("PENDING_EFFECTIVE_DATE"),                         // idx_PENDING_EFFECTIVE_DATE
                    rs.getBigDecimal("SHIFT"),                                    // idx_SHIFT
                    rs.getString("ACTIVE_ON")                                     // idx_ACTIVE_ON
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Employee Maintenance data.");
                worker.cancel(true);
            }
            employeeCount++;
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
                employeesScrollPane.setViewportView(table);
                filterTextField.requestFocusInWindow();
            }
            refreshTableLock.release();
            if (cancelled)
            {
                closeForm();
            }
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (table.convertRowIndexToModel(row) != currentRow ||
                        table.getSelectedRows().length > 1)
                    {
                        return false;
                    }
                    else if (UserData.getUserType().equals("POWER") && powerUserOverrideCheckBox.isSelected())
                    {
                        switch (column)
                        {
                            case idx_FEEDER:
                            case idx_SITE:
                            case idx_MU:
                            case idx_EMPID:
                                return false;
                            default:
                                return true;
                        }
                    }
                    else if (UserData.getUserAccessLevel().equals("READONLY") ||
                             !table.getValueAt(row, idx_FEEDER).toString().equals(feeder) ||
                             !table.getValueAt(row, idx_SITE).toString().equals(site))
                    {
                        return false;
                    }
                    else
                    {
                        if (table.getValueAt(row, idx_ACTIVE_ON) != null)
                        {
                            String activeOn = table.getValueAt(row, idx_ACTIVE_ON).toString();
                            Scanner scan = new Scanner(activeOn).useDelimiter("\\s+");
                            if (scan.hasNext())
                            {
                                String activeOnFeederSite = scan.next();
                                if (!(feeder + site).equals(activeOnFeederSite))
                                {
                                    return false;
                                }
                            }
                        }

                        switch (column)
                        {
                            case idx_BAND:
                            case idx_OTHER_PAYROLL_ID:
                            case idx_COACH:
                            case idx_PARTTIME_FLAG:
                            case idx_BILINGUAL_FLAG:
                            case idx_SHIFT:
                            case idx_HOURS_PER_WEEK:
                            case idx_CURRENT_STATUS:
                            case idx_CURRENT_EFFECTIVE_DATE:
                            case idx_FOUR_DAY:
                            case idx_SIX_DAY:
                            case idx_NCS_DATE:
                            case idx_CHILD_BIRTH_DATE:
                            case idx_EXTRA_OFF_DAYS:
                                return true;
                            case idx_STOP_PAYROLL_REPORTING:
                                boolean checked = (Boolean)table.getValueAt(row, idx_STOP_PAYROLL_REPORTING);
                                Date chgd_date = (Date)table.getValueAt(row, idx_STOP_PAYROLL_CHGD_DATE);
                                boolean employeeNotActive = Arrays.asList("INACTIVE", "SEPARATED").contains(Misc.objectToString(table.getValueAt(row, idx_CURRENT_STATUS)));
                                String activeOn = Misc.objectToString(table.getValueAt(row, idx_ACTIVE_ON));
                                boolean employeeNotActiveElsewhere = (activeOn.equals("") || activeOn.equals(" "));
                                // if checked and chgd_date < current payroll start date || if status in {"INACTIVE", "SEPARATED"} and employee isn't active elsewhere
                                return ((checked && (chgd_date == null || chgd_date.compareTo(Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose())) >= 0)) || (employeeNotActive && employeeNotActiveElsewhere));
                            case idx_PENDING_STATUS:
                                return Arrays.asList("ACTIVE", "INACTIVE").contains(Misc.objectToString(table.getValueAt(row, idx_CURRENT_STATUS)));
                            case idx_PENDING_EFFECTIVE_DATE:
                                return Arrays.asList("ACTIVE", "INACTIVE").contains(Misc.objectToString(table.getValueAt(row, idx_CURRENT_STATUS))) && table.getValueAt(row, idx_PENDING_STATUS) != null && !table.getValueAt(row, idx_PENDING_STATUS).equals("");
                            default:
                                return false;
                        }
                    }
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_SHIFT:
                        case idx_HOURS_PER_WEEK:
                        case idx_EXTRA_OFF_DAYS:
                            return BigDecimal.class;
                        case idx_COACHES_MATCH:
                        case idx_PARTTIME_FLAG:
                        case idx_BILINGUAL_FLAG:
                        case idx_STOP_PAYROLL_REPORTING:
                        case idx_FOUR_DAY:
                        case idx_SIX_DAY:
                            return Boolean.class;
                        case idx_CURRENT_EFFECTIVE_DATE:
                        case idx_STOP_PAYROLL_CHGD_DATE:
                        case idx_NCS_DATE:
                        case idx_CHILD_BIRTH_DATE:
                        case idx_BEGIN_DATE:
                        case idx_LAST_DATE:
                        case idx_PENDING_EFFECTIVE_DATE:
                            return Date.class;
                        case idx_FEEDER:
                        case idx_SITE:
                        case idx_BAND:
                        case idx_MU:
                        case idx_AGENTID:
                        case idx_EMPID:
                        case idx_OTHER_PAYROLL_ID:
                        case idx_EMPLOYEE:
                        case idx_COACH:
                        case idx_WEBPHONE_SUPERVISOR:
                        case idx_CURRENT_STATUS:
                        case idx_STOP_PAYROLL_CHGD_BY:
                        case idx_PENDING_STATUS:
                        case idx_ACTIVE_ON:
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (UserData.getUserAccessLevel().equals("READONLY") ||
                            !table.getValueAt(row, idx_FEEDER).toString().equals(feeder) ||
                            !table.getValueAt(row, idx_SITE).toString().equals(site))
                        {
                            c.setBackground(Color.LIGHT_GRAY);
                        }
                        else if (table.getValueAt(row, idx_ACTIVE_ON) != null)
                        {
                            String activeOn = table.getValueAt(row, idx_ACTIVE_ON).toString();
                            Scanner scan = new Scanner(activeOn).useDelimiter("\\s");
                            if (scan.hasNext())
                            {
                                String activeOnFeederSite = scan.next();
                                if (!(feeder + site).equals(activeOnFeederSite))
                                {
                                    c.setBackground(Color.LIGHT_GRAY);
                                }
                            }
                        }
                    }
                    return c;
                }
            };
        }

        private void configureTable()
        {
            dataModel.addTableModelListener(new TableModelListener()
            {
                @Override
                public void tableChanged(TableModelEvent e)
                {
                    if (currentRow != -1)
                    {
                        if (e.getColumn() == idx_FOUR_DAY && dataModel.getValueAt(currentRow, idx_FOUR_DAY).equals(true) && dataModel.getValueAt(currentRow, idx_SIX_DAY).equals(true))
                        {
                            dataModel.setValueAt(false, currentRow, idx_SIX_DAY);
                        }
                        if (e.getColumn() == idx_SIX_DAY && dataModel.getValueAt(currentRow, idx_SIX_DAY).equals(true) && dataModel.getValueAt(currentRow, idx_FOUR_DAY).equals(true))
                        {
                            dataModel.setValueAt(false, currentRow, idx_FOUR_DAY);
                        }
                    }
                }
            });
            
            Action employeeTableAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener etcl = (TableCellListener)e.getSource();
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow < 0)
                    {
                        return;
                    }
                    if (etcl.getColumn() == idx_COACH)
                    {
                        boolean coachesMatch = table.getValueAt(selectedRow, idx_COACH) == table.getValueAt(selectedRow, idx_WEBPHONE_SUPERVISOR);
                        table.setValueAt(coachesMatch, selectedRow, idx_COACHES_MATCH);
                    }
                    if (etcl.getColumn() == idx_CURRENT_STATUS)
                    {
                        updatePendingStatusCombo(Misc.objectToString(table.getValueAt(selectedRow, idx_CURRENT_STATUS)));
                        updateActiveOn(table.getValueAt(selectedRow, idx_EMPID).toString());
                        if (table.getValueAt(selectedRow, idx_CURRENT_STATUS).toString().equals("ACTIVE") &&
                            (Boolean)table.getValueAt(selectedRow, idx_STOP_PAYROLL_REPORTING))
                        {
                            table.setValueAt(false, selectedRow, idx_STOP_PAYROLL_REPORTING);
                            table.setValueAt(null, selectedRow, idx_STOP_PAYROLL_CHGD_BY);
                            table.setValueAt(null, selectedRow, idx_STOP_PAYROLL_CHGD_DATE);
                            String mu = table.getValueAt(selectedRow, idx_MU).toString();
                            String empid = table.getValueAt(selectedRow, idx_EMPID).toString();
                            updateOtherPayrollCompleted(getFormComponent(), mu, empid, false, null, null);
                        }
                    }
                    if (etcl.getColumn() == idx_STOP_PAYROLL_REPORTING)
                    {
                        boolean stopPayroll = (Boolean)table.getValueAt(selectedRow, idx_STOP_PAYROLL_REPORTING);
                        String chgd_by = null;
                        Date chgd_date = null;
                        if (stopPayroll)
                        {
                            Misc.msgbox(getFormComponent(), "By checking this box, this employee will no longer be included in payroll files generated.", "Payroll Completed", 2, 1, 1);
                            chgd_by = UserData.getUUID();
                            chgd_date = Oracle.getCurTime(getFormComponent());
                        }
                        table.setValueAt(chgd_by, selectedRow, idx_STOP_PAYROLL_CHGD_BY);
                        table.setValueAt(chgd_date, selectedRow, idx_STOP_PAYROLL_CHGD_DATE);
                        String mu = table.getValueAt(selectedRow, idx_MU).toString();
                        String empid = table.getValueAt(selectedRow, idx_EMPID).toString();
                        updateOtherPayrollCompleted(getFormComponent(), mu, empid, stopPayroll, chgd_by, chgd_date);
                    }
                    if (etcl.getColumn() == idx_PENDING_STATUS)
                    {
                        if (etcl.getNewValue().equals(""))
                        {
                            table.setValueAt(null, selectedRow, idx_PENDING_EFFECTIVE_DATE);
                        }
                    }
                    employeeUpdated = true;
                    currentRow = table.convertRowIndexToModel(selectedRow);
                }
            };
            table.addPropertyChangeListener(new TableCellListener(table, employeeTableAction));

            Misc.configureTable(table, false, true, false);

            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);

            Misc.setTableSorterNumeralComparator(table);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_PARTTIME_FLAG, 60, false);
            Misc.setColumnSettings(table, idx_BILINGUAL_FLAG, 60, false);
            if (editType.equals("DETAIL"))
            {
                Misc.setColumnSettings(table, idx_FEEDER, 60);
                Misc.setColumnSettings(table, idx_SITE, 40);
            }
            else // editType.equals("NORMAL")
            {
                Misc.setColumnSettings(table, idx_FEEDER, 0, false);
                Misc.setColumnSettings(table, idx_SITE, 0, false);
            }
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(table, idx_BAND, 60);
                DefaultCellEditor be = new DefaultCellEditor(bandCombo);
                be.setClickCountToStart(2);
                table.getColumnModel().getColumn(idx_BAND).setCellEditor(be);
            }
            else
            {
                Misc.setColumnSettings(table, idx_BAND, 0, false);
            }
            Misc.setColumnSettings(table, idx_MU, 40);
            Misc.setColumnSettings(table, idx_AGENTID, 80);
            Misc.setColumnSettings(table, idx_EMPID, 80);
            if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(table, idx_OTHER_PAYROLL_ID, 100);
            }
            else
            {
                Misc.setColumnSettings(table, idx_OTHER_PAYROLL_ID, 0, false);
            }
            Misc.setColumnSettings(table, idx_EMPLOYEE, 150, Constants.LEFT);
            Misc.setColumnSettings(table, idx_COACH, 80);
            Misc.setColumnSettings(table, idx_WEBPHONE_SUPERVISOR, 80);
            Misc.setColumnSettings(table, idx_COACHES_MATCH, 0, false);
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(table, idx_NCS_DATE, 80);
                Misc.setColumnSettings(table, idx_CHILD_BIRTH_DATE, 80);
            }
            else
            {
                Misc.setColumnSettings(table, idx_NCS_DATE, 0);
                Misc.setColumnSettings(table, idx_CHILD_BIRTH_DATE, 0);
            }
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(table, idx_EXTRA_OFF_DAYS, 60);
            }
            else
            {
                Misc.setColumnSettings(table, idx_EXTRA_OFF_DAYS, 0);
            }
            Misc.setColumnSettings(table, idx_CURRENT_STATUS, 80);
            Misc.setColumnSettings(table, idx_CURRENT_EFFECTIVE_DATE, 80);
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(table, idx_STOP_PAYROLL_REPORTING, 80, false);
                Misc.setColumnSettings(table, idx_FOUR_DAY, 50, false);
                Misc.setColumnSettings(table, idx_SIX_DAY, 50, false);
            }
            else
            {
                Misc.setColumnSettings(table, idx_STOP_PAYROLL_REPORTING, 0, false);
                Misc.setColumnSettings(table, idx_FOUR_DAY, 0, true);
                Misc.setColumnSettings(table, idx_SIX_DAY, 0, true);
            }
            Misc.setColumnSettings(table, idx_STOP_PAYROLL_CHGD_BY, 0);
            Misc.setColumnSettings(table, idx_STOP_PAYROLL_CHGD_DATE, 0);
            Misc.setColumnSettings(table, idx_BEGIN_DATE, 80);
            Misc.setColumnSettings(table, idx_LAST_DATE, 80);
            Misc.setColumnSettings(table, idx_PENDING_STATUS, 80);
            Misc.setColumnSettings(table, idx_PENDING_EFFECTIVE_DATE, 80);
            Misc.setColumnSettings(table, idx_SHIFT, 0, true, Constants.CENTER); // hidden for now, make width 60 in future if we decide to use
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(table, idx_HOURS_PER_WEEK, 60, true, Constants.CENTER);
            }
            else
            {
                Misc.setColumnSettings(table, idx_HOURS_PER_WEEK, 0, true, Constants.CENTER);
            }
            Misc.setColumnSettings(table, idx_ACTIVE_ON, 0, false);

            table.getColumnModel().getColumn(idx_HOURS_PER_WEEK).setCellEditor(new HoursEditor(0.0, 99.0, true));

            DefaultCellEditor cse = new DefaultCellEditor(currentStatusCombo);
            cse.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_CURRENT_STATUS).setCellEditor(cse);
            
            DefaultCellEditor pse = new DefaultCellEditor(pendingStatusCombo);
            pse.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_PENDING_STATUS).setCellEditor(pse);
            
            DefaultCellEditor cde = new DefaultCellEditor(currentDateCombo)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JComboBox dateCombo = (JComboBox)getComponent();
                    Object value = dateCombo.getSelectedItem();
                    if (value instanceof Date)
                    {
                        return value;
                    }
                    else if (value instanceof String && !value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }

                @Override
                public boolean stopCellEditing()
                {
                    if (!formClosing && !verifyCurrentDate(currentDateCombo))
                    {
                        if (!userSaysRevertCurrent())
                        {
                            return false;//continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            cde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_CURRENT_EFFECTIVE_DATE).setCellEditor(cde);
            
            final JTextField tfCurrent = (JTextField)currentDateCombo.getEditor().getEditorComponent();
            tfCurrent.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "check");
            tfCurrent.getActionMap().put("check", new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (verifyCurrentDate(currentDateCombo))
                    {
                        tfCurrent.postActionEvent(); // stop editing
                    }
                    else // text is invalid
                    {
                        if (userSaysRevertCurrent())
                        {
                            tfCurrent.postActionEvent(); // inform the editor
                        }
                    }
                }
            });

            DefaultCellEditor ope = new DefaultCellEditor(new JFormattedTextField())
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.objectToString(value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    return ftf.getText();
                }

                @Override
                public boolean stopCellEditing()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    ftf.setText(ftf.getText().replace(" ", ""));
                    int selectedRow = table.getSelectedRow();
                    String empid = Misc.objectToString(table.getValueAt(selectedRow, idx_EMPID));
                    String previousValue = Misc.objectToString(table.getValueAt(selectedRow, idx_OTHER_PAYROLL_ID));
                    String payrollID = ftf.getText();
                    if (!formClosing && payrollID != null && !payrollID.equals("") && Oracle.otherPayrollIDAlreadyExists(getFormComponent(), feeder, site, empid, payrollID))
                    {
                        if (!userSaysRevertPayrollID(ftf, previousValue))
                        {
                            return false;//continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            ope.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_OTHER_PAYROLL_ID).setCellEditor(ope);
            
            DefaultCellEditor eoe = new DefaultCellEditor(new JFormattedTextField())
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.objectToString(value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    return ftf.getText();
                }

                @Override
                public boolean stopCellEditing()
                {
                    JFormattedTextField ftf = (JFormattedTextField)getComponent();
                    ftf.setText(ftf.getText().replace(" ", ""));
                    int selectedRow = table.getSelectedRow();
                    String empid = Misc.objectToString(table.getValueAt(selectedRow, idx_EMPID));
                    String previousValue = Misc.objectToString(table.getValueAt(selectedRow, idx_EXTRA_OFF_DAYS));
                    String extraOffEntered = ftf.getText();
                    if (!formClosing && !verifyExtraOff(empid, extraOffEntered))
                    {
                        if (!userSaysRevertExtraOff(ftf, previousValue))
                        {
                            return false; // continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            eoe.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_EXTRA_OFF_DAYS).setCellEditor(eoe);
            
            DefaultCellEditor ncsde = new DefaultCellEditor(ncsDateCombo)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JComboBox dateCombo = (JComboBox)getComponent();
                    Object value = dateCombo.getSelectedItem();
                    if (value instanceof Date)
                    {
                        return value;
                    }
                    else if (value instanceof String && !value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            ncsde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_NCS_DATE).setCellEditor(ncsde);
            
            JTextField tfChildBirthDate = new JTextField();
            DefaultCellEditor cbde = new DefaultCellEditor(tfChildBirthDate)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JTextField tf = (JTextField)getComponent();
                    Object value = tf.getText();
                    if (!value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            cbde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_CHILD_BIRTH_DATE).setCellEditor(cbde);
            JTextField tfBeginDate = new JTextField();
            DefaultCellEditor bde = new DefaultCellEditor(tfBeginDate)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JTextField tf = (JTextField)getComponent();
                    Object value = tf.getText();
                    if (!value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            bde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_BEGIN_DATE).setCellEditor(bde);
            JTextField tfLastDate = new JTextField();
            DefaultCellEditor lde = new DefaultCellEditor(tfLastDate)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JTextField tf = (JTextField)getComponent();
                    Object value = tf.getText();
                    if (!value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }
            };
            lde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_LAST_DATE).setCellEditor(lde);
            DefaultCellEditor pde = new DefaultCellEditor(pendingDateCombo)
            {
                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
                {
                    return super.getTableCellEditorComponent(table, Misc.dateToStringMDY((Date)value), isSelected, row, column);
                }

                @Override
                public Object getCellEditorValue()
                {
                    JComboBox dateCombo = (JComboBox)getComponent();
                    Object value = dateCombo.getSelectedItem();
                    if (value instanceof Date)
                    {
                        return value;
                    }
                    else if (value instanceof String && !value.toString().equals(""))
                    {
                        return Misc.stringToDateMDY(getFormComponent(), value.toString());
                    }
                    else
                    {
                        return null;
                    }
                }

                @Override
                public boolean stopCellEditing()
                {
                    if (!verifyPendingDate(pendingDateCombo))
                    {
                        if (!userSaysRevertPending())
                        {
                            return false;//continue editing
                        }
                    }
                    return super.stopCellEditing();
                }
            };
            pde.setClickCountToStart(2);
            table.getColumnModel().getColumn(idx_PENDING_EFFECTIVE_DATE).setCellEditor(pde);
            final JTextField tfPending = (JTextField)pendingDateCombo.getEditor().getEditorComponent();
            tfPending.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "check");
            tfPending.getActionMap().put("check", new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (verifyPendingDate(pendingDateCombo))
                    {
                        tfPending.postActionEvent(); // stop editing
                    }
                    else // text is invalid
                    {
                        if (userSaysRevertPending())
                        {
                            tfPending.postActionEvent(); // inform the editor
                        }
                    }
                }
            });
            table.setRowHeight(20);

            if (employeeCount > 0)
            {
                currentRow = 0;
                table.setRowSelectionInterval(0, 0);
                changingEmployees = true;
                changeEmployee(0);
                changingEmployees = false;
            }

            table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = table.getSelectedRow();
                        if (selectedRow != -1 && table.convertRowIndexToModel(selectedRow) != currentRow)
                        {
                            if (!changingEmployees)
                            {
                                changingEmployees = true;
                                changeEmployee(selectedRow);
                                changingEmployees = false;
                            }
                        }
                    }
                }
            });
            processFilter();
        }
    }
    
    private class UpdatePayrollIDsThread implements Runnable
    {
        @Override
        @SuppressFBWarnings(value="RV_DONT_JUST_NULL_CHECK_READLINE", justification="We don't use the value returned from readLine() when counting lines.")
        public void run()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.HOURGLASS);
                        updatePayrollIDsButton.setEnabled(false);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showOpenDialog(getFormComponent());
            if (returnVal == JFileChooser.APPROVE_OPTION)
            {
                try
                {
                    // get the number of lines in the file
                    int lineCount = 0;
                    File payrollIDFile = fc.getSelectedFile();
                    BufferedReader file = new BufferedReader(new FileReader(payrollIDFile.getAbsolutePath()));
                    try
                    {
                        while (file.readLine() != null)
                        {
                            lineCount++;
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                    final int maxProgress = lineCount;
                    
                    // display the progress monitor
                    SwingUtilities.invokeLater(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            progressMonitor = new ProgressMonitor(getFormComponent(), "Updating Payroll IDs", null, 0, maxProgress);
                            progressMonitor.setProgress(0);
                        }
                    });
                    
                    // read the file, update each employee and increment the progress bar
                    payrollIDFile = fc.getSelectedFile();
                    file = new BufferedReader(new FileReader(payrollIDFile.getAbsolutePath()));
                    try
                    {
                        String line;
                        int currentLine = 0;
                        proceed = true;
                        cancel = false;
                        while ((line = file.readLine()) != null && proceed && !cancel)
                        {
                            currentLine++;
                            final int currentProgress = currentLine;
                            SwingUtilities.invokeLater(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    if (progressMonitor.isCanceled())
                                    {
                                        progressMonitor.close();
                                        cancel = true;
                                    }
                                    else
                                    {
                                        progressMonitor.setProgress(currentProgress);
                                    }
                                }
                            });
                            if (line.contains(","))
                            {
                                String values[] = line.split(",");
                                String payrollID = values[0].replace(" ", "");
                                String empid = values[1].toUpperCase(Locale.ENGLISH).replace(" ", "");
                                String message = "";
                                if (!Misc.isNumeric(payrollID))
                                {
                                    proceed = false;
                                    message = "Invalid payrollID.";
                                }
                                else if (empid.length() != 6)
                                {
                                    proceed = false;
                                    message = "Invalid empid.";
                                }
                                else if (payrollID.length() > 10)
                                {
                                    proceed = false;
                                    message = "Payroll ID is too long.";
                                }
                                else if (Oracle.otherPayrollIDAlreadyExists(getFormComponent(), feeder, site, empid, payrollID))
                                {
                                    proceed = false;
                                    message = "Payroll ID already exists for a different employee.";
                                }
                                if (proceed)
                                {
                                    Oracle.updateEmployeePayrollID(getFormComponent(), feeder, site, empid, payrollID);
                                }
                                else
                                {
                                    proceed = Misc.msgbox(getFormComponent(), "<html><font color = \"red\">Error on line " + currentLine + ".<br>Empid: " + empid + "&nbsp&nbsp&nbsp Payroll ID: " + payrollID + "</font><br><br><font color = \"blue\">" + message + "</font><br><br>This record will not be processed.<br>Click OK to continue, or Cancel to stop.", "Updating Payroll IDs", 2, 2, 1);
                                }
                                if (!proceed)
                                {
                                    progressMonitor.close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        file.close();
                    }
                }
                catch (IOException ex)
                {
                    proceed = false;
                    Misc.errorMsgDefault(getFormComponent(), ex, "Failed to read payroll ID file.");
                }
                
                refreshData();
                if (proceed && !cancel)
                {
                    Misc.msgbox(getFormComponent(), "Payroll IDs updated.", "Updating Payroll IDs", 1, 1, 1);
                }
            }
            
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        setCursor(Constants.NORMAL);
                        updatePayrollIDsButton.setEnabled(true);
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
        }
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertCurrent()
    {
        Toolkit.getDefaultToolkit().beep();
        JTextField tf = ((JTextField) currentDateCombo.getEditor().getEditorComponent());
        tf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(tf),
            "The date must be formatted as mm/dd/yyyy.\n"
            + "The current effective date cannot be a date more than 30 days in the future.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            tf.setText(currentDateCombo.getSelectedItem().toString());
            return true;
        }
        return false;
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertPending()
    {
        Toolkit.getDefaultToolkit().beep();
        JTextField tf = ((JTextField) pendingDateCombo.getEditor().getEditorComponent());
        tf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(tf),
            "The date must be formatted as mm/dd/yyyy.\n"
            + "The pending effective date must be a date after the last reported date.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            tf.setText(pendingDateCombo.getSelectedItem().toString());
            return true;
        }
        return false;
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @param ftf
     * @param previousValue
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertPayrollID(JFormattedTextField ftf, String previousValue)
    {
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "The payroll ID entered already exists for another employee on this site.",
            "Invalid Text Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
            return true;
        }
        return false;
    }
    
    /**
     * Lets the user know that the text they entered is invalid. Returns true if the user elects to revert to the last good value.
     * Otherwise, returns false, indicating that the user wants to continue editing.
     * @param ftf
     * @param previousValue
     * @return true if revert, false otherwise
     */
    protected boolean userSaysRevertExtraOff(JFormattedTextField ftf, String previousValue)
    {
        Toolkit.getDefaultToolkit().beep();
        ftf.selectAll();
        Object[] options = {"Edit", "Revert"};
        int answer = JOptionPane.showOptionDialog(
            SwingUtilities.getWindowAncestor(ftf),
            "The amount entered is less than the employee has already taken,\n"
                + "or the format entered is invalid.",
            "Invalid Amount Entered",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.ERROR_MESSAGE,
            null,
            options,
            options[1]);
        
        if (answer == 1) // Revert!
        {
            ftf.setValue(previousValue);
            return true;
        }
        return false;
    }
    
    private void updatePendingStatusCombo(String currentStatus)
    {
        switch (currentStatus)
        {
            case "ACTIVE":
                pendingStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "INACTIVE"}));
                break;
            case "INACTIVE":
                pendingStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "ACTIVE"}));
                break;
            case "":
            default:
                pendingStatusCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "ACTIVE", "INACTIVE"}));
                
        }
    }
    
    private void updateActiveOn(String empid)
    {
        String activeOn = null;
        // get activeOn
        for (int i = 0; i < table.getRowCount(); i++)
        {
            if (table.getValueAt(i, idx_EMPID).toString().equals(empid) &&
                table.getValueAt(i, idx_CURRENT_STATUS).toString().equals("ACTIVE"))
            {
                String activeFeeder = table.getValueAt(i, idx_FEEDER).toString();
                String activeSite = table.getValueAt(i, idx_SITE).toString();
                String activeMu = table.getValueAt(i, idx_MU).toString();
                activeOn = activeFeeder + activeSite + " " + activeMu;
                break;
            }
        }
        
        // set activeOn
        for (int i = 0; i < table.getRowCount(); i++)
        {
            if (table.getValueAt(i, idx_EMPID).toString().equals(empid))
            {
                table.setValueAt(activeOn, i, idx_ACTIVE_ON);
            }
        }
    }
    
    private boolean verifyCurrentStatus()
    {
        boolean output = true;
        int selectedRow = table.getSelectedRow();
        table.setValueAt(Oracle.getEmployeeActiveOn(getFormComponent(), table.getValueAt(selectedRow, idx_EMPID).toString()), selectedRow, idx_ACTIVE_ON);
        if (table.getValueAt(selectedRow, idx_ACTIVE_ON) != null)
        {
            String activeOn = table.getValueAt(selectedRow, idx_ACTIVE_ON).toString();
            String mu = table.getValueAt(selectedRow, idx_MU).toString();
            if (!activeOn.equals(feeder + site + " " + mu))
            {
                output = false;
            }
        }
        return output;
    }
    
    private boolean verifyCurrentDate(JComboBox comboBox)
    {
        boolean output = true;
        String text = ((JTextField) comboBox.getEditor().getEditorComponent()).getText();
        Date value;
        try
        {
            DateFormat df = new SimpleDateFormat("M/d/yyyy", Locale.ENGLISH);
            value = df.parse(text);
            
            Date curDatePlus30 = Misc.dateAddDays(curDate, 30);
            if (value.compareTo(curDatePlus30) > 0)
            {
                output = false;
            }
        }
        catch (ParseException ex)
        {
            output = false;
        }
        return output;
    }
    
    private boolean verifyPendingDate(JComboBox comboBox)
    {
        boolean output = true;
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1)
        {
            Date lastDate = (Date) table.getValueAt(selectedRow, idx_LAST_DATE);
            String text = ((JTextField) comboBox.getEditor().getEditorComponent()).getText();
            Date value;
            if (text != null && !text.equals(""))
            {
                try
                {
                    DateFormat df = new SimpleDateFormat("M/d/yyyy", Locale.ENGLISH);
                    value = df.parse(text);
                }
                catch (ParseException ex)
                {
                    output = false;
                }
            }
        }
        return output;
    }
    
    private boolean verifyExtraOff(String empid, String value)
    {
        boolean output;
        Calendar cal = Calendar.getInstance();
        cal.setTime(RegionData.getPayClose());
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        Date startDate = cal.getTime();
        cal.set(Calendar.MONTH, Calendar.DECEMBER);
        cal.set(Calendar.DAY_OF_MONTH, 31);
        Date endDate = cal.getTime();
        
        try
        {
            double amountEntered = Double.parseDouble(value);
            output = (Oracle.getExtraOffTaken(getFormComponent(), feeder, empid, startDate, endDate) <= amountEntered);
        }
        catch (NumberFormatException ex)
        {
            output = false;    
        }
        return output;
    }
    
    private void updateOtherPayrollCompleted(Component parentFrame, String mu, String empid, boolean payrollCompleted, String chgdBy, Date dateChanged)
    {
        if (Oracle.updateOtherPayrollCompleted(parentFrame, feeder, site, mu, empid, payrollCompleted, chgdBy, dateChanged))
        {
            for (int i = 0; i < table.getRowCount(); i++)
            {
                if (table.getValueAt(i, idx_EMPID).equals(empid) &&
                    table.getValueAt(i, idx_FEEDER).equals(feeder) &&
                    table.getValueAt(i, idx_SITE).equals(site) &&
                    !table.getValueAt(i, idx_MU).equals(mu))
                {
                    table.setValueAt(payrollCompleted, i, idx_STOP_PAYROLL_REPORTING);
                    table.setValueAt(chgdBy, i, idx_STOP_PAYROLL_CHGD_BY);
                    table.setValueAt(dateChanged, i, idx_STOP_PAYROLL_CHGD_DATE);
                }
            }
        }
    }
    
    public void changeEmployee(int selectedRow)
    {
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        updatePendingStatusCombo(Misc.objectToString(table.getValueAt(selectedRow, idx_CURRENT_STATUS)));
        updateDatabase();
        currentRow = table.convertRowIndexToModel(selectedRow);
    }
    
    private void clearFilter()
    {
        filterEnabled = false;
        filterColumnComboBox.setSelectedIndex(0);
        filterTextField.setText("");
        if (editType.equals("NORMAL"))
        {
            filterEmployeeStatusComboBox.setSelectedIndex(1);
        }
        else //editType.equals("DETAIL")
        {
            filterEmployeeStatusComboBox.setSelectedIndex(0);
        }
        filterEmployeeCoachComboBox.setSelectedIndex(0);
        filterEnabled = true;
    }
    
    private void processFilter()
    {
        if (table == null || !worker.isDone() || !filterEnabled)
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> textFilter;
        RowFilter<CustomTableModel, Object> dateFilter = null;
        RowFilter<CustomTableModel, Object> inputFilter;
        RowFilter<CustomTableModel, Object> employeeStatusFilter;
        RowFilter<CustomTableModel, Object> coachFilter = RowFilter.regexFilter(".*", idx_COACHES_MATCH);
        if (filterCoachDiscrepancies)
        {
            coachFilter = new RowFilter<CustomTableModel, Object>()
            {
                @Override
                public boolean include(RowFilter.Entry entry)
                {
                    return entry.getValue(idx_COACHES_MATCH).equals(false);
                }
            };
        }
        
        try
        {
            if (filterColumn == -1)
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
                }
            }
            else
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText(), filterColumn);
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()), filterColumn);
                }
            }
            employeeStatusFilter = RowFilter.regexFilter(employeeStatusFilterText, idx_CURRENT_STATUS);
            
            inputFilters.add(textFilter);
            if (dateFilter != null)
            {
                inputFilters.add(dateFilter);
            }
            inputFilter = RowFilter.orFilter(inputFilters);
            
            filters.add(inputFilter);
            filters.add(employeeStatusFilter);
            filters.add(coachFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
        }
    }
    
    private void updateDatabase()
    {
        if (table == null)
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0)
        {
            return;
        }
        if (employeeUpdated)
        {
            setCursor(Constants.HOURGLASS);
            Oracle.updateEmployeeTable(getFormComponent(),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_FEEDER)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_SITE)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_BAND)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_MU)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPID)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_AGENTID)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPLOYEE)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_COACH)).toUpperCase(Locale.ENGLISH),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_WEBPHONE_SUPERVISOR)).toUpperCase(Locale.ENGLISH),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_CURRENT_STATUS)),
                (Date)dataModel.getValueAt(currentRow, idx_CURRENT_EFFECTIVE_DATE),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_STOP_PAYROLL_REPORTING)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_STOP_PAYROLL_CHGD_BY)),
                (Date)dataModel.getValueAt(currentRow, idx_STOP_PAYROLL_CHGD_DATE),
                (Date)dataModel.getValueAt(currentRow, idx_NCS_DATE),
                (Date)dataModel.getValueAt(currentRow, idx_CHILD_BIRTH_DATE),
                Misc.objectToDouble(dataModel.getValueAt(currentRow, idx_EXTRA_OFF_DAYS)),
                (Date)dataModel.getValueAt(currentRow, idx_BEGIN_DATE),
                (Date)dataModel.getValueAt(currentRow, idx_LAST_DATE),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_PENDING_STATUS)),
                (Date)dataModel.getValueAt(currentRow, idx_PENDING_EFFECTIVE_DATE),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_PARTTIME_FLAG)),
                Misc.objectToDouble(dataModel.getValueAt(currentRow, idx_SHIFT)),
                Misc.objectToDouble(dataModel.getValueAt(currentRow, idx_HOURS_PER_WEEK)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_OTHER_PAYROLL_ID)),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_BILINGUAL_FLAG)),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_FOUR_DAY)),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_SIX_DAY)),
                UserData.getUUID()
            );
            setCursor(Constants.NORMAL);
            employeeUpdated = false;
            currentRow = table.convertRowIndexToModel(selectedRow);
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        formClosing = true;
        if (table != null && table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        
        updateDatabase();
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LOAEmployeesButton;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton clearPendingButton;
    private javax.swing.JPanel controlPanel;
    private javax.swing.JPanel controlPanel2;
    private javax.swing.JButton deleteRecordButton;
    private javax.swing.JButton employeeHistoryButton;
    private javax.swing.JScrollPane employeesScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel fillerClearLabel2;
    private javax.swing.JButton filterClearButton;
    private javax.swing.JLabel filterClearLabel;
    private javax.swing.JComboBox<String> filterColumnComboBox;
    private javax.swing.JLabel filterColumnTextLabel;
    private javax.swing.JComboBox<String> filterEmployeeCoachComboBox;
    private javax.swing.JLabel filterEmployeeCoachLabel;
    private javax.swing.JComboBox<String> filterEmployeeStatusComboBox;
    private javax.swing.JLabel filterEmployeeStatusLabel;
    private javax.swing.JPanel filterLabelsPanel;
    private javax.swing.JTextField filterTextField;
    private javax.swing.JLabel filterTextLabel;
    private javax.swing.JPanel filtersPanel;
    private javax.swing.JPanel gridPanel;
    private javax.swing.JButton helpButton;
    private javax.swing.JPanel highlightPanel;
    private javax.swing.JPanel highlightPanel2;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JLabel multiSelectLabel;
    private javax.swing.JPanel multiSelectPanel;
    private javax.swing.JPanel normalPanel;
    private javax.swing.JCheckBox powerUserOverrideCheckBox;
    private javax.swing.JButton printButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton separatedEmployeesButton;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel1;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton transferEmployeesButton;
    private javax.swing.JButton updateAllCoachesButton;
    private javax.swing.JButton updateCoachButton;
    private javax.swing.JButton updatePayrollIDsButton;
    private javax.swing.JButton updateStatusButton;
    // End of variables declaration//GEN-END:variables
}
