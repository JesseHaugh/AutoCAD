/**
 * This form can be opened in several different ways.
 *   These are determined by the constructor parameter string editType, which can be the following values:
 *     NORMAL           - Displays all employees on a schedule.
 *     IMPORTED         - Indicates that the schedule has recently been imported - Either opens ImportNotifications or proceeds using NORMAL editType as above.
 *     DETAIL           - Displays a detailed view on a single employee.
 *     PRIOR            - Displays all employees for all dates that are not approved and have dates prior to the current payroll period.
 *     UPDATE           - Displays all employees for all dates that have status of 'Updated'.
 *     REVIEW UPDATES   - Indicates that updates are being reviewed - Either opens ImportUpdateMessages or proceeds using UPDATE editType as above.
 *     BYEMPLOYEE       - Same as DETAIL, but coming from the TimeReportingByEmployee or PayrollPeriodApproval forms.
 *     APPR READ ONLY   - Same as DETAIL, but no records are locked & all data is read only.
 *     CHANGES          - Displays all unapproved changes in the selected date range (current pay period)
 */
package tvi.gui;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import tvicore.objects.HoursEditor;
import tvicore.objects.MinutesEditor;
import tvicore.objects.TableCellListener;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import javax.swing.text.JTextComponent;
import tvicore.dao.AbsenceCodeRecord;
import tvicore.dao.AttendanceCodeRecord;
import tvicore.objects.CustomTableModel;
import tvicore.dao.ExtraPaymentCodeRecord;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.reports.PdfReports;
import tvicore.dao.ReasonCodeRecord;
import tvicore.dao.ShiftRecord;
import tvicore.resources.Resources;

public final class TimeReporting extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile TimeReporting instance;
    
    private final String feeder;
    private final String site;
    private final String mu;
    private final String empid;
    private final Date startDate;
    private final Date endDate;
    private final String union;
    private final String editType;
    
    private static final Semaphore refreshTimeReportingLock = new Semaphore(1, true);
    
    JTable timeTotalsTable = new JTable();
    JTable absencesTable = new JTable();
    JTable extraPaymentsTable = new JTable();
    JTable attendancesTable = new JTable();
    CustomTableModel timeTotalsData;
    CustomTableModel absencesData;
    CustomTableModel extraPaymentsData;
    CustomTableModel attendancesData;
    TableSwingWorker timeTotalsWorker;
    TableSwingWorker absencesWorker;
    TableSwingWorker extraPaymentsWorker;
    TableSwingWorker attendancesWorker;
    
    private String empidFilterText = ".*";
    private String reportingDateFilterText = ".*";
    private String recordTypeFilterText = "Current";
    private TableRowSorter<CustomTableModel> absencesSorter;
    private TableRowSorter<CustomTableModel> extraPaymentsSorter;
    private TableRowSorter<CustomTableModel> attendancesSorter;
    
    String currentCodeType = "Absence Detail";
    JComboBox<String> commentCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> costCenterCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
    JComboBox<String> reasonCodeCombo = new JComboBox<>();
    JComboBox<String> absenceCodeCombo = new JComboBox<>();
    JComboBox<String> extraPaymentCodeCombo = new JComboBox<>();
    JComboBox<String> attendanceCodeCombo = new JComboBox<>();
    
    int timeTotalsRow = -1;
    boolean employeeUpdated = false;
    boolean deletingEmployee = false;
    
    Date selectedDate;
    String selectedMU;
    int selectedTOTALVIEWID;
    int employeeCount;
    String employee = "";
    String empidSelected = "";
    ArrayList<String> absencesChanged = new ArrayList<>();
    ArrayList<String> extraPaymentsChanged = new ArrayList<>();
    ArrayList<String> attendancesChanged = new ArrayList<>();
    ArrayList<String> changedEmpidList = new ArrayList<>();
    
    boolean readOnly = false;
    boolean changingEmployees = false;
    
    List<Integer> hiddenColumns = new ArrayList<>();
    // Define index variables to reference columns in detail section TIME TOTALS
    // ANY CHANGES MADE HERE NEED TO BE REFLECTED IN ADDEMPLOYEES
    final static int idx_EMPID                     = 0;
    final static int idx_AGENTID                   = 1;
    final static int idx_DWS                       = 2;
    final static int idx_HOLIDAY_FLAG              = 3;
    final static int idx_ABSENCE_READY             = 4;
    final static int idx_TIME_WORKED_READY         = 5;
    final static int idx_TIME_TOTALS_READY         = 6;
    final static int idx_MESSAGE                   = 7;
    final static int idx_APPROVED_BY               = 8;
    final static int idx_DATE_APPROVED             = 9;
    final static int idx_OTHERFLAGS                = 10;
    final static int idx_MANUAL_CMP_BY             = 11;
    final static int idx_TO_ELINK_DATE_TIME        = 12;
    final static int idx_COMP_OR_LOAD_DATE         = 13;
    final static int idx_LOAD_STATUS               = 14;
    final static int idx_DATE_TV_MODIFIED          = 15;
    final static int idx_TOTALVIEWID               = 16;
    final static int idx_MU                        = 17;
    final static int idx_DIFF_SOURCE               = 18;
    final static int idx_REPORTING_DATE            = 19;
    final static int idx_APPR                      = 20;
    final static int idx_STATUS                    = 21;
    final static int idx_EMPLOYEE                  = 22;
    final static int idx_SHIFT                     = 23;
    final static int idx_REG                       = 24;
    final static int idx_OVERTIME                  = 25;
    final static int idx_OT_1030                   = 26;
    final static int idx_OT_8115                   = 27;
    final static int idx_COMPUTED_OT               = 28;
    final static int idx_CALL_OVERLAP              = 29;
    final static int idx_CALL_OUT                  = 30;
    final static int idx_PREM                      = 31;
    final static int idx_FLEX_HRS                  = 32;
    final static int idx_EVENING_HOURS             = 33;
    final static int idx_NIGHT_HOURS               = 34;
    final static int idx_SUND                      = 35;
    final static int idx_HOLIDAY_WORKED            = 36;
    final static int idx_REGTOTAL                  = 37;
    final static int idx_ABSENCE_TOTAL             = 38;
    final static int idx_EXTRAPAY_FLAG             = 39;
    final static int idx_ATTEND_FLAG               = 40;
    final static int idx_TARDY_FLAG                = 41;
    final static int idx_RD                        = 42;
    final static int idx_BILINGUAL_FLAG            = 43;
    final static int idx_MA_FLAG                   = 44;
    final static int idx_MEAL_ALLOWANCE            = 45;
    final static int idx_DIFF_SOURCE_DISP          = 46;
    final static int idx_DIFFNIGHT                 = 47;
    final static int idx_SHIFT_TRADED              = 48;
    final static int idx_CARFARE                   = 49;
    final static int idx_CARFARE_DWS               = 50;
    final static int idx_DIFF_060                  = 51;
    final static int idx_DIFF_150                  = 52;
    final static int idx_DIFF_185                  = 53;
    final static int idx_DIFF_200                  = 54;
    final static int idx_DIFF_220                  = 55;
    final static int idx_DIFF_270                  = 56;
    final static int idx_DIFF_300                  = 57;
    final static int idx_DIFF_600                  = 58;
    final static int idx_DIFF_800                  = 59;
    final static int idx_DIFF_900                  = 60;
    final static int idx_DIFF_1_PERCENT            = 61;
    final static int idx_DIFF_1_5_PERCENT          = 62;
    final static int idx_DIFF_2_PERCENT            = 63;
    final static int idx_DIFF_2_5_PERCENT          = 64;
    final static int idx_DIFF_3_PERCENT            = 65;
    final static int idx_GAP                       = 66;
    final static int idx_SIXTH_DAY                 = 67;
    final static int idx_OVERTIME_REFUSED          = 68;
    final static int idx_OVERTIME_NOT_AVAILABLE    = 69;
    final static int idx_PARTTIME_FLAG             = 70;
    final static int idx_LOCKED_BY                 = 71;
    final static int idx_RECORD_TYPE               = 72;
    // Define index variables to reference columns in detail section ABSENCES
    final static int idx_Abs_EMPID                 = 0;
    final static int idx_Abs_REPORTING_DATE        = 1;
    final static int idx_Abs_RECKEY                = 2;
    final static int idx_Abs_CHGD_BY               = 3;
    final static int idx_Abs_DATE_CHGD             = 4;
    final static int idx_Abs_DEL_RECORD            = 5;
    final static int idx_Abs_SAP_CODE              = 6;
    final static int idx_Abs_CODE_DESC             = 7;
    final static int idx_Abs_REASON_CODE_DESC      = 8;
    final static int idx_Abs_HOURS_TREC            = 9;
    final static int idx_Abs_MINS_TREC             = 10;
    final static int idx_Abs_DAYS                  = 11;
    final static int idx_Abs_COMMENT               = 12;
    final static int idx_Abs_RECORD_TYPE           = 13;
    // Define index variables to reference columns in detail section ATTENDANCES
    final static int idx_Att_EMPID                 = 0;
    final static int idx_Att_REPORTING_DATE        = 1;
    final static int idx_Att_RECKEY                = 2;
    final static int idx_Att_CHGD_BY               = 3;
    final static int idx_Att_DATE_CHGD             = 4;
    final static int idx_Att_DEL_RECORD            = 5;
    final static int idx_Att_SAP_CODE              = 6;
    final static int idx_Att_CODE_DESC             = 7;
    final static int idx_Att_HOURS_AREC            = 8;
    final static int idx_Att_MINS_AREC             = 9;
    final static int idx_Att_DAYS                  = 10;
    final static int idx_Att_COST_CENTER           = 11;
    final static int idx_Att_LOCATION_CODE         = 12;
    final static int idx_Att_ACTIVITY              = 13;
    final static int idx_Att_EC                    = 14;
    final static int idx_Att_PROJECT_NUMBER        = 15;
    final static int idx_Att_FRC                   = 16;
    final static int idx_Att_TAX_AREA              = 17;
    final static int idx_Att_RECORD_TYPE           = 18;
    // Define index variables to reference columns in detail section EXTRA PAYMENTS
    final static int idx_Ext_EMPID                 = 0;
    final static int idx_Ext_REPORTING_DATE        = 1;
    final static int idx_Ext_RECKEY                = 2;
    final static int idx_Ext_CHGD_BY               = 3;
    final static int idx_Ext_DATE_CHGD             = 4;
    final static int idx_Ext_DEL_RECORD            = 5;
    final static int idx_Ext_SAP_CODE              = 6;
    final static int idx_Ext_CODE_DESC             = 7;
    final static int idx_Ext_AMOUNT_EREC           = 8;
    final static int idx_Ext_MINS_EREC             = 9;
    final static int idx_Ext_COST_CENTER           = 10;
    final static int idx_Ext_LOCATION_CODE         = 11;
    final static int idx_Ext_ACTIVITY              = 12;
    final static int idx_Ext_PROJECT_NUMBER        = 13;
    final static int idx_Ext_AMOUNT_TYPE           = 14;
    final static int idx_Ext_RECORD_TYPE           = 15;
    
    Comparator<String> statusComparator = new Comparator<String>()
    {
        @Override
        public int compare(String s1, String s2)
        {
            int c1;
            int c2;
            switch (s1)
            {
                case "Updated":
                    c1 = 1;
                    break;
                case "Error":
                    c1 = 2;
                    break;
                case "Not Ready":
                    c1 = 3;
                    break;
                case "Separated":
                    c1 = 4;
                    break;
                case "Not Active":
                    c1 = 5;
                    break;
                case "Pending":
                    c1 = 6;
                    break;
                case "Ready":
                    c1 = 7;
                    break;
                default:
                    c1 = 8;
                    break;
            }
            switch (s2)
            {
                case "Updated":
                    c2 = 1;
                    break;
                case "Error":
                    c2 = 2;
                    break;
                case "Not Ready":
                    c2 = 3;
                    break;
                case "Separated":
                    c2 = 4;
                    break;
                case "Not Active":
                    c2 = 5;
                    break;
                case "Pending":
                    c2 = 6;
                    break;
                case "Ready":
                    c2 = 7;
                    break;
                default:
                    c2 = 8;
                    break;
            }
            return c2 - c1;
        }
    };
    
    private Action deleteRecord = new AbstractAction()
    {
        @Override
        @SuppressFBWarnings(value="DB_DUPLICATE_SWITCH_CLAUSES", justification="index values are the same for all tables, but may not be in the future.")
        public void actionPerformed(ActionEvent e)
        {
            JTable table = (JTable)e.getSource();
            int column_code;
            int column_reckey;
            if (table.isEditing())
            {
                table.getCellEditor().stopCellEditing();
            }
            String tableName = table.getName();
            switch (tableName)
            {
                case "absencesTable":
                    column_code = idx_Abs_CODE_DESC;
                    column_reckey = idx_Abs_RECKEY;
                    break;
                case "attendancesTable":
                    column_code = idx_Att_CODE_DESC;
                    column_reckey = idx_Att_RECKEY;
                    break;
                case "extraPaymentsTable":
                    column_code = idx_Ext_CODE_DESC;
                    column_reckey = idx_Ext_RECKEY;
                    break;
                default:
                    Misc.msgbox(getFormComponent(), "Unhandled table name, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                    return;
            }
            int modelRow = Integer.parseInt(e.getActionCommand());
            String deleteCode = "";
            if (table.getModel().getValueAt(modelRow, column_code) != null)
            {
                deleteCode = Misc.objectToString(table.getModel().getValueAt(modelRow, column_code));
            }
            String recKey = Misc.objectToString(table.getModel().getValueAt(modelRow, column_reckey));
            if (Misc.msgbox(getFormComponent(), "DELETE " + deleteCode + "?", "Deleting Record", 1, 2, 1))
            {
                setCursor(Constants.HOURGLASS);
                switch (tableName)
                {
                    case "absencesTable":
                        Oracle.deleteAbsence(getFormComponent(), empidSelected, selectedDate, recKey);
                        flagTimeTotals();
                        if (absencesChanged.contains(recKey))
                        {
                            absencesChanged.remove(recKey);
                        }
                        break;
                    case "attendancesTable":
                        Oracle.deleteAttendance(getFormComponent(), empidSelected, selectedDate, recKey);
                        flagTimeTotals();
                        if (attendancesChanged.contains(recKey))
                        {
                            attendancesChanged.remove(recKey);
                        }
                        break;
                    case "extraPaymentsTable":
                        Oracle.deleteExtraPayment(getFormComponent(), empidSelected, selectedDate, recKey);
                        flagTimeTotals();
                        if (extraPaymentsChanged.contains(recKey))
                        {
                            extraPaymentsChanged.remove(recKey);
                        }
                        break;
                    default:
                        // do nothing, any exceptions would be caught above
                }
                ((CustomTableModel)table.getModel()).removeRow(modelRow);
            }
            setCursor(Constants.NORMAL);
        }
    };
    
    public static void reloadCostCenterComboInstance()
    {
        if (instance != null)
        {
            instance.reloadCostCenterCombo();
        }
    }
    
    private void reloadCostCenterCombo()
    {
        if (costCenterCombo.getItemCount() > 0)
        {
            costCenterCombo.removeAllItems();
            costCenterCombo.addItem("");
        }
        ResultSetWrapper results = Oracle.getResultsCostCenters(getFormComponent(), feeder, site);
        ResultSet rs = results.getResultSet();
        try
        {
            while (rs.next())
            {
                costCenterCombo.addItem(rs.getString("COST_CENTER"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error reloading cost centers.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static void reloadCommentComboInstance()
    {
        if (instance != null)
        {
            instance.reloadCommentCombo();
        }
    }
    
    private void reloadCommentCombo()
    {
        if (commentCombo.getItemCount() > 0)
        {
            commentCombo.removeAllItems();
        }
        
        ResultSetWrapper results = Oracle.getResultsComments(getFormComponent(), feeder, site);
        ResultSet rs = results.getResultSet();
        
        try
        {
            commentCombo.addItem("");
            while (rs.next())
            {
                commentCombo.addItem(rs.getString("REASON_TEXT"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error reloading comments.");
        }
        finally
        {
            results.close();
        }
    }
    
    public static boolean focusInstance()
    {
        if (instance != null)
        {
            instance.toFront();
        }
        return instance != null;
    }
    
    public synchronized static TimeReporting getInstance(Component parentFrame, String feeder, String site, String mu, String empid, Date startDate, Date endDate, String union, String editType)
    {
        if (ImportNotifications.exists())
        {
            Misc.msgbox(parentFrame, "Cannot open time reporting screen at this time, an Imported schedule is being opened.\nFinish opening the current schedule and then close it to proceed.", "Imported schedule opening.", 1, 1, 1);
            return null; // do not open time reporting
        }
        else if (ImportUpdateMessages.exists())
        {
            Misc.msgbox(parentFrame, "Cannot open time reporting screen at this time, a Review Updates screen is being opened.\nFinish opening and then close it to proceed.", "Imported schedule opening.", 1, 1, 1);
            return null; // do not open time reporting
        }
        else if (instance != null)
        {
            if (Misc.objectEquals(instance.feeder, feeder) &&
                Misc.objectEquals(instance.site, site) &&
                Misc.objectEquals(instance.mu, mu) &&
                Misc.objectEquals(instance.empid, empid) &&
                Misc.objectEquals(instance.startDate, startDate) &&
                Misc.objectEquals(instance.endDate, endDate) &&
                Misc.objectEquals(instance.union, union) &&
                Misc.objectEquals(instance.editType, editType))
            {
                instance.toFront();
            }
            else
            {
                String msg = "<html>Another schedule is already open, you must apply any"
                           + "<br>active changes and close it before opening another."
                           + "<br><b>The open schedule will now be restored.</b></html>";
                Misc.msgbox(parentFrame, msg, "Opening existing schedule window", 1, 1, 1);
                instance.toFront();
            }
        }
        
        if (instance == null)
        {
            if (editType.equals("IMPORTED"))
            {
                if (UserData.getUserAccessLevel().equals("READONLY"))
                {
                    Misc.msgbox(parentFrame, "Cannot open an 'Imported' schedule with a read only profile until it has been reviewed.", "Read Only profile restriction", 1, 1, 1);
                    return null; // do not open time reporting
                }
                if (RegionData.getNewFeature())
                {
                    if(Oracle.getNumRosterNotifications(parentFrame, feeder, site, mu, startDate) > 0)
                    {
                        ImportRosterNotifications.getInstance(parentFrame, feeder, site, mu, startDate, union, UserData.getUUID(), "Imported");
                        return null;
                    }
                    else
                    {
                        Oracle.setRecordsUnlocked(parentFrame, feeder, site, mu, null, startDate, endDate, "NORMAL", "TVI");
                        Oracle.updateScheduleStatus(parentFrame, feeder, site, mu, startDate, endDate, "NORMAL");
                        editType = "NORMAL"; // no items to review, open TimeReporting with "NORMAL" editType
                    }
                    
                }    
                else
                {
                    int numberOfTransferEmps = 0;
                    int numberOfOffDays = 0;
                    int numberOfDuplicateEmps = 0;
                    int numberOfInactiveEmps = 0;
                
                    List<Integer> numberOfNotifications = Oracle.getImportNotifications(parentFrame, feeder, site, mu, startDate);
                    if (numberOfNotifications.size() >= 4)
                    {
                        numberOfTransferEmps = numberOfNotifications.get(0);
                        numberOfOffDays = numberOfNotifications.get(1);
                        numberOfDuplicateEmps = numberOfNotifications.get(2);
                        numberOfInactiveEmps = numberOfNotifications.get(3);
                    }
                    if (numberOfTransferEmps + numberOfOffDays + numberOfDuplicateEmps + numberOfInactiveEmps > 0)
                    {
                        // Items need review, open ImportNotifications:
                        ImportNotifications.getInstance(parentFrame, feeder, site, mu, startDate, union, numberOfTransferEmps, numberOfOffDays, numberOfDuplicateEmps, numberOfInactiveEmps);
                        return null;
                    }
                    else
                    {
                        editType = "NORMAL"; // no items to review, open TimeReporting with "NORMAL" editType
                    }
                }
            }
            else if (editType.equals("REVIEW UPDATES"))
            {
                ResultSetWrapper resultsUpdateMsgs = Oracle.getResultsMessagesUpdated(parentFrame, feeder, site, mu);
                try
                {
                    if (resultsUpdateMsgs.getResultSet().isBeforeFirst())
                    {
                        ImportUpdateMessages.getInstance(parentFrame, feeder, site, RegionData.getSiteUnion(), resultsUpdateMsgs);
                        return null;
                    }
                    else
                    {
                        editType = "UPDATE"; // no items to review, open TimeReporting with "UPDATE" editType
                        resultsUpdateMsgs.close();
                    }
                }
                catch (SQLException ex)
                {
                    Misc.errorMsgDatabase(parentFrame, ex, false, "SQL Error checking updated schedule messages.");
                }
            }
            
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new TimeReporting(feeder, site, mu, empid, startDate, endDate, union, editType);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    public TimeReporting(String feeder, String site, String mu, String empid, Date startDate, Date endDate, String union, String editType)
    {
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.empid = empid;
        this.startDate = startDate;
        this.endDate = endDate;
        this.union = Misc.objectToString(union);
        this.editType = editType;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            testDBLabel.setVisible(true);
        }
        else
        {
            testDBLabel.setVisible(false);
        }
        if (RegionData.getNewFeature())
        {
            addEmployeeButton.setVisible(false);
            changeEmpidButton.setVisible(false); 
            employeeDetailButton.setText("Employee Detail");
            employeeDetailButton.setPreferredSize(new java.awt.Dimension(135, 30));
            
            deleteEmployeeButton.setText("Delete Employee");
            deleteEmployeeButton.setPreferredSize(new java.awt.Dimension(135, 30));
            
            employeeMaintenanceButton.setText("Employee Maint");
            employeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(135, 30));
            
            verifReportButton.setText("Verif Report");
            verifReportButton.setPreferredSize(new java.awt.Dimension(135, 30));
        }
        else
        {
            importErrorsButton.setVisible(false);
        }
        deletingEmployee = false;
        if (editType.equals("NORMAL"))
        {
            Misc.setLastNormalScheduleDate(startDate);
        }
        
        dayOfWeekLabel.setText("");
        reportingDateLabel.setText("");
        feederSiteLabel.setText(feeder + ", Site " + site);
        muLabel.setText("MU: " + mu);
        unionLabel.setText("Union: " + union);
        employeeLabel.setText("");
        empidLabel.setText("");
        holidayFlag.setVisible(false);
        readOnlyFlag.setVisible(false);
        messageArea.setVisible(false);
        timeTotalsScrollPane.setVisible(false);
        
        String title = editType;
        Color color = new Color(255, 255, 255);
        switch (editType)
        {
            case "NORMAL":
                title = "MU Schedule: Displaying all employees for the selected date.";
                color = Constants.LTBLUE;
                break;
            case "DETAIL":
            case "BYEMPLOYEE":
            case "APPR READ ONLY":
                title = "Employee Detail: Displaying a detailed view for the selected employee.";
                color = Constants.LTGREEN;
                break;
            case "PRIOR":
                title = "Prior Approval: Displaying all unapproved records for dates prior to the current payroll period.";
                color = Constants.LTYELLOW;
                break;
            case "UPDATE":
                title = "Updated Employees: Displaying all employees with a status of 'Updated'.";
                color = Constants.LTORANGE;
                break;
            case "CHANGES":
                title = "Approving TVI Changes: Displaying all unapproved changes made in TVI after import, in the current payroll period.";
                color = Constants.LTRED;
                break;
            default:
                Misc.msgbox(getFormComponent(), "Unhandled Time Reporting form edit type, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                closeForm();
        }
        editTypeTextField.setText(title);
        editTypeTextField.setBackground(color);
        
        numOfEmpsLabel.setVisible(false);
        dwsDisplay.setEditable(false);
        startStopButton.setVisible(true);
        if (!UserData.getUserType().equals("POWER"))
        {
            toggleSendButton1.setVisible(false);
            toggleSendButton2.setVisible(false);
        }
        reloadCostCenterCombo();
        reloadCommentCombo();
        
        setHiddenColumns();
        initializeListeners();
    }
    
    public static boolean exists()
    {
        return instance != null;
    }
    
    public static String getEditType()
    {
        if (instance != null)
        {
            return instance.editType;
        }
        else
        {
            return null;
        }
    }
    
    /***************************************************************************
    * setHiddenColumns
    * Called by the constructor when the form is first generated.
    * Determines which columns to display in the TimeTotalsTable
    * - depends on the feeder and union
    ***************************************************************************/
    private void setHiddenColumns()
    {
        // Create a list of all columns
        List<Integer> allColumns = new ArrayList<>();
        for (int i = idx_EMPID; i <= idx_RECORD_TYPE; i++)
        {
            allColumns.add(i);
        }
        // Create a list of columns visible for all feeders/unions
        List<Integer> columnsToShow = new ArrayList<>(Arrays.asList
        (
            idx_REPORTING_DATE, idx_APPR, idx_STATUS, idx_EMPLOYEE, idx_SHIFT, idx_REG, idx_OVERTIME, idx_REGTOTAL, idx_ABSENCE_TOTAL, idx_TARDY_FLAG,
            idx_PARTTIME_FLAG, idx_LOCKED_BY
        ));
        if (!Arrays.asList("NORMAL", "IMPORTED").contains(editType))
        {
            columnsToShow.add(idx_MU);
        }
        if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
        {
            columnsToShow.add(idx_RECORD_TYPE);
        }
        // Add conditional columns for their respective feeders/unions
        switch (feeder)
        {
            case "MEX":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_OT_1030, idx_OT_8115, idx_COMPUTED_OT, idx_CALL_OVERLAP, idx_CALL_OUT, idx_ATTEND_FLAG, idx_SUND, idx_HOLIDAY_WORKED
                ));
                break;
            case "CZE":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_CALL_OUT, idx_FLEX_HRS, idx_EXTRAPAY_FLAG, idx_NIGHT_HOURS, idx_PREM, idx_SUND, idx_MEAL_ALLOWANCE, idx_HOLIDAY_WORKED
                ));
                break;
            case "POL":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_OVERTIME, idx_OT_1030, idx_OT_8115, idx_COMPUTED_OT, idx_CALL_OUT, idx_FLEX_HRS, idx_EXTRAPAY_FLAG, idx_EVENING_HOURS, idx_NIGHT_HOURS, idx_SUND
                ));
                break;
            case "SVK":
                columnsToShow.addAll(Arrays.asList
                (
                    idx_CALL_OUT, idx_FLEX_HRS, idx_EXTRAPAY_FLAG, idx_EVENING_HOURS, idx_NIGHT_HOURS, idx_PREM, idx_SUND, idx_MEAL_ALLOWANCE, idx_HOLIDAY_WORKED
                ));
                break;
            default:
                columnsToShow.addAll(Arrays.asList
                (
                    idx_CALL_OUT, idx_EXTRAPAY_FLAG, idx_ATTEND_FLAG, idx_EVENING_HOURS, idx_NIGHT_HOURS, idx_RD, idx_MA_FLAG, idx_DIFF_SOURCE_DISP, idx_DIFFNIGHT,
                    idx_OVERTIME_REFUSED, idx_OVERTIME_NOT_AVAILABLE, idx_MEAL_ALLOWANCE
                ));
                break;
        }
        // Subtract the visible columns from the list of all columns to get the list of columns to hide
        hiddenColumns = Misc.getHiddenColumns(allColumns, columnsToShow);
    }
    
    /***************************************************************************
    * initializeListeners
    * • Called by the TimeReporting constructor when the form is first generated.
    * Creates the popupMenu listeners
    * - When the reason code cell is being edited, a comboBox is displayed;
    *   popupMenuWilBecomeInvisible is invoked when the comboBox stops displaying,
    *   which then automatically starts editing the next cell for the user.
    ***************************************************************************/
    private void initializeListeners()
    {
        absenceCodeCombo.addPopupMenuListener(new PopupMenuListener()
        {
            @Override
            public void popupMenuWillBecomeInvisible(PopupMenuEvent e)
            {
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        String sapCode = absenceCodeCombo.getSelectedItem().toString().substring(0, 4);
                        absencesTable.setValueAt(sapCode, absencesTable.getSelectedRow(), idx_Abs_SAP_CODE);
                        if (reasonCodeCombo.getItemCount() > 1)
                        {
                            absencesTable.changeSelection(absencesTable.getSelectedRow(), idx_Abs_REASON_CODE_DESC, false, false);
                            absencesTable.editCellAt(absencesTable.getSelectedRow(), idx_Abs_REASON_CODE_DESC);
                            reasonCodeCombo.showPopup();
                            reasonCodeCombo.requestFocusInWindow();
                        }
                        else
                        {
                            
                            if (Arrays.asList("MTDY", "TOL1", "TDY1").contains(sapCode))
                            {
                                absencesTable.changeSelection(absencesTable.getSelectedRow(), idx_Abs_MINS_TREC, false, false);
                                absencesTable.editCellAt(absencesTable.getSelectedRow(), idx_Abs_MINS_TREC);
                            }
                            else
                            {
                                absencesTable.changeSelection(absencesTable.getSelectedRow(), idx_Abs_HOURS_TREC, false, false);
                                absencesTable.editCellAt(absencesTable.getSelectedRow(), idx_Abs_HOURS_TREC);
                            }
                            
                            JTextComponent jtc = (JTextComponent) absencesTable.getEditorComponent();
                            jtc.requestFocusInWindow();
                            jtc.selectAll();
                        }
                    }
                });
            }
            @Override
            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                // no change
            }
            @Override
            public void popupMenuCanceled(PopupMenuEvent e) {
                // no change
            }
        });
        reasonCodeCombo.addPopupMenuListener(new PopupMenuListener()
        {
            @Override
            public void popupMenuWillBecomeInvisible(PopupMenuEvent e)
            {
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        absencesTable.changeSelection(absencesTable.getSelectedRow(), idx_Abs_HOURS_TREC, false, false);
                        absencesTable.editCellAt(absencesTable.getSelectedRow(), idx_Abs_HOURS_TREC);
                        JTextComponent jtc = (JTextComponent) absencesTable.getEditorComponent();
                        if (jtc != null)
                        {
                            jtc.requestFocusInWindow();
                            jtc.selectAll();
                        }
                    }
                });
            }
            @Override
            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                // no change
            }
            @Override
            public void popupMenuCanceled(PopupMenuEvent e) {
                // no change
            }
        });
        extraPaymentCodeCombo.addPopupMenuListener(new PopupMenuListener()
        {
            @Override
            public void popupMenuWillBecomeInvisible(PopupMenuEvent e)
            {
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        String sapCode = extraPaymentCodeCombo.getSelectedItem().toString().substring(0, 4);
                        extraPaymentsTable.setValueAt(sapCode, extraPaymentsTable.getSelectedRow(), idx_Ext_SAP_CODE);
                        extraPaymentsTable.changeSelection(extraPaymentsTable.getSelectedRow(), idx_Ext_AMOUNT_EREC, false, false);
                        extraPaymentsTable.editCellAt(extraPaymentsTable.getSelectedRow(), idx_Ext_AMOUNT_EREC);
                        JTextComponent jtc = (JTextComponent) extraPaymentsTable.getEditorComponent();
                        jtc.requestFocusInWindow();
                        jtc.selectAll();
                    }
                });
            }
            @Override
            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                // no change
            }
            @Override
            public void popupMenuCanceled(PopupMenuEvent e) {
                // no change
            }
        });
        attendanceCodeCombo.addPopupMenuListener(new PopupMenuListener()
        {
            @Override
            public void popupMenuWillBecomeInvisible(PopupMenuEvent e)
            {
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        String sapCode = absenceCodeCombo.getSelectedItem().toString().substring(0, 4);
                        absencesTable.setValueAt(sapCode, absencesTable.getSelectedRow(), idx_Abs_SAP_CODE);
                        if (feeder.equals("CZE"))
                        {
                            attendancesTable.changeSelection(attendancesTable.getSelectedRow(), idx_Att_MINS_AREC, false, false);
                            attendancesTable.editCellAt(attendancesTable.getSelectedRow(), idx_Att_MINS_AREC);
                        }
                        else
                        {
                            attendancesTable.changeSelection(attendancesTable.getSelectedRow(), idx_Att_HOURS_AREC, false, false);
                            attendancesTable.editCellAt(attendancesTable.getSelectedRow(), idx_Att_HOURS_AREC);
                        }
                        JTextComponent jtc = (JTextComponent) attendancesTable.getEditorComponent();
                        jtc.requestFocusInWindow();
                        jtc.selectAll();
                    }
                });
            }
            @Override
            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
                // no change
            }
            @Override
            public void popupMenuCanceled(PopupMenuEvent e) {
                // no change
            }
        });
    }
    
    private void flagTimeTotals()
    {
        employeeUpdated = true;
        if (timeTotalsRow > -1)
        {
            if (Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS)).equals("Completed"))
            {
                timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
            }
        }
        timeTotalsData.setValueAt("", timeTotalsRow, idx_APPROVED_BY);
        timeTotalsData.setValueAt("", timeTotalsRow, idx_DATE_APPROVED);
        timeTotalsData.setValueAt("N", timeTotalsRow, idx_APPR);
    }
    
    /***************************************************************************
    * reloadReasonCodeCombo
    * • Called by fillAbsences, fillAttendances when the selected time reporting code is changed
    * Populates the reasonCodeCombo comboBox with the appropriate reason codes
    ***************************************************************************/
    private void reloadReasonCodeCombo(String sapCode)
    {
        if (reasonCodeCombo.getItemCount() > 0)
        {
            reasonCodeCombo.removeAllItems();
        }
        reasonCodeCombo.addItem("");
        for (ReasonCodeRecord reason : RegionData.getReasonCodes())
        {
            if (sapCode.equals(reason.getSapCode()) &&
                reason.getSapReasonCode() != null &&
                reason.getSapReasonCode().length() > 0 &&
                Misc.checkUnionFlag(feeder, reason.getUnionFlags(), union))
            {
                reasonCodeCombo.addItem(reason.getSapReasonCode() + "  -  " + reason.getDescription());
            }
        }
        reasonCodeCombo.setMaximumRowCount(30);
    }
    
    /***************************************************************************
    * changeEmployee
    * • Called to change the selected timeTotals row
    * @param selectedRow
    ***************************************************************************/
    private void changeEmployee(int selectedRow)
    {
        if (readOnly || UserData.getUserAccessLevel().equals("READONLY"))
        {
            moveToNewEmployee(selectedRow);
            return;
        }
        if (timeTotalsRow != -1)
        {
            if (!timeTotalsTable.getValueAt(timeTotalsRow, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                moveToNewEmployee(selectedRow);
                return;
            }
        }
        if (absencesTable.isEditing())
        {
            absencesTable.getCellEditor().stopCellEditing();
        }
        if (attendancesTable.isEditing())
        {
            attendancesTable.getCellEditor().stopCellEditing();
        }
        if (extraPaymentsTable.isEditing())
        {
            extraPaymentsTable.getCellEditor().stopCellEditing();
        }
        if (timeTotalsTable.isEditing())
        {
            timeTotalsTable.getCellEditor().stopCellEditing();
        }
        if (timeTotalsRow == -1 && employeeCount > 0)
        {
            moveToNewEmployee(selectedRow);
            return;
        }
        if (empidSelected == null || empidSelected.isEmpty())
        {
            empidSelected = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_EMPID));
        }
        boolean messageIsFYI = false;
        boolean messageIsTVI = false;
        String message = Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_MESSAGE));
        if (message.length() > 4)
        {
            switch (message.substring(0, 4))
            {
                case "FYI:":
                    messageIsFYI = true;
                    break;
                case "TVI:":
                    messageIsTVI = true;
                    break;
                default: // do nothing
            }
        }
        String status = Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS));
        if (status.equals("Error"))
        {
            if (!Arrays.asList("Resend", "Manual").contains(Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_MANUAL_CMP_BY))))
            {
                timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
                employeeUpdated = true;
            }
        }
        else if ((status.equals("Not Ready") && messageIsFYI) ||
                 (status.equals("Updated") && !messageIsTVI))
        {
            timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
            employeeUpdated = true;
        }
        else if (status.equals("Updated") && messageIsTVI)
        {
            timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);
            employeeUpdated = true;
        }
        boolean okToChangeEmployee = true;
        if (employeeUpdated)
        {
            if (!messageIsFYI && !status.equals("Completed"))
            {
                timeTotalsData.setValueAt("", timeTotalsRow, idx_MESSAGE);
            }
            okToChangeEmployee = sumAndCheckData(timeTotalsRow);
            if (!okToChangeEmployee)
            {
                timeTotalsTable.clearSelection();
                timeTotalsTable.changeSelection(timeTotalsTable.convertRowIndexToView(timeTotalsRow), idx_PARTTIME_FLAG, false, false);
            }
            else
            {
                if (!deletingEmployee)
                {
                    updateDatabase(timeTotalsRow);
                }
                employeeUpdated = false;
            }
        }
        if (okToChangeEmployee)
        {
            moveToNewEmployee(selectedRow);
        }
    }
    
    private void moveToNewEmployee(int selectedRow)
    {
        timeTotalsRow = timeTotalsTable.convertRowIndexToModel(selectedRow);
        employeeUpdated = false;
        attendancesChanged.clear();
        absencesChanged.clear();
        extraPaymentsChanged.clear();
        employee = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_EMPLOYEE));
        empidSelected = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_EMPID));
        selectedMU = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_MU));
        selectedDate = (Date) timeTotalsTable.getValueAt(selectedRow, idx_REPORTING_DATE);
        selectedTOTALVIEWID = (Integer) timeTotalsTable.getValueAt(selectedRow, idx_TOTALVIEWID);
        muLabel.setText("MU: " + selectedMU);
        double shift = Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT));
        if (Misc.isHoliday(RegionData.getHolidayCodes(), selectedDate, union, shift))
        {
            holidayFlag.setVisible(true);
        }
        else
        {
            holidayFlag.setVisible(false);
        }
        String message = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_MESSAGE));
        if (message.matches(".*This is the ... OFF day this week.*") ||
                 message.matches(".*This week has . OFF days.*"))
        {
            Date lastDayOfWeek = Misc.getNextDayOfWeek(selectedDate, RegionData.getLastDayOfWeek(), true);
            Date firstDayOfWeek = Misc.dateAddDays(lastDayOfWeek, -6);
            int numOffDays = Oracle.getNumOffDaysInWeek(getFormComponent(), feeder, site, empidSelected, firstDayOfWeek, selectedDate);
            int totalOffDays = Oracle.getNumOffDaysInWeek(getFormComponent(), feeder, site, empidSelected, firstDayOfWeek, lastDayOfWeek);
            int otherFlags = (Integer)timeTotalsData.getValueAt(timeTotalsRow, idx_OTHERFLAGS);
            if (totalOffDays <= 2 && otherFlags == 0)
            {
                message = "";
            }
            else if (otherFlags == -9)
            {
                message = "FYI: Deleting data from eLink.";
            }
            else if (numOffDays <= 2)
            {
                if (totalOffDays == 3)
                {
                    message = "FYI: This week has 3 OFF days. Only valid for parttime or 4/10 employees!!";
                }
                else
                {
                    message = "TVI: This week has " + totalOffDays + " OFF days. Correct or email TVI Support!!";
                }
            }
            else if (numOffDays == 3)
            {
                message = "FYI: This is the 3rd OFF day this week. Only valid for parttime or 4/10 employees!!";
            }
            else
            {
                message = "TVI: This is the " + numOffDays + "th OFF day this week. Correct or email TVI Support!!";
            }
            Oracle.setTimeTotalsMessage(getFormComponent(), feeder, site, empidSelected, selectedDate, message);
        }
        messageArea.setText(message);
        messageArea.setVisible(!message.equals(""));
        dwsDisplay.setText(Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_DWS)));
        employeeLabel.setText(employee);
        empidLabel.setText(empidSelected);
        reportingDateLabel.setText(Misc.dateToStringMDY(selectedDate));
        dayOfWeekLabel.setText(Misc.dateToStringShortDay(selectedDate));
        
        empidFilterText = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_EMPID));
        reportingDateFilterText = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_REPORTING_DATE));
        recordTypeFilterText = Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_RECORD_TYPE));
        processFilter();
        
        if ((feeder.equals("POL") && shift == 0.0 && Misc.objectToDouble(timeTotalsTable.getValueAt(selectedRow, idx_OVERTIME)) == 0.0) ||
            (Misc.objectToDouble(timeTotalsTable.getValueAt(selectedRow, idx_ABSENCE_TOTAL)) > 0.0))
        {
            currentCodeType = "Absence Detail";
            absencesScrollPane.setViewportView(absencesTable);
            absencesTable.setFillsViewportHeight(true);
        }
        else if (timeTotalsTable.getValueAt(selectedRow, idx_EXTRAPAY_FLAG).equals(true))
        {
            currentCodeType = "Extra Pay Detail";
            absencesScrollPane.setViewportView(extraPaymentsTable);
            extraPaymentsTable.setFillsViewportHeight(true);
        }
        else
        {
            currentCodeType = "Attendances Detail";
            absencesScrollPane.setViewportView(attendancesTable);
            attendancesTable.setFillsViewportHeight(true);
        }
        
        // If the selected record is locked, don't allow the user to make changes
        if (!readOnly)
        {
            if (timeTotalsTable.getValueAt(selectedRow, idx_LOCKED_BY) != null &&
                !timeTotalsTable.getValueAt(selectedRow, idx_LOCKED_BY).equals(UserData.getUUID()))
            {
                setControlsReadOnly();
                readOnlyFlag.setText("Read Only - Record locked by: " + timeTotalsTable.getValueAt(selectedRow, idx_LOCKED_BY));
                readOnlyFlag.setVisible(true);
            }
            else if (timeTotalsTable.getValueAt(selectedRow, idx_STATUS).equals("Separated"))
            {
                setControlsReadOnly();
                readOnlyFlag.setText("Employee is separated. Click 'Del Empl'");
                readOnlyFlag.setVisible(true);
            }
            else if (timeTotalsTable.getValueAt(selectedRow, idx_STATUS).equals("Not Active"))
            {
                setControlsReadOnly();
                if (Misc.isNumeric(timeTotalsTable.getValueAt(selectedRow, idx_EMPID).toString()))
                {
                    readOnlyFlag.setText("Update employee ID. Click 'Chg UUID'");
                }
                else
                {
                    readOnlyFlag.setText("Employee is inactive. Click 'Chg to Ready'");
                }
                readOnlyFlag.setVisible(true);
            }
            else if (timeTotalsTable.getValueAt(selectedRow, idx_STATUS).equals("Pending"))
            {
                setControlsReadOnly();
                readOnlyFlag.setText("Employee is pending. Call TVI Support");
                readOnlyFlag.setVisible(true);
            }
            else
            {
                setControlsEnabled(true);
                readOnlyFlag.setVisible(false);
            }
        }
        
        // If in the approving changes view and a history record is selected, disable the approve emp button
        if (Arrays.asList("CHANGES", "PRIOR").contains(editType))
        {
            approveEmpButton.setEnabled(Arrays.asList("Current", "Deleted").contains(Misc.objectToString(timeTotalsTable.getValueAt(selectedRow, idx_RECORD_TYPE))));
        }
    }
    
    private void encodeDWS()
    {
        String newDWS = Oracle.encodeDWS(
            getFormComponent(),                                                                   // parentFrame
            feeder,                                                                               // p_feeder
            Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT)),             // p_shiftHours
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFFNIGHT)),        // p_NightDiff
            union,                                                                                // p_union
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_CARFARE_DWS)),      // p_CarFare
            0,                                                                                    // p_diff_15Percent
            0,                                                                                    // p_RNA_FLAG
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_060)),         // p_Diff060
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_150)),         // p_Diff150
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_185)),         // p_Diff185
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_200)),         // p_Diff200
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_220)),         // p_Diff220
            0,                                                                                    // p_Diff250
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_270)),         // p_Diff270
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_300)),         // p_Diff300
            0,                                                                                    // p_Diff400
            0,                                                                                    // p_Diff500
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_900)),         // p_Diff900
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_600)),         // p_Diff600
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_800)),         // p_Diff800
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_1_PERCENT)),   // p_Diff_1_percent
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_1_5_PERCENT)), // p_Diff_1_5_percent
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_2_PERCENT)),   // p_Diff_2_percent
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_2_5_PERCENT)), // p_Diff_2_5_percent
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_3_PERCENT)),   // p_Diff_3_percent
            Misc.booleanToOracle(timeTotalsData.getValueAt(timeTotalsRow, idx_GAP))               // p_Gap
        );
        if (!(Misc.objectEquals(timeTotalsData.getValueAt(timeTotalsRow, idx_DWS), "OFFA") && Misc.objectEquals(newDWS, "OFF")))
        {
            timeTotalsData.setValueAt(newDWS, timeTotalsRow, idx_DWS);
            dwsDisplay.setText(newDWS);
        }
    }
    
    private boolean sumAndCheckData(int rowIn)//DYADD rowIn unused, uses timeTotalsRow instead - safe?
    {
        double shift = Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT));
        double regular = 0;
        double prem = 0;
        double prem_tvi40 = 0;
        double sund = 0;
        double regExtHolidayHoursWorked = 0;
        double overtime = 0;
        double callout = 0;
        double totalHoursWorked = 0;
        double absencesTotal = 0;
        double add2RegPlusAbsTotal = 0;
        double hours;
        double pdoHours = 0;
        double holdHours = 0;
        double holidayAllowanceHours;
        double holidayHoursWorked = 0;
        boolean coHoliday = false;
        boolean floatingHoliday = false;
        double noHolidayAllowance = 0;
        double prePostHours = 0;
        double nightHours = 0;
        double eveningHours = 0;
        double compTimeEarned = 0;
        int currentDiffSource;
        boolean validatesOk = true;
        boolean absencesReady = true;
        boolean attendancesReady = true;
        boolean extraPaymentsReady = true;
        boolean timeTotalsReady = true;
        String code2Check;
        String reasonCode2Check;
        String comment2Check;
        boolean reasonCodeRequired = false;
        boolean add2RegPlusAbs = false;
        String process1Arec = "";
        String process2Arec = "";
        String process3Arec = "";
        String process4Arec = "";
        String process1Trec = "";
        String process2Trec = "";
        String process3Trec = "";
        String process1Erec = "";
        String process2Erec = "";
        String process3Erec = "";
        boolean attendFlag = false;
        boolean gotExtraPayment = false;
        boolean gotRD = false;
        boolean gotMA = false;
        double meal_allowance = 0;
        boolean gotBilingual = false;
        boolean gotCarFare = false;
        boolean gotTardy = false;
        boolean holidayTraded = false;
        boolean hasRestDayWorked = false;
        double hoursToRemoveFromRegAbs = 0;
        int mealVouchers = 0;
        double totalHoursWorkedCZE = 0;
        double sumTotalHoursWorkedCZE = 0;
        double totalOT1030 = 0;
        double totalOT8115 = 0;
        double totalOTComputed = 0;
        double totalOTOverlap = 0;
        double totalOT_POL = 0;
        double totalOT50_POL = 0;
        double totalOT100_POL = 0;
        double totalOTO_POL = 0;
        boolean g_hour8_flag_nv = false;
        double g_counts_for_8_hrrule = 0;
        String muState = "";
        String message = "";
        
        if (Misc.isHoliday(RegionData.getHolidayCodes(), selectedDate, union, shift))
        {
            coHoliday = true;
        }
        int length = empidSelected.length();
        if (length != 6)
        {
            Misc.msgbox(getFormComponent(), "Employee UUID must be 6 characters", "TVI - UUID verification failed", 1, 1, 1);
            message = "TVI: ERROR - ATTID must be Corrected";
            timeTotalsReady = false;
        }
        if (!Misc.isAlpha(empidSelected.substring(0, 2)))
        {
            Misc.msgbox(getFormComponent(), "Employee UUID must start with 2 alphas", "TVI - UUID verification failed", 1, 1, 1);
            message = "TVI: ERROR - ATTID must be Corrected";
            timeTotalsReady = false;
        }
        /*****************************************
        * Check for holiday traded / deferred HONP
        *****************************************/
        for (int i = 0; i < attendancesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)) &&
                    (
                        (editType.equals("UPDATE") && Misc.objectToString(attendancesData.getValueAt(i, idx_Att_RECORD_TYPE)).equals("Current")) ||
                        attendancesData.getValueAt(i, idx_Att_RECORD_TYPE) == null ||
                        attendancesData.getValueAt(i, idx_Att_RECORD_TYPE).equals("")
                    )
                )
            {
                code2Check = Misc.objectToString(attendancesData.getValueAt(i, idx_Att_SAP_CODE));
                if (Arrays.asList("HONP", "HOLF").contains(code2Check))
                {
                    holidayTraded = true;
                }
            }
        }
        
        /***********************************************************************
        * ABSENCES
        ***********************************************************************/
        for (int i = absencesData.getRowCount() - 1; i >= 0; i--)
        {
            if (empidSelected.equals(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_EMPID))) &&
                selectedDate.equals((Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE)) &&
                    (
                        (editType.equals("UPDATE") && Misc.objectToString(absencesData.getValueAt(i, idx_Abs_RECORD_TYPE)).equals("Current")) ||
                        absencesData.getValueAt(i, idx_Abs_RECORD_TYPE) == null ||
                        absencesData.getValueAt(i, idx_Abs_RECORD_TYPE).equals("")
                    )
                )
            {
                code2Check = Misc.objectToString(absencesData.getValueAt(i, idx_Abs_SAP_CODE));
                if (Arrays.asList("MTDY", "TOL1", "TDY1", "TDY3").contains(code2Check))
                {
                    gotTardy = true;
                }
                reasonCode2Check = Misc.objectToReasonCode(absencesData.getValueAt(i, idx_Abs_REASON_CODE_DESC));
                comment2Check = Misc.objectToString(absencesData.getValueAt(i, idx_Abs_COMMENT));
                if (reasonCode2Check == null)
                {
                    reasonCode2Check = "";
                }
                if (reasonCode2Check.length() > 6)
                {
                    reasonCode2Check = reasonCode2Check.substring(0, 6);
                }
                if (code2Check.length() != 4)
                {
                    Misc.msgbox(getFormComponent(), "Absence Code MUST be 4 Characters! ", "Validating Absences", 1, 1, 1);
                    absencesReady = false;
                    validatesOk = false;
                }
                hours = Misc.objectToDouble(absencesData.getValueAt(i, idx_Abs_HOURS_TREC));
                if (hours == 0.0)
                {
                    Misc.msgbox(getFormComponent(), "Hours must be > 0! Update or Del ", "Validating Absences", 1, 1, 1);
                    message = "TVI: An absence code has 0 hours.";
                    absencesReady = false;
                }
                for (AbsenceCodeRecord absence : RegionData.getAbsenceCodes())
                {
                    if (code2Check.equals(absence.getSapCode()))
                    {
                        add2RegPlusAbs = absence.isAdd2RegPlusAbs();
                        reasonCodeRequired = absence.isReasonCodeRequired();
                        process1Trec = absence.getProcess1Trec();
                        process2Trec = absence.getProcess2Trec();
                        process3Trec = absence.getProcess3Trec();
                        break;
                    }
                }
                if (reasonCodeRequired && reasonCode2Check.length() < 6)
                {
                    Misc.msgbox(getFormComponent(), "Reason Code Required!", "Validating Absences", 1, 1, 1);
                    message = "TVI: Reason Code Required!";
                    absencesReady = false;
                }
                if (!reasonCodeRequired && reasonCode2Check.length() > 1)
                {
                    Misc.msgbox(getFormComponent(), "Remove Reason Code!", "Validating Absences", 1, 1, 1);
                    message = "TVI: Remove Reason Code!";
                    absencesReady = false;
                }
                if (absencesData.getValueAt(i, idx_Abs_COMMENT) != null)
                {
                    if (Misc.objectToString(absencesData.getValueAt(i, idx_Abs_COMMENT)).length() > 15)
                    {
                        Misc.msgbox(getFormComponent(), "Comments must be < 16 Characters.  Your Comment will be Truncated", "Validating Absences", 1, 1, 1);
                        absencesData.setValueAt(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_COMMENT)).substring(0, 15), i, 10);
                    }
                }
                if (code2Check.equals("None"))
                {
                    Misc.msgbox(getFormComponent(), "Absence code None is not valid!", "Validating Absences", 1, 1, 1);
                    message = "TVI: No translation found email TVI Support at " + Constants.EMAIL;
                    absencesReady = false;
                }
                if ("ABS_EXT".equals(process1Trec))                // MXUE overtime union paid
                {
                    overtime += hours;
                }
                if (add2RegPlusAbs)
                {
                    add2RegPlusAbsTotal += hours;
                }
                if ("NO_HOLI_ALLOWANCE".equals(process3Trec))      // DISU, LOAD, LOAF
                {
                    noHolidayAllowance += hours;
                }
                if ("EW01:EW02".equals(process1Trec))
                {
                    pdoHours += hours;
                }
                if ("PREPOST".equals(process3Trec))
                {
                    prePostHours += hours;
                }
                if (coHoliday && !holidayTraded)
                {
                    if (Arrays.asList("FILF", "FILP", "FILU", "FISA", "FISP").contains(code2Check))
                    {
                        Misc.msgbox(getFormComponent(), "WARNING!! If FMLA is for less than a week use NON FMLA code on the holiday with I00054 reason code!", "FMLA on Holiday", 1,1, 1);
                    }
                }
                if ("HOLIDAY".equals(process1Trec))
                {
                    if (Arrays.asList("HLDY", "HOLX").contains(code2Check))
                    {
                        absencesTotal += hours;
                    }
                    else
                    {
                        holdHours += hours;
                    }
                    if (coHoliday && !holidayTraded)
                    {
                        if ("FLOATING".equals(process2Trec))
                        {
                            Misc.msgbox(getFormComponent(), "Code NOT valid on Company Holiday! " + code2Check, "Validating Absences", 1, 1, 1);
                            message = "TVI: Code NOT valid on Company Holiday! " + code2Check;
                            absencesReady = false;
                        }
                    }
                    else
                    {
                        if ("COMPANY".equals(process3Trec))
                        {
                            Misc.msgbox(getFormComponent(), "TVI: Code only valid on Company Holiday! " + code2Check, "Validating Absences", 1, 1, 1);
                            message = "TVI: Code only valid on Company Holiday! " + code2Check;
                            absencesReady = false;
                        }
                        else
                        {
                            floatingHoliday = true;
                        }
                    }
                }
                else if (add2RegPlusAbs)
                {
                    absencesTotal += hours;
                }
                
                if (feeder.equals("MEX"))
                {
                    if (Arrays.asList("0101", "0107", "0200", "0201", "0203", "0205", "0207").contains(code2Check) && comment2Check.contains("Partial"))
                    {
                        hoursToRemoveFromRegAbs += hours;
                    }
                    else if (code2Check.equals("0100") && reasonCode2Check.equals("M00009") && comment2Check.contains("Partial"))
                    {
                        hoursToRemoveFromRegAbs += hours;
                    }
                    
                    int mins = Misc.objectToInt(absencesData.getValueAt(i, idx_Abs_MINS_TREC));
                    if (code2Check.equals("TOL1")) // if value entered for tolerance is > 4 minutes, reject
                    {
                        if (mins > 4)
                        {
                            Misc.msgbox(getFormComponent(), "Tolerances must be reported for 4 or less minutes, report 5 or more as tardy.", "Tolerance Amount", 1, 1, 1);
                            message = "TVI: Tolerances must be reported for 4 or less minutes, report 5 or more as tardy.";
                            absencesReady = false;
                        }
                    }
                    if (code2Check.equals("TDY1")) // if value entered for tardy is < 5 minutes, reject
                    {
                        if (mins < 5)
                        {
                            Misc.msgbox(getFormComponent(), "Tardies must be reported for 5 or more minutes, report 4 minutes or less as tolerance.", "Tardy Amount", 1, 1, 1);
                            message = "TVI: Tardies must be reported for 5 or more minutes, report 4 or less as tolerance.";
                            absencesReady = false;
                        }
                    }
                }
                if (feeder.equals("CZE"))
                {
                    if (code2Check.equals("0111"))
                    {
                        if (hours != shift && hours != shift / 2)
                        {
                            Misc.msgbox(getFormComponent(), "Vacation hours must be reported in full day or half day increments.", "Vacation Amount", 1, 1, 1);
                            message = "FYI: Vacation hours must be reported in full day or half day increments.";
                        }
                    }
                }
                if (Arrays.asList("CZE","SVK").contains(feeder))
                    {  
                        if (Arrays.asList("0112", "0530").contains(code2Check))
                        {
                            double extraOffHours = Oracle.getExtraOffHours(getFormComponent(), feeder, site, mu, empidSelected);
                            if (extraOffHours > 0)
                            {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(RegionData.getPayClose());
                                cal.set(Calendar.MONTH, Calendar.JANUARY);
                                cal.set(Calendar.DAY_OF_MONTH, 1);
                                Date startDateOfYear = cal.getTime();
                                cal.set(Calendar.MONTH, Calendar.DECEMBER);
                                cal.set(Calendar.DAY_OF_MONTH, 31);
                                Date endDateOfYear = cal.getTime();
                                
                                double extraOffTaken = Oracle.getExtraOffTaken(getFormComponent(),feeder,empid,startDateOfYear,endDateOfYear );
                                double hoursToReport = Misc.objectToDouble(absencesData.getValueAt(i, idx_Abs_HOURS_TREC));
                                
                                if (hoursToReport > (extraOffHours - extraOffTaken))
                                {
                                    timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);                     
                                    Misc.msgbox(getFormComponent(), "Employee does not have enough extra off hours available in Employee Maintenance.", "Extra Off Days", 1, 1, 1);
                                    message = "TVI: Employee does not have enough extra off hours available in Employee Maintenance.";
                                    timeTotalsReady = false;
                                }
                            }
                            else
                            {
                                timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);
                                Misc.msgbox(getFormComponent(), "Employee does not have any extra off hours available in Employee Maintenance.", "Extra Off Days", 1, 1, 1);
                                message = "TVI: Employee does not have any extra off hours available in Employee Maintenance.";
                                timeTotalsReady = false;
                            }
                        }
                    }
            }
        }
        timeTotalsData.setValueAt(gotTardy, timeTotalsRow, idx_TARDY_FLAG);
        
        /***********************************************************************
        * ATTENDANCES
        ***********************************************************************/
        for (int i = 0; i < attendancesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)) &&
                    (
                        (editType.equals("UPDATE") && Misc.objectToString(attendancesData.getValueAt(i, idx_Att_RECORD_TYPE)).equals("Current")) ||
                        attendancesData.getValueAt(i, idx_Att_RECORD_TYPE) == null ||
                        attendancesData.getValueAt(i, idx_Att_RECORD_TYPE).equals("")
                    )
                )
            {
                code2Check = Misc.objectToString(attendancesData.getValueAt(i, idx_Att_SAP_CODE));
                hours = Misc.objectToDouble(attendancesData.getValueAt(i, idx_Att_HOURS_AREC));
                if (hours == 0.0)
                {
                    Misc.msgbox(getFormComponent(), "Hours must be > 0! Update or Del ", "Validating Attendances", 1, 1, 1);
                    message = "TVI: An attendance code has 0 hours.";
                    attendancesReady = false;
                }
                for (AttendanceCodeRecord attendance : RegionData.getAttendanceCodes())
                {
                    if (code2Check.equals(attendance.getSapCodeArec()))
                    {
                        process1Arec = attendance.getProcess1Arec();
                        process2Arec = attendance.getProcess2Arec();
                        process3Arec = attendance.getProcess3Arec();
                        process4Arec = attendance.getProcess4Arec();
                        break;
                    }
                }
                if ("REG".equals(process1Arec))
                {
                    regular += hours;
                    totalHoursWorked += hours;
                    if (!"REG_NOT_ABS".equals(process3Arec))
                    {
                        add2RegPlusAbsTotal += hours;
                    }
                }
                if (Arrays.asList("CZE", "SVK").contains(feeder))
                {
                    if ("EXT".equals(process2Arec))
                    {
                        overtime += hours;
                        totalHoursWorked += hours;
                    }
                    if ("CAL".equals(process1Arec))
                    {
                        callout += hours;
                    }
                }
                else
                {
                    if ("EXT".equals(process1Arec))
                    {
                        overtime += hours;
                        totalHoursWorked += hours;
                    }
                    if ("CAL".equals(process1Arec))
                    {
                        callout += hours;
                        totalHoursWorked += hours;
                    }
                }
                if ("REG_EXT".equals(process1Arec))
                {
                    regExtHolidayHoursWorked += hours;
                }
                if (!coHoliday)
                {
                    if ("COMPANY_HOLIDAY".equals(process4Arec) || "MAKE_NOT_HOLIDAY".equals(process4Arec))
                    {
                        Misc.msgbox(getFormComponent(), code2Check + " only valid on Company Holiday! ", "Validating Attendances", 1, 1, 1);
                        message = "TVI: Code only valid on Company Holiday! - " + code2Check;
                        attendancesReady = false;
                    }
                    else
                    {
                        if (holidayTraded)
                        {
                            if ("COMPANY_HOLIDAY".equals(process4Arec))
                            {
                                Misc.msgbox(getFormComponent(), code2Check + " only valid on Company Holiday! ", "Validating Attendances", 1, 1, 1);
                                message = "TVI: Code only valid on Company Holiday! - " + code2Check;
                                attendancesReady = false;
                            }
                        }
                    }
                }
                if ("HOLIDAY".equals(process3Arec))
                {
                    if ("HOLIDAY_WORKED".equals(process2Arec))
                    {
                        if (feeder.equals("MEX") && !coHoliday)
                        {
                            // don't display under holiday hours
                        }
                        else
                        {
                            holidayHoursWorked += hours;
                        }
                    }
                }
                if ("PREM".equals(process1Arec))
                {
                    if (Misc.objectToInt(attendancesData.getValueAt(i, idx_Att_RECKEY)) != 89)
                    {
                        prem += hours;
                    }
                    else
                    {
                        prem_tvi40 += hours;
                    }
                }
                if (feeder.equals("SVK"))
                {
                    if ("SUND".equals(process2Arec))
                    {
                        sund += hours;
                    }
                }
                if ("SUND".equals(process1Arec))
                {
                    sund += hours;
                }
                if ("EVENING".equals(process2Arec))
                {
                    eveningHours += hours;
                }
                if ("NIGHT".equals(process2Arec))
                {
                    nightHours += hours;
                }
                if ("CMPE".equals(process1Arec))
                {
                    compTimeEarned += hours;
                }
                if ("ATTEND_FLAG".equals(process2Arec))
                {
                    attendFlag = true;
                }
                if ("RD_FLAG".equals(process2Arec))
                {
                    gotRD = true;
                }
                if ("BILINGUAL_FLAG".equals(process2Arec))
                {
                    gotBilingual = true;
                }
                if (Arrays.asList("EW01", "EW01").contains(code2Check) && pdoHours == 0)
                {
                    Misc.msgbox(getFormComponent(), code2Check + " Requires absence: " + process4Arec, "Validating Attendances", 1, 1, 1);
                }
                if (feeder.equals("MEX"))
                {
                    if (code2Check.equals("1014") && !Misc.dateIsDayOfWeek(selectedDate, Calendar.SUNDAY))
                    {
                        Misc.msgbox(getFormComponent(), code2Check + " is only valid on a Sunday! ", "Validating Attendances", 1, 1, 1);
                        message = "TVI: Code only valid on a Sunday! - " + code2Check;
                        attendancesReady = false;
                    }
                    else if (code2Check.equals("1020") && shift != 0)
                    {
                        Misc.msgbox(getFormComponent(), code2Check + " is only valid when shift is 0! ", "Validating Attendances", 1, 1, 1);
                        message = "TVI: Code only valid when shift is 0! - " + code2Check;
                        attendancesReady = false;
                    }
                    else if (Arrays.asList("1026", "1028").contains(code2Check))
                    {
                        hasRestDayWorked = true;
                    }
                    else if (code2Check.equals("1030"))
                    {
                        totalOT1030 += hours;
                    }
                    else if (code2Check.equals("8115"))
                    {
                        if (Misc.objectToString(attendancesData.getValueAt(i, idx_Att_COST_CENTER)).equalsIgnoreCase("Overlap"))
                        {
                            totalOTComputed += hours;
                        }
                        else
                        {
                            totalOT8115 += hours;
                        }
                    }
                    else if (Arrays.asList("OTI1", "OTI2").contains(code2Check))
                    {
                        totalOTOverlap += hours;
                    }
                }
                if (feeder.equals("CZE"))
                {
                    if (Arrays.asList("0200", "0210", "0211").contains(code2Check))
                    {
                        sumTotalHoursWorkedCZE += hours;
                    }
                    if (code2Check.equals("0201"))
                    {
                        totalHoursWorkedCZE += hours;
                    }
                }
                if (feeder.equals("POL"))
                {
                    if (code2Check.equals("EXTA"))
                    {
                        totalOT_POL += hours;
                        totalOT50_POL += hours;
                    }
                    if (code2Check.equals("EXTP"))
                    {
                        totalOT_POL += hours;
                        totalOT100_POL += hours;
                    }
                    if (code2Check.equals("EXTO"))
                    {
                        totalOT_POL += hours;
                        totalOTO_POL += hours;
                    }
                }
            }
        }
        /***********************************************************************
        * EXTRA PAYMENTS
        ***********************************************************************/
        for (int i = 0; i < extraPaymentsData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_EMPID))) &&
                selectedDate.equals((Date) extraPaymentsData.getValueAt(i, idx_Ext_REPORTING_DATE)) &&
                    (
                        (editType.equals("UPDATE") && Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_RECORD_TYPE)).equals("Current")) ||
                        extraPaymentsData.getValueAt(i, idx_Ext_RECORD_TYPE) == null ||
                        extraPaymentsData.getValueAt(i, idx_Ext_RECORD_TYPE).equals("")
                    )
                )
            {
                code2Check = Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_SAP_CODE));
                if (code2Check.length() != 4)
                {
                    Misc.msgbox(getFormComponent(), "Extra Payment Code MUST be 4 Characters!", "Validating Extra Payments", 1, 1, 1);
                    extraPaymentsReady = false;
                    validatesOk = false;
                }
                hours = Misc.objectToDouble(extraPaymentsData.getValueAt(i, idx_Ext_AMOUNT_EREC));
                if (hours == 0.0)
                {
                    Misc.msgbox(getFormComponent(), "Hours must be > 0! Update or Del", "Validating Extra Payments", 1, 1, 1);
                    message = "TVI: An extra payment code has 0 hours.";
                    extraPaymentsReady = false;
                }
                for (ExtraPaymentCodeRecord extraPayment : RegionData.getExtraPaymentCodes())
                {
                    if (code2Check.equals(extraPayment.getCodeErec()))
                    {
                        process1Erec = extraPayment.getProcess1Erec();
                        process2Erec = extraPayment.getProcess2Erec();
                        process3Erec = extraPayment.getProcess3Erec();
                        break;
                    }
                }
                if ("MA_FLAG".equals(process2Erec))
                {
                    gotMA = true;
                    meal_allowance += hours;
                }
                if ("EXTRAPAY_FLAG".equals(process2Erec))
                {
                    gotExtraPayment = true;
                }
                if ("RD_FLAG".equals(process2Erec))
                {
                    gotRD = true;
                }
                if ("BILINGUAL_FLAG".equals(process2Erec))
                {
                    gotBilingual = true;
                }
                if ("CARFARE_FLAG".equals(process2Erec))       // BTI
                {
                    gotCarFare = true;
                }
                if ("MEAL_VOUCHER".equals(process2Erec))       // CZE
                {
                    mealVouchers += (int)hours;
                }
            }
        }
        
        currentDiffSource = Misc.objectToInt(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_SOURCE));
        if (currentDiffSource == 2)
        {
            if (prePostHours != shift)
            {
                currentDiffSource += 10;
                timeTotalsData.setValueAt(currentDiffSource, timeTotalsRow, idx_DIFF_SOURCE);
                timeTotalsData.setValueAt(Misc.getDiffSource(currentDiffSource), timeTotalsRow, idx_DIFF_SOURCE_DISP);
            }
        }
        if (feeder.equals("SVK"))
        {
            timeTotalsData.setValueAt(mealVouchers, timeTotalsRow, idx_MEAL_ALLOWANCE);
        }
        if (feeder.equals("CZE"))
        {
            timeTotalsData.setValueAt(mealVouchers, timeTotalsRow, idx_MEAL_ALLOWANCE);
            
            if (sumTotalHoursWorkedCZE > 0 && totalHoursWorkedCZE != sumTotalHoursWorkedCZE)
            {
                // if 0201 exists for this emp, delete it
                String recKey = null;
                int rowNum = -1;
                for (int i = 0; i < attendancesData.getRowCount(); i++)
                {
                    if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                        selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)) &&
                        Misc.objectToString(attendancesData.getValueAt(i, idx_Att_SAP_CODE)).equals("0201") &&
                        Misc.objectToString(attendancesData.getValueAt(i, idx_Att_RECORD_TYPE)).equals("Current"))
                    {
                        rowNum = i;
                        recKey = Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_RECKEY));
                        break;
                    }
                }
                if (rowNum != -1 && recKey != null)
                {
                    attendancesData.removeRow(rowNum);
                    Oracle.deleteAttendance(getFormComponent(), empidSelected, selectedDate, recKey);
                }
                
                // Add the new code
                addAttendance("0201", sumTotalHoursWorkedCZE);
            }
        }
        if (feeder.equals("MEX"))
        {
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOT1030), timeTotalsRow, idx_OT_1030);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOT8115), timeTotalsRow, idx_OT_8115);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOTComputed), timeTotalsRow, idx_COMPUTED_OT);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOTOverlap), timeTotalsRow, idx_CALL_OVERLAP);
        }
        if (floatingHoliday)
        {
            if (holdHours < shift)
            {
                switch (feeder)
                {
                    case "MEX":
                        holdHours = 0;
                        break;
                    default:
                        Misc.msgbox(getFormComponent(), "Floating Holiday! Holiday absence hours should be equal to shift!", "Validating Absences", 1, 1, 1);
                        message = "FYI: Holiday absence hours should be equal to shift!";
                }
            }
        }
        if (coHoliday || floatingHoliday)
        {
            if (regExtHolidayHoursWorked > 0)
            {
                regular = shift - absencesTotal;
                overtime = regExtHolidayHoursWorked - regular;
                totalHoursWorked += regExtHolidayHoursWorked;
                add2RegPlusAbsTotal += regular;
            }
        }
        if ((coHoliday || floatingHoliday) && !holidayTraded && !Arrays.asList("CZE", "POL", "SVK").contains(feeder))
        {
            if (totalHoursWorked != holidayHoursWorked && totalHoursWorked > 0)
            {
                Misc.msgbox(getFormComponent(), "Non Holiday Code used on Company or Floating Holiday!", "Holiday - Validating Absences", 1, 1, 1);
                message = "TVI: Non Holiday Code used on Company or Floating Holiday!";
                floatingHoliday = false;
                absencesReady = false;
            }
        }
        if (feeder.equals("MEX"))
        {
            add2RegPlusAbsTotal -= hoursToRemoveFromRegAbs;
            absencesTotal -= hoursToRemoveFromRegAbs;
        }
        
        if (add2RegPlusAbsTotal != Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT)))
        {
            if (absencesReady && attendancesReady && extraPaymentsReady)
            {
                if (!(feeder.equals("MEX") && shift == 0 && hasRestDayWorked))
                {
                    if (holdHours > 0 || holidayHoursWorked > 0)
                    {
                        Misc.msgbox(getFormComponent(), "Reg + ABS does NOT = SHIFT! May need HLDY for holiday hours not worked", "Validating Employee", 1, 1, 1);
                        message = "TVI: Reg + ABS Must equal Shift! May need HLDY for hours not worked";
                        timeTotalsReady = false;
                    }
                    else
                    {
                        if (Misc.objectEquals(timeTotalsData.getValueAt(timeTotalsRow, idx_DWS), "OFFA"))
                        {
                            message = "FYI: Absence on an OFF day!";
                        }
                        else
                        {
                            Misc.msgbox(getFormComponent(), "Reg + ABS does NOT = SHIFT!", "Validating Employee", 1, 1, 1);
                            message = "TVI: Reg + ABS Must equal Shift!";
                            timeTotalsReady = false;
                        }
                    }
                }
            }
        }
        if (totalHoursWorked + absencesTotal > 24)
        {
            Misc.msgbox(getFormComponent(), "Total time worked + absences cannot exceed 24 hours", "Validating Time Totals", 1, 1, 1);
            message = "TVI: Total time worked + absences cannot exceed 24 hours.";
            timeTotalsReady = false;
        }
        if (Misc.objectEquals(timeTotalsData.getValueAt(timeTotalsRow, idx_DWS), "NONE"))
        {
            encodeDWS();
        }
        if (Misc.objectEquals(timeTotalsData.getValueAt(timeTotalsRow, idx_DWS), "NONE"))
        {
            timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);
            Misc.msgbox(getFormComponent(), "DWS is NONE, click the 'Chg to Ready' button to update or email TVI Support: " + Constants.EMAIL, "DWS Error", 1, 1, 1);
            message = "TVI: DWS is NONE, click 'Chg to Ready' to update or email TVI Support: " + Constants.EMAIL;
            timeTotalsReady = false;
        }
        if (absencesReady && attendancesReady && extraPaymentsReady && timeTotalsReady)
        {
            timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
        }
        else
        {
            timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);
        }
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(regular), timeTotalsRow, idx_REG);
        if (feeder.equals("POL"))
        {
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOT_POL), timeTotalsRow, idx_OVERTIME);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOT50_POL), timeTotalsRow, idx_OT_1030);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOT100_POL), timeTotalsRow, idx_OT_8115);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(totalOTO_POL), timeTotalsRow, idx_COMPUTED_OT);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(compTimeEarned), timeTotalsRow, idx_CALL_OUT);
        }
        else
        {
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(overtime), timeTotalsRow, idx_OVERTIME);
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(callout), timeTotalsRow, idx_CALL_OUT);
        }
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(add2RegPlusAbsTotal), timeTotalsRow, idx_REGTOTAL);
        prem += prem_tvi40;
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(prem), timeTotalsRow, idx_PREM);
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(sund), timeTotalsRow, idx_SUND);
        if (Arrays.asList("CZE", "SVK").contains(feeder))
        {
            timeTotalsData.setValueAt(Misc.doubleToBigDecimal(compTimeEarned), timeTotalsRow, idx_FLEX_HRS);
        }
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(eveningHours), timeTotalsRow, idx_EVENING_HOURS);
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(nightHours), timeTotalsRow, idx_NIGHT_HOURS);
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(holidayHoursWorked), timeTotalsRow, idx_HOLIDAY_WORKED);
        timeTotalsData.setValueAt(Misc.doubleToBigDecimal(absencesTotal), timeTotalsRow, idx_ABSENCE_TOTAL);
        if (coHoliday)
        {
            timeTotalsData.setValueAt(coHoliday, timeTotalsRow, idx_HOLIDAY_FLAG);
        }
        else
        {
            timeTotalsData.setValueAt(floatingHoliday, timeTotalsRow, idx_HOLIDAY_FLAG);
        }
        timeTotalsData.setValueAt(attendFlag, timeTotalsRow, idx_ATTEND_FLAG);
        timeTotalsData.setValueAt(gotExtraPayment, timeTotalsRow, idx_EXTRAPAY_FLAG);
        timeTotalsData.setValueAt(gotRD, timeTotalsRow, idx_RD);
        timeTotalsData.setValueAt(gotMA, timeTotalsRow, idx_MA_FLAG);
        timeTotalsData.setValueAt(gotBilingual, timeTotalsRow, idx_BILINGUAL_FLAG);
        timeTotalsData.setValueAt(gotCarFare, timeTotalsRow, idx_CARFARE);
        
        timeTotalsData.setValueAt(message, timeTotalsRow, idx_MESSAGE);
        messageArea.setText(message);
        messageArea.setVisible(!message.equals(""));
        
        return validatesOk;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        topPanel = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        controlPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();
        editTypeTextField = new javax.swing.JTextField();
        feederSitePanel = new javax.swing.JPanel();
        feederSiteLabel = new javax.swing.JLabel();
        muLabel = new javax.swing.JLabel();
        unionLabel = new javax.swing.JLabel();
        row1 = new javax.swing.JPanel();
        holidayFlag = new javax.swing.JTextField();
        dayOfWeekLabel = new javax.swing.JLabel();
        reportingDateLabel = new javax.swing.JLabel();
        topControls = new javax.swing.JPanel();
        employeeDetailButton = new javax.swing.JButton();
        addEmployeeButton = new javax.swing.JButton();
        deleteEmployeeButton = new javax.swing.JButton();
        changeEmpidButton = new javax.swing.JButton();
        employeeMaintenanceButton = new javax.swing.JButton();
        verifReportButton = new javax.swing.JButton();
        row2 = new javax.swing.JPanel();
        messageArea = new javax.swing.JTextField();
        readOnlyFlag = new javax.swing.JTextField();
        testDBLabel = new javax.swing.JLabel();
        row3 = new javax.swing.JPanel();
        approveEmpButton = new javax.swing.JButton();
        approveAllButton = new javax.swing.JButton();
        importErrorsButton = new javax.swing.JButton();
        changeToReadyButton = new javax.swing.JButton();
        toggleSendButton1 = new javax.swing.JButton();
        toggleSendButton2 = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        employeeLabel = new javax.swing.JLabel();
        empidLabel = new javax.swing.JLabel();
        header2Panel = new javax.swing.JPanel();
        col1 = new javax.swing.JPanel();
        absencesButton = new javax.swing.JButton();
        addAbsenceButton = new javax.swing.JButton();
        extraPaymentsButton = new javax.swing.JButton();
        addExtraPaymentButton = new javax.swing.JButton();
        attendancesButton = new javax.swing.JButton();
        addAttendanceButton = new javax.swing.JButton();
        col2 = new javax.swing.JPanel();
        absencesScrollPane = new javax.swing.JScrollPane();
        loadingPanel = new javax.swing.JPanel();
        loadingLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        col3 = new javax.swing.JPanel();
        commentFormButton = new javax.swing.JButton();
        startStopButton = new javax.swing.JButton();
        dwsLabel = new javax.swing.JLabel();
        dwsDisplay = new javax.swing.JTextField();
        bodyPanel = new javax.swing.JPanel();
        timeTotalsScrollPane = new javax.swing.JScrollPane();
        rowCountPanel = new javax.swing.JPanel();
        numOfEmpsLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Time Reporting");
        setBackground(new java.awt.Color(183, 255, 255));
        setMinimumSize(new java.awt.Dimension(1040, 500));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(183, 255, 255));
        topPanel.setMinimumSize(new java.awt.Dimension(200, 260));
        topPanel.setPreferredSize(new java.awt.Dimension(1024, 260));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        headerPanel.setBackground(new java.awt.Color(183, 255, 255));
        headerPanel.setMinimumSize(new java.awt.Dimension(200, 260));
        headerPanel.setPreferredSize(new java.awt.Dimension(1024, 260));
        headerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        controlPanel.setBackground(new java.awt.Color(183, 255, 255));
        controlPanel.setMinimumSize(new java.awt.Dimension(1020, 150));
        controlPanel.setPreferredSize(new java.awt.Dimension(1024, 150));
        controlPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(183, 255, 255));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(90, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        controlPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 30, -1, -1));

        editTypeTextField.setEditable(false);
        editTypeTextField.setBackground(new java.awt.Color(204, 255, 204));
        editTypeTextField.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        editTypeTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        editTypeTextField.setText("Edit Type");
        editTypeTextField.setPreferredSize(new java.awt.Dimension(1024, 30));
        controlPanel.add(editTypeTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        feederSitePanel.setBackground(new java.awt.Color(183, 255, 255));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSiteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederSiteLabel.setText("Feeder, Site");
        feederSitePanel.add(feederSiteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 120, -1));

        muLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        muLabel.setText("MU: ");
        muLabel.setPreferredSize(new java.awt.Dimension(64, 16));
        feederSitePanel.add(muLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 100, -1));

        unionLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        unionLabel.setText("Union:");
        feederSitePanel.add(unionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 150, -1));

        controlPanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 160, -1));

        row1.setBackground(new java.awt.Color(183, 255, 255));
        row1.setPreferredSize(new java.awt.Dimension(764, 40));
        row1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        holidayFlag.setBackground(new java.awt.Color(255, 102, 255));
        holidayFlag.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        holidayFlag.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        holidayFlag.setText("Holiday");
        holidayFlag.setMinimumSize(new java.awt.Dimension(70, 30));
        holidayFlag.setPreferredSize(new java.awt.Dimension(70, 30));
        row1.add(holidayFlag, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, -1, -1));

        dayOfWeekLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dayOfWeekLabel.setText("day");
        dayOfWeekLabel.setPreferredSize(new java.awt.Dimension(35, 30));
        row1.add(dayOfWeekLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(73, 5, -1, -1));

        reportingDateLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        reportingDateLabel.setText("date");
        reportingDateLabel.setPreferredSize(new java.awt.Dimension(100, 30));
        row1.add(reportingDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 5, -1, -1));

        topControls.setBackground(new java.awt.Color(183, 255, 255));
        topControls.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 2, 5));

        employeeDetailButton.setBackground(new java.awt.Color(183, 255, 255));
        employeeDetailButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        employeeDetailButton.setText("Empl Detail");
        employeeDetailButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeDetailButton.setPreferredSize(new java.awt.Dimension(90, 30));
        employeeDetailButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeDetailButtonActionPerformed(evt);
            }
        });
        topControls.add(employeeDetailButton);

        addEmployeeButton.setBackground(new java.awt.Color(183, 255, 255));
        addEmployeeButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addEmployeeButton.setText("Add Empl");
        addEmployeeButton.setPreferredSize(new java.awt.Dimension(90, 30));
        addEmployeeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addEmployeeButtonActionPerformed(evt);
            }
        });
        topControls.add(addEmployeeButton);

        deleteEmployeeButton.setBackground(new java.awt.Color(183, 255, 255));
        deleteEmployeeButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteEmployeeButton.setText("Del Empl");
        deleteEmployeeButton.setPreferredSize(new java.awt.Dimension(90, 30));
        deleteEmployeeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteEmployeeButtonActionPerformed(evt);
            }
        });
        topControls.add(deleteEmployeeButton);

        changeEmpidButton.setBackground(new java.awt.Color(183, 255, 255));
        changeEmpidButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        changeEmpidButton.setText("Chg UUID");
        changeEmpidButton.setPreferredSize(new java.awt.Dimension(90, 30));
        changeEmpidButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeEmpidButtonActionPerformed(evt);
            }
        });
        topControls.add(changeEmpidButton);

        employeeMaintenanceButton.setBackground(new java.awt.Color(183, 255, 255));
        employeeMaintenanceButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        employeeMaintenanceButton.setText("Emp Maint");
        employeeMaintenanceButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        employeeMaintenanceButton.setPreferredSize(new java.awt.Dimension(90, 30));
        employeeMaintenanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeMaintenanceButtonActionPerformed(evt);
            }
        });
        topControls.add(employeeMaintenanceButton);

        verifReportButton.setBackground(new java.awt.Color(183, 255, 255));
        verifReportButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        verifReportButton.setText("Verif Rpt");
        verifReportButton.setPreferredSize(new java.awt.Dimension(90, 30));
        verifReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verifReportButtonActionPerformed(evt);
            }
        });
        topControls.add(verifReportButton);

        row1.add(topControls, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, -1, -1));

        controlPanel.add(row1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, -1));

        row2.setBackground(new java.awt.Color(183, 255, 255));
        row2.setMinimumSize(new java.awt.Dimension(860, 40));
        row2.setPreferredSize(new java.awt.Dimension(860, 40));
        row2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        messageArea.setEditable(false);
        messageArea.setBackground(new java.awt.Color(255, 255, 51));
        messageArea.setText("message");
        messageArea.setMargin(new java.awt.Insets(2, 5, 2, 2));
        messageArea.setPreferredSize(new java.awt.Dimension(650, 30));
        row2.add(messageArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 5, -1, -1));

        readOnlyFlag.setBackground(new java.awt.Color(255, 51, 51));
        readOnlyFlag.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        readOnlyFlag.setText("Read Only");
        readOnlyFlag.setMinimumSize(new java.awt.Dimension(210, 30));
        readOnlyFlag.setPreferredSize(new java.awt.Dimension(210, 30));
        row2.add(readOnlyFlag, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, -1, -1));

        controlPanel.add(row2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        testDBLabel.setBackground(new java.awt.Color(255, 51, 51));
        testDBLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        testDBLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        testDBLabel.setText("TEST DATABASE");
        testDBLabel.setName(""); // NOI18N
        controlPanel.add(testDBLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, -1, -1));

        row3.setBackground(new java.awt.Color(183, 255, 255));
        row3.setPreferredSize(new java.awt.Dimension(600, 40));
        row3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        approveEmpButton.setBackground(new java.awt.Color(183, 255, 255));
        approveEmpButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        approveEmpButton.setText("Approve Emp");
        approveEmpButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        approveEmpButton.setPreferredSize(new java.awt.Dimension(100, 30));
        approveEmpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approveEmpButtonActionPerformed(evt);
            }
        });
        row3.add(approveEmpButton);

        approveAllButton.setBackground(new java.awt.Color(183, 255, 255));
        approveAllButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        approveAllButton.setText("Approve All");
        approveAllButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        approveAllButton.setPreferredSize(new java.awt.Dimension(100, 30));
        approveAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approveAllButtonActionPerformed(evt);
            }
        });
        row3.add(approveAllButton);

        importErrorsButton.setBackground(new java.awt.Color(183, 255, 255));
        importErrorsButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        importErrorsButton.setText("Import Notif");
        importErrorsButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        importErrorsButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importErrorsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importErrorsButtonActionPerformed(evt);
            }
        });
        row3.add(importErrorsButton);

        changeToReadyButton.setBackground(new java.awt.Color(183, 255, 255));
        changeToReadyButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        changeToReadyButton.setText("Chg to Ready");
        changeToReadyButton.setMargin(new java.awt.Insets(2, 6, 2, 6));
        changeToReadyButton.setPreferredSize(new java.awt.Dimension(100, 30));
        changeToReadyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeToReadyButtonActionPerformed(evt);
            }
        });
        row3.add(changeToReadyButton);

        toggleSendButton1.setBackground(new java.awt.Color(183, 255, 255));
        toggleSendButton1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        toggleSendButton1.setText("-1");
        toggleSendButton1.setToolTipText("Send only SHIFT");
        toggleSendButton1.setMargin(new java.awt.Insets(2, 5, 2, 5));
        toggleSendButton1.setPreferredSize(new java.awt.Dimension(30, 23));
        toggleSendButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggleSendButton1ActionPerformed(evt);
            }
        });
        row3.add(toggleSendButton1);

        toggleSendButton2.setBackground(new java.awt.Color(183, 255, 255));
        toggleSendButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        toggleSendButton2.setText("-9");
        toggleSendButton2.setToolTipText("Send only DREC");
        toggleSendButton2.setMargin(new java.awt.Insets(2, 5, 2, 5));
        toggleSendButton2.setPreferredSize(new java.awt.Dimension(30, 23));
        toggleSendButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toggleSendButton2ActionPerformed(evt);
            }
        });
        row3.add(toggleSendButton2);

        refreshButton.setBackground(new java.awt.Color(183, 255, 255));
        refreshButton.setText("Refresh Screen");
        refreshButton.setMargin(new java.awt.Insets(2, 5, 2, 5));
        refreshButton.setPreferredSize(new java.awt.Dimension(100, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        row3.add(refreshButton);

        controlPanel.add(row3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 110, 660, -1));

        employeeLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        employeeLabel.setText("employee");
        employeeLabel.setPreferredSize(new java.awt.Dimension(200, 20));
        controlPanel.add(employeeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 105, -1, -1));

        empidLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        empidLabel.setText("empid");
        empidLabel.setPreferredSize(new java.awt.Dimension(90, 20));
        controlPanel.add(empidLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 125, -1, -1));

        headerPanel.add(controlPanel);

        header2Panel.setBackground(new java.awt.Color(183, 255, 255));
        header2Panel.setMinimumSize(new java.awt.Dimension(200, 150));
        header2Panel.setName(""); // NOI18N
        header2Panel.setPreferredSize(new java.awt.Dimension(1020, 150));
        header2Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        col1.setBackground(new java.awt.Color(183, 255, 255));
        col1.setMinimumSize(new java.awt.Dimension(160, 110));
        col1.setPreferredSize(new java.awt.Dimension(160, 110));
        java.awt.GridBagLayout jPanel10Layout = new java.awt.GridBagLayout();
        jPanel10Layout.rowHeights = new int[] {1, 1, 1};
        jPanel10Layout.rowWeights = new double[] {1.0, 1.0, 1.0};
        col1.setLayout(jPanel10Layout);

        absencesButton.setBackground(new java.awt.Color(255, 255, 200));
        absencesButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        absencesButton.setText("Absences");
        absencesButton.setFocusable(false);
        absencesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                absencesButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        col1.add(absencesButton, gridBagConstraints);

        addAbsenceButton.setBackground(new java.awt.Color(255, 255, 200));
        addAbsenceButton.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        addAbsenceButton.setText("Add");
        addAbsenceButton.setFocusable(false);
        addAbsenceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAbsenceButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        col1.add(addAbsenceButton, gridBagConstraints);

        extraPaymentsButton.setBackground(new java.awt.Color(200, 255, 200));
        extraPaymentsButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        extraPaymentsButton.setText("Extra Pay");
        extraPaymentsButton.setFocusable(false);
        extraPaymentsButton.setPreferredSize(new java.awt.Dimension(89, 23));
        extraPaymentsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                extraPaymentsButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        col1.add(extraPaymentsButton, gridBagConstraints);

        addExtraPaymentButton.setBackground(new java.awt.Color(200, 255, 200));
        addExtraPaymentButton.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        addExtraPaymentButton.setText("Add");
        addExtraPaymentButton.setFocusable(false);
        addExtraPaymentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addExtraPaymentButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        col1.add(addExtraPaymentButton, gridBagConstraints);

        attendancesButton.setBackground(new java.awt.Color(255, 200, 200));
        attendancesButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        attendancesButton.setText("Attendance");
        attendancesButton.setFocusable(false);
        attendancesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attendancesButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        col1.add(attendancesButton, gridBagConstraints);

        addAttendanceButton.setBackground(new java.awt.Color(255, 200, 200));
        addAttendanceButton.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        addAttendanceButton.setText("Add");
        addAttendanceButton.setFocusable(false);
        addAttendanceButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAttendanceButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        col1.add(addAttendanceButton, gridBagConstraints);

        header2Panel.add(col1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        col2.setBackground(new java.awt.Color(183, 255, 255));
        col2.setMinimumSize(new java.awt.Dimension(787, 110));
        col2.setPreferredSize(new java.awt.Dimension(787, 110));
        col2.setLayout(new javax.swing.BoxLayout(col2, javax.swing.BoxLayout.LINE_AXIS));

        absencesScrollPane.setMaximumSize(new java.awt.Dimension(787, 32767));
        absencesScrollPane.setMinimumSize(new java.awt.Dimension(787, 23));
        absencesScrollPane.setPreferredSize(new java.awt.Dimension(787, 100));

        loadingPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        loadingPanel.add(loadingLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));

        progressBar.setPreferredSize(new java.awt.Dimension(740, 25));
        progressBar.setStringPainted(true);
        loadingPanel.add(progressBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 75, -1, -1));

        absencesScrollPane.setViewportView(loadingPanel);

        col2.add(absencesScrollPane);

        header2Panel.add(col2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, -1, -1));

        col3.setBackground(new java.awt.Color(183, 255, 255));
        col3.setMinimumSize(new java.awt.Dimension(75, 110));
        col3.setPreferredSize(new java.awt.Dimension(75, 110));
        col3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        commentFormButton.setBackground(new java.awt.Color(183, 255, 255));
        commentFormButton.setText("<html><div align='center' width='100%'>Comment<br>Maint.</div></html>");
        commentFormButton.setMargin(new java.awt.Insets(2, 2, 2, 2));
        commentFormButton.setPreferredSize(new java.awt.Dimension(74, 34));
        commentFormButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                commentFormButtonActionPerformed(evt);
            }
        });
        col3.add(commentFormButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        startStopButton.setBackground(new java.awt.Color(183, 255, 255));
        startStopButton.setText("<html><div align='center' width='100%'>Start Stop<br>Times</div></html>");
        startStopButton.setMargin(new java.awt.Insets(2, 5, 2, 5));
        startStopButton.setPreferredSize(new java.awt.Dimension(74, 34));
        startStopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startStopButtonActionPerformed(evt);
            }
        });
        col3.add(startStopButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 34, -1, -1));

        dwsLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        dwsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dwsLabel.setText("<html><u><b>DWS</b></u></html>");
        dwsLabel.setPreferredSize(new java.awt.Dimension(50, 16));
        col3.add(dwsLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 50, -1));

        dwsDisplay.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dwsDisplay.setEnabled(false);
        dwsDisplay.setPreferredSize(new java.awt.Dimension(50, 20));
        col3.add(dwsDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 87, -1, -1));

        header2Panel.add(col3, new org.netbeans.lib.awtextra.AbsoluteConstraints(947, 0, -1, -1));

        headerPanel.add(header2Panel);

        topPanel.add(headerPanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        bodyPanel.setBackground(new java.awt.Color(183, 255, 255));
        bodyPanel.setAlignmentX(0.0F);
        bodyPanel.setAlignmentY(0.0F);
        bodyPanel.setMaximumSize(new java.awt.Dimension(1710, 1600));
        bodyPanel.setName(""); // NOI18N
        bodyPanel.setLayout(new javax.swing.BoxLayout(bodyPanel, javax.swing.BoxLayout.Y_AXIS));

        timeTotalsScrollPane.setAlignmentY(0.0F);
        timeTotalsScrollPane.setDoubleBuffered(true);
        timeTotalsScrollPane.setMaximumSize(new java.awt.Dimension(1710, 1600));
        timeTotalsScrollPane.setMinimumSize(new java.awt.Dimension(100, 100));
        bodyPanel.add(timeTotalsScrollPane);

        rowCountPanel.setBackground(new java.awt.Color(183, 255, 255));
        rowCountPanel.setMaximumSize(new java.awt.Dimension(1710, 30));
        rowCountPanel.setMinimumSize(new java.awt.Dimension(100, 30));
        rowCountPanel.setPreferredSize(new java.awt.Dimension(100, 30));
        rowCountPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 0));

        numOfEmpsLabel.setText("Number of employees: ");
        numOfEmpsLabel.setPreferredSize(new java.awt.Dimension(160, 30));
        rowCountPanel.add(numOfEmpsLabel);

        bodyPanel.add(rowCountPanel);

        getContentPane().add(bodyPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
    
    private void verifReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verifReportButtonActionPerformed
        String orientation;
        int choice = JOptionPane.showOptionDialog
        (
            null,
            "Please select an orientation.",
            "Verification Report",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new String[]{"LANDSCAPE", "PORTRAIT", "CANCEL"},
            "UPDATE"
        );
        
        switch (choice)
        {
            case 0:
                orientation = "LANDSCAPE";
                break;
            case 1:
                orientation = "PORTRAIT";
                break;
            default: // user cancel
                return;
        }
        setCursor(Constants.HOURGLASS);
        PdfReports.createScheduleVerificationReport(getFormComponent(), feeder, site, mu, empid, UserData.getUUID(), startDate, endDate, editType, orientation);
        setCursor(Constants.NORMAL);
    }//GEN-LAST:event_verifReportButtonActionPerformed
    
    private void approveAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approveAllButtonActionPerformed
        if (!UserData.getUserAccessLevel().equals("APPROVAL"))
        {
            Misc.msgbox(getFormComponent(), "You DO NOT have Permissions to Approve for this site.  Email TVI Support!  " + Constants.EMAIL, "Approvals", 1, 1, 1);
            return;
        }
        
        boolean refresh, notLocked;
        Date payrollStart = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose());
        switch (editType)
        {
            case "NORMAL":
                refresh = Oracle.approveBy(getFormComponent(), feeder, site, mu, null, startDate, endDate, UserData.getUUID(), "MU", payrollStart, "ALL");
                notLocked = Oracle.areAnyRecordsNotLockedBy(getFormComponent(), feeder, site, mu, "ALL", startDate, endDate, UserData.getUUID());
                break;
            case "PRIOR":
                refresh = Oracle.approveBy(getFormComponent(), feeder, site, null, null, startDate, endDate, UserData.getUUID(), "PRIOR", payrollStart, null);
                notLocked = Oracle.areAnyRecordsNotLockedBy(getFormComponent(), feeder, site, "ALL", "ALL", startDate, endDate, UserData.getUUID());
                Misc.msgbox(getFormComponent(), "The screen will now be refreshed. Records that have been approved will no longer appear on the screen.", "Prior Approval", 1, 1, 1);
                break;
            case "DETAIL":
            case "BYEMPLOYEE":
                refresh = Oracle.approveBy(getFormComponent(), feeder, site, null, empidSelected, startDate, endDate, UserData.getUUID(), "EMP", payrollStart, null);
                notLocked = Oracle.areAnyRecordsNotLockedBy(getFormComponent(), feeder, site, "ALL", empidSelected, startDate, endDate, UserData.getUUID());
                break;
            case "CHANGES":
                refresh = Oracle.approveChanges(getFormComponent(), feeder, site, null, startDate, endDate, UserData.getUUID(), "ALL");
                notLocked = false;
                Misc.msgbox(getFormComponent(), "The screen will now be refreshed. Changes that have been approved will no longer appear on the screen.", "Approving Changes", 1, 1, 1);
                break;
            default:
                refresh = false;
                notLocked = false;
                Misc.msgbox(getFormComponent(), "Approval not available on this screen.", "Approvals Detail View", 1, 1, 1);
                break;
        }
        if (refresh)
        {
            new Thread(new RefreshDataThread()).start();
            if (notLocked)
            {
                Misc.msgbox(getFormComponent(), "Not all employees could be approved, some records are currently in use by other users.", "Some Records Not Approved", 1, 1, 1);
            }
        }
    }//GEN-LAST:event_approveAllButtonActionPerformed

    private void approveEmpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approveEmpButtonActionPerformed
        if (!UserData.getUserAccessLevel().equals("APPROVAL"))
        {
            Misc.msgbox(getFormComponent(), "You DO NOT have Permissions to Approve for this site.  Email TVI Support!  " + Constants.EMAIL, "Approvals", 1, 1, 1);
            return;
        }
        
        int selectedrow = timeTotalsTable.getSelectedRow();//DYADD change to timeTotalsData for safety?
        if (selectedrow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select an employee to Approve!", "Approve Employee", 1, 1, 1);
            return;
        }
        
        String lockedBy = Misc.objectToString(timeTotalsTable.getValueAt(selectedrow, idx_LOCKED_BY));
        if (!lockedBy.equals(UserData.getUUID()))
        {
            Misc.msgbox(getFormComponent(), "Cannot approve, selected record is locked by: " + lockedBy, "Record Locked", 1, 1, 1);
            return;
        }
        
        String empidin = Misc.objectToString(timeTotalsTable.getValueAt(selectedrow, idx_EMPID));
        Date reportingDateEmp = (Date) timeTotalsTable.getValueAt(selectedrow, idx_REPORTING_DATE);
        String approvalFlag = Misc.objectToString(timeTotalsTable.getValueAt(selectedrow, idx_APPR));
        if (approvalFlag.equals("Y"))
        {
            Misc.msgbox(getFormComponent(), "Employee is already Approved", "Approve Employee", 1, 1, 1);
            return;
        }
        
        if (editType.equals("CHANGES"))
        {
            if (Oracle.approveChanges(getFormComponent(), feeder, site, empidin, reportingDateEmp, reportingDateEmp, UserData.getUUID(), "EMP"))
            {
                timeTotalsData.setValueAt("Y", timeTotalsTable.convertRowIndexToModel(selectedrow), idx_APPR);
                if (Arrays.asList("Current", "Last Load").contains(Misc.objectToString(timeTotalsTable.getValueAt(selectedrow, idx_RECORD_TYPE))))
                {
                    for (int i = 0; i < timeTotalsTable.getRowCount(); i++)
                    {
                        if (Misc.objectToString(timeTotalsTable.getValueAt(i, idx_EMPID)).equals(timeTotalsTable.getValueAt(selectedrow, idx_EMPID)) &&
                            timeTotalsTable.getValueAt(i, idx_REPORTING_DATE).equals(timeTotalsTable.getValueAt(selectedrow, idx_REPORTING_DATE)) &&
                            Arrays.asList("Current", "Last Load").contains(Misc.objectToString(timeTotalsTable.getValueAt(i, idx_RECORD_TYPE))) &&
                            i != selectedrow)
                        {
                            timeTotalsData.setValueAt("Y", timeTotalsTable.convertRowIndexToModel(i), idx_APPR);
                            break;
                        }
                    }
                }
                else if (Arrays.asList("Deleted", "Restored").contains(Misc.objectToString(timeTotalsTable.getValueAt(selectedrow, idx_RECORD_TYPE))))
                {
                    for (int i = 0; i < timeTotalsTable.getRowCount(); i++)
                    {
                        if (Misc.objectToString(timeTotalsTable.getValueAt(i, idx_EMPID)).equals(timeTotalsTable.getValueAt(selectedrow, idx_EMPID)) &&
                            timeTotalsTable.getValueAt(i, idx_REPORTING_DATE).equals(timeTotalsTable.getValueAt(selectedrow, idx_REPORTING_DATE)) &&
                            Arrays.asList("Deleted", "Restored").contains(Misc.objectToString(timeTotalsTable.getValueAt(i, idx_RECORD_TYPE))) &&
                            i != selectedrow)
                        {
                            timeTotalsData.setValueAt("Y", timeTotalsTable.convertRowIndexToModel(i), idx_APPR);
                            break;
                        }
                    }
                }
            }
        }
        else if (Oracle.approveBy(getFormComponent(), feeder, site, null, empidin, reportingDateEmp, reportingDateEmp, UserData.getUUID(), "EMP", Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), RegionData.getPayClose()), null))
        {
            timeTotalsData.setValueAt("Y", timeTotalsTable.convertRowIndexToModel(selectedrow), idx_APPR);
        }
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_approveEmpButtonActionPerformed

    private void insertAbs()
    {
        Date changedDate = Oracle.getCurTime(getFormComponent());
        int newReckey = 0;
        int thisReckey;
        for (int i = 0; i < absencesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_EMPID))) &&
                selectedDate.equals((Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE)))
            {
                thisReckey = (Integer) absencesData.getValueAt(i, idx_Abs_RECKEY);
                if (thisReckey > newReckey)
                {
                    newReckey = thisReckey;
                }
            }
        }
        newReckey++;
        String sapCode = RegionData.getAbsenceCodes().get(0).getSapCode();
        String codeDescription = RegionData.getAbsenceCodes().get(0).getDescription();
        int days = 0;
        if (feeder.equals("MEX") && Misc.isNumeric(sapCode))
        {
            days = 1;
        }
        absencesData.addRow(new Object[]
        {
            empidSelected,                       // idx_Abs_EMPID
            selectedDate,                        // idx_Abs_REPORTING_DATE
            newReckey,                           // idx_Abs_RECKEY
            UserData.getUUID(),                  // idx_Abs_CHGD_BY
            changedDate,                         // idx_Abs_DATE_CHGD
            "Del",                               // idx_Abs_DEL_RECORD
            sapCode,                             // idx_Abs_SAP_CODE
            sapCode + "  -  " + codeDescription, // idx_Abs_CODE_DESC
            "",                                  // idx_Abs_REASON_CODE_DESC
            0,                                   // idx_Abs_HOURS_TREC
            0,                                   // idx_Abs_MINS_TREC
            days,                                // idx_Abs_DAYS
            "",                                  // idx_Abs_COMMENT
            ""                                   // idx_Abs_RECORD_TYPE
        });
        Oracle.insertAbsence(getFormComponent(), // parentFrame
            feeder,                              // feeder
            site,                                // site
            selectedTOTALVIEWID,                 // totalviewID
            selectedMU,                          // mu
            selectedDate,                        // reportingDate
            empidSelected,                       // empid
            newReckey,                           // recKey
            sapCode,                             // sapCodeTrec
            codeDescription,                     // codeDescription
            0.0,                                 // hoursTrec
            "",                                  // reasonCode
            "",                                  // reasonText
            0,                                   // readyFlag
            "",                                  // reasonDescription
            UserData.getUUID(),                  // changedBy
            0                                    // minsTrec
        );
        flagTimeTotals();
    }
    
    private void insertAtt()
    {
        Date changedDate = Oracle.getCurTime(getFormComponent());
        int newReckey = 0;
        int thisReckey;
        for (int i = 0; i < attendancesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)))
            {
                thisReckey = (Integer) attendancesData.getValueAt(i, idx_Att_RECKEY);
                if (thisReckey > newReckey)
                {
                    newReckey = thisReckey;
                }
            }
        }
        newReckey++;
        String sapCode = RegionData.getAttendanceCodes().get(0).getSapCodeArec();
        String codeDescription = RegionData.getAttendanceCodes().get(0).getDescriptionArec();
        attendancesData.addRow(new Object[]
        {
            empidSelected,                       // idx_Att_EMPID
            selectedDate,                        // idx_Att_REPORTING_DATE
            newReckey,                           // idx_Att_RECKEY
            UserData.getUUID(),                  // idx_Att_CHGD_BY
            changedDate,                         // idx_Att_DATE_CHGD
            "Del",                               // idx_Att_DEL_RECORD
            sapCode,                             // idx_Att_SAP_CODE
            sapCode + "  -  " + codeDescription, // idx_Att_CODE_DESC
            0,                                   // idx_Att_HOURS_AREC
            0,                                   // idx_Att_MINS_AREC
            0,                                   // idx_Att_DAYS
            "",                                  // idx_Att_COST_CENTER
            "",                                  // idx_Att_LOCATION_CODE
            "",                                  // idx_Att_ACTIVITY
            "",                                  // idx_Att_EC
            "",                                  // idx_Att_PROJECT_NUMBER
            "",                                  // idx_Att_FRC
            "",                                  // idx_Att_TAX_AREA
            ""                                   // idx_Att_RECORD_TYPE
        });
        Oracle.insertAttendance(getFormComponent(), // parentFrame
            feeder,                                 // feeder
            site,                                   // site
            selectedTOTALVIEWID,                    // totalviewID
            selectedMU,                             // mu
            selectedDate,                           // reportingDate
            empidSelected,                          // empid
            newReckey,                              // recKey
            sapCode,                                // sapCodeArec
            codeDescription,                        // codeDescription
            0.0,                                    // hoursArec
            "",                                     // activity
            "",                                     // costCenter
            "",                                     // locationCode
            "",                                     // projectNumber
            "",                                     // deptTrackingCode
            0,                                      // readyFlag
            "",                                     // taxArea
            "",                                     // frc
            "",                                     // ec
            UserData.getUUID(),                     // changedBy
            0                                       // minsArec
        );
        flagTimeTotals();
    }
    
    private void insertExtraPay()
    {
        Date changedDate = Oracle.getCurTime(getFormComponent());
        int newReckey = 0;
        int thisReckey;
        for (int i = 0; i < extraPaymentsData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_EMPID))) &&
                selectedDate.equals((Date) extraPaymentsData.getValueAt(i, idx_Ext_REPORTING_DATE)))
            {
                thisReckey = (Integer) extraPaymentsData.getValueAt(i, idx_Ext_RECKEY);
                if (thisReckey > newReckey)
                {
                    newReckey = thisReckey;
                }
            }
        }
        newReckey++;
        String sapCode = RegionData.getExtraPaymentCodes().get(0).getCodeErec();
        String codeDescription = RegionData.getExtraPaymentCodes().get(0).getDescriptionErec();
        String amountType = RegionData.getExtraPaymentCodes().get(0).getAmountTypeErec();
        extraPaymentsData.addRow(new Object[]
        {
            empidSelected,                       // idx_Ext_EMPID
            selectedDate,                        // idx_Ext_REPORTING_DATE
            newReckey,                           // idx_Ext_RECKEY
            UserData.getUUID(),                  // idx_Ext_CHGD_BY
            changedDate,                         // idx_Ext_DATE_CHGD
            "Del",                               // idx_Ext_DEL_RECORD
            sapCode,                             // idx_Ext_SAP_CODE
            sapCode + "  -  " + codeDescription, // idx_Ext_CODE_DESC
            0.0,                                 // idx_Ext_AMOUNT_EREC
            0,                                   // idx_Ext_MINS_EREC
            "",                                  // idx_Ext_COST_CENTER
            "",                                  // idx_Ext_LOCATION_CODE
            "",                                  // idx_Ext_ACTIVITY
            "",                                  // idx_Ext_PROJECT_NUMBER
            amountType,                          // idx_Ext_AMOUNT_TYPE
            ""                                   // idx_Ext_RECORD_TYPE
        });
        Oracle.insertExtraPayment(getFormComponent(), // parentFrame
            feeder,                                   // feeder
            site,                                     // site
            selectedTOTALVIEWID,                      // totalviewID
            selectedMU,                               // mu
            selectedDate,                             // reportingDate
            empidSelected,                            // empid
            newReckey,                                // recKey
            sapCode,                                  // sapCodeErec
            codeDescription,                          // codeDescription
            0.0,                                      // amountErec
            0,                                        // minsErec
            amountType,                               // amountType
            "",                                       // activity
            "",                                       // costCenter
            "",                                       // locationCode
            "",                                       // deptTrackingCode
            "",                                       // projectNumber
            "",                                       // ec
            UserData.getUUID()                        // changedBy
        );
        flagTimeTotals();
    }
    
    private void updateDatabase(int row)
    {
        setCursor(Constants.HOURGLASS);
        if ((Integer)timeTotalsData.getValueAt(row, idx_OTHERFLAGS) == -1)
        {
            if (Misc.objectToString(timeTotalsData.getValueAt(row, idx_MANUAL_CMP_BY)).equals("Resend"))
            {
                timeTotalsData.setValueAt("", row, idx_MANUAL_CMP_BY);
            }
            else
            {
                timeTotalsData.setValueAt(0, row, idx_OTHERFLAGS);
            }
        }
        
        Oracle.updateTimeTotals(getFormComponent(),                                          // parentFrame
            (Date) timeTotalsData.getValueAt(row, idx_REPORTING_DATE),                       // reportingDate
            empidSelected,                                                                   // empid
            Misc.objectToString(timeTotalsData.getValueAt(row, idx_DWS)),                    // dws
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_PARTTIME_FLAG)),         // parttimeFlag
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_HOLIDAY_FLAG)),          // holidayFlag
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_REG)),                    // reg
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_OVERTIME)),               // overtime   0210 + 0211 CZE
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_CALL_OUT)),               // callout    OT Weekday 0210 CZE
            0.0,                                                                             // total
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_REGTOTAL)),               // regTotal   CZE total hours worked OVERTIME + REG
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_ABSENCE_TOTAL)),          // absencesTotal
            0.0,                                                                             // absencesExtTotal
            0.0,                                                                             // ccTotal
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_EXTRAPAY_FLAG)),         // extraPayFlag
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_DIFFNIGHT)),             // diffShiftCWA
            0.0,                                                                             // leadHoursRegCWA
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_FLEX_HRS)),               // flexHours
            0,                                                                               // workedPdoBefore
            0,                                                                               // workedPdoAfter
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_ABSENCE_READY)),         // absencesReady
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_TIME_WORKED_READY)),     // timeWorkedReady
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_TIME_TOTALS_READY)),     // timeTotalsReady
            Misc.objectToString(timeTotalsData.getValueAt(row, idx_MESSAGE)),                // message
            0,                                                                               // highlightName
            Misc.objectToString(timeTotalsData.getValueAt(row, idx_STATUS)),                 // status
            0,                                                                               // tardyPaid1
            0,                                                                               // tardyPaid2
            0,                                                                               // tardyPaid3
            0,                                                                               // tardyPaid4
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_OVERTIME_REFUSED)),       // overtimeRefused
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_OVERTIME_NOT_AVAILABLE)), // overtimeNotAvailable
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_NIGHT_HOURS)),            // diffHoursRegCWA    NIGHT HOUURS WORKED CZE AND SVK
            0.0,                                                                             // leadHoursExtCWA
            0,                                                                               // holidayTraded
            0,                                                                               // ovnt
            0.0,                                                                             // bilingualDiffHourly
            0.0,                                                                             // bilingualDiffDaily
            0.0,                                                                             // leadHoursRegIBEW
            0.0,                                                                             // leadHoursExtIBEW
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_EVENING_HOURS)),          // diffHrsRegIBEW     EVENING HOURS WORKED SVK
            0.0,                                                                             // diffHoursExtIBEW
            0,                                                                               // workedHdBeforePost
            0,                                                                               // workedHdAfterPost
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_HOLIDAY_WORKED)),         // holi               MEX 1018 Houliday hours worked CZE Holiday Hours 0224
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_RD)),                    // rd
            0,                                                                               // TiuFlag
            Misc.objectToInt(timeTotalsData.getValueAt(row, idx_MEAL_ALLOWANCE)),            // mealAllowance
            0.0,                                                                             // rdHours
            0.0,                                                                             // rdAmt
            UserData.getUUID(),                                                              // chgdBy
            0.0,                                                                             // diffHoursExtCWA
            Misc.objectToInt(timeTotalsData.getValueAt(row, idx_DIFF_SOURCE)),               // diffSource
            0.0,                                                                             // callup
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_SIXTH_DAY)),             // sixthDay
            (Integer)timeTotalsData.getValueAt(row, idx_OTHERFLAGS),                         // otherFlags
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_SHIFT)),                  // shift
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_ATTEND_FLAG)),           // attendFlag
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_CARFARE)),               // carfareFlag
            Misc.objectToInt(timeTotalsData.getValueAt(row, idx_LOAD_STATUS)),               // loadStatus
            Misc.objectToInt(timeTotalsData.getValueAt(row, idx_DATE_TV_MODIFIED)),          // dateTVModified
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_SHIFT_TRADED)),          // shiftTraded
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_TARDY_FLAG)),            // tardyFlag
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_MA_FLAG)),               // maFlag
            0,                                                                               // rnaFlag
            Misc.booleanToOracle(timeTotalsData.getValueAt(row, idx_BILINGUAL_FLAG)),        // bilingualFlag
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_PREM)),                   // prem        OT Weekend/Holiday 0211 CZE
            Misc.objectToDouble(timeTotalsData.getValueAt(row, idx_SUND)),                   // sund        Total Weekend Hours 0222 CZE
            -1,                                                                              // cfasValidated  only used in INFOR client, default to -1 otherwise
            0                                                                                // resendFlag only used in INFOR client, default to 0 otherwise
        );
	
        if (!absencesChanged.isEmpty())
        {
            for (int i = 0; i < absencesChanged.size(); i++)
            {
                String reckey = absencesChanged.get(i);
                int absenceRow = -1;
                for (int j = 0; j < absencesTable.getRowCount(); j++)//DYADD change to absencesData for safety?
                {
                    if (Misc.objectToString(absencesTable.getValueAt(j, idx_Abs_RECKEY)).equals(reckey) &&
                        absencesTable.getValueAt(j, idx_Abs_EMPID).equals(empidSelected) &&
                        absencesTable.getValueAt(j, idx_Abs_REPORTING_DATE).equals(selectedDate))
                    {
                        absenceRow = j;
                        break;
                    }
                }
                if (absenceRow != -1)
                {
                    Oracle.updateAbsence(getFormComponent(),                                                            // parentFrame
                        (Date) timeTotalsData.getValueAt(row, idx_REPORTING_DATE),                                      // reportingDate
                        empidSelected,                                                                                  // empid
                        Misc.objectToInt(absencesTable.getValueAt(absenceRow, idx_Abs_RECKEY)),                         // recKey
                        Misc.objectToString(absencesTable.getValueAt(absenceRow, idx_Abs_SAP_CODE)),                    // sapCodeTrec
                        Misc.objectToString(absencesTable.getValueAt(absenceRow, idx_Abs_CODE_DESC)).substring(9),      // codeDescription
                        Misc.objectToDouble(absencesTable.getValueAt(absenceRow, idx_Abs_HOURS_TREC)),                  // hoursTrec
                        Misc.objectToReasonCode(absencesTable.getValueAt(absenceRow, idx_Abs_REASON_CODE_DESC)),        // reasonCode
                        Misc.objectToString(absencesTable.getValueAt(absenceRow, idx_Abs_COMMENT)),                     // reasonText
                        -1,                                                                                             // readyFlag
                        Misc.objectToReasonDescription(absencesTable.getValueAt(absenceRow, idx_Abs_REASON_CODE_DESC)), // reasonDescription
                        UserData.getUUID(),                                                                             // changedBy
                        Misc.objectToInt(absencesTable.getValueAt(absenceRow, idx_Abs_MINS_TREC))                       // minsTrec
                    );
                }
            }
        }
        if (!attendancesChanged.isEmpty())
        {
            for (int i = 0; i < attendancesChanged.size(); i++)
            {
                String reckey = attendancesChanged.get(i);
                int attendanceRow = -1;
                for (int j = 0; j < attendancesTable.getRowCount(); j++)//DYADD change to attendancesData for safety?
                {
                    if (Misc.objectToString(attendancesTable.getValueAt(j, idx_Att_RECKEY)).equals(reckey) &&
                        attendancesTable.getValueAt(j, idx_Att_EMPID).equals(empidSelected) &&
                        attendancesTable.getValueAt(j, idx_Att_REPORTING_DATE).equals(selectedDate))
                    {
                        attendanceRow = j;
                        break;
                    }
                }
                if (attendanceRow != -1)
                {
                    Oracle.updateAttendance(getFormComponent(),                                                            // parentFrame
                        (Date) timeTotalsData.getValueAt(row, idx_REPORTING_DATE),                                         // reportingDate
                        empidSelected,                                                                                     // empid
                        Misc.objectToInt(attendancesTable.getValueAt(attendanceRow, idx_Att_RECKEY)),                      // recKey
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_SAP_CODE)),                 // sapCodeArec
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_CODE_DESC)).substring(9),   // codeDescription
                        Misc.objectToDouble(attendancesTable.getValueAt(attendanceRow, idx_Att_HOURS_AREC)),               // hoursArec
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_ACTIVITY)),                 // activity
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_COST_CENTER)),              // costCenter
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_LOCATION_CODE)),            // locationCode
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_PROJECT_NUMBER)),           // projectNumber
                        "",                                                                                                // deptTrackingCode
                        -1,                                                                                                // readyFlag
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_TAX_AREA)),                 // taxArea
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_FRC)),                      // frc
                        Misc.objectToString(attendancesTable.getValueAt(attendanceRow, idx_Att_EC)),                       // ec
                        UserData.getUUID(),                                                                                // changedBy
                        Misc.objectToInt(attendancesTable.getValueAt(attendanceRow, idx_Att_MINS_AREC))                    // minsArec
                    );
                }
            }
        }
        if (!extraPaymentsChanged.isEmpty())
        {
            for (int i = 0; i < extraPaymentsChanged.size(); i++)
            {
                String reckey = extraPaymentsChanged.get(i);
                int extraPaymentsRow = -1;
                for (int j = 0; j < extraPaymentsTable.getRowCount(); j++)//DYADD change to extraPaymentsData for safety?
                {
                    if (Misc.objectToString(extraPaymentsTable.getValueAt(j, idx_Ext_RECKEY)).equals(reckey) &&
                        extraPaymentsTable.getValueAt(j, idx_Ext_EMPID).equals(empidSelected) &&
                        extraPaymentsTable.getValueAt(j, idx_Ext_REPORTING_DATE).equals(selectedDate))
                    {
                        extraPaymentsRow = j;
                        break;
                    }
                }
                if (extraPaymentsRow != -1)
                {
                    Oracle.updateExtraPayment(getFormComponent(),                                                                // parentFrame
                        (Date) timeTotalsData.getValueAt(row, idx_REPORTING_DATE),                                               // reportingDate
                        empidSelected,                                                                                           // empid
                        Misc.objectToInt(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_RECKEY)),                       // recKey
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_SAP_CODE)),                  // sapCodeErec
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_CODE_DESC)).substring(9),    // codeDescription
                        Misc.objectToDouble(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_AMOUNT_EREC)),               // amountErec
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_AMOUNT_TYPE)),               // amountType
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_ACTIVITY)),                  // activity
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_COST_CENTER)),               // costCenter
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_LOCATION_CODE)),             // locationCode
                        "",                                                                                                      // deptTrackingCode
                        Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_PROJECT_NUMBER)),            // projectNumber
                        "",                                                                                                      // ec
                        UserData.getUUID(),                                                                                      // changedBy
                        Misc.objectToInt(extraPaymentsTable.getValueAt(extraPaymentsRow, idx_Ext_MINS_EREC))                     // minsErec
                    );
                }
            }
        }
        setCursor(Constants.NORMAL);
    }
    
    private void absencesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_absencesButtonActionPerformed
        stopDetailTableCellEditing();
        currentCodeType = "Absence Detail";
        absencesScrollPane.setViewportView(absencesTable);
        absencesTable.setFillsViewportHeight(true);
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_absencesButtonActionPerformed
    
    private void extraPaymentsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_extraPaymentsButtonActionPerformed
        stopDetailTableCellEditing();
        currentCodeType = "Extra Pay Detail";
        absencesScrollPane.setViewportView(extraPaymentsTable);
        extraPaymentsTable.setFillsViewportHeight(true);
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_extraPaymentsButtonActionPerformed
    
    private void attendancesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attendancesButtonActionPerformed
        stopDetailTableCellEditing();
        currentCodeType = "Attendance Detail";
        absencesScrollPane.setViewportView(attendancesTable);
        attendancesTable.setFillsViewportHeight(true);
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_attendancesButtonActionPerformed
    
    private void addAbsenceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAbsenceButtonActionPerformed
        stopDetailTableCellEditing();
        if (!currentCodeType.equals("Absence Detail"))
        {
            absencesScrollPane.setViewportView(absencesTable);
            absencesTable.setFillsViewportHeight(true);
            currentCodeType = "Absence Detail";
        }
        insertAbs();
        absencesTable.changeSelection(absencesTable.getRowCount() - 1, idx_Abs_CODE_DESC, false, false);
        absencesTable.editCellAt(absencesTable.getRowCount() - 1, idx_Abs_CODE_DESC);
        absenceCodeCombo.showPopup();
        absenceCodeCombo.requestFocusInWindow();
    }//GEN-LAST:event_addAbsenceButtonActionPerformed
    
    private void addExtraPaymentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addExtraPaymentButtonActionPerformed
        stopDetailTableCellEditing();
        if (!currentCodeType.equals("Extra Pay Detail"))
        {
            absencesScrollPane.setViewportView(extraPaymentsTable);
            extraPaymentsTable.setFillsViewportHeight(true);
            currentCodeType = "Extra Pay Detail";
        }
        insertExtraPay();
        extraPaymentsTable.changeSelection(extraPaymentsTable.getRowCount() - 1, idx_Ext_CODE_DESC, false, false);
        extraPaymentsTable.editCellAt(extraPaymentsTable.getRowCount() - 1, idx_Ext_CODE_DESC);
        extraPaymentCodeCombo.showPopup();
        extraPaymentCodeCombo.requestFocusInWindow();
    }//GEN-LAST:event_addExtraPaymentButtonActionPerformed
    
    private void addAttendanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAttendanceButtonActionPerformed
        stopDetailTableCellEditing();
        if (!currentCodeType.equals("Attendance Detail"))
        {
            absencesScrollPane.setViewportView(attendancesTable);
            attendancesTable.setFillsViewportHeight(true);
            currentCodeType = "Attendance Detail";
        }
        insertAtt();
        attendancesTable.changeSelection(attendancesTable.getRowCount() - 1, idx_Att_CODE_DESC, false, false);
        attendancesTable.editCellAt(attendancesTable.getRowCount() - 1, idx_Att_CODE_DESC);
        attendanceCodeCombo.showPopup();
        attendanceCodeCombo.requestFocusInWindow();
    }//GEN-LAST:event_addAttendanceButtonActionPerformed
            
    private void employeeDetailButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeDetailButtonActionPerformed
        if (!editType.equals("NORMAL"))
        {
            Misc.msgbox(getFormComponent(), "Detail not allowed now.", "", 1, 1, 1);
        }
        else
        {
            Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, startDate, endDate, "NORMAL", UserData.getUUID());
            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, startDate, endDate, "NORMAL");
            refreshRelatedScreens();
            
            final String empidDetail = empidSelected;
            final Date endDateDetail = Oracle.getPayrollEndDate(getFormComponent(), RegionData.getPayCycle(), startDate);
            final Date startDateDetail;
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                startDateDetail = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDateDetail);
            }
            else
            {
                startDateDetail = Oracle.getPreviousPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDateDetail);
            }
            
            if (employeeCount > 0)
            {
                changeEmployee(0);
            }
            
            closeChildForms();
            dispose();
            releaseInstance();
            
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, empidDetail, startDateDetail, endDateDetail, union, "DETAIL");
        }
    }//GEN-LAST:event_employeeDetailButtonActionPerformed
    
    private void deleteEmployeeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEmployeeButtonActionPerformed
        if (timeTotalsTable.getSelectedRow() == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select a record first.", "Delete Employee", 1, 1, 1);
            return;
        }
        boolean okToDelete = true;
        boolean attemptRestore = true;
        String msg;
        if ("Completed".equals(Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS))))
        {
            Misc.msgbox(getFormComponent(), "You cannot delete an EMPLOYEE with a Completed STATUS, CALL TVI SUPPORT", "Deleting Employee", 1, 1, 1);
            okToDelete = false;
        }
        if (okToDelete && !UserData.getUserType().equals("POWER"))
        {
            msg = "<html>WARNING!! by using this button you will delete " + employee + " from this TVI Schedule ONLY<br>"
                + "Only do this if you are sure you do not want to report time for this EMPLOYEE for this date!<br>"
                + "If this record has been successfully sent to elink in the past, deleting will restore the last completed record.</html>";
            okToDelete = Misc.msgbox(getFormComponent(), msg, "Deleting Employee", 1, 2, 1);
        }
        if (okToDelete && UserData.getUserType().equals("POWER")) // give power users option to delete without restore
        {
            int choice = JOptionPane.showOptionDialog
            (
                null,
                "Choose an action:\nSelect RESTORE to restore the last completed history record.\nSelect DELETE to simply delete the record.",
                "Deleting Record",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                new String[]{"RESTORE", "DELETE", "CANCEL"},
                "RESTORE"
            );
            switch (choice)
            {
                case 0:
                    attemptRestore = true;
                    break;
                case 1:
                    attemptRestore = false;
                    break;
                default: // user cancel
                    okToDelete = false;
                    break;
            }
        }
        if (okToDelete)
        {
            if (attemptRestore && Oracle.wasCompleted(getFormComponent(), feeder, site, selectedMU, selectedDate, empidSelected)) // Delete the record. If a completed history record exists, restore it.
            {
                deletingEmployee = true;
                timeTotalsData.setValueAt("Not Ready", timeTotalsRow, idx_STATUS);
                Oracle.restoreFromHistory(getFormComponent(), feeder, site, selectedMU, empidSelected, selectedDate, UserData.getUUID());
                if (!UserData.getUserType().equals("POWER"))
                {
                    Misc.msgbox(getFormComponent(), "TVI will now restore the previously completed value for this employee.\n If you need the record removed, contact TVI support.", "Deleting Employee", 1, 1, 1);
                }
                new Thread(new RefreshDataThread()).start();
            }
            else // Simply delete the record.
            {
                if (Oracle.deleteEmployee(getFormComponent(), feeder, site, selectedMU, selectedDate, empidSelected, UserData.getUUID()))
                {
                    Oracle.updateEmployeeRecordsBeginLastDates(getFormComponent(), feeder, site, selectedMU, empidSelected, "TTDELETE");
                    timeTotalsData.removeRow(timeTotalsRow);
                    if (editType.equals("UPDATE"))
                    {
                        for (int i = timeTotalsData.getRowCount() - 1; i >= 0; i--)
                        {
                            if (empidSelected.equals(Misc.objectToString(timeTotalsData.getValueAt(i, idx_EMPID))) &&
                                selectedDate.equals((Date) timeTotalsData.getValueAt(i, idx_REPORTING_DATE)))
                            {
                                timeTotalsData.removeRow(i);
                                employeeCount--;
                            }
                        }
                    }
                    // *** Absences
                    for (int i = absencesData.getRowCount() - 1; i >= 0; i--)
                    {
                        if (empidSelected.equals(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_EMPID))) &&
                            selectedDate.equals((Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE)))
                        {
                            absencesData.removeRow(i);
                        }
                    }
                    // *** Attendance
                    for (int i = attendancesData.getRowCount() - 1; i >= 0; i--)
                    {
                        if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                            selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)))
                        {
                            attendancesData.removeRow(i);
                        }
                    }
                    // *** Extra Payments
                    for (int i = extraPaymentsData.getRowCount() - 1; i >= 0; i--)
                    {
                        if (empidSelected.equals(Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_EMPID))) &&
                            selectedDate.equals((Date) extraPaymentsData.getValueAt(i, idx_Ext_REPORTING_DATE)))
                        {
                            extraPaymentsData.removeRow(i);
                        }
                    }
                    
                    employeeUpdated = false;
                    employeeCount--;
                    updateTableSize();
                    setNumOfEmpsLabel();
                    if (employeeCount > 0)
                    {
                        timeTotalsRow = 0;
                        timeTotalsTable.changeSelection(timeTotalsRow, 0, false, false);
                        moveToNewEmployee(0);
                    }
                    else
                    {
                        emptySchedule();
                    }
                }
            }
        }
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_deleteEmployeeButtonActionPerformed
    
    @SuppressFBWarnings(value="SF_SWITCH_FALLTHROUGH", justification="Intended fallthrough to default for INT feeders on SEPARATED status.")
    private void changeToReadyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeToReadyButtonActionPerformed
        String status = Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS));
        Date reportingDate = (Date) timeTotalsTable.getValueAt(timeTotalsRow, idx_REPORTING_DATE);
        switch (status)
        {
            case "Completed":
                timeTotalsData.setValueAt("", timeTotalsRow, idx_MESSAGE);
                messageArea.setVisible(false);
                timeTotalsData.setValueAt("N", timeTotalsRow, idx_APPR);
                timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
                employeeUpdated = true;
                break;
            case "Separated":
                if (Arrays.asList("CZE", "MEX", "POL", "SVK").contains(feeder))
                {
                    //do nothing, continue to default to re-evaluate status
                }
                else
                {
                    if (Misc.objectEquals(Oracle.getEmployeeStatus(getFormComponent(), feeder, site, mu, empidSelected, reportingDate), "ACTIVE"))
                    {
                        //do nothing, continue to default to re-evaluate status
                    }
                    else
                    {
                        Misc.msgbox(getFormComponent(), "Employee must have status of ACTIVE to change to ready.", "Change to Ready", 0, 1, 1);
                        break;
                    }
                }
            case "Not Active":
                String attid = timeTotalsData.getValueAt(timeTotalsRow, idx_EMPID).toString();
                if (Oracle.isEmployeeActiveElsewhere(getFormComponent(), feeder, site, mu, attid, reportingDate))
                {
                    Misc.msgbox(getFormComponent(), "Employee is active on another MU, email TVI Support to correct: " + Constants.EMAIL, "Employee Status", 1, 1, 1);
                }
                else if (Oracle.isEmployeeActiveOn(getFormComponent(), feeder, site, mu, attid, reportingDate))
                {
                    timeTotalsData.setValueAt("", timeTotalsRow, idx_MESSAGE);
                    messageArea.setVisible(false);
                    timeTotalsData.setValueAt("N", timeTotalsRow, idx_APPR);
                    timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
                    encodeDWS();
                    flagTimeTotals();
                    sumAndCheckData(timeTotalsRow);
                    employeeUpdated = true;
                }
                else
                {
                    Misc.msgbox(getFormComponent(), "Employee isn't active for this MU, open Employee Maintenance to correct.", "Employee Status", 1, 1, 1);
                }
                break;
            default:
                encodeDWS();
                flagTimeTotals();
                sumAndCheckData(timeTotalsRow);
                Misc.msgbox(getFormComponent(), "Status has been re-evaluated.", "Change to Ready", 1, 1, 1);
                break;
        }
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_changeToReadyButtonActionPerformed
    
    private void addEmployeeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addEmployeeButtonActionPerformed
        AddEmployees.getInstance(getFormComponent(), feeder, site, mu, startDate);
    }//GEN-LAST:event_addEmployeeButtonActionPerformed
    
    private void changeEmpidButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeEmpidButtonActionPerformed
        String status = Misc.objectToString(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS));
        boolean okToChange;
        if (status.equals("Completed"))
        {
            Misc.msgbox(getFormComponent(), "You cannot change the UUID for a completed record - email TVI Support: " + Constants.EMAIL, "TVI - change UUID aborted", 1, 1, 1);
            return;
        }
        //Get the UUID from the user
        String newUUID = null;
        JTextField tf = new JTextField("");
        Misc.setEditorCharLimit(tf, 6, true);
        Object[] options = { "OK", "Cancel" };
        if (JOptionPane.showOptionDialog(getFormComponent(), tf, "Enter new UUID:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, "") == JOptionPane.OK_OPTION)
        {
            newUUID = tf.getText().toUpperCase(Locale.ENGLISH);
        }
        if (newUUID == null)
        {
            return;
        }
        if (newUUID.equals(empidSelected))
        {
            Misc.msgbox(getFormComponent(), "Employee UUID the same - not changed ", "TVI - change UUID aborted", 1, 1, 1);
            return;
        }
        if (newUUID.equals(""))
        {
            Misc.msgbox(getFormComponent(), "No UUID entered - UUID not changed ", "TVI - change UUID aborted", 1, 1, 1);
            return;
        }
        if (newUUID.length() != 6)
        {
            Misc.msgbox(getFormComponent(), "Employee UUID must be 6 characters - UUID not changed", "TVI - change UUID aborted", 1, 1, 1);
            return;
        }
        try
        {
            okToChange = false;
            Integer.parseInt(newUUID.substring(1, 2));
        }
        catch (NumberFormatException ex)
        {
            okToChange = true;
        }
        if (okToChange)
        {
            try
            {
                okToChange = false;
                Integer.parseInt(newUUID.substring(1, 2));
            }
            catch (NumberFormatException ex)
            {
                okToChange = true;
            }
        }
        if (!okToChange)
        {
            Misc.msgbox(getFormComponent(), "Employee UUID must begin with 2 alpha characters", "TVI - change UUID aborted", 1, 1, 1);
            return;
        }
        if (status.equals("Not Active"))
        {
            Date reportingDate = (Date) timeTotalsData.getValueAt(timeTotalsRow, idx_REPORTING_DATE);
            if (Oracle.doesEmployeeRecordConflict(getFormComponent(), feeder, site, mu, newUUID, reportingDate))
            {
                Misc.msgbox(getFormComponent(), "This employee already exists on another MU for this date, email TVI Support to correct: " + Constants.EMAIL, "Employee Status", 1, 1, 1);
                return;
            }
            if (!Oracle.isEmployeeActiveOn(getFormComponent(), feeder, site, mu, newUUID, reportingDate))
            {
                Misc.msgbox(getFormComponent(), "Employee is not active on this site, email TVI Support to correct: " + Constants.EMAIL, "Employee Status", 1, 1, 1);
                return;
            }
        }
        if (Oracle.changeUUID(getFormComponent(), selectedDate, empidSelected, newUUID))
        {
            timeTotalsData.setValueAt(newUUID, timeTotalsRow, idx_EMPID);
            // *** Absences
            for (int i = 0; i < absencesData.getRowCount(); i++)
            {
                if (empidSelected.equals(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_EMPID))) &&
                    selectedDate.equals((Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE)))
                {
                    absencesData.setValueAt(newUUID, i, idx_Abs_EMPID);
                }
            }
            // *** Attendance
            for (int i = 0; i < attendancesData.getRowCount(); i++)
            {
                if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                    selectedDate.equals((Date) (attendancesData.getValueAt(i, idx_Att_REPORTING_DATE))))
                {
                    attendancesData.setValueAt(newUUID, i, idx_Att_EMPID);
                }
            }
            // *** Extra Payments
            for (int i = 0; i < extraPaymentsData.getRowCount(); i++)
            {
                if (empidSelected.equals(Misc.objectToString(extraPaymentsData.getValueAt(i, idx_Ext_EMPID))) &&
                    selectedDate.equals((Date) (extraPaymentsData.getValueAt(i, idx_Ext_REPORTING_DATE))))
                {
                    extraPaymentsData.setValueAt(newUUID, i, idx_Ext_EMPID);
                }
            }
            empidSelected = newUUID;
            empidLabel.setText(empidSelected);
            employeeUpdated = true;
            if (Arrays.asList("DETAIL", "BYEMPLOYEE").contains(editType))
            {
                changedEmpidList.add(newUUID);
            }
        }
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_changeEmpidButtonActionPerformed
    
    private void employeeMaintenanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeMaintenanceButtonActionPerformed
        if (!RegionData.getNewFeature())
        {
            EmployeeMaintenance.getInstance(getFormComponent(), feeder, site, empidSelected);
        }
        else
        {
            EmployeeRosterMaintenance.getInstance(getFormComponent(), feeder, site, empidSelected);
        }
        
    }//GEN-LAST:event_employeeMaintenanceButtonActionPerformed
        
    private void commentFormButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_commentFormButtonActionPerformed
        CommentList.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_commentFormButtonActionPerformed
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void startStopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startStopButtonActionPerformed
        int selectedRow = timeTotalsTable.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select a record first.", "Start & Stops", 1, 1, 1);
            return;
        }
        final String startStopMU = timeTotalsTable.getValueAt(selectedRow, idx_MU).toString();
        final Date startStopDate = (Date) timeTotalsTable.getValueAt(selectedRow, idx_REPORTING_DATE);
        final String startStopEmployee = timeTotalsTable.getValueAt(selectedRow, idx_EMPLOYEE).toString();
        final String recordType = timeTotalsTable.getValueAt(selectedRow, idx_RECORD_TYPE).toString();
        StartStopTimes.getInstance(getFormComponent(), feeder, site, startStopMU, empidSelected, startStopEmployee, startStopDate, recordType);
    }//GEN-LAST:event_startStopButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        new Thread(new RefreshDataThread()).start();
        Misc.setIndexAbsCode(idx_Abs_SAP_CODE);
        Misc.setIndexAttCode(idx_Att_SAP_CODE);
        Misc.setIndexExtCode(idx_Ext_SAP_CODE);
    }//GEN-LAST:event_formWindowOpened

    private void toggleSendButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggleSendButton2ActionPerformed
        int otherFlags = (Integer)timeTotalsData.getValueAt(timeTotalsRow, idx_OTHERFLAGS);
        switch (otherFlags)
        {
            case 0:
                timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
                timeTotalsData.setValueAt(-9, timeTotalsRow, idx_OTHERFLAGS);
                timeTotalsData.setValueAt("FYI: TVI Support removing from eLink", timeTotalsRow, idx_MESSAGE);
                break;
            case -9:
                timeTotalsData.setValueAt(0, timeTotalsRow, idx_OTHERFLAGS);
                timeTotalsData.setValueAt("", timeTotalsRow, idx_MESSAGE);
                break;
            default:
                return;
        }
        updateDatabase(timeTotalsRow);
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_toggleSendButton2ActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        if (editType.equals("NORMAL") && Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, startDate).equals("Imported"))
        {
            Misc.msgbox(getFormComponent(), "Schedule has been re-imported, closing form.", "Schedule Re-Imported", 1, 1, 1);
            closeForm();
        }
        else
        {
            new Thread(new RefreshDataThread()).start();
        }
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void toggleSendButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toggleSendButton1ActionPerformed
        int otherFlags = (Integer)timeTotalsData.getValueAt(timeTotalsRow, idx_OTHERFLAGS);
        switch (otherFlags)
        {
            case 0:
                timeTotalsData.setValueAt("Ready", timeTotalsRow, idx_STATUS);
                timeTotalsData.setValueAt(-1, timeTotalsRow, idx_OTHERFLAGS);
                timeTotalsData.setValueAt("Resend", timeTotalsRow, idx_MANUAL_CMP_BY);
                break;
            case -1:
                timeTotalsData.setValueAt(0, timeTotalsRow, idx_OTHERFLAGS);
                timeTotalsData.setValueAt("", timeTotalsRow, idx_MANUAL_CMP_BY);
                break;
            default:
                return;
        }
        updateDatabase(timeTotalsRow);
        timeTotalsTable.requestFocusInWindow();
    }//GEN-LAST:event_toggleSendButton1ActionPerformed

    private void importErrorsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importErrorsButtonActionPerformed
        ImportRosterNotifications.getInstance(getFormComponent(), feeder, site, mu, startDate, union, UserData.getUUID(), "");
    }//GEN-LAST:event_importErrorsButtonActionPerformed
    
    public static void addEmployeeInstance(Object[] row)
    {
        if (instance != null)
        {
            instance.addEmployee(row);
        }
    }
    
    private void addEmployee(Object[] row)
    {
        timeTotalsData.addRow(row);
        employeeCount++;
        setNumOfEmpsLabel();
        updateTableSize();
        int rowNum = timeTotalsData.getRowCount() - 1;
        changeEmployee(rowNum);
        
        timeTotalsTable.getRowSorter().setSortKeys(null); // unsort timetotals
        timeTotalsData.moveRow(rowNum, rowNum, timeTotalsTable.convertRowIndexToModel(0));
        timeTotalsTable.changeSelection(0, 0, false, false); // select the top row
        moveToNewEmployee(0);
    }
    
    private void updateTableSize()
    {
        int maxWidth = 20;
        for (int i = 0; i < timeTotalsTable.getColumnCount(); i++)
        {
            maxWidth += timeTotalsTable.getColumnModel().getColumn(i).getPreferredWidth();
        }
        int maxHeight = timeTotalsTable.getRowHeight() * employeeCount + timeTotalsTable.getTableHeader().getPreferredSize().height + 20;
        timeTotalsScrollPane.setMaximumSize(new Dimension(maxWidth, maxHeight));
        timeTotalsScrollPane.revalidate();
        rowCountPanel.setMaximumSize(new Dimension(maxWidth, 30));
        rowCountPanel.revalidate();
    }
    
    private void setNumOfEmpsLabel()
    {
        switch (editType)
        {
            case "DETAIL":
            case "BYEMPLOYEE":
            case "APPR READ ONLY":
                numOfEmpsLabel.setText("Number of days displayed: " + employeeCount);
                break;
            case "PRIOR":
            case "UPDATE":
            case "CHANGES":
                numOfEmpsLabel.setText("Num of records displayed: " + employeeCount);
                break;
            default:
                numOfEmpsLabel.setText("Number of employees: " + employeeCount);
                break;
        }
        numOfEmpsLabel.setVisible(true);
    }
    
    private void addAbsence(String sapcode, double hoursTREC)
    {
        Date changedDate = Oracle.getCurTime(getFormComponent());
        int newReckey = 0;
        int thisReckey;
        String description = "";
        for (AbsenceCodeRecord absence : RegionData.getAbsenceCodes())
        {
            if (absence.getSapCode().equals(sapcode))
            {
                description = absence.getDescription();
            }
        }
        for (int i = 0; i < absencesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(absencesData.getValueAt(i, idx_Abs_EMPID))) &&
                selectedDate.equals((Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE)))
            {
                if (Misc.objectToString(absencesData.getValueAt(i, idx_Abs_SAP_CODE)).equals(sapcode)) // the equivelancy code already exists
                {
                    if (!absencesData.getValueAt(i, idx_Abs_HOURS_TREC).equals(hoursTREC)) // the equivelancy value needs to be updated
                    {
                        String recKey = Misc.objectToString(absencesData.getValueAt(i, idx_Abs_RECKEY));
                        Oracle.deleteAbsence(getFormComponent(), empidSelected, (Date) absencesData.getValueAt(i, idx_Abs_REPORTING_DATE), recKey);
                        if (hoursTREC > 0)
                        {
                            Oracle.insertAbsence(getFormComponent(),            // parentFrame
                                feeder,                                         // feeder
                                site,                                           // site
                                selectedTOTALVIEWID,                            // totalviewID
                                selectedMU,                                     // mu
                                selectedDate,                                   // reportingDate
                                empidSelected,                                  // empid
                                Integer.parseInt(recKey),                       // recKey
                                sapcode,                                        // sapCodeTrec
                                description,                                    // codeDescription
                                hoursTREC,                                      // hoursTrec
                                "",                                             // reasonCode
                                "",                                             // reasonText
                                0,                                              // readyFlag
                                "",                                             // reasonDescription
                                UserData.getUUID(),                             // changedBy
                                Misc.hoursToMinutes(hoursTREC)                  // minsTrec
                            );
                            absencesData.setValueAt(BigDecimal.valueOf(hoursTREC).setScale(2, RoundingMode.HALF_EVEN), i, idx_Abs_HOURS_TREC);
                        }
                        else
                        {
                            absencesData.removeRow(i);
                            absencesTable.revalidate();
                        }
                        
                        Misc.msgbox(getFormComponent(), "Absence equivelancy \"" + sapcode + "\" recalculated for employee: " + empidSelected, "Absence Code Generation", 1, 1, 1);
                    }
                    return;
                }
                thisReckey = Misc.objectToInt(absencesData.getValueAt(i, idx_Abs_RECKEY));
                if (thisReckey > newReckey)
                {
                    newReckey = thisReckey;
                }
            }
        }
        if (hoursTREC <= 0)
        {
            return;//don't generate a negative or 0-hour record
        }
        newReckey++;
        int days = 0;
        if (feeder.equals("MEX") && Misc.isNumeric(sapcode))
        {
            days = 1;
        }
        absencesData.addRow(new Object[]
        {
            empidSelected,                   // idx_Abs_EMPID
            selectedDate,                    // idx_Abs_REPORTING_DATE
            newReckey,                       // idx_Abs_RECKEY
            UserData.getUUID(),              // idx_Abs_CHGD_BY
            changedDate,                     // idx_Abs_DATE_CHGD
            "Del",                           // idx_Abs_DEL_RECORD
            sapcode,                         // idx_Abs_SAP_CODE
            sapcode + "  -  " + description, // idx_Abs_CODE_DESC
            "",                              // idx_Abs_REASON_CODE_DESC
            hoursTREC,                       // idx_Abs_HOURS_TREC
            0,                               // idx_Abs_MINS_TREC
            days,                            // idx_Abs_DAYS
            "",                              // idx_Abs_COMMENT
            ""                               // idx_Abs_RECORD_TYPE
        });
        Oracle.insertAbsence(getFormComponent(),  // parentFrame
            feeder,                               // feeder
            site,                                 // site
            selectedTOTALVIEWID,                  // totalviewID
            selectedMU,                           // mu
            selectedDate,                         // reportingDate
            empidSelected,                        // empid
            newReckey,                            // recKey
            sapcode,                              // sapCodeTrec
            description,                          // codeDescription
            hoursTREC,                            // hoursTrec
            "",                                   // reasonCode
            "",                                   // reasonText
            0,                                    // readyFlag
            "",                                   // reasonDescription
            UserData.getUUID(),                   // changedBy
            Misc.hoursToMinutes(hoursTREC)        // minsTrec
        );
        flagTimeTotals();
        Misc.msgbox(getFormComponent(), "Absence equivelancy \"" + sapcode + "\" generated for employee: " + empidSelected, "Absence Code Generation", 1, 1, 1);
    }
    
    private void addAttendance(String sapcode, double hoursAREC)
    {
        Date changedDate = Oracle.getCurTime(getFormComponent());
        int newReckey = 0;
        int thisReckey;
        String description = "";
        for (AttendanceCodeRecord attendance : RegionData.getAttendanceCodes())
        {
            if (attendance.getSapCodeArec().equals(sapcode))
            {
                description = attendance.getDescriptionArec();
            }
        }
        for (int i = 0; i < attendancesData.getRowCount(); i++)
        {
            if (empidSelected.equals(Misc.objectToString(attendancesData.getValueAt(i, idx_Att_EMPID))) &&
                selectedDate.equals((Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE)))
            {
                if (Misc.objectToString(attendancesData.getValueAt(i, idx_Att_SAP_CODE)).equals(sapcode)) // the code already exists
                {
                    if (Misc.objectToDouble(attendancesData.getValueAt(i, idx_Att_HOURS_AREC)) != hoursAREC) // the value needs to be updated
                    {
                        String recKey = Misc.objectToString(attendancesData.getValueAt(i, idx_Att_RECKEY));
                        Oracle.deleteAttendance(getFormComponent(), empidSelected, (Date) attendancesData.getValueAt(i, idx_Att_REPORTING_DATE), recKey);
                        if (hoursAREC > 0)
                        {
                            Oracle.insertAttendance(getFormComponent(),      // parentFrame
                                feeder,                                      // feeder
                                site,                                        // site
                                selectedTOTALVIEWID,                         // totalviewID
                                selectedMU,                                  // mu
                                selectedDate,                                // reportingDate
                                empidSelected,                               // empid
                                Integer.parseInt(recKey),                    // recKey
                                sapcode,                                     // sapCodeArec
                                description,                                 // codeDescription
                                hoursAREC,                                   // hoursArec
                                "",                                          // activity
                                "",                                          // costCenter
                                "",                                          // locationCode
                                "",                                          // projectNumber
                                "",                                          // deptTrackingCode
                                0,                                           // readyFlag
                                "",                                          // taxArea
                                "",                                          // frc
                                "",                                          // ec
                                UserData.getUUID(),                          // changedBy
                                Misc.hoursToMinutes(hoursAREC)               // minsArec
                            );
                            attendancesData.setValueAt(Misc.doubleToBigDecimal(hoursAREC), i, idx_Att_HOURS_AREC);
                            attendancesData.setValueAt(Misc.hoursToMinutes(hoursAREC), i, idx_Att_MINS_AREC);
                        }
                        else
                        {
                            attendancesData.removeRow(i);
                            attendancesTable.revalidate();
                        }
                        
                        Misc.msgbox(getFormComponent(), "Attendance \"" + sapcode + "\" recalculated for employee: " + empidSelected, "Attendance Code Generation", 1, 1, 1);
                    }
                    return;
                }
                thisReckey = Misc.objectToInt(attendancesData.getValueAt(i, idx_Att_RECKEY));
                if (thisReckey > newReckey)
                {
                    newReckey = thisReckey;
                }
            }
        }
        if (hoursAREC <= 0)
        {
            return;//don't generate a negative or 0-hour record
        }
        newReckey++;
        double shift = Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT));
        BigDecimal days = BigDecimal.valueOf(0);
        if (feeder.equals("CZE") && sapcode.equals("0200") && shift > 0)
        {
            days = BigDecimal.valueOf(hoursAREC).divide(BigDecimal.valueOf(shift)).setScale(2, RoundingMode.HALF_EVEN);
        }
        attendancesData.addRow(new Object[]
        {
            empidSelected,                   // idx_Att_EMPID
            selectedDate,                    // idx_Att_REPORTING_DATE
            newReckey,                       // idx_Att_RECKEY
            UserData.getUUID(),              // idx_Att_CHGD_BY
            changedDate,                     // idx_Att_DATE_CHGD
            "Del",                           // idx_Att_DEL_RECORD
            sapcode,                         // idx_Att_SAP_CODE
            sapcode + " - " + description,   // idx_Att_CODE_DESC
            hoursAREC,                       // idx_Att_HOURS_AREC
            Misc.hoursToMinutes(hoursAREC),  // idx_Att_MINS_AREC
            days,                            // idx_Att_DAYS
            "",                              // idx_Att_COST_CENTER
            "",                              // idx_Att_LOCATION_CODE
            "",                              // idx_Att_ACTIVITY
            "",                              // idx_Att_EC
            "",                              // idx_Att_PROJECT_NUMBER
            "",                              // idx_Att_FRC
            "",                              // idx_Att_TAX_AREA
            ""                               // idx_Att_RECORD_TYPE
        });
        Oracle.insertAttendance(getFormComponent(),   // parentFrame
            feeder,                                   // feeder
            site,                                     // site
            selectedTOTALVIEWID,                      // totalviewID
            selectedMU,                               // mu
            selectedDate,                             // reportingDate
            empidSelected,                            // empid
            newReckey,                                // recKey
            sapcode,                                  // sapCodeArec
            description,                              // codeDescription
            hoursAREC,                                // hoursArec
            "",                                       // activity
            "",                                       // costCenter
            "",                                       // locationCode
            "",                                       // projectNumber
            "",                                       // deptTrackingCode
            0,                                        // readyFlag
            "",                                       // taxArea
            "",                                       // frc
            "",                                       // ec
            UserData.getUUID(),                       // changedBy
            Misc.hoursToMinutes(hoursAREC)            // minsArec
        );
        flagTimeTotals();
    }
    
    private void emptySchedule()
    {
        timeTotalsRow = -1;
        setControlsEnabled(false);
        addEmployeeButton.setEnabled(true);
        loadingLabel.setText("EMPTY SCHEDULE");
        absencesScrollPane.setViewportView(loadingPanel);
        progressBar.setVisible(false);
        if (editType.equals("NORMAL"))
        {
            if (UserData.getUserType().equals("POWER"))
            {
                if (Misc.msgbox(getFormComponent(), "Schedule is empty. Select OK to delete.", "Empty Schedule", -1, 2, 1))
                {
                    Oracle.deleteSchedule(getFormComponent(), feeder, site, mu, startDate);
                    refreshRelatedScreens();
                    closeChildForms();
                    releaseInstance();
                    dispose();
                }
            }
            else
            {
                Misc.msgbox(getFormComponent(), "Schedule is empty and will be deleted.", "Empty Schedule", 1, 1, 1);
                Oracle.deleteSchedule(getFormComponent(), feeder, site, mu, startDate);
                refreshRelatedScreens();
                closeChildForms();
                releaseInstance();
                dispose();
            }
        }
    }
    
    private class RefreshDataThread implements Runnable
    {
        CountDownLatch latch;
        ResultSetWrapper results = null;
        boolean finishedTimeTotals = false;
        boolean finishedAbsences = false;
        boolean finishedExtraPayments = false;
        boolean finishedAttendances = false;
        boolean cancelRefresh = false;
        
        @Override
        public void run()
        {
            if (refreshTimeReportingLock.tryAcquire())
            {
                try
                {
                    timeTotalsWorker = null;
                    absencesWorker = null;
                    extraPaymentsWorker = null;
                    attendancesWorker = null;
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    // this needs to be run before the dataModels are overridden so that changeEmployee() gets a chance to update the database
                    // when it needs to cancel refreshing, it sets cancelRefresh = true to cancel the workers after they're initialized
                    initializeRefresh();
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    timeTotalsData = new CustomTableModel(buildColumnNamesTimeTotals());
                    absencesData = new CustomTableModel(buildColumnNamesAbsences());
                    extraPaymentsData = new CustomTableModel(buildColumnNamesExtraPayments());
                    attendancesData = new CustomTableModel(buildColumnNamesAttendances());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethodTimeTotals = this::getResultsTimeTotals;
                    Supplier<ResultSetWrapper> getResultsMethodAbsences = this::getResultsAbsences;
                    Supplier<ResultSetWrapper> getResultsMethodExtraPayments = this::getResultsExtraPayments;
                    Supplier<ResultSetWrapper> getResultsMethodAttendances = this::getResultsAttendances;
                    Function<ResultSet, Object[]> processResultsFuncTimeTotals = this::processResultsTimeTotals;
                    Function<ResultSet, Object[]> processResultsFuncAbsences = this::processResultsAbsences;
                    Function<ResultSet, Object[]> processResultsFuncExtraPayments = this::processResultsExtraPayments;
                    Function<ResultSet, Object[]> processResultsFuncAttendances = this::processResultsAttendances;
                    Consumer<Boolean> finalizeRefreshMethodTimeTotals = this::finalizeRefreshTimeTotals;
                    Consumer<Boolean> finalizeRefreshMethodAbsences = this::finalizeRefreshAbsences;
                    Consumer<Boolean> finalizeRefreshMethodExtraPayments = this::finalizeRefreshExtraPayments;
                    Consumer<Boolean> finalizeRefreshMethodAttendances = this::finalizeRefreshAttendances;
                    
                    // initialize a CountDownLatch with the number of workers to wait for
                    latch = new CountDownLatch(4);
                    
                    // initialize the custom swing workers
                    timeTotalsWorker = new TableSwingWorker(getFormComponent(), timeTotalsData, getResultsMethodTimeTotals, processResultsFuncTimeTotals, finalizeRefreshMethodTimeTotals, latch);
                    absencesWorker = new TableSwingWorker(getFormComponent(), absencesData, getResultsMethodAbsences, processResultsFuncAbsences, finalizeRefreshMethodAbsences, latch);
                    extraPaymentsWorker = new TableSwingWorker(getFormComponent(), extraPaymentsData, getResultsMethodExtraPayments, processResultsFuncExtraPayments, finalizeRefreshMethodExtraPayments, latch);
                    attendancesWorker = new TableSwingWorker(getFormComponent(), attendancesData, getResultsMethodAttendances, processResultsFuncAttendances, finalizeRefreshMethodAttendances, latch);
                    
                    if (cancelRefresh)
                    {
                        timeTotalsWorker.cancel(true);
                        absencesWorker.cancel(true);
                        extraPaymentsWorker.cancel(true);
                        attendancesWorker.cancel(true);
                    }
                    
                    if (!timeTotalsWorker.isCancelled() && !absencesWorker.isCancelled() && !extraPaymentsWorker.isCancelled() && !attendancesWorker.isCancelled())
                    {
                        getResults();
                    }
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    timeTotalsWorker.execute();
                    absencesWorker.execute();
                    extraPaymentsWorker.execute();
                    attendancesWorker.execute();
                }
                finally
                {
                    if (timeTotalsWorker == null || absencesWorker == null || extraPaymentsWorker == null || attendancesWorker == null) // The thread encountered an error before the workers could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTimeReportingLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                // change employee selection to trigger update logic
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (timeTotalsTable != null)
                        {
                            if (timeTotalsTable.getSelectedRow() != -1)
                            {
                                changeEmployee(0);
                            }
                        }
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            // disable controls & set view during refresh
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    refreshButton.setEnabled(false);
                    timeTotalsScrollPane.setVisible(false);
                    setControlsEnabled(false);
                    addEmployeeButton.setEnabled(false);
                    deleteEmployeeButton.setEnabled(false);
                    changeToReadyButton.setEnabled(false);
                    changeEmpidButton.setEnabled(false);
                    numOfEmpsLabel.setVisible(false);
                    absencesScrollPane.setViewportView(loadingPanel);
                    progressBar.setValue(0);
                    progressBar.setVisible(true);
                }
            });
            
            // check schedule status
            if (editType.equals("NORMAL"))
            {
                String status = Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, startDate);
                if (status == null)
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                Misc.msgbox(getFormComponent(), "No data found, the schedule will now close.", "Schedule does not exist.", 1, 1, 1);
                                closeChildForms();
                                
                                releaseInstance();
                                dispose();
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    cancelRefresh = true;
                }
                else if (status.equals("Imported"))// Not performed on refresh
                {
                    Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, startDate, endDate, "NORMAL", "TVI");
                }
            }
            
            // check if records are locked on another form
            boolean recordsLockedByAnotherForm;
            if (Arrays.asList("DETAIL", "BYEMPLOYEE").contains(editType))
            {
                recordsLockedByAnotherForm = Oracle.areAnyRecordsLockedByAnotherForm(getFormComponent(), feeder, site, "ALL", empid, startDate, endDate, UserData.getUUID(), "DETAIL");
            }
            else if (editType.equals("PRIOR"))
            {
                recordsLockedByAnotherForm = Oracle.areAnyRecordsLockedByAnotherForm(getFormComponent(), feeder, site, "ALL", "ALL", startDate, endDate, UserData.getUUID(), "PRIOR");
            }
            else if (editType.equals("UPDATE"))
            {
                recordsLockedByAnotherForm = Oracle.areAnyRecordsLockedByAnotherForm(getFormComponent(), feeder, site, "ALL", "ALL", null, null, UserData.getUUID(), "UPDATE");
            }
            else if (editType.equals("NORMAL"))
            {
                recordsLockedByAnotherForm = Oracle.areAnyRecordsLockedByAnotherForm(getFormComponent(), feeder, site, mu, "ALL", startDate, endDate, UserData.getUUID(), "NORMAL");
            }
            else if (editType.equals("CHANGES"))
            {
                recordsLockedByAnotherForm = Oracle.areAnyRecordsLockedByAnotherForm(getFormComponent(), feeder, site, "ALL", "ALL", startDate, endDate, UserData.getUUID(), "CHANGE");
            }
            else // editType is "APPR READ ONLY"
            {
                recordsLockedByAnotherForm = false;
            }
            if (recordsLockedByAnotherForm)
            {
                try
                {
                    SwingUtilities.invokeAndWait(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            if (PayrollPeriodApproval.exists())
                            {
                                String message = "<html>You already have some of these records locked in another window,<br>"
                                               + "you must release them by closing the form before you can continue.<br>"
                                               + "<b>The relevant window will now be restored.</b</html>";
                                Misc.msgbox(getFormComponent(), message, "Records already locked in another window.", 1, 1, 1);
                                PayrollPeriodApproval.focusInstance();
                                
                                closeChildForms();
                                releaseInstance();
                                dispose();
                                cancelRefresh = true;
                            }
                            else
                            {
                                Misc.msgbox(getFormComponent(), "You have some of these records locked by an unknown process. Email TVI Support at " + Constants.EMAIL, "Records locked", 1, 1, 1);
                            }
                        }
                    });
                }
                catch (InterruptedException | InvocationTargetException ex) {}
            }
            
            // lock the records
            if (!UserData.getUserAccessLevel().equals("READONLY"))
            {
                if (Arrays.asList("DETAIL", "BYEMPLOYEE").contains(editType))
                {
                    Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, null, empid, startDate, endDate, UserData.getUUID(), "DETAIL");
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                }
                else if (editType.equals("PRIOR"))
                {
                    Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, null, null, startDate, endDate, UserData.getUUID(), "PRIOR");
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                }
                else if (editType.equals("UPDATE"))
                {
                    Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, mu, null, null, null, UserData.getUUID(), "UPDATE");
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, null, null, "UPDATE");
                }
                else if (editType.equals("NORMAL"))
                {
                    Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, mu, null, startDate, endDate, UserData.getUUID(), "NORMAL");
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, startDate, endDate, "NORMAL");
                }
                else if (editType.equals("CHANGES"))
                {
                    Oracle.setRecordsLockedBy(getFormComponent(), feeder, site, null, null, startDate, endDate, UserData.getUUID(), "CHANGE");
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                }
            }
            
            timeTotalsRow = -1;
            employeeCount = 0;
        }
        
        /**
        * buildColumnNamesTimeTotals()
        * 
        * Builds the column names to use for the timeTotalsTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesTimeTotals()
        {
            String[] colNames = new String[]
            {
                "",                                              // idx_EMPID
                "",                                              // idx_AGENTID
                "",                                              // idx_DWS
                "",                                              // idx_HOLIDAY_FLAG
                "",                                              // idx_ABSENCE_READY
                "",                                              // idx_TIME_WORKED_READY
                "",                                              // idx_TIME_TOTALS_READY
                "",                                              // idx_MESSAGE
                "",                                              // idx_APPROVED_BY
                "",                                              // idx_DATE_APPROVED
                "",                                              // idx_OTHERFLAGS
                "",                                              // idx_MANUAL_CMP_BY
                "",                                              // idx_TO_ELINK_DATE_TIME
                "",                                              // idx_COMP_OR_LOAD_DATE
                "",                                              // idx_LOAD_STATUS
                "",                                              // idx_DATE_TV_MODIFIED
                "",                                              // idx_TOTALVIEWID
                "MU",                                            // idx_MU
                "",                                              // idx_DIFF_SOURCE
                "Date",                                          // idx_REPORTING_DATE
                "Appr",                                          // idx_APPR
                "Status",                                        // idx_STATUS
                "Employee",                                      // idx_EMPLOYEE
                "Shift",                                         // idx_SHIFT
                "REG",                                           // idx_REG
                "EXT",                                           // idx_OVERTIME
                Misc.centerHTML("OT<br>1030"),                   // idx_OT_1030           MEX ONLY
                Misc.centerHTML("OT<br>8115"),                   // idx_OT_8115           MEX ONLY
                Misc.centerHTML("Computed<br>OT"),               // idx_COMPUTED_OT       MEX ONLY
                Misc.centerHTML("OTCC"),                         // idx_CALL_OVERLAP
                Misc.centerHTML("Call<br>Out"),                  // idx_CALL_OUT
                "Prem",                                          // idx_PREM
                "Flex",                                          // idx_FLEX_HRS
                Misc.centerHTML("Evening<br>Hours"),             // idx_EVENING_HOURS
                Misc.centerHTML("Night<br>Hours"),               // idx_NIGHT_HOURS
                "SUND",                                          // idx_SUND
                Misc.centerHTML("Holiday<br>Worked"),            // idx_HOLIDAY_WORKED
                Misc.centerHTML("Reg +<br>Abs"),                 // idx_REGTOTAL
                "Abs",                                           // idx_ABSENCE_TOTAL
                "Extra",                                         // idx_EXTRAPAY_FLAG
                "Attend",                                        // idx_ATTEND_FLAG
                "Tardy",                                         // idx_TARDY_FLAG
                "RD",                                            // idx_RD
                Misc.centerHTML("Multi<br>lingual"),             // idx_BILINGUAL_FLAG
                "MA",                                            // idx_MA_FLAG
                Misc.centerHTML("Meal<br>Voucher"),              // idx_MA_ALLOWANCE
                Misc.centerHTML("Diff<br>Srce"),                 // idx_DIFF_SOURCE_DISP
                Misc.centerHTML("Nite<br>Diff"),                 // idx_DIFFNIGHT
                Misc.centerHTML("Shft<br>Trade"),                // idx_SHIFT_TRADED
                Misc.centerHTML("Car<br>Fare<br>$"),             // idx_CARFARE
                Misc.centerHTML("Car<br>Fare<br>DWS"),           // idx_CARFARE_DWS
                "0.60",                                          // idx_DIFF_060
                Misc.centerHTML("Sat<br>1.50"),                  // idx_DIFF_150
                "1.85",                                          // idx_DIFF_185
                "2.00",                                          // idx_DIFF_200
                "2.20",                                          // idx_DIFF_220
                "2.70",                                          // idx_DIFF_270
                "3.00",                                          // idx_DIFF_300
                Misc.centerHTML("Split<br>6.00"),                // idx_DIFF_600
                Misc.centerHTML("Split<br>8.00"),                // idx_DIFF_800
                "9.00",                                          // idx_DIFF_900
                "1%",                                            // idx_DIFF_1_PERCENT
                "1.5%",                                          // idx_DIFF_1_5_PERCENT
                "2%",                                            // idx_DIFF_2_PERCENT
                "2.5%",                                          // idx_DIFF_2_5_PERCENT
                "3%",                                            // idx_DIFF_3_PERCENT
                "Split",                                         // idx_GAP
                Misc.centerHTML("6th<br>Day"),                   // idx_SIXTH_DAY
                Misc.centerHTML("OT<br>Ref"),                    // idx_OVERTIME_REFUSED
                Misc.centerHTML("OT<br>NA"),                     // idx_OVERTIME_NOT_AVAILABLE
                Misc.centerHTML("Part<br>Time"),                 // idx_PARTTIME_FLAG
                Misc.centerHTML("Locked<br>By"),                 // idx_LOCKED_BY
                Misc.centerHTML("Record<br>Type")                // idx_RECORD_TYPE
            };
            
            switch (feeder)
            {
                case "MEX":
                    colNames[idx_OVERTIME] = Misc.centerHTML("Apprvd<br>OT Tot");
                    colNames[idx_CALL_OVERLAP] = Misc.centerHTML("Call<br>Overlap");
                    colNames[idx_CALL_OUT] = Misc.centerHTML("Rest Day<br>Worked");
                    break;
                case "CZE":
                    colNames[idx_OVERTIME] = "OT";
                    colNames[idx_CALL_OUT] = Misc.centerHTML("OT<br>Weekday");
                    colNames[idx_PREM] = Misc.centerHTML("OT<br>Weekend<br>Holiday");
                    colNames[idx_FLEX_HRS] = Misc.centerHTML("CompTime");
                    colNames[idx_SUND] = Misc.centerHTML("Weekend<br>Hours");
                    break;
                case "POL":
                    colNames[idx_OVERTIME] = Misc.centerHTML("OT<br>Total");
                    colNames[idx_OT_1030] = Misc.centerHTML("OT<br>50%");
                    colNames[idx_OT_8115] = Misc.centerHTML("OT<br>100%");
                    colNames[idx_COMPUTED_OT] = Misc.centerHTML("OT<br>ODAY");
                    colNames[idx_CALL_OUT] = Misc.centerHTML("CompTime");
                    colNames[idx_SUND] = Misc.centerHTML("Weekend<br>Hours");
                    break;
                case "SVK":
                    colNames[idx_OVERTIME] = "OT";
                    colNames[idx_CALL_OUT] = Misc.centerHTML("OT<br>Weekday");
                    colNames[idx_PREM] = Misc.centerHTML("OT<br>Weekend");
                    colNames[idx_FLEX_HRS] = Misc.centerHTML("CompTime");
                    colNames[idx_SUND] = Misc.centerHTML("Weekend<br>Hours");
                    break;
                default:
                    break;
            }
            
            return colNames;
        }
        
        /**
        * buildColumnNamesAbsences()
        * 
        * Builds the column names to use for the absencesTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesAbsences()
        {
            return new String[]
            {
                "",                                 // idx_Abs_EMPID
                "",                                 // idx_Abs_REPORTING_DATE
                "",                                 // idx_Abs_RECKEY
                "",                                 // idx_Abs_CHGD_BY
                "",                                 // idx_Abs_DATE_CHGD
                "",                                 // idx_Abs_DEL_RECORD
                "",                                 // idx_Abs_SAP_CODE
                "Absence Code",                     // idx_Abs_CODE_DESC
                "Reason Code",                      // idx_Abs_REASON_CODE_DESC
                "Hours",                            // idx_Abs_HOURS_TREC
                "Mins",                             // idx_Abs_MINS_TREC
                "Days",                             // idx_Abs_DAYS
                "Comments",                         // idx_Abs_COMMENT
                ""                                  // idx_Abs_RECORD_TYPE
            };
        }
        
        /**
        * buildColumnNamesExtraPayments()
        * 
        * Builds the column names to use for the extraPaymentsTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesExtraPayments()
        {
            return new String[]
            {
                "",                            // idx_Ext_EMPID
                "",                            // idx_Ext_REPORTING_DATE
                "",                            // idx_Ext_RECKEY
                "",                            // idx_Ext_CHGD_BY
                "",                            // idx_Ext_DATE_CHGD
                "",                            // idx_Ext_DEL_RECORD
                "",                            // idx_Ext_SAP_CODE
                "Extra Payment",               // idx_Ext_CODE_DESC
                "Amount",                      // idx_Ext_AMOUNT_EREC
                "Mins",                        // idx_Ext_MINS_EREC
                "Cost Center",                 // idx_Ext_COST_CENTER
                "Loc Code",                    // idx_Ext_LOCATION_CODE
                "Act Code",                    // idx_Ext_ACTIVITY
                "Project #",                   // idx_Ext_PROJECT_NUMBER
                "",                            // idx_Ext_AMOUNT_TYPE
                ""                             // idx_Ext_RECORD_TYPE
            };
        }
        
        /**
        * buildColumnNamesAttendances()
        * 
        * Builds the column names to use for the attendancesTable, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNamesAttendances()
        {
            return new String[]
            {
                "",                              // idx_Att_EMPID
                "",                              // idx_Att_REPORTING_DATE
                "",                              // idx_Att_RECKEY
                "",                              // idx_Att_CHGD_BY
                "",                              // idx_Att_DATE_CHGD
                "",                              // idx_Att_DEL_RECORD
                "",                              // idx_Att_SAP_CODE
                "Attendance Code",               // idx_Att_CODE_DESC
                "Hours",                         // idx_Att_HOURS_AREC
                "Mins",                          // idx_Att_MINS_AREC
                "Days",                          // idx_Att_DAYS
                "Cost Center",                   // idx_Att_COST_CENTER
                "Loc Code",                      // idx_Att_LOCATION_CODE
                "Act Code",                      // idx_Att_ACTIVITY
                "EC",                            // idx_Att_EC
                "Project #",                     // idx_Att_PROJECT_NUMBER
                "FRC",                           // idx_Att_FRC
                "Tax Area",                      // idx_Att_TAX_AREA
                ""                               // idx_Att_RECORD_TYPE
            };
        }
        
        /**
        * getResults
        * 
        * Gets the results for all four tables; the individual supplier methods will extract and send the relevant resultsets.
        * The resultsets will be closed in the TableSwingWorkers, but the CallableStatement will be closed once all workers are finished executing.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        */
        private void getResults()
        {
            switch (editType)
            {
                case "NORMAL":
                    results = Oracle.getResultsNormal(getFormComponent(), feeder, site, mu, startDate, endDate);
                    progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, mu, null, startDate, endDate, "NORMAL"));
                    break;
                case "PRIOR":
                    results = Oracle.getResultsPrior(getFormComponent(), feeder, site, startDate, endDate);
                    progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, null, null, startDate, endDate, "PRIOR"));
                    break;
                case "UPDATE":
                    results = Oracle.getResultsUpdated(getFormComponent(), feeder, site, mu);
                    progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, null, null, startDate, endDate, "UPDATE"));
                    break;
                case "DETAIL":
                case "BYEMPLOYEE":
                case "APPR READ ONLY":
                    results = Oracle.getResultsByEmployee(getFormComponent(), feeder, site, empid, startDate, endDate);
                    progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, null, empid, startDate, endDate, "EMPLOYEE"));
                    break;
                case "CHANGES":
                    results = Oracle.getResultsChanged(getFormComponent(), feeder, site, startDate, endDate);
                    progressBar.setMaximum(Oracle.getProgressRowCount(getFormComponent(), feeder, site, null, null, startDate, endDate, "CHANGES"));
                    break;
                default:
                    results = null;
                    Misc.msgbox(getFormComponent(), "Unhandled Time Reporting form edit type, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
                    closeForm();
            }
        }
        
        /**
        * getResultsTimeTotals()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the timeTotals resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsTimeTotals()
        {
            return new ResultSetWrapper(results.getResultSetArray()[0]);
        }
        
        /**
        * getResultsAbsences()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the absences resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsAbsences()
        {
            return new ResultSetWrapper(results.getResultSetArray()[2]);
        }
        
        /**
        * getResultsExtraPayments()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the extraPayments resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsExtraPayments()
        {
            return new ResultSetWrapper(results.getResultSetArray()[3]);
        }
        
        /**
        * getResultsAttendances()
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * Creates a ResultSetWrapper for the attendances resultset - the worker will close the resultset when finished.
        * 
        * @return ResultSetWrapper 
        */
        private ResultSetWrapper getResultsAttendances()
        {
            return new ResultSetWrapper(results.getResultSetArray()[1]);
        }
        
        /**
        * processResultsTimeTotals
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsTimeTotals(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                tvicore.dao.DwsRecord dwsRecord = Misc.getDWSRecord(RegionData.getDwsCodes(), rs.getString("DWS"));
                String approved = Misc.makeYorN(rs.getObject("APPROVED_BY"));
                String recordType = "";
                String lockedBy = Misc.objectToString(rs.getObject("LOCKED_BY"));
                if (editType.equals("CHANGES"))
                {
                    approved = Misc.makeYorN(rs.getObject("CHG_APPROVED_BY"));
                }
                if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                {
                    recordType = rs.getObject("THE_TYPE").toString();
                }
                data = new Object[]
                {
                    rs.getString("EMPID"),                                             // idx_EMPID
                    rs.getString("AGENTID"),                                           // idx_AGENTID
                    rs.getString("DWS"),                                               // idx_DWS
                    Misc.oracleToBoolean(rs.getObject("HOLIDAY_FLAG")),                // idx_HOLIDAY_FLAG
                    Misc.oracleToBoolean(rs.getObject("ABSENCE_READY")),               // idx_ABSENCE_READY
                    Misc.oracleToBoolean(rs.getObject("TIME_WORKED_READY")),           // idx_TIME_WORKED_READY
                    Misc.oracleToBoolean(rs.getObject("TIME_TOTALS_READY")),           // idx_TIME_TOTALS_READY
                    rs.getString("MESSAGE"),                                           // idx_MESSAGE
                    rs.getString("APPROVED_BY"),                                       // idx_APPROVED_BY
                    rs.getDate("DATE_APPROVED"),                                       // idx_DATE_APPROVED
                    Misc.objectToInt(rs.getObject("OTHERFLAGS")),                      // idx_OTHERFLAGS
                    rs.getString("MANUAL_CMP_BY"),                                     // idx_MANUAL_CMP_BY
                    rs.getTimestamp("TO_ELINK_DATE_TIME"),                             // idx_TO_ELINK_DATE_TIME
                    rs.getTimestamp("COMP_OR_LOAD_DATE"),                              // idx_COMP_OR_LOAD_DATE
                    Misc.objectToInt(rs.getObject("LOAD_STATUS")),                     // idx_LOAD_STATUS
                    rs.getInt("DATE_TV_MODIFIED"),                                     // idx_DATE_TV_MODIFIED
                    Misc.objectToInt(rs.getObject("TOTALVIEWID")),                     // idx_TOTALVIEWID
                    rs.getString("MU"),                                                // idx_MU
                    Misc.objectToInt(rs.getObject("DIFF_SOURCE")),                     // idx_DIFF_SOURCE
                    rs.getDate("REPORTING_DATE"),                                      // idx_REPORTING_DATE
                    approved,                                                          // idx_APPR
                    rs.getString("STATUS"),                                            // idx_STATUS
                    rs.getString("EMPLOYEE"),                                          // idx_EMPLOYEE
                    rs.getBigDecimal("SHIFT"),                                         // idx_SHIFT
                    rs.getBigDecimal("REG"),                                           // idx_REG
                    rs.getBigDecimal("OVERTIME"),                                      // idx_OVERTIME
                    rs.getBigDecimal("OT_1030"),                                       // idx_OT_1030
                    rs.getBigDecimal("OT_8115"),                                       // idx_OT_8115
                    rs.getBigDecimal("COMPUTED_OT"),                                   // idx_COMPUTED_OT
                    rs.getBigDecimal("CALL_OVERLAP"),                                  // idx_CALL_OVERLAP
                    rs.getBigDecimal("CALL_OUT"),                                      // idx_CALL_OUT
                    rs.getBigDecimal("PR05"),                                          // idx_PREM
                    rs.getBigDecimal("FLEX_HRS"),                                      // idx_FLEX_HRS
                    rs.getBigDecimal("DIFF_HRS_REG_IBEW"),                             // idx_EVENING_HOURS CZE
                    rs.getBigDecimal("DIFF_HRS_REG_CWA"),                              // idx_NIGHT_HOURS CZE AND SVK
                    rs.getBigDecimal("SUND"),                                          // idx_SUND
                    rs.getBigDecimal("HOLI"),                                          // idx_HOLIDAY_WORKED
                    rs.getBigDecimal("REGTOTAL"),                                      // idx_REGTOTAL
                    rs.getBigDecimal("ABSENCE_TOTAL"),                                 // idx_ABSENCE_TOTAL
                    Misc.oracleToBoolean(rs.getObject("EXTRAPAY_FLAG")),               // idx_EXTRAPAY_FLAG
                    Misc.oracleToBoolean(rs.getObject("ATTEND_FLAG")),                 // idx_ATTEND_FLAG
                    Misc.oracleToBoolean(rs.getObject("TARDY_FLAG")),                  // idx_TARDY_FLAG
                    Misc.oracleToBoolean(rs.getObject("RD")),                          // idx_RD
                    Misc.oracleToBoolean(rs.getObject("BILINGUAL_FLAG")),              // idx_BILINGUAL_FLAG
                    Misc.oracleToBoolean(rs.getObject("MA_FLAG")),                     // idx_MA_FLAG
                    rs.getInt("MEAL_ALLOWANCE"),                                       // idx_MEAL_ALLOWANCE
                    Misc.getDiffSource(Misc.objectToInt(rs.getObject("DIFF_SOURCE"))), // idx_DIFF_SOURCE_DISP
                    dwsRecord.getDIFF_NIGHT(),                                         // idx_DIFFNIGHT
                    Misc.oracleToBoolean(rs.getObject("SHIFT_TRADED")),                // idx_SHIFT_TRADED
                    Misc.oracleToBoolean(rs.getObject("CARFARE_FLAG")),                // idx_CARFARE
                    dwsRecord.getCARFARE(),                                            // idx_CARFARE_DWS
                    dwsRecord.getDIFF_060(),                                           // idx_DIFF_060
                    dwsRecord.getDIFF_150(),                                           // idx_DIFF_150
                    dwsRecord.getDIFF_185(),                                           // idx_DIFF_185
                    dwsRecord.getDIFF_200(),                                           // idx_DIFF_200
                    dwsRecord.getDIFF_220(),                                           // idx_DIFF_220
                    dwsRecord.getDIFF_270(),                                           // idx_DIFF_270
                    dwsRecord.getDIFF_300(),                                           // idx_DIFF_300
                    dwsRecord.getDIFF_600(),                                           // idx_DIFF_600
                    dwsRecord.getDIFF_800(),                                           // idx_DIFF_800
                    dwsRecord.getDIFF_900(),                                           // idx_DIFF_900
                    dwsRecord.getDIFF_1_PERCENT(),                                     // idx_DIFF_1_PERCENT
                    dwsRecord.getDIFF_1_5_PERCENT(),                                   // idx_DIFF_1_5_PERCENT
                    dwsRecord.getDIFF_2_PERCENT(),                                     // idx_DIFF_2_PERCENT
                    dwsRecord.getDIFF_2_5_PERCENT(),                                   // idx_DIFF_2_5_PERCENT
                    dwsRecord.getDIFF_3_PERCENT(),                                     // idx_DIFF_3_PERCENT
                    dwsRecord.getGAP(),                                                // idx_GAP
                    Misc.oracleToBoolean(rs.getObject("SIXTHDAY")),                    // idx_SIXTH_DAY
                    rs.getBigDecimal("OVERTIME_REFUSED"),                              // idx_OVERTIME_REFUSED
                    rs.getBigDecimal("OVERTIME_NOT_AVAILABLE"),                        // idx_OVERTIME_NOT_AVAILABLE
                    Misc.oracleToBoolean(rs.getObject("PARTTIME_FLAG")),               // idx_PARTTIME_FLAG
                    lockedBy,                                                          // idx_LOCKED_BY
                    recordType                                                         // idx_RECORD_TYPE
                };
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        progressBar.setValue(progressBar.getValue() + 1);
                    }
                });
                employeeCount++;
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading time totals data.");
                timeTotalsWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsAbsences
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsAbsences(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                int days = 0;
                if (feeder.equals("MEX") && Misc.isNumeric(rs.getString("SAP_CODE_TREC")))
                {
                    days = 1;
                }
                String recordType = "";
                if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                {
                    recordType = rs.getObject("THE_TYPE").toString();
                }
                data = new Object[]
                {
                    rs.getString("EMPID"),                                                                // idx_Abs_EMPID
                    rs.getDate("REPORTING_DATE"),                                                         // idx_Abs_REPORTING_DATE
                    rs.getInt("RECKEY"),                                                                  // idx_Abs_RECKEY
                    rs.getString("CHGD_BY"),                                                              // idx_Abs_CHGD_BY
                    rs.getDate("DATE_CHGD"),                                                              // idx_Abs_DATE_CHGD
                    "Del",                                                                                // idx_Abs_DEL_RECORD
                    rs.getString("SAP_CODE_TREC"),                                                        // idx_Abs_SAP_CODE
                    rs.getString("SAP_CODE_TREC") + "  -  " + rs.getString("CODE_DESCRIPTION"),           // idx_Abs_CODE_DESC
                    Misc.makeReasonCode(rs.getString("REASON_CODE"), rs.getString("REASON_DESCRIPTION")), // idx_Abs_REASON_CODE_DESC
                    rs.getBigDecimal("HOURS_TREC"),                                                       // idx_Abs_HOURS_TREC
                    rs.getInt("MINS_TREC"),                                                               // idx_Abs_MINS_TREC
                    days,                                                                                 // idx_Abs_DAYS
                    rs.getString("REASON_TEXT"),                                                          // idx_Abs_COMMENT
                    recordType                                                                            // idx_Abs_RECORD_TYPE
                };
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        progressBar.setValue(progressBar.getValue() + 1);
                    }
                });
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading absences data.");
                absencesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsExtraPayments
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsExtraPayments(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String recordType = "";
                if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                {
                    recordType = rs.getObject("THE_TYPE").toString();
                }
                data = new Object[]
                {
                    rs.getString("EMPID"),                                                      // idx_Ext_EMPID
                    rs.getDate("REPORTING_DATE"),                                               // idx_Ext_REPORTING_DATE
                    rs.getInt("RECKEY"),                                                        // idx_Ext_RECKEY
                    rs.getString("CHGD_BY"),                                                    // idx_Ext_CHGD_BY
                    rs.getDate("DATE_CHGD"),                                                    // idx_Ext_DATE_CHGD
                    "Del",                                                                      // idx_Ext_DEL_RECORD
                    rs.getString("SAP_CODE_EREC"),                                              // idx_Ext_SAP_CODE
                    rs.getString("SAP_CODE_EREC") + "  -  " + rs.getString("CODE_DESCRIPTION"), // idx_Ext_CODE_DESC
                    rs.getBigDecimal("AMOUNT_EREC"),                                            // idx_Ext_AMOUNT_EREC
                    rs.getInt("MINS_EREC"),                                                     // idx_Ext_MINS_EREC
                    rs.getString("COST_CENTER"),                                                // idx_Ext_COST_CENTER
                    rs.getString("LOCATION_CODE"),                                              // idx_Ext_LOCATION_CODE
                    rs.getString("ACTIVITY"),                                                   // idx_Ext_ACTIVITY
                    rs.getString("PROJECT_NUMBER"),                                             // idx_Ext_PROJECT_NUMBER
                    rs.getString("AMOUNT_TYPE"),                                                // idx_Ext_AMOUNT_TYPE
                    recordType                                                                  // idx_Ext_RECORD_TYPE
                };
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        progressBar.setValue(progressBar.getValue() + 1);
                    }
                });
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading extra payments data.");
                extraPaymentsWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * processResultsAttendances
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResultsAttendances(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                String recordType = "";
                if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                {
                    recordType = rs.getObject("THE_TYPE").toString();
                }
                BigDecimal days = BigDecimal.valueOf(0);
                if (feeder.equals("CZE"))
                {
                    String sapCode = rs.getString("SAP_CODE_AREC");
                    if (sapCode.equals("0200"))
                    {
                        String empid = rs.getString("EMPID");
                        int ttRow = -1;
                        for (int i = 0; i < timeTotalsData.getRowCount(); i++)
                        {
                            if (timeTotalsData.getValueAt(i, idx_EMPID).equals(empid))
                            {
                                ttRow = i;
                                break;
                            }
                        }
                        if (ttRow >= 0) // should never have an attendance record for an employee without a corresponding time totals record
                        {
                            double shift = Misc.objectToDouble(timeTotalsData.getValueAt(ttRow, idx_SHIFT));
                            if (shift > 0)
                            {
                                days = rs.getBigDecimal("HOURS_AREC").divide(BigDecimal.valueOf(shift)).setScale(2, RoundingMode.HALF_EVEN);
                            }
                        }
                    }
                }
                data = new Object[]
                {
                    rs.getString("EMPID"),                                                      // idx_Att_EMPID
                    rs.getDate("REPORTING_DATE"),                                               // idx_Att_REPORTING_DATE
                    rs.getInt("RECKEY"),                                                        // idx_Att_RECKEY
                    rs.getString("CHGD_BY"),                                                    // idx_Att_CHGD_BY
                    rs.getDate("DATE_CHGD"),                                                    // idx_Att_DATE_CHGD
                    "Del",                                                                      // idx_Att_DEL_RECORD
                    rs.getString("SAP_CODE_AREC"),                                              // idx_Att_SAP_CODE
                    rs.getString("SAP_CODE_AREC") + "  -  " + rs.getString("CODE_DESCRIPTION"), // idx_Att_CODE_DESC
                    rs.getBigDecimal("HOURS_AREC"),                                             // idx_Att_HOURS_AREC
                    rs.getInt("MINS_AREC"),                                                     // idx_Att_MINS_AREC
                    days,                                                                       // idx_Att_DAYS
                    rs.getString("COST_CENTER"),                                                // idx_Att_COST_CENTER
                    rs.getString("LOCATION_CODE"),                                              // idx_Att_LOCATION_CODE
                    rs.getString("ACTIVITY"),                                                   // idx_Att_ACTIVITY
                    rs.getString("EC"),                                                         // idx_Att_EC
                    rs.getString("PROJECT_NUMBER"),                                             // idx_Att_PROJECT_NUMBER
                    rs.getString("FRC"),                                                        // idx_Att_FRC
                    rs.getString("TAX_AREA"),                                                   // idx_Att_TAX_AREA
                    recordType                                                                  // idx_Att_RECORD_TYPE
                };
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        progressBar.setValue(progressBar.getValue() + 1);
                    }
                });
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading attendances data.");
                attendancesWorker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefreshTimeTotals
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshTimeTotals(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createTimeTotalsTable();
                configureTimeTotalsTable();
            }
            
            finishedTimeTotals = true;
            if (finishedTimeTotals && finishedAbsences && finishedExtraPayments && finishedAttendances)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshAbsences
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshAbsences(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createAbsencesTable();
                configureAbsencesTable();
            }
            
            finishedAbsences = true;
            if (finishedTimeTotals && finishedAbsences && finishedExtraPayments && finishedAttendances)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshExtraPayments
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshExtraPayments(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createExtraPaymentsTable();
                configureExtraPaymentsTable();
            }
            
            finishedExtraPayments = true;
            if (finishedTimeTotals && finishedAbsences && finishedExtraPayments && finishedAttendances)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefreshAttendances
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefreshAttendances(Boolean cancelled)
        {
            if (!cancelled)
            {
                // table creation and configuration methods are defined below inside this thread
                createAttendancesTable();
                configureAttendancesTable();
            }
            
            finishedAttendances = true;
            if (finishedTimeTotals && finishedAbsences && finishedExtraPayments && finishedAttendances)
            {
                finalizeRefresh();
            }
        }
        
        /**
        * finalizeRefresh
        * 
        * Called once all four table workers are finished executing.
        * This closes the callable statement and releases the semaphore lock.
        * 
        * Once this code is executed, if not cancelled, the tables are finished and displayed, ready for the user.
        */
        private void finalizeRefresh()
        {
            try
            {
                // wait for all of the workers to properly finish and release their latches
                latch.await();
                if (results != null)
                {
                    results.close();
                }
            }
            catch (InterruptedException ex) { }
            if (!timeTotalsWorker.isCancelled() && !absencesWorker.isCancelled() && !extraPaymentsWorker.isCancelled() && !attendancesWorker.isCancelled())
            {
                progressBar.setVisible(false);
                changingEmployees = true;
                employeeUpdated = false;
                if (employeeCount > 0)
                {
                    timeTotalsTable.setRowSelectionInterval(0, 0);
                    changeEmployee(0);
                }
                else
                {
                    emptySchedule();
                }
                changingEmployees = false;
                
                RegionData.updateSiteInfo(getFormComponent(), feeder, site);
                if (Arrays.asList("PRIOR", "APPR READ ONLY", "CHANGES").contains(editType) ||
                    RegionData.getSiteLock() != null ||
                    UserData.getUserAccessLevel().equals("READONLY") ||
                    (endDate != null && endDate.compareTo(Misc.dateAddDays(RegionData.getPayClose(), -380)) < 0) && !UserData.getUserType().equals("POWER"))
                {
                    readOnly = true;
                    setControlsReadOnly();
                    readOnlyFlag.setText("Read Only");
                    if (RegionData.getSiteLock() != null)
                    {
                        switch (RegionData.getSiteLock())
                        {
                            case "PAY PERIOD":
                                readOnlyFlag.setText("Read Only - Begin new pay period");
                                break;
                            case "COMPUTE 40":
                                readOnlyFlag.setText("Read Only - Compute 40 Hr check");
                                break;
                            case "COMPUTE FUTURE":
                                readOnlyFlag.setText("Read Only - Compute future check");
                                break;
                            case "ADDING RECORDS":
                                readOnlyFlag.setText("Read Only - Adding records");
                                break;
                            default:
                                readOnlyFlag.setText("Read Only - Site locked");
                                break;
                        }
                    }
                    readOnlyFlag.setVisible(true);
                }
                else
                {
                    readOnly = false;
                    setControlsEnabled(true);
                    readOnlyFlag.setVisible(false);
                    if (timeTotalsTable.getRowCount() > 0)
                    {
                        // Set read only controls for the top row if locked
                        if (timeTotalsTable.getValueAt(0, idx_LOCKED_BY) != null &&
                            !timeTotalsTable.getValueAt(0, idx_LOCKED_BY).equals(UserData.getUUID()))
                        {
                            setControlsReadOnly();
                            readOnlyFlag.setText("Read Only - Record locked by: " + timeTotalsTable.getValueAt(0, idx_LOCKED_BY));
                            readOnlyFlag.setVisible(true);
                        }
                        if (Arrays.asList("Separated", "Not Active", "Pending").contains(timeTotalsTable.getValueAt(0, idx_STATUS).toString()))
                        {
                            setControlsReadOnly();
                            readOnlyFlag.setVisible(true);
                        }
                    }
                    else
                    {
                        setControlsEnabled(false);
                        if (editType.equals("NORMAL"))
                        {
                            addEmployeeButton.setEnabled(true);
                        }
                    }
                }
                
                setNumOfEmpsLabel();
                timeTotalsScrollPane.setViewportView(timeTotalsTable);
                timeTotalsScrollPane.setVisible(true);
                timeTotalsTable.setFillsViewportHeight(true);
                timeTotalsTable.requestFocusInWindow();
                refreshButton.setEnabled(true);
                validate();
            }
            
            refreshTimeReportingLock.release();
        }
        
        private void createTimeTotalsTable()
        {
            timeTotalsTable = new JTable(timeTotalsData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (readOnly || UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        return false;
                    }
                    else if (timeTotalsTable.convertRowIndexToModel(row) != timeTotalsRow)
                    {
                        return false;
                    }
                    else if (timeTotalsTable.getValueAt(row, idx_LOCKED_BY) != null &&
                            !timeTotalsTable.getValueAt(row, idx_LOCKED_BY).equals(UserData.getUUID()))
                    {
                        return false;
                    }
                    else if (Arrays.asList("Separated", "Not Active", "Pending").contains(timeTotalsTable.getValueAt(row, idx_STATUS).toString()))
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_SHIFT:
                            case idx_DIFFNIGHT:
                            case idx_SHIFT_TRADED:
                            case idx_CARFARE_DWS:
                            case idx_DIFF_060:
                            case idx_DIFF_150:
                            case idx_DIFF_185:
                            case idx_DIFF_200:
                            case idx_DIFF_220:
                            case idx_DIFF_270:
                            case idx_DIFF_300:
                            case idx_DIFF_600:
                            case idx_DIFF_800:
                            case idx_DIFF_900:
                            case idx_DIFF_1_PERCENT:
                            case idx_DIFF_1_5_PERCENT:
                            case idx_DIFF_2_PERCENT:
                            case idx_DIFF_2_5_PERCENT:
                            case idx_DIFF_3_PERCENT:
                            case idx_SIXTH_DAY:
                            case idx_OVERTIME_REFUSED:
                            case idx_OVERTIME_NOT_AVAILABLE:
                            case idx_PARTTIME_FLAG:
                                return true;
                            case idx_GAP:
                            default:
                                return false;
                         }
                    }
                }
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_SHIFT:
                        case idx_REG:
                        case idx_OVERTIME:
                        case idx_OT_1030:
                        case idx_OT_8115:
                        case idx_COMPUTED_OT:    
                        case idx_CALL_OVERLAP:
                        case idx_CALL_OUT:
                        case idx_PREM:
                        case idx_FLEX_HRS:
                        case idx_EVENING_HOURS:
                        case idx_NIGHT_HOURS:
                        case idx_SUND:
                        case idx_HOLIDAY_WORKED:
                        case idx_REGTOTAL:
                        case idx_ABSENCE_TOTAL:
                        case idx_OVERTIME_REFUSED:
                        case idx_OVERTIME_NOT_AVAILABLE:
                            return BigDecimal.class;
                        case idx_HOLIDAY_FLAG:
                        case idx_ABSENCE_READY:
                        case idx_TIME_WORKED_READY:
                        case idx_TIME_TOTALS_READY:
                        case idx_EXTRAPAY_FLAG:
                        case idx_ATTEND_FLAG:
                        case idx_TARDY_FLAG:
                        case idx_RD:
                        case idx_BILINGUAL_FLAG:
                        case idx_MA_FLAG:
                        case idx_DIFFNIGHT:
                        case idx_SHIFT_TRADED:
                        case idx_CARFARE:
                        case idx_CARFARE_DWS:
                        case idx_DIFF_060:
                        case idx_DIFF_150:
                        case idx_DIFF_185:
                        case idx_DIFF_200:
                        case idx_DIFF_220:
                        case idx_DIFF_270:
                        case idx_DIFF_300:
                        case idx_DIFF_600:
                        case idx_DIFF_800:
                        case idx_DIFF_900:
                        case idx_DIFF_1_PERCENT:
                        case idx_DIFF_1_5_PERCENT:
                        case idx_DIFF_2_PERCENT:
                        case idx_DIFF_2_5_PERCENT:
                        case idx_DIFF_3_PERCENT:
                        case idx_GAP:
                        case idx_SIXTH_DAY:
                        case idx_PARTTIME_FLAG:
                            return Boolean.class;
                        case idx_DATE_APPROVED:
                        case idx_TO_ELINK_DATE_TIME:
                        case idx_COMP_OR_LOAD_DATE:
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MEAL_ALLOWANCE:
                        case idx_OTHERFLAGS:
                        case idx_LOAD_STATUS:
                        case idx_DATE_TV_MODIFIED:
                        case idx_TOTALVIEWID:
                        case idx_DIFF_SOURCE:
                            return Integer.class;
                        case idx_EMPID:
                        case idx_AGENTID:
                        case idx_DWS:
                        case idx_MESSAGE:
                        case idx_APPROVED_BY:
                        case idx_MANUAL_CMP_BY:
                        case idx_MU:
                        case idx_APPR:
                        case idx_STATUS:
                        case idx_EMPLOYEE:
                        case idx_DIFF_SOURCE_DISP:
                        case idx_LOCKED_BY:
                        case idx_RECORD_TYPE:
                        default:
                            return String.class;
                    }
                }
                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        if (timeTotalsTable.getValueAt(row, idx_LOCKED_BY) != null &&
                            !timeTotalsTable.getValueAt(row, idx_LOCKED_BY).equals(UserData.getUUID()))
                        {
                            if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                            {
                                c.setBackground(new Color(230, 230, 230));
                            }
                            else
                            {
                                c.setBackground(Color.LIGHT_GRAY);
                            }
                        }
                        else if ((Integer)timeTotalsTable.getValueAt(row, idx_OTHERFLAGS) == -9 && UserData.getUserType().equals("POWER"))
                        {
                            c.setBackground(Color.MAGENTA);
                        }
                        else if ((Integer)timeTotalsTable.getValueAt(row, idx_OTHERFLAGS) == -1 && UserData.getUserType().equals("POWER"))
                        {
                            c.setBackground(Color.CYAN);
                        }
                        else if (column == idx_STATUS)
                        {
                            if (Misc.objectToString(timeTotalsTable.getValueAt(row, idx_STATUS)).equals("Error"))
                            {
                                String manualCompleteBy = Misc.objectToString(timeTotalsTable.getValueAt(row, idx_MANUAL_CMP_BY));
                                if (Arrays.asList("Manual", "Resend").contains(manualCompleteBy))
                                {
                                    c.setBackground(Color.CYAN);
                                }
                                else
                                {
                                    c.setBackground(Color.RED);
                                }
                            }
                            else if (Arrays.asList("Updated", "Not Ready", "Pending").contains(Misc.objectToString(timeTotalsTable.getValueAt(row, idx_STATUS))))
                            {
                                c.setBackground(Color.YELLOW);
                            }
                            else
                            {
                                c.setBackground(Color.WHITE);
                            }
                        }
                        else
                        {
                            c.setBackground(Color.WHITE);
                        }
                    }
                    return c;
                }
                @Override
                public void paintComponent(Graphics g)
                {
                    super.paintComponent(g);
                    if (timeTotalsTable.getRowCount() > 0)
                    {
                        if (Arrays.asList("DETAIL", "BYEMPLOYEE", "APPR READ ONLY").contains(editType))
                        {
                            // Only draw week lines when sorting by date ascending
                            if (!timeTotalsTable.getRowSorter().getSortKeys().isEmpty())
                            {
                                if (!(timeTotalsTable.getRowSorter().getSortKeys().get(0).getColumn() == idx_REPORTING_DATE &&
                                    timeTotalsTable.getRowSorter().getSortKeys().get(0).getSortOrder().toString().equals("ASCENDING")))
                                {
                                    return;
                                }
                            }
                            Date endOfWeek = Misc.getNextDayOfWeek((Date) timeTotalsTable.getValueAt(0, idx_REPORTING_DATE), RegionData.getLastDayOfWeek(), false);
                            for (int i = 0; i < timeTotalsTable.getRowCount(); i++)//DYADD change to timeTotalsData for safety?
                            {
                                if (((Date) timeTotalsTable.getValueAt(i, idx_REPORTING_DATE)).compareTo(endOfWeek) > 0)
                                {
                                    int y = i * timeTotalsTable.getRowHeight();
                                    g.drawLine(0, y, timeTotalsTable.getWidth(), y);
                                    endOfWeek = Misc.getNextDayOfWeek((Date) timeTotalsTable.getValueAt(i, idx_REPORTING_DATE), RegionData.getLastDayOfWeek(), false);
                                }
                            }
                        }
                        else if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
                        {
                            // Only draw lines when sorting by employee
                            if (!timeTotalsTable.getRowSorter().getSortKeys().isEmpty())
                            {
                                if (timeTotalsTable.getRowSorter().getSortKeys().get(0).getColumn() != idx_EMPLOYEE)
                                {
                                    return;
                                }
                            }
                            
                            String empid = Misc.objectToString(timeTotalsTable.getValueAt(0, idx_EMPID));
                            Date date = (Date) timeTotalsTable.getValueAt(0, idx_REPORTING_DATE);
                            for (int i = 0; i < timeTotalsTable.getRowCount(); i++)//DYADD change to timeTotalsData for safety?
                            {
                                if (!Misc.objectToString(timeTotalsTable.getValueAt(i, idx_EMPID)).equals(empid) ||
                                    !((Date) timeTotalsTable.getValueAt(i, idx_REPORTING_DATE)).equals(date))
                                {
                                    int y = i * timeTotalsTable.getRowHeight();
                                    g.drawLine(0, y, timeTotalsTable.getWidth(), y);
                                }
                                empid = Misc.objectToString(timeTotalsTable.getValueAt(i, idx_EMPID));
                                date = (Date) timeTotalsTable.getValueAt(i, idx_REPORTING_DATE);
                            }
                        }
                    }
                }
            };
        }
        
        private void createAbsencesTable()
        {
            absencesTable = new JTable(absencesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    String absenceCode;
                    absenceCode = Misc.objectToString(absencesTable.getValueAt(row, idx_Abs_SAP_CODE));
                    if (readOnly)
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_Abs_DEL_RECORD:
                            case idx_Abs_CODE_DESC:
                            case idx_Abs_REASON_CODE_DESC:
                                return true;
                            case idx_Abs_HOURS_TREC:
                                if (absenceCode.length() > 3)
                                {
                                    return !Arrays.asList("MTDY", "TOL1", "TDY1").contains(absenceCode);
                                }
                                else
                                {
                                    return true;
                                }
                            case idx_Abs_MINS_TREC:
                                if (absenceCode.length() > 3)
                                {
                                    return Arrays.asList("MTDY", "TOL1", "TDY1").contains(absenceCode);
                                }
                                else
                                {
                                    return false;
                                }
                            case idx_Abs_COMMENT:
                                return true;
                            default:
                                return false;
                        }
                    }
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Abs_HOURS_TREC:
                            return BigDecimal.class;
                        case idx_Abs_REPORTING_DATE:
                        case idx_Abs_DATE_CHGD:
                            return Date.class;
                        case idx_Abs_RECKEY:
                        case idx_Abs_MINS_TREC:
                        case idx_Abs_DAYS:
                            return Integer.class;
                        case idx_Abs_EMPID:
                        case idx_Abs_CHGD_BY:
                        case idx_Abs_DEL_RECORD:
                        case idx_Abs_CODE_DESC:
                        case idx_Abs_REASON_CODE_DESC:
                        case idx_Abs_COMMENT:
                        case idx_Abs_RECORD_TYPE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void createExtraPaymentsTable()
        {
            extraPaymentsTable = new JTable(extraPaymentsData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (readOnly)
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_Ext_DEL_RECORD:
                            case idx_Ext_CODE_DESC:
                            case idx_Ext_AMOUNT_EREC:
                            case idx_Ext_COST_CENTER:
                            case idx_Ext_LOCATION_CODE:
                            case idx_Ext_ACTIVITY:
                            case idx_Ext_PROJECT_NUMBER:
                                return true;
                            case idx_Ext_MINS_EREC:
                            default:
                                return false;
                        }
                    }
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Ext_AMOUNT_EREC:
                            return BigDecimal.class;
                        case idx_Ext_REPORTING_DATE:
                        case idx_Ext_DATE_CHGD:
                            return Date.class;
                        case idx_Ext_RECKEY:
                        case idx_Ext_MINS_EREC:
                            return Integer.class;
                        case idx_Ext_EMPID:
                        case idx_Ext_CHGD_BY:
                        case idx_Ext_DEL_RECORD:
                        case idx_Ext_CODE_DESC:
                        case idx_Ext_COST_CENTER:
                        case idx_Ext_LOCATION_CODE:
                        case idx_Ext_ACTIVITY:
                        case idx_Ext_PROJECT_NUMBER:
                        case idx_Ext_AMOUNT_TYPE:
                        case idx_Ext_RECORD_TYPE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void createAttendancesTable()
        {
            attendancesTable = new JTable(attendancesData)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (readOnly)
                    {
                        return false;
                    }
                    else
                    {
                        switch (column)
                        {
                            case idx_Att_DEL_RECORD:
                            case idx_Att_CODE_DESC:
                            case idx_Att_COST_CENTER:
                            case idx_Att_LOCATION_CODE:
                            case idx_Att_ACTIVITY:
                            case idx_Att_EC:
                            case idx_Att_PROJECT_NUMBER:
                            case idx_Att_FRC:
                            case idx_Att_TAX_AREA:
                            case idx_Att_HOURS_AREC:
                                return true;
                            case idx_Att_MINS_AREC:
                                return Arrays.asList("CZE", "POL", "SVK").contains(feeder);
                            case idx_Att_DAYS:
                            default:
                                return false;
                        }
                    }
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_Att_HOURS_AREC:
                        case idx_Att_DAYS:
                            return BigDecimal.class;
                        case idx_Att_REPORTING_DATE:
                        case idx_Att_DATE_CHGD:
                            return Date.class;
                        case idx_Att_RECKEY:
                        case idx_Att_MINS_AREC:
                            return Integer.class;
                        case idx_Att_EMPID:
                        case idx_Att_CHGD_BY:
                        case idx_Att_DEL_RECORD:
                        case idx_Att_CODE_DESC:
                        case idx_Att_COST_CENTER:
                        case idx_Att_LOCATION_CODE:
                        case idx_Att_ACTIVITY:
                        case idx_Att_EC:
                        case idx_Att_PROJECT_NUMBER:
                        case idx_Att_FRC:
                        case idx_Att_TAX_AREA:
                        case idx_Att_RECORD_TYPE:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTimeTotalsTable()
        {
            timeTotalsTable.setName("timeTotalsTable");
            Action ttaction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener tttcl = (TableCellListener)e.getSource();
                    if (tttcl.getColumn() == idx_DIFFNIGHT)
                    {
                        int oldDiffSourcecode = Misc.objectToInt(timeTotalsData.getValueAt(timeTotalsRow, idx_DIFF_SOURCE));
                        if (oldDiffSourcecode < 10)
                        {
                            int newDiffSourcecode = oldDiffSourcecode + 10;
                            String newDiffSourceDisp = Misc.getDiffSource(newDiffSourcecode);
                            timeTotalsData.setValueAt(newDiffSourceDisp, timeTotalsRow, idx_DIFF_SOURCE_DISP);
                            timeTotalsData.setValueAt(newDiffSourcecode, timeTotalsRow, idx_DIFF_SOURCE);
                        }
                    }
                    else if (tttcl.getColumn() == idx_PARTTIME_FLAG)
                    {
                        Misc.msgbox(getFormComponent(), "Part Time flag changed.", "TVI : FYI Message", 1, 1, 1);
                    }
                    encodeDWS();
                    flagTimeTotals();
                }
            };
            timeTotalsTable.addPropertyChangeListener(new TableCellListener(timeTotalsTable, ttaction));
            
            Misc.configureTable(timeTotalsTable, true, false, false);
            
            // set the status comparator
            TableRowSorter<?> ttsorter = (TableRowSorter<?>)timeTotalsTable.getRowSorter();
            if (ttsorter == null)
            {
                ttsorter = new TableRowSorter<>((CustomTableModel)timeTotalsTable.getModel());
            }
            ttsorter.setComparator(idx_STATUS, statusComparator);
            timeTotalsTable.setRowSorter(ttsorter);
            
            timeTotalsTable.setSelectionBackground(Constants.SALMON);
            timeTotalsTable.setSelectionForeground(Color.BLACK);
            
            timeTotalsTable.getColumnModel().getColumn(idx_OVERTIME_REFUSED).setCellEditor(new HoursEditor(0.0, 24.0, true));
            timeTotalsTable.getColumnModel().getColumn(idx_OVERTIME_NOT_AVAILABLE).setCellEditor(new HoursEditor(0.0, 24.0, true));
            Misc.setHeaderRenderer(timeTotalsTable, true, true, Constants.CYAN);
            Misc.setColumnSettings(timeTotalsTable, idx_MU, 40);
            Misc.setColumnSettings(timeTotalsTable, idx_REPORTING_DATE, 75);
            Misc.setColumnSettings(timeTotalsTable, idx_APPR, 35);
            Misc.setColumnSettings(timeTotalsTable, idx_STATUS, 60);
            Misc.setColumnHeaderRenderer(timeTotalsTable, idx_EMPLOYEE, false, true, Constants.CYAN);//set left alignment
            Misc.setColumnSettings(timeTotalsTable, idx_EMPLOYEE, 140, Constants.LEFT);
            Misc.setColumnSettings(timeTotalsTable, idx_SHIFT, 50);
            Misc.setColumnSettings(timeTotalsTable, idx_REG, 40, true, Constants.CENTER);
            if (feeder.equals("POL"))
            {
                Misc.setColumnSettings(timeTotalsTable, idx_OVERTIME, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_OT_1030, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_OT_8115, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_COMPUTED_OT, 55, true, Constants.CENTER);
            }
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(timeTotalsTable, idx_OVERTIME, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_OT_1030, 50, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_OT_8115, 50, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_COMPUTED_OT, 60, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_CALL_OVERLAP, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_CALL_OUT, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_HOLIDAY_WORKED, 50, true, Constants.CENTER);
            }
            else if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(timeTotalsTable, idx_OVERTIME, 55, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_CALL_OUT, 65, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_HOLIDAY_WORKED, 65, true, Constants.CENTER);
            }
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                Misc.setColumnSettings(timeTotalsTable, idx_PREM, 65, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_FLEX_HRS, 65, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_EVENING_HOURS, 65, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_NIGHT_HOURS, 65, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_SUND, 65, true, Constants.CENTER);
            }
            else
            {
                Misc.setColumnSettings(timeTotalsTable, idx_PREM, 40, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_FLEX_HRS, 40, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_EVENING_HOURS, 40, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_NIGHT_HOURS, 40, true, Constants.CENTER);
                Misc.setColumnSettings(timeTotalsTable, idx_SUND, 40, true, Constants.CENTER);
            }
            Misc.setColumnSettings(timeTotalsTable, idx_REGTOTAL, 40, true, Constants.CENTER);
            Misc.setColumnHeaderRenderer(timeTotalsTable, idx_ABSENCE_TOTAL, true, true, Constants.LTYELLOW);
            Misc.setColumnSettings(timeTotalsTable, idx_ABSENCE_TOTAL, 40, true, Constants.CENTER);
            Misc.setColumnHeaderRenderer(timeTotalsTable, idx_EXTRAPAY_FLAG, true, true, Constants.LTGREEN);
            Misc.setColumnSettings(timeTotalsTable, idx_EXTRAPAY_FLAG, 45, false);
            Misc.setColumnHeaderRenderer(timeTotalsTable, idx_ATTEND_FLAG, true, true, Constants.LTRED);
            Misc.setColumnSettings(timeTotalsTable, idx_ATTEND_FLAG, 50, false);
            Misc.setColumnSettings(timeTotalsTable, idx_TARDY_FLAG, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_RD, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_BILINGUAL_FLAG, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_MA_FLAG, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_MEAL_ALLOWANCE, 55, true, Constants.CENTER);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_SOURCE_DISP, 40);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFFNIGHT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_SHIFT_TRADED, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_CARFARE, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_CARFARE_DWS, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_060, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_150, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_185, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_200, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_220, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_270, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_300, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_600, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_800, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_900, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_1_PERCENT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_1_5_PERCENT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_2_PERCENT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_2_5_PERCENT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_DIFF_3_PERCENT, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_GAP, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_SIXTH_DAY, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_OVERTIME_REFUSED, 35, true, Constants.CENTER);
            Misc.setColumnSettings(timeTotalsTable, idx_OVERTIME_NOT_AVAILABLE, 35, true, Constants.CENTER);
            Misc.setColumnSettings(timeTotalsTable, idx_PARTTIME_FLAG, 40, false);
            Misc.setColumnSettings(timeTotalsTable, idx_LOCKED_BY, 50);
            Misc.setColumnSettings(timeTotalsTable, idx_RECORD_TYPE, 60);
            for (int columnIndex2Hide : hiddenColumns)
            {
                Misc.setColumnSettings(timeTotalsTable, columnIndex2Hide, 0, false);
            }
            
            timeTotalsTable.setRowHeight(25);
            updateTableSize();
            timeTotalsTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
            JComboBox<String> shiftComboBox = new JComboBox<>();
            for (ShiftRecord shift : RegionData.getShiftCodes())
            {
                if (Misc.checkUnionFlag(feeder, shift.getUnionFlags(), union))
                {
                    if (((DefaultComboBoxModel)(shiftComboBox.getModel())).getIndexOf(shift.getHoursPerDay()) == -1) //prevent duplicates from being added
                    {
                        shiftComboBox.addItem(Misc.formatAsHours(shift.getHoursPerDay()));
                    }
                }
            }
            shiftComboBox.setMaximumRowCount(20);
            DefaultCellEditor shiftce = new DefaultCellEditor(shiftComboBox);
            shiftce.setClickCountToStart(2);
            timeTotalsTable.getColumnModel().getColumn(idx_SHIFT).setCellEditor(shiftce);
            
            timeTotalsTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = timeTotalsTable.getSelectedRow();
                        if (selectedRow != -1 && timeTotalsTable.convertRowIndexToModel(selectedRow) != timeTotalsRow)
                        {
                            if (!changingEmployees)
                            {
                                changingEmployees = true;
                                changeEmployee(selectedRow);
                                changingEmployees = false;
                            }
                        }
                    }
                }
            });
            absenceCodeCombo.removeAllItems();
            for (AbsenceCodeRecord absence : RegionData.getAbsenceCodes())
            {
                if (Misc.checkUnionFlag(feeder, absence.getUnionFlags(), union))
                {
                    absenceCodeCombo.addItem(absence.getSapCode() + "  -  " + absence.getDescription());
                }
            }
            absenceCodeCombo.setMaximumRowCount(30);
            attendanceCodeCombo.removeAllItems();
            for (AttendanceCodeRecord attendance : RegionData.getAttendanceCodes())
            {
                if (Misc.checkUnionFlag(feeder, attendance.getUnionFlagsArec(), union))
                {
                    attendanceCodeCombo.addItem(attendance.getSapCodeArec() + "  -  " + attendance.getDescriptionArec());
                }
            }
            attendanceCodeCombo.setMaximumRowCount(30);
            extraPaymentCodeCombo.removeAllItems();
            for (ExtraPaymentCodeRecord extraPayment : RegionData.getExtraPaymentCodes())
            {
                if (Misc.checkUnionFlag(feeder, extraPayment.getUnionFlagsErec(), union))
                {
                    extraPaymentCodeCombo.addItem(extraPayment.getCodeErec() + "  -  " + extraPayment.getDescriptionErec()
                    );
                }
            }
            extraPaymentCodeCombo.setMaximumRowCount(30);
            extraPaymentCodeCombo.addItemListener(new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent e)
                {
                    int selectedRowExtraPayments = extraPaymentsTable.getSelectedRow();
                    if (selectedRowExtraPayments > -1)
                    {
                        if (e.getStateChange() == ItemEvent.SELECTED)
                        {
                            int codeIndex = extraPaymentCodeCombo.getSelectedIndex();
                            extraPaymentsData.setValueAt(RegionData.getExtraPaymentCodes().get(codeIndex).getAmountTypeErec(), extraPaymentsTable.convertRowIndexToModel(selectedRowExtraPayments), idx_Ext_AMOUNT_TYPE);
                        }
                    }
                }
            });
        }
        
        private void configureAbsencesTable()
        {
            Action absencesAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener absencestcl = (TableCellListener)e.getSource();
                    int selectedRowAbsences = absencesTable.getSelectedRow();
                    String sapCode = Misc.objectToString(absencesTable.getValueAt(selectedRowAbsences, idx_Abs_CODE_DESC)).substring(0, 4);
                    absencesTable.setValueAt(sapCode, absencesTable.getSelectedRow(), idx_Abs_SAP_CODE);
                    if (absencestcl.getColumn() == idx_Abs_HOURS_TREC)
                    {
                        absencesData.setValueAt(Misc.hoursToMinutes(Misc.objectToDouble(absencesTable.getValueAt(selectedRowAbsences, idx_Abs_HOURS_TREC))), absencesTable.convertRowIndexToModel(selectedRowAbsences), idx_Abs_MINS_TREC);
                    }
                    if (absencestcl.getColumn() == idx_Abs_MINS_TREC)
                    {
                        absencesData.setValueAt(Misc.minutesToHours(Misc.objectToInt(absencesTable.getValueAt(selectedRowAbsences, idx_Abs_MINS_TREC)), false), absencesTable.convertRowIndexToModel(selectedRowAbsences), idx_Abs_HOURS_TREC);
                    }
                    if (absencestcl.getColumn() == idx_Abs_CODE_DESC)
                    {
                        int day = 0;
                        if (feeder.equals("MEX") && Misc.isNumeric(sapCode))
                        {
                            day = 1;
                        }
                        absencesData.setValueAt(day, absencesTable.convertRowIndexToModel(selectedRowAbsences), idx_Abs_DAYS);

                        String prevReason = reasonCodeCombo.getSelectedItem().toString();
                        reloadReasonCodeCombo(sapCode);
                        boolean comboContainsPrev = false;
                        for (int i = 0; i < reasonCodeCombo.getItemCount(); i++)
                        {
                            if (reasonCodeCombo.getItemAt(i).equals(prevReason))
                            {
                                comboContainsPrev = true;
                                break;
                            }
                        }
                        if (!comboContainsPrev)
                        {
                            absencesData.setValueAt("", absencesTable.convertRowIndexToModel(selectedRowAbsences), idx_Abs_REASON_CODE_DESC);
                        }
                    }

                    if (!absencesChanged.contains(Misc.objectToString(absencesTable.getValueAt(selectedRowAbsences, idx_Abs_RECKEY))))
                    {
                        absencesChanged.add(Misc.objectToString(absencesTable.getValueAt(selectedRowAbsences, idx_Abs_RECKEY)));
                    }
                    flagTimeTotals();
                }
            };
            Misc.configureTable(absencesTable, false, false, false);
            
            absencesTable.setName("absencesTable");
            absencesTable.addPropertyChangeListener(new TableCellListener(absencesTable, absencesAction));
            Misc.addButtonToTable(absencesTable, deleteRecord, idx_Abs_DEL_RECORD);
            
            absencesSorter = new TableRowSorter<>(absencesData);
            absencesTable.setRowSorter(absencesSorter);
            Misc.setTableSorterNumeralComparator(absencesTable);
            
            absencesTable.setSelectionBackground(Constants.SALMON);
            absencesTable.setSelectionForeground(Color.BLACK);
            
            Misc.setHeaderRenderer(absencesTable, true, true, Constants.LTYELLOW);
            Misc.setColumnSettings(absencesTable, idx_Abs_EMPID, 0, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_REPORTING_DATE, 0, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_RECKEY, 0, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_CHGD_BY, 0, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_DATE_CHGD, 0, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_DEL_RECORD, 55, false);
            Misc.setColumnSettings(absencesTable, idx_Abs_SAP_CODE, 0, false);
            Misc.setColumnHeaderRenderer(absencesTable, idx_Abs_CODE_DESC, false, true, Constants.LTYELLOW);//set left alignment
            Misc.setColumnSettings(absencesTable, idx_Abs_CODE_DESC, 250, Constants.LEFT);
            Misc.setColumnHeaderRenderer(absencesTable, idx_Abs_REASON_CODE_DESC, false, true, Constants.LTYELLOW);//set left alignment
            Misc.setColumnSettings(absencesTable, idx_Abs_REASON_CODE_DESC, 240, Constants.LEFT);
            Misc.setColumnSettings(absencesTable, idx_Abs_HOURS_TREC, 45, true, Constants.CENTER);
            Misc.setColumnSettings(absencesTable, idx_Abs_MINS_TREC, 45, true, Constants.CENTER);
            if (feeder.equals("MEX"))
            {
                Misc.setColumnSettings(absencesTable, idx_Abs_DAYS, 45);
                Misc.setColumnSettings(absencesTable, idx_Abs_COMMENT, 105);
            }
            else
            {
                Misc.setColumnSettings(absencesTable, idx_Abs_DAYS, 0);
                Misc.setColumnSettings(absencesTable, idx_Abs_COMMENT, 150);
            }
            Misc.setColumnSettings(absencesTable, idx_Abs_RECORD_TYPE, 0, false);
            
            DefaultCellEditor ace = new DefaultCellEditor(absenceCodeCombo);
            ace.setClickCountToStart(2);
            DefaultCellEditor rce = new DefaultCellEditor(reasonCodeCombo);
            rce.setClickCountToStart(2);
            commentCombo.setEditable(true);
            Misc.setEditorCharLimit(commentCombo.getEditor().getEditorComponent(), 15, false);
            commentCombo.setMaximumRowCount(30);
            DefaultCellEditor cce = new DefaultCellEditor(commentCombo);
            cce.setClickCountToStart(2);
            absencesTable.getColumnModel().getColumn(idx_Abs_COMMENT).setCellEditor(cce);
            absencesTable.getColumnModel().getColumn(idx_Abs_CODE_DESC).setCellEditor(ace);
            absencesTable.getColumnModel().getColumn(idx_Abs_REASON_CODE_DESC).setCellEditor(rce);
            absencesTable.getColumnModel().getColumn(idx_Abs_HOURS_TREC).setCellEditor(new HoursEditor(0.0, 24.0, true));
            absencesTable.getColumnModel().getColumn(idx_Abs_MINS_TREC).setCellEditor(new MinutesEditor(0, 1440, false));
            absencesTable.setRowHeight(20);
            absencesTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
            absencesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent eabs)
                {
                    if (!eabs.getValueIsAdjusting())
                    {
                        int absenceRow = absencesTable.getSelectedRow();
                        if (absenceRow != -1)
                        {
                            reloadReasonCodeCombo(Misc.objectToString(absencesTable.getValueAt(absenceRow, idx_Abs_SAP_CODE)));
                        }
                    }
                }
            });
        }
        
        private void configureExtraPaymentsTable()
        {
            Action extraPaymentsAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (!extraPaymentsChanged.contains(Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsTable.getSelectedRow(), idx_Ext_RECKEY))))
                    {
                        extraPaymentsChanged.add(Misc.objectToString(extraPaymentsTable.getValueAt(extraPaymentsTable.getSelectedRow(), idx_Ext_RECKEY)));
                    }
                    flagTimeTotals();
                }
            };
            
            Misc.configureTable(extraPaymentsTable, false, false, false);
            
            extraPaymentsTable.setName("extraPaymentsTable");
            extraPaymentsTable.addPropertyChangeListener(new TableCellListener(extraPaymentsTable, extraPaymentsAction));
            Misc.addButtonToTable(extraPaymentsTable, deleteRecord, idx_Ext_DEL_RECORD);
            
            extraPaymentsSorter = new TableRowSorter<>(extraPaymentsData);
            extraPaymentsTable.setRowSorter(extraPaymentsSorter);
            Misc.setTableSorterNumeralComparator(extraPaymentsTable);
            
            extraPaymentsTable.setSelectionBackground(Constants.SALMON);
            extraPaymentsTable.setSelectionForeground(Color.BLACK);
            
            Misc.setHeaderRenderer(extraPaymentsTable, true, true, Constants.LTGREEN);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_EMPID, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_REPORTING_DATE, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_RECKEY, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_CHGD_BY, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_DATE_CHGD, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_DEL_RECORD, 55, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_SAP_CODE, 0, false);
            Misc.setColumnHeaderRenderer(extraPaymentsTable, idx_Ext_CODE_DESC, false, true, Constants.LTGREEN);//set left alignment
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_CODE_DESC, 230, Constants.LEFT);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_AMOUNT_EREC, 80, true, Constants.CENTER);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_MINS_EREC, 0, true, Constants.CENTER);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_COST_CENTER, 125);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_LOCATION_CODE, 80);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_ACTIVITY, 90);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_PROJECT_NUMBER, 80);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_AMOUNT_TYPE, 0, false);
            Misc.setColumnSettings(extraPaymentsTable, idx_Ext_RECORD_TYPE, 0, false);
            
            costCenterCombo.setEditable(true);
            Misc.setEditorCharLimit(costCenterCombo.getEditor().getEditorComponent(), 9, true);
            costCenterCombo.setMaximumRowCount(30);
            DefaultCellEditor ccce = new DefaultCellEditor(costCenterCombo);
            DefaultCellEditor epce = new DefaultCellEditor(extraPaymentCodeCombo);
            epce.setClickCountToStart(2);
            DefaultCellEditor upperCaseEditor = new DefaultCellEditor(new JTextField());
            DefaultCellEditor upperCaseEditorLimit6 = new DefaultCellEditor(new JTextField());
            DefaultCellEditor upperCaseEditorLimit7 = new DefaultCellEditor(new JTextField());
            Misc.setEditorCharLimit(upperCaseEditorLimit6.getComponent(), 6, true);
            Misc.setEditorCharLimit(upperCaseEditorLimit7.getComponent(), 7, true);
            
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_COST_CENTER).setCellEditor(ccce);
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_LOCATION_CODE).setCellEditor(upperCaseEditorLimit6);
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_ACTIVITY).setCellEditor(upperCaseEditorLimit6);
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_PROJECT_NUMBER).setCellEditor(upperCaseEditorLimit7);
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_AMOUNT_TYPE).setCellEditor(upperCaseEditor);
            extraPaymentsTable.getColumnModel().getColumn(idx_Ext_CODE_DESC).setCellEditor(epce);
            extraPaymentsTable.setRowHeight(20);
            extraPaymentsTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        }
        
        private void configureAttendancesTable()
        {
            Action attendancesAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener attendancestcl = (TableCellListener)e.getSource();
                    int selectedRowAttendances = attendancesTable.getSelectedRow();
                    String sapCode = Misc.objectToString(attendancesTable.getValueAt(selectedRowAttendances, idx_Att_CODE_DESC)).substring(0, 4);
                    attendancesTable.setValueAt(sapCode, selectedRowAttendances, idx_Att_SAP_CODE);
                    if (attendancestcl.getColumn() == idx_Att_HOURS_AREC)
                    {
                        attendancesData.setValueAt(Misc.hoursToMinutes(Misc.objectToDouble(attendancesTable.getValueAt(selectedRowAttendances, idx_Att_HOURS_AREC))), attendancesTable.convertRowIndexToModel(selectedRowAttendances), idx_Att_MINS_AREC);
                    }
                    if (attendancestcl.getColumn() == idx_Att_MINS_AREC)
                    {
                        attendancesData.setValueAt(Misc.minutesToHours(Misc.objectToInt(attendancesTable.getValueAt(selectedRowAttendances, idx_Att_MINS_AREC)), false), attendancesTable.convertRowIndexToModel(selectedRowAttendances), idx_Att_HOURS_AREC);
                    }
                    if (!attendancesChanged.contains(Misc.objectToString(attendancesTable.getValueAt(attendancesTable.getSelectedRow(), idx_Att_RECKEY))))
                    {
                        attendancesChanged.add(Misc.objectToString(attendancesTable.getValueAt(attendancesTable.getSelectedRow(), idx_Att_RECKEY)));
                    }
                    double shift = Misc.objectToDouble(timeTotalsData.getValueAt(timeTotalsRow, idx_SHIFT));
                    if (feeder.equals("CZE") && attendancestcl.getColumn() == idx_Att_HOURS_AREC && sapCode.equals("0200") && shift > 0)
                    {
                        BigDecimal days = ((BigDecimal)attendancesData.getValueAt(attendancesTable.convertRowIndexToModel(selectedRowAttendances), idx_Att_HOURS_AREC)).divide(BigDecimal.valueOf(shift)).setScale(2, RoundingMode.HALF_EVEN);
                        attendancesData.setValueAt(days, attendancesTable.convertRowIndexToModel(selectedRowAttendances), idx_Att_DAYS);
                    }
                    flagTimeTotals();
                    // Check input for Attendance Detail
                    if (!Misc.isHoliday(RegionData.getHolidayCodes(), selectedDate, union, shift))
                    {
                        if ("HOLX".equals(sapCode))
                        {
                            Misc.msgbox(getFormComponent(), "HOLX is only valid on a holiday.", "Invalid Code", 1, 1, 1);
                        }
                    }
                }
            };
            
            Misc.configureTable(attendancesTable, false, false, false);
            
            attendancesTable.setName("attendancesTable");
            attendancesTable.addPropertyChangeListener(new TableCellListener(attendancesTable, attendancesAction));
            Misc.addButtonToTable(attendancesTable, deleteRecord, idx_Att_DEL_RECORD);
            
            attendancesSorter = new TableRowSorter<>(attendancesData);
            attendancesTable.setRowSorter(attendancesSorter);
            Misc.setTableSorterNumeralComparator(attendancesTable);
            
            attendancesTable.setSelectionBackground(Constants.SALMON);
            attendancesTable.setSelectionForeground(Color.BLACK);
            
            Misc.setHeaderRenderer(attendancesTable, true, true, Constants.LTRED);
            Misc.setColumnSettings(attendancesTable, idx_EMPID, 0, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_REPORTING_DATE, 0, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_RECKEY, 0, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_CHGD_BY, 0, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_DATE_CHGD, 0, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_DEL_RECORD, 55, false);
            Misc.setColumnSettings(attendancesTable, idx_Att_SAP_CODE, 0, false);
            Misc.setColumnHeaderRenderer(attendancesTable, idx_Att_CODE_DESC, false, true, Constants.LTRED);//set left alignment
            Misc.setColumnSettings(attendancesTable, idx_Att_CODE_DESC, 215, Constants.LEFT);
            Misc.setColumnSettings(attendancesTable, idx_Att_HOURS_AREC, 50, true, Constants.CENTER);
            Misc.setColumnSettings(attendancesTable, idx_Att_MINS_AREC, 45, true, Constants.CENTER);
            if (feeder.equals("CZE"))
            {
                Misc.setColumnSettings(attendancesTable, idx_Att_DAYS, 45);
            }
            else
            {
                Misc.setColumnSettings(attendancesTable, idx_Att_DAYS, 0);
            }
            Misc.setColumnSettings(attendancesTable, idx_Att_COST_CENTER, 80);
            Misc.setColumnSettings(attendancesTable, idx_Att_LOCATION_CODE, 80);
            Misc.setColumnSettings(attendancesTable, idx_Att_ACTIVITY, 80);
            Misc.setColumnSettings(attendancesTable, idx_Att_EC, 30);
            Misc.setColumnSettings(attendancesTable, idx_Att_PROJECT_NUMBER, 90);
            Misc.setColumnSettings(attendancesTable, idx_Att_FRC, 45);
            Misc.setColumnSettings(attendancesTable, idx_Att_TAX_AREA, 60);
            Misc.setColumnSettings(attendancesTable, idx_Att_RECORD_TYPE, 0, false);
            
            for (int i = 0; i <= idx_Att_DATE_CHGD; i++)
            {
                attendancesTable.getColumnModel().getColumn(i).setMinWidth(0);
                attendancesTable.getColumnModel().getColumn(i).setMaxWidth(0);
                attendancesTable.getColumnModel().getColumn(i).setWidth(0);
                attendancesTable.getColumnModel().getColumn(i).setPreferredWidth(0);
            }
            
            costCenterCombo.setEditable(true);
            Misc.setEditorCharLimit(costCenterCombo.getEditor().getEditorComponent(), 9, true);
            costCenterCombo.setMaximumRowCount(30);
            
            DefaultCellEditor ccce = new DefaultCellEditor(costCenterCombo);
            DefaultCellEditor attce = new DefaultCellEditor(attendanceCodeCombo);
            attce.setClickCountToStart(2);
            DefaultCellEditor upperCaseEditorLimit1 = new DefaultCellEditor(new JTextField());
            DefaultCellEditor upperCaseEditorLimit4 = new DefaultCellEditor(new JTextField());
            DefaultCellEditor upperCaseEditorLimit6 = new DefaultCellEditor(new JTextField());
            DefaultCellEditor upperCaseEditorLimit7 = new DefaultCellEditor(new JTextField());
            Misc.setEditorCharLimit(upperCaseEditorLimit1.getComponent(), 1, true);
            Misc.setEditorCharLimit(upperCaseEditorLimit4.getComponent(), 4, true);
            Misc.setEditorCharLimit(upperCaseEditorLimit6.getComponent(), 6, true);
            Misc.setEditorCharLimit(upperCaseEditorLimit7.getComponent(), 7, true);
            
            attendancesTable.getColumnModel().getColumn(idx_Att_COST_CENTER).setCellEditor(ccce);
            attendancesTable.getColumnModel().getColumn(idx_Att_LOCATION_CODE).setCellEditor(upperCaseEditorLimit6);
            attendancesTable.getColumnModel().getColumn(idx_Att_ACTIVITY).setCellEditor(upperCaseEditorLimit6);
            attendancesTable.getColumnModel().getColumn(idx_Att_EC).setCellEditor(upperCaseEditorLimit1);
            attendancesTable.getColumnModel().getColumn(idx_Att_PROJECT_NUMBER).setCellEditor(upperCaseEditorLimit7);
            attendancesTable.getColumnModel().getColumn(idx_Att_FRC).setCellEditor(upperCaseEditorLimit6);
            attendancesTable.getColumnModel().getColumn(idx_Att_TAX_AREA).setCellEditor(upperCaseEditorLimit4);
            attendancesTable.getColumnModel().getColumn(idx_Att_CODE_DESC).setCellEditor(attce);
            attendancesTable.getColumnModel().getColumn(idx_Att_HOURS_AREC).setCellEditor(new HoursEditor(0.0, 24.0, true));
            attendancesTable.getColumnModel().getColumn(idx_Att_MINS_AREC).setCellEditor(new MinutesEditor(0, 1440, true));
            
            attendancesTable.setRowHeight(20);
            attendancesTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        }
    }
    
    private void processFilter()
    {
        if (absencesTable == null || extraPaymentsTable == null || attendancesTable == null ||
            !absencesWorker.isDone() || !extraPaymentsWorker.isDone() || !attendancesWorker.isDone())
        {
            return;
        }
        
        // Absences Filtering
        if (absencesTable.isEditing())
        {
            absencesTable.getCellEditor().stopCellEditing();
        }
        
        List<RowFilter<CustomTableModel, Object>> filtersAbsences = new ArrayList<>();
        RowFilter<CustomTableModel, Object> empidFilterAbsences = RowFilter.regexFilter(empidFilterText, idx_Abs_EMPID);
        RowFilter<CustomTableModel, Object> reportingDateFilterAbsences = RowFilter.regexFilter(reportingDateFilterText, idx_Abs_REPORTING_DATE);
        RowFilter<CustomTableModel, Object> recordTypeFilterAbsences = RowFilter.regexFilter(recordTypeFilterText, idx_Abs_RECORD_TYPE);
        filtersAbsences.add(empidFilterAbsences);
        filtersAbsences.add(reportingDateFilterAbsences);
        if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
        {
            filtersAbsences.add(recordTypeFilterAbsences);
        }
        
        if (absencesSorter != null)
        {
            absencesSorter.setRowFilter(RowFilter.andFilter(filtersAbsences));
        }
        
        // ExtraPayments Filtering
        if (extraPaymentsTable.isEditing())
        {
            extraPaymentsTable.getCellEditor().stopCellEditing();
        }
        
        List<RowFilter<CustomTableModel, Object>> filtersExtraPayments = new ArrayList<>();
        RowFilter<CustomTableModel, Object> empidFilterExtraPayments = RowFilter.regexFilter(empidFilterText, idx_Ext_EMPID);
        RowFilter<CustomTableModel, Object> reportingDateFilterExtraPayments = RowFilter.regexFilter(reportingDateFilterText, idx_Ext_REPORTING_DATE);
        RowFilter<CustomTableModel, Object> recordTypeFilterExtraPayments = RowFilter.regexFilter(recordTypeFilterText, idx_Ext_RECORD_TYPE);
        filtersExtraPayments.add(empidFilterExtraPayments);
        filtersExtraPayments.add(reportingDateFilterExtraPayments);
        if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
        {
            filtersExtraPayments.add(recordTypeFilterExtraPayments);
        }
        
        if (extraPaymentsSorter != null)
        {
            extraPaymentsSorter.setRowFilter(RowFilter.andFilter(filtersExtraPayments));
        }
        
        // Attendances Filtering
        if (attendancesTable.isEditing())
        {
            attendancesTable.getCellEditor().stopCellEditing();
        }
        
        List<RowFilter<CustomTableModel, Object>> filtersAttendances = new ArrayList<>();
        RowFilter<CustomTableModel, Object> empidFilterAttendances = RowFilter.regexFilter(empidFilterText, idx_Att_EMPID);
        RowFilter<CustomTableModel, Object> reportingDateFilterAttendances = RowFilter.regexFilter(reportingDateFilterText, idx_Att_REPORTING_DATE);
        RowFilter<CustomTableModel, Object> recordTypeFilterAttendances = RowFilter.regexFilter(recordTypeFilterText, idx_Att_RECORD_TYPE);
        filtersAttendances.add(empidFilterAttendances);
        filtersAttendances.add(reportingDateFilterAttendances);
        if (Arrays.asList("CHANGES", "PRIOR", "UPDATE").contains(editType))
        {
            filtersAttendances.add(recordTypeFilterAttendances);
        }
        
        if (attendancesSorter != null)
        {
            attendancesSorter.setRowFilter(RowFilter.andFilter(filtersAttendances));
        }
    }
    
    private void refreshRelatedScreens()
    {
        PayrollGeneration.refreshInstance();
        Schedules.refreshInstance();
        if (editType.equals("PRIOR"))
        {
            PreviousPayrollCorrections.refreshInstance();
        }
    }
    
    private void closeChildForms()
    {
        AddEmployees.closeInstance();
        DisabilityReportBySchedule.closeInstance();
        StartStopTimes.closeInstance();
    }
    
    private void setControlsEnabled(final boolean enabled)
    {
        String userAccessLevel = UserData.getUserAccessLevel();
        addEmployeeButton.setEnabled(enabled && editType.equals("NORMAL") && !userAccessLevel.equals("READONLY"));
        absencesTable.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        extraPaymentsTable.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        attendancesTable.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        employeeDetailButton.setEnabled(enabled && editType.equals("NORMAL"));
        deleteEmployeeButton.setEnabled(enabled && !Arrays.asList("PRIOR", "CHANGES").contains(editType) && !userAccessLevel.equals("READONLY"));
        changeEmpidButton.setEnabled(enabled && !editType.equals("UPDATE") && !userAccessLevel.equals("READONLY"));
        employeeMaintenanceButton.setEnabled(enabled);
        verifReportButton.setEnabled(enabled);
        approveEmpButton.setEnabled(enabled && !editType.equals("UPDATE") && !userAccessLevel.equals("READONLY"));
        approveAllButton.setEnabled(enabled && !editType.equals("UPDATE") && !userAccessLevel.equals("READONLY"));
        changeToReadyButton.setEnabled(enabled && !editType.equals("UPDATE") && !userAccessLevel.equals("READONLY"));
        absencesButton.setEnabled(enabled);
        addAbsenceButton.setEnabled(enabled && !RegionData.getAbsenceCodes().isEmpty() && !userAccessLevel.equals("READONLY"));
        extraPaymentsButton.setEnabled(enabled);
        addExtraPaymentButton.setEnabled(enabled && !RegionData.getExtraPaymentCodes().isEmpty() && !userAccessLevel.equals("READONLY"));
        attendancesButton.setEnabled(enabled);
        addAttendanceButton.setEnabled(enabled && !RegionData.getAttendanceCodes().isEmpty() && !userAccessLevel.equals("READONLY"));
        toggleSendButton1.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        toggleSendButton2.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        commentFormButton.setEnabled(enabled && !userAccessLevel.equals("READONLY"));
        startStopButton.setEnabled(enabled);
        
        int selectedRow = timeTotalsTable.getSelectedRow();
        if (selectedRow != -1)
        {
            if (timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_STATUS).equals("Separated") &&
                timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_LOCKED_BY).equals(UserData.getUUID()) &&
                readOnly == false)
            {
                addEmployeeButton.setEnabled(editType.equals("NORMAL") && !userAccessLevel.equals("READONLY"));
                deleteEmployeeButton.setEnabled(!userAccessLevel.equals("READONLY"));
            }
            if (timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_STATUS).equals("Not Active") &&
                timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_LOCKED_BY).equals(UserData.getUUID()) &&
                readOnly == false)
            {
                addEmployeeButton.setEnabled(editType.equals("NORMAL") && !userAccessLevel.equals("READONLY"));
                deleteEmployeeButton.setEnabled(!userAccessLevel.equals("READONLY"));
                changeToReadyButton.setEnabled(!Misc.isNumeric(timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_EMPID).toString()));
                changeEmpidButton.setEnabled(Misc.isNumeric(timeTotalsTable.getValueAt(timeTotalsTable.getSelectedRow(), idx_EMPID).toString()));
            }
        }
    }
    
    private void setControlsReadOnly()
    {
        setControlsEnabled(false);
        employeeMaintenanceButton.setEnabled(true);
        absencesButton.setEnabled(true);
        extraPaymentsButton.setEnabled(true);
        attendancesButton.setEnabled(true);
        startStopButton.setEnabled(true);
        employeeDetailButton.setEnabled(editType.equals("NORMAL"));
        verifReportButton.setEnabled(Arrays.asList("NORMAL", "DETAIL", "BYEMPLOYEE", "APPR READ ONLY").contains(editType));
        if (employeeCount > 0)
        {
            changeToReadyButton.setEnabled(Arrays.asList("Not Active", "Separated").contains(timeTotalsData.getValueAt(timeTotalsRow, idx_STATUS).toString()));
        }
        
        boolean disableApproval = false;
        if (RegionData.getSiteLock() != null && !RegionData.getSiteLock().equals("PAY PERIOD"))
        {
            disableApproval = true;
        }
        approveEmpButton.setEnabled(!disableApproval && !Arrays.asList("APPR READ ONLY", "UPDATE").contains(editType) && !UserData.getUserAccessLevel().equals("READONLY"));
        approveAllButton.setEnabled(!disableApproval && !Arrays.asList("APPR READ ONLY", "UPDATE").contains(editType) && !UserData.getUserAccessLevel().equals("READONLY"));
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    private void stopDetailTableCellEditing()
    {
        if (absencesTable.isEditing())
        {
            absencesTable.getCellEditor().stopCellEditing();
        }
        if (extraPaymentsTable.isEditing())
        {
            extraPaymentsTable.getCellEditor().stopCellEditing();
        }
        if (attendancesTable.isEditing())
        {
            attendancesTable.getCellEditor().stopCellEditing();
        }
    }
    
    public static void closeInstance()
    {
        if (instance != null)
        {
            instance.closeForm();
        }
    }
    
    private void closeForm()
    {
        if (timeTotalsWorker != null)
        {
            timeTotalsWorker.cancel(true);
        }
        if (absencesWorker != null)
        {
            absencesWorker.cancel(true);
        }
        if (extraPaymentsWorker != null)
        {
            extraPaymentsWorker.cancel(true);
        }
        if (attendancesWorker != null)
        {
            attendancesWorker.cancel(true);
        }
        
        setCursor(Constants.HOURGLASS);
        if (employeeCount > 0 && timeTotalsScrollPane.isVisible())
        {
            changeEmployee(0);
        }
        
        switch (editType)
        {
            case "NORMAL":
                if (!Misc.objectEquals(Oracle.getScheduleStatus(getFormComponent(), feeder, site, mu, startDate), "Imported"))
                {
                    Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, startDate, endDate, "NORMAL", UserData.getUUID());
                    Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, startDate, endDate, "NORMAL");
                }
                break;
            case "PRIOR":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, null, null, startDate, endDate, "PRIOR", UserData.getUUID());
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                break;
            case "UPDATE":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, null, null, "UPDATE", UserData.getUUID());
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, null, null, "UPDATE");
                break;
            case "DETAIL":
            case "BYEMPLOYEE":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, null, empid, startDate, endDate, "DETAIL", UserData.getUUID());
                for (int i = 0; i < changedEmpidList.size(); i++)
                {
                    Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, null, changedEmpidList.get(i), startDate, endDate, "DETAIL", UserData.getUUID());
                }
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                break;
            case "CHANGES":
                Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, null, null, startDate, endDate, "CHANGES", UserData.getUUID());
                Oracle.updateScheduleStatus(getFormComponent(), feeder, site, null, startDate, endDate, "DETAIL");
                break;
            default:
                // do nothing
        }
        refreshRelatedScreens();
        closeChildForms();
        
        dispose();
        releaseInstance();
        
        if (editType.equals("DETAIL"))
        {
            Date reportingDate = Misc.getLastNormalScheduleDate();
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
        }
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton absencesButton;
    private javax.swing.JScrollPane absencesScrollPane;
    private javax.swing.JButton addAbsenceButton;
    private javax.swing.JButton addAttendanceButton;
    private javax.swing.JButton addEmployeeButton;
    private javax.swing.JButton addExtraPaymentButton;
    private javax.swing.JButton approveAllButton;
    private javax.swing.JButton approveEmpButton;
    private javax.swing.JButton attendancesButton;
    private javax.swing.JPanel bodyPanel;
    private javax.swing.JButton changeEmpidButton;
    private javax.swing.JButton changeToReadyButton;
    private javax.swing.JPanel col1;
    private javax.swing.JPanel col2;
    private javax.swing.JPanel col3;
    private javax.swing.JButton commentFormButton;
    private javax.swing.JPanel controlPanel;
    private javax.swing.JLabel dayOfWeekLabel;
    private javax.swing.JButton deleteEmployeeButton;
    private javax.swing.JTextField dwsDisplay;
    private javax.swing.JLabel dwsLabel;
    private javax.swing.JTextField editTypeTextField;
    private javax.swing.JLabel empidLabel;
    private javax.swing.JButton employeeDetailButton;
    private javax.swing.JLabel employeeLabel;
    private javax.swing.JButton employeeMaintenanceButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton extraPaymentsButton;
    private javax.swing.JLabel feederSiteLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JPanel header2Panel;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JTextField holidayFlag;
    private javax.swing.JButton importErrorsButton;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel loadingPanel;
    private javax.swing.JTextField messageArea;
    private javax.swing.JLabel muLabel;
    private javax.swing.JLabel numOfEmpsLabel;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField readOnlyFlag;
    private javax.swing.JButton refreshButton;
    private javax.swing.JLabel reportingDateLabel;
    private javax.swing.JPanel row1;
    private javax.swing.JPanel row2;
    private javax.swing.JPanel row3;
    private javax.swing.JPanel rowCountPanel;
    private javax.swing.JButton startStopButton;
    private javax.swing.JLabel testDBLabel;
    private javax.swing.JScrollPane timeTotalsScrollPane;
    private javax.swing.JButton toggleSendButton1;
    private javax.swing.JButton toggleSendButton2;
    private javax.swing.JPanel topControls;
    private javax.swing.JPanel topPanel;
    private javax.swing.JLabel unionLabel;
    private javax.swing.JButton verifReportButton;
    // End of variables declaration//GEN-END:variables
}
