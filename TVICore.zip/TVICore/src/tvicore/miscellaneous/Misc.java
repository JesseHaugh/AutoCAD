package tvicore.miscellaneous;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.OrientationRequested;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.text.PlainDocument;
import oracle.jdbc.OracleResultSet;
import tvicore.dao.AbsenceCodeRecord;
import tvicore.dao.AttendanceCodeRecord;
import tvicore.dao.CFAS_Validation;
import tvicore.dao.DwsRecord;
import tvicore.dao.ExtraPaymentCodeRecord;
import tvicore.dao.HolidayRecord;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.dao.UserData;
import tvicore.objects.ButtonColumn;
import tvicore.objects.CharLimitFilter;
import tvicore.objects.CustomTableModel;
import tvicore.objects.CellRenderer;
import tvicore.objects.HeaderRenderer;


public class Misc
{
    private static final ArrayList<Component> formList = new ArrayList<>();
    
    private static Runnable closeForms = null;
    private static boolean shuttingDown = false;
    private static boolean hideMessages = false;
    private static boolean exitting = false;
    private static Date lastNormalScheduleDate;
    private static Timer timeoutTimer = new Timer();
    private static Timer checkDatabaseTimer = new Timer();
    public static Timer shutdownTimer = new Timer();
    
    public static final Semaphore employeeSelectionLock = new Semaphore(1, true); // used for all reports utilizing EmployeeSelectionPanel, as they share use of the temporary table GTT_Employee_Selection
    private static final Semaphore downloadFileLock = new Semaphore(1, true); // used by downloadAndExecuteJar, prevent downloading multiple files at once and potential issues with downloadBytesRead tracking
    public static final Semaphore validateAllocationsLock = new Semaphore(1, true); //used by BeginNewPayPeriod and Schedules
        
    private static int idx_Abs_SAP_CODE = 6;
    private static int idx_Att_SAP_CODE = 6;
    private static int idx_Ext_SAP_CODE = 6;
    
    private static int downloadBytesRead;
    
    public static ArrayList<Component> getFormList() { return formList; }
    
    public static boolean getShuttingDown() { return shuttingDown; }
    public static void setShuttingDown(boolean value) { shuttingDown = value; }
    
    public static Date getLastNormalScheduleDate() { return new Date(lastNormalScheduleDate.getTime()); }
    public static void setLastNormalScheduleDate(Date value) { lastNormalScheduleDate = new Date(value.getTime()); }
    
    public static void setCloseFormsRunnable(Runnable value) { closeForms = value; }
    
    public static int getIndexAbsCode() { return idx_Abs_SAP_CODE; }
    public static int getIndexAttCode() { return idx_Att_SAP_CODE; }
    public static int getIndexExtCode() { return idx_Ext_SAP_CODE; }
    public static void setIndexAbsCode(int value) { idx_Abs_SAP_CODE = value; }
    public static void setIndexAttCode(int value) { idx_Att_SAP_CODE = value; }
    public static void setIndexExtCode(int value) { idx_Ext_SAP_CODE = value; }
    
    /**
     * Closes the application & updates the user's access log record.
     * 
     * @param parentFrame the frame to center messages on
     * @param sbcid
     * @param userIP
     * @param exitType reason for exit, examples: ("NO ACCESS", "DATABASE OFFLINE", "UPGRADING", "NORMAL", "EXCEPTION", "SQL EXCEPTION", "FORCED LOGOFF", "TIMEOUT")
     */
    public static void exit(Component parentFrame, String exitType)
    {
        if (exitting)
        {
            return;
        }
        exitting = true;
        hideMessages = true;
        if (Oracle.hasConnection())
        {
            if (closeForms != null)
            {
                closeForms.run();
            }
            if (exitType != null && UserData.getUUID() != null && !UserData.getUUID().equals(""))
            {
                Oracle.updateUserAccessLog(parentFrame, UserData.getUUID(), "OUT", 0, exitType, UserData.getUserIP());
                Oracle.unlockRecordsByUser(parentFrame, UserData.getUUID());
            }
            Oracle.closeConnection();
        }
        System.exit(0);
    }
    
    /**
     * Customizable message to display to the user.
     * 
     * @param parentFrame the frame to center messages on
     * @param message the message to display
     * @param title the title for the message frame
     * @param iconType JOptionPane.{ERROR_MESSAGE = 0, INFORMATION_MESSAGE = 1, WARNING_MESSAGE = 2, QUESTION_MESSAGE = 3, PLAIN_MESSAGE = -1}
     * @param optionType showMessageDialog (OK) = 1, showConfirmDialog (OK/CANCEL) = 2
     * @param numberOfBeeps number of system beeps to play
     * @return if standard message: true if successful, false otherwise; if confirmationDialog: user selection
     */
    public static boolean msgbox(Component parentFrame, String message, String title, int iconType, int optionType, int numberOfBeeps)
    {
        for (int i = 0; i < numberOfBeeps; i++)
        {
            Toolkit.getDefaultToolkit().beep();
        }
        if (optionType == 1)
        {
            if (!hideMessages)
            {
                JOptionPane.showMessageDialog(parentFrame, message, title, iconType);
            }
            return true;
        }
        else
        {
            int rc = JOptionPane.showConfirmDialog(parentFrame, message, title, JOptionPane.OK_CANCEL_OPTION, iconType);
            return rc == 0;
        }
    }
    
    /**
     * Displays details for the SQLException, closes the database connection, and exits the program
     * 
     * @param parentFrame the frame to center messages on
     * @param ex the SQLException caught
     * @param exit whether or not to close the application after displaying the message
     * @param identifier a list of strings to display on the error message (optional parameters, each string is a new line)
     */
    public static void errorMsgDatabase(Component parentFrame, SQLException ex, boolean exit, String... identifier)
    {
        StringBuilder errormsg = new StringBuilder();
        errormsg.append("<html><center>TVI has encountered an unexpected database exception.<br><font color = \"red\">");
        if (parentFrame != null)
        {
            errormsg.append(parentFrame.getClass().toString().replace("class tvi.gui.", ""));
        }
        if (ex != null)
        {
            if (parentFrame != null)
            {
                errormsg.append(" - ");
            }
            errormsg.append(ex.getMessage().replace("\n", "</font><br><font color = \"red\">"));
            errormsg.append("</font><br><font color = \"red\">SQL State: ");
            errormsg.append(ex.getSQLState());
            errormsg.append("</font><br><font color = \"red\">Error Code: ");
            errormsg.append(ex.getErrorCode());
        }
        errormsg.append("</font><br>");
        if (identifier != null && identifier.length > 0)
        {
            for (String line : identifier)
            {
                errormsg.append("<br><font size=\"+2\" color = \"blue\">");
                errormsg.append(line);
                errormsg.append("</font>");
            }
            errormsg.append("<br>");
        }
        if (exit)
        {
            errormsg.append("<br>TVI WILL NOW EXIT.");
        }
        errormsg.append("<br>If this problem persists, email TVI Support at: ");
        errormsg.append(Constants.EMAIL);
        msgbox(parentFrame, errormsg.toString(), "TVI Exception - DATABASE", JOptionPane.PLAIN_MESSAGE, 1, 1);
        if (exit)
        {
            exit(parentFrame, "SQL EXCEPTION");
        }
    }
    
    /**
     * For critical errors that require the client to exit
     * 
     * @param parentFrame the frame to center messages on
     * @param ex the Exception caught
     * @param identifier a list of strings to display on the error message (optional parameters, each string is a new line)
     */
    public static void errorMsgCritical(Component parentFrame, Exception ex, String... identifier)
    {
        StringBuilder errormsg = new StringBuilder();
        errormsg.append("<html><center>TVI has encountered an unexpected exception in a critical process:<br><font color = \"red\">");
        if (parentFrame != null)
        {
            errormsg.append(parentFrame.getClass().toString().replace("class tvi.gui.", ""));
        }
        if (ex != null)
        {
            if (parentFrame != null)
            {
                errormsg.append(" - ");
            }
            errormsg.append(ex.getClass().toString());
            errormsg.append("</font><br><font color = \"red\">");
            if (ex.getMessage() != null)
            {
                errormsg.append(ex.getMessage().replace("\n", " - "));
            }
        }
        errormsg.append("</font>");
        if (identifier != null && identifier.length > 0)
        {
            errormsg.append("<br>");
            for (String line : identifier)
            {
                errormsg.append("<br><font size=\"+2\" color = \"blue\">");
                errormsg.append(line);
                errormsg.append("</font>");
            }
        }
        errormsg.append("<br><br>TVI WILL NOW EXIT.<br>If this problem persists, email TVI Support at: ");
        errormsg.append(Constants.EMAIL);
        msgbox(parentFrame, errormsg.toString(), "TVI Exception - CRITICAL", JOptionPane.PLAIN_MESSAGE, 1, 1);
        exit(parentFrame, "EXCEPTION");
    }
    
    /**
     * For generic, non-critical un-handled exceptions. Use as detailed notification only.
     * 
     * @param parentFrame the frame to center messages on
     * @param ex the Exception caught
     * @param identifier a list of strings to display on the error message (optional parameters, each string is a new line)
     */
    public static void errorMsgDefault(Component parentFrame, Exception ex, String... identifier)
    {
        StringBuilder errormsg = new StringBuilder();
        errormsg.append("<html><center>TVI has encountered an unexpected exception:<br><font color = \"red\">");
        if (parentFrame != null)
        {
            errormsg.append(parentFrame.getClass().toString().replace("class tvi.gui.", ""));
        }
        if (ex != null)
        {
            if (parentFrame != null)
            {
                errormsg.append(" - ");
            }
            errormsg.append(ex.getClass().toString());
            errormsg.append("</font><br><font color = \"red\">");
            errormsg.append(ex.getMessage().replace("\n", " - "));
        }
        errormsg.append("</font>");
        if (identifier != null && identifier.length > 0)
        {
            errormsg.append("<br>");
            for (String line : identifier)
            {
                errormsg.append("<br><font size=\"+2\" color = \"blue\">");
                errormsg.append(line);
                errormsg.append("</font>");
            }
        }
        errormsg.append("<br><br>If this problem persists, email TVI Support at: ");
        errormsg.append(Constants.EMAIL);
        msgbox(parentFrame, errormsg.toString(), "TVI Exception", JOptionPane.PLAIN_MESSAGE, 1, 1);
    }
    
    /**
     * Gets the current user's UUID from their current login
     */
    public static String getUUID()
    {
        String sbcid = System.getProperty("user.name").toUpperCase(Locale.ENGLISH);
        
        if (sbcid.length() > 6)
        {
            sbcid = sbcid.substring(0, 6);
        }
        else if (sbcid.length() == 0)
        {
            errorMsgCritical(null, new Exception("ATTUID ERROR"), "TVI encountered a problem with your network domain userid.");
        }
        switch (sbcid)
        {
            case "BREPR":
            case "BREPRE":
                sbcid = "BP7322";
                break;
            case "DEBBIELYNCH":
            case "DEBBIE":
                sbcid = "DL8398";
                break;
            case "KAREN":
                sbcid = "KT1654";
                break;
            default: //do nothing
        }
        return sbcid;
    }
    
    /**
     * Moves the opened form to the same screen that it's parent was on
     * 
     * @param parentFrame the originating form
     * @param frame the new form to open
     * @param maximize true for fullscreen, false for center
     */
    public static void showOnSameScreen(Component parentFrame, JFrame frame, boolean maximize)
    {
        if (!shuttingDown)
        {
            resetTimeoutTimer();
        }
        if (!formList.contains(frame))
        {
            formList.add(frame);
        }
        GraphicsConfiguration gc;
        if (parentFrame != null)
        {
            gc = parentFrame.getGraphicsConfiguration();
        }
        else
        {
            gc = frame.getGraphicsConfiguration();
        }
        frame.setExtendedState(java.awt.Frame.NORMAL);
        frame.setVisible(true);
        frame.setLocation(gc.getBounds().getLocation());
        frame.setSize(frame.getPreferredSize());
        if (UserData.getPreferFullscreen() && maximize)
        {
            frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
            frame.setResizable(true);
        }
        else //center
        {
            centerFrame(frame);
        }
    }
    
    /**
     * Centers the frame on the screen
     * 
     * @param frame
     */
    public static void centerFrame(JFrame frame)
    {
        Rectangle bounds = frame.getGraphicsConfiguration().getBounds();
        int center_x = bounds.x + bounds.width / 2;
        int center_y = bounds.y + bounds.height / 2;

        frame.setLocation(center_x - frame.getWidth() / 2, center_y - frame.getHeight() / 2);
    }
    
    /**
     * Ensures the formList only contains visible, open forms. Removes closed or hidden forms.
     */
    public static void updateFormList()
    {
        for (int i = formList.size() - 1; i > 0; i--)
        {
            if (formList.get(i) == null)
            {
                formList.remove(i);
            }
            else if (!formList.get(i).isVisible())
            {
                formList.remove(i);
            }
        }
    }
    
    /**
     * For generic, non-critical un-handled exceptions. Use as detailed notification only.
     * 
     * @param table the table to configure
     * @param autoRowSort set false if using a special row sort
     * @param multiSelect row selection method; true = multiselect, false = single
     * @param colsResizable when true, users can adjust width of columns
     */
    public static void configureTable(JTable table, boolean autoRowSort, boolean multiSelect, boolean colsResizable)
    {
        table.setFillsViewportHeight(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getTableHeader().setReorderingAllowed(false);
        
        if (autoRowSort)
        {
            setTableSorterNumeralComparator(table);
        }
        if (multiSelect)
        {
            table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        }
        else
        {
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        }
        
        TableColumnModel ccols = table.getColumnModel();
        Enumeration<TableColumn> ce = ccols.getColumns();
        while (ce.hasMoreElements())
        {
            TableColumn ccol = ce.nextElement();
            ccol.setResizable(colsResizable);
            ccol.sizeWidthToFit();
        }
    }
    
    /**
     * Configures the given table's HeaderRenderer.
     * 
     * @param table the JTable to modify
     * @param center boolean that determines if the header should be centered
     * @param bold boolean that determines if the header text should be bold
     * @param color header text color
     */
    public static void setHeaderRenderer(JTable table, boolean center, boolean bold, Color color)
    {
        HeaderRenderer headerRenderer = new HeaderRenderer(table, center, bold, color);
        table.getTableHeader().setDefaultRenderer(headerRenderer);
        for (int i = 0; i < table.getModel().getColumnCount(); i++)
        {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
    }
    
    /**
     * Configures the HeaderRenderer for the specified column.
     * 
     * @param table the JTable to modify
     * @param index the column index to configure
     * @param center boolean that determines if the header should be centered
     * @param bold boolean that determines if the header text should be bold
     * @param color header text color
     */
    public static void setColumnHeaderRenderer(JTable table, int index, boolean center, boolean bold, Color color)
    {
        HeaderRenderer headerRenderer = new HeaderRenderer(table, center, bold, color);
        table.getColumnModel().getColumn(index).setHeaderRenderer(headerRenderer);
    }
    
    /**
     * Configures the given table for the specified column index.
     * 
     * @param table the JTable to modify
     * @param index
     * @param width
     */
    public static void setColumnSettings(JTable table, int index, int width)
    {
        setColumnSettings(table, index, width, true);
    }
    
    /**
     * Configures the given table for the specified column index.
     * Default cell renderer, with option to exclude
     * 
     * @param table the JTable to modify
     * @param index
     * @param width
     * @param useCellRenderer
     */
    public static void setColumnSettings(JTable table, int index, int width, boolean useCellRenderer)
    {
        setColumnWidth(table, index, width);
        if (useCellRenderer)
        {
            table.getColumnModel().getColumn(index).setCellRenderer(new CellRenderer(table.getColumnModel().getColumn(index), null, false, JLabel.CENTER));
        }
    }
    
    /**
     * Configures the given table for the specified column index.
     * Use to override default alignment.
     * 
     * @param table the JTable to modify
     * @param index the index of the column to modify
     * @param width the new width of the column
     * @param alignment the alignment integer index (SwingConstants.CENTER = 0, SwingConstants.LEFT = 2, SwingConstants.RIGHT = 4)
     */
    public static void setColumnSettings(JTable table, int index, int width, int alignment)
    {
        // override default alignment
        setColumnWidth(table, index, width);
        table.getColumnModel().getColumn(index).setCellRenderer(new CellRenderer(table.getColumnModel().getColumn(index), null, false, alignment));
    }
    
    /**
     * Configures the given table for the specified column index.
     * Use to override default date format.
     * 
     * @param table the JTable to modify
     * @param index the index of the column to modify
     * @param width the new width of the column
     * @param dateFormat the new date format to use
     * @param alignment the alignment integer index (SwingConstants.CENTER = 0, SwingConstants.LEFT = 2, SwingConstants.RIGHT = 4)
     */
    public static void setColumnSettings(JTable table, int index, int width, String dateFormat, int alignment)
    {
        setColumnWidth(table, index, width);
        table.getColumnModel().getColumn(index).setCellRenderer(new CellRenderer(table.getColumnModel().getColumn(index), dateFormat, false, alignment));
    }
    
    /**
     * Configures the given table for the specified column index.
     * Use to hide zero values.
     * 
     * @param table the JTable to modify
     * @param index the index of the column to modify
     * @param width the new width of the column
     * @param hideZeroes boolean, determines if zero values should be hidden
     * @param alignment the alignment integer index (SwingConstants.CENTER = 0, SwingConstants.LEFT = 2, SwingConstants.RIGHT = 4)
     */
    public static void setColumnSettings(JTable table, int index, int width, boolean hideZeroes, int alignment)
    {
        setColumnWidth(table, index, width);
        table.getColumnModel().getColumn(index).setCellRenderer(new CellRenderer(table.getColumnModel().getColumn(index), null, true, alignment));
    }
    
    /**
     * Sets the column width for the specified table and column index.
     * 
     * @param table the JTable to modify
     * @param index the index of the column to modify
     * @param width the new width of the column
     */
    public static void setColumnWidth(JTable table, int index, int width)
    {
        if (width == 0)
        {
            table.getColumnModel().getColumn(index).setMinWidth(0);
            table.getColumnModel().getColumn(index).setMaxWidth(0);
            table.getColumnModel().getColumn(index).setWidth(0);
        }
        table.getColumnModel().getColumn(index).setPreferredWidth(width);
    }
    
    /**
     * Scales a scroll pane to fit the specified table's current size (with 20px buffer for scroll bars)
     * 
     * @param parentFrame the frame to center messages on
     * @param scrollPane the scroll pane container
     * @param table the contained table
     */
    public static void scaleScrollPaneToTable(Component parentFrame, JScrollPane scrollPane, JTable table)
    {
        int maxWidth = 20;
        for (int i = 0; i < table.getColumnModel().getColumnCount(); i++)
        {
            maxWidth += table.getColumnModel().getColumn(i).getPreferredWidth();
        }
        int maxHeight = table.getRowHeight() * table.getRowCount() + table.getTableHeader().getPreferredSize().height + 20;
        
        scrollPane.setMaximumSize(new Dimension(maxWidth, maxHeight));
        scrollPane.setPreferredSize(new Dimension(maxWidth, maxHeight));
        parentFrame.validate();
    }
    
    /**
     * Updates the given table's rowsorter to use a numeral comparator.  Should be run AFTER any filters are assigned to the table.
     * 
     * @param table the table to modify
     */
    public static void setTableSorterNumeralComparator(JTable table)
    {
        TableRowSorter<?> sorter = (TableRowSorter<?>)table.getRowSorter();
        if (sorter == null)
        {
            if (table.getModel() instanceof CustomTableModel)
            {
                sorter = new TableRowSorter<>((CustomTableModel)table.getModel());
            }
            else // instanceof DefaultTableModel
            {
                sorter = new TableRowSorter<>((DefaultTableModel)table.getModel());
            }
        }
        ArrayList<Class<?>> classList = new ArrayList<>();
        classList.add(BigDecimal.class);
        classList.add(Double.class);
        classList.add(Integer.class);
        for (int i = 0; i < table.getColumnCount(); i++)
        {
            if (classList.contains(table.getColumnClass(i)))
            {
                Comparator<Object> numeralComparator = new Comparator<Object>()
                {
                    @Override
                    public int compare(Object a, Object b)
                    {
                        double d1 = objectToDouble(a);
                        double d2 = objectToDouble(b);
                        return Double.compare(d1, d2);
                    }
                };
                sorter.setComparator(i, numeralComparator);
            }
        }
        table.setRowSorter(sorter);
    }
    
    /**
     * Converts the given Object to a String (adds a handler for null value).
     * 
     * @param amountIn Object value to convert
     * @return output as String, or "" if input was null
     */
    public static String objectToString(Object amountIn)
    {
        if (amountIn == null)
        {
            return "";
        }
        else
        {
            return amountIn.toString();
        }
    }
    
    /**
     * Checks if the given objects are equal, and handles null values.
     * NOTE: doesn't guarantee the objects aren't null for future operations.
     * 
     * @param amountIn Object value to check
     * @param value Object to compare to
     * @return output true if the objects match, false otherwise
     */
    public static boolean objectEquals(Object amountIn, Object value)
    {
        if (amountIn == null)
        {
            return value == null;
        }
        else
        {
            return amountIn.equals(value);
        }
    }
    
    /**
     * Converts the given Object to a double.
     * 
     * @param amountIn Object value to convert
     * @return output as double, or 0.0 if input was null or ""
     */
    public static double objectToDouble(Object amountIn)
    {
        if (amountIn == null)
        {
            return 0.0;
        }
        else if (amountIn.toString().isEmpty())
        {
            return 0.0;
        }
        else
        {
            return Double.parseDouble(amountIn.toString());
        }
    }
    
    /**
     * Converts a double value to BigDecimal format.
     * 
     * @param amountIn double value to convert
     * @return output as BigDecimal (rounded to 2 decimal places)
     */
    public static BigDecimal doubleToBigDecimal(double amountIn)
    {
        return BigDecimal.valueOf(amountIn).setScale(2, RoundingMode.HALF_EVEN);
    }
    
    /**
     * Converts an Object to an integer.
     * 
     * @param amountIn Object value to convert
     * @return output as integer, or 0 if input was null or ""
     */
    public static int objectToInt(Object amountIn)
    {
        if (amountIn == null)
        {
            return 0;
        }
        else if (amountIn.toString().isEmpty())
        {
            return 0;
        }
        else
        {
            return Integer.parseInt(amountIn.toString());
        }
    }
    
    /**
     * Converts an Object to a String.
     * 
     * @param amountIn Object value to convert
     * @return output as String, or "ALL" if input was null
     */
    public static String objectToALL(Object amountIn)
    {
        if (amountIn == null)
        {
            return "ALL";
        }
        else
        {
            return amountIn.toString();
        }
    }
    
    /**
     * Converts an Object to a reason code String.
     * 
     * @param amountIn Object value to convert
     * @return String containing first 6 characters of input, or "" if input was null or insufficient length
     */
    public static String objectToReasonCode(Object amountIn)
    {
        if (amountIn == null)
        {
            return "";
        }
        else if (amountIn.toString().length() < 6)
        {
            return "";
        }
        else
        {
            return amountIn.toString().substring(0, 6);
        }
    }
    
    /**
     * Converts an Object to reason code description String.
     * 
     * @param amountIn Object value to convert
     * @return output as string excluding the first 11 characters, or "" if the input was null or insufficient length.
     */
    public static String objectToReasonDescription(Object amountIn)
    {
        if (amountIn == null)
        {
            return "";
        }
        else if (amountIn.toString().length() < 11)
        {
            return "";
        }
        else
        {
            return amountIn.toString().substring(11);
        }
    }
    
    /**
     * makeReasonCode
     * 
     * Creates a reason code from the given code and description.
     * 
     * @param codeIn
     * @param descriptionIn
     * @return reason code String
     */
    public static String makeReasonCode(Object codeIn, Object descriptionIn)
    {
        if (codeIn == null)
        {
            return "";
        }
        else
        {
            if (descriptionIn == null)
            {
                descriptionIn = " ";
            }
            return codeIn.toString() + "  -  " + descriptionIn.toString();
        }
    }
    
    /**
     * Converts the given number of minutes to an hour value with 2 decimal places.
     * 
     * @param minutes the number of minutes to convert
     * @param quarter if true, will round to the nearest quarter hour (.00, .25, .50, .75)
     * @return number of hours in BigDecimal output, formated as #.##
     */
    public static BigDecimal minutesToHours(Integer minutes, boolean quarter)
    {
        if (quarter)
        {
            return new BigDecimal(Math.round((minutes / 15.0)) * .25).setScale(2);
        }
        else
        {
            return new BigDecimal(minutes / 60.0).setScale(2, RoundingMode.HALF_UP);
        }
    }
    
    /**
     * Converts hours to minutes.
     * 
     * @param hours
     * @return integer number of minutes
     */
    public static int hoursToMinutes(double hours)
    {
        return (int)(hours * 60.0 + .5);
    }
    
    /**
     * Formats the given Objext as a numerical String with 2 decimal places.
     * 
     * @param amountIn the object to convert
     * @return String output, formated as #.##
     */
    public static String formatAsHours(Object amountIn)
    {
        DecimalFormat df = new DecimalFormat("#0.00");
        if (amountIn == null)
        {
            return "0.00";
        }
        else if (isInteger(amountIn.toString()))
        {
            return df.format((double) Integer.parseInt(amountIn.toString()));
        }
        else
        {
            return df.format(Double.parseDouble(amountIn.toString()));
        }
    }
    
    /**
     * Converts an Object to boolean ("-1" = true, "0" or other = false).
     * 
     * @param amountIn Object to convert
     * @return true if object value = "-1", false otherwise
     */
    public static boolean oracleToBoolean(Object amountIn)
    {
        if (amountIn == null)
        {
            return false;
        }
        else
        {
            return amountIn.toString().equals("-1");
        }
    }
    
    /**
     * Converts a boolean to an Object for the Oracle database.
     * 
     * @param amountIn boolean to convert
     * @return Object with value of "-1" if true, "0" otherwise
     */
    public static int booleanToOracle(Object amountIn)
    {
        if ((Boolean)amountIn)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
    
    /**
     * Converts an Object into a String, simply "Y" if not null, "N" otherwise.
     * 
     * @param amountIn Ovject value to convert
     * @return "Y", or "N" if amountIn is null
     */
    public static String makeYorN(Object amountIn)
    {
        if (amountIn == null)
        {
            return "N";
        }
        else
        {
            return "Y";
        }
    }
    
    /**
     * Checks if the given string is numberic.
     * 
     * @param str the input string to check
     * @return true if the input string is numeric, false otherwise
     */
    public static boolean isNumeric(String str)
    {
        return str.matches("[+-]?\\d*(\\.\\d+)?");
    }
    
    /**
     * Checks if the given string is alphanumeric.
     * 
     * @param str the input string to check
     * @return true if the input string contains at least one number and one letter, false otherwise
     */
    public static boolean isAlphaNumeric(String str)
    {
        return (str.matches(".*\\d+.*") && str.matches(".*[a-z|A-Z]+.*"));
    }
    
    /**
     * Checks if the given string is alpha.
     * 
     * @param str the input string to check
     * @return true if the input string contains at least one letter, false otherwise
     */
    public static boolean isAlpha(String str)
    {
        return (str.matches(".*[a-z|A-Z]+.*"));
    }
    
    /**
     * Checks if the given string contains any special characters (i.e. characters other than 0-9, a-z, A-Z)
     * 
     * @param str the input string to check
     * @return true if the input string contains at least one non-alpha or non-numeric character, false otherwise
     */
    public static boolean containsSpecialCharacters(String str)
    {
        return str.matches(".*[^a-zA-Z0-9]+.*");
    }
    
    /**
     * Checks if the given String is an integer.
     * 
     * @param str the input string to check
     * @return true if the input string is an integer, false otherwise
     */
    public static boolean isInteger(String str)
    {
        boolean output = true;
        try
        {
            Integer.parseInt(str);
        }
        catch (NumberFormatException e)
        {
            output = false;
        }
        return output;
    }
    
    /**
     * Alters the given Date to reflect only the date, not time (sets hours, minutes, seconds, milliseconds to 0)
     * 
     * @param dateIn the input Date to change
     * @return the input Date with time of day information cleared.
     */
    public static Date dateNoTime(Date dateIn)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateIn);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
    
    /**
     * Checks if the given String is a date.
     * 
     * @param str the input string to check
     * @return true if the input String is a date, false otherwise
     */
    public static boolean isDate(String str)
    {
        if (str == null)
        {
            return false;
        }
        ArrayList<SimpleDateFormat> dateFormats = new ArrayList<>();
        dateFormats.add(new SimpleDateFormat("M/d/yyyy"));
        Date date = null;
        for (SimpleDateFormat format : dateFormats)
        {
            try
            {
                format.setLenient(false);
                date = format.parse(str);
            }
            catch (ParseException e)
            {
                //no problem
            }
            if (date != null)
            {
                break;
            }
        }
        return date != null;
    }
    
    /**
     * Converts the given date to the specified String format.
     * 
     * @param dateIn the input Date to convert
     * @param format the String format to use when converting (i.e. "MM/dd/yyyy")
     * @return formatted String output
     */
    public static String dateToString(Date dateIn, String format)
    {
        try
        {
            DateFormat df = new SimpleDateFormat(format);
            return df.format(dateIn);
        }
        catch (NullPointerException ex)
        {
            return "";
        }
    }
    
    /**
     * Converts the given date to String in the format "MM/dd/yyyy".
     * 
     * @param dateIn the Date value to convert
     * @return formatted String output, ex: "03/14/1592"
     */
    public static String dateToStringMDY(Date dateIn)
    {
        return dateToString(dateIn, "MM/dd/yyyy");
    }
    
    /**
     * Converts the given date to String in the format "EEE" (Day of week)
     * 
     * @param dateIn the Date value to convert
     * @return formatted String output, ex: "Mon"
     */
    public static String dateToStringShortDay(Date dateIn)
    {
        return dateToString(dateIn, "EEE");
    }
    
    /**
     * Converts the given String to Date, using the specified format.
     * 
     * @param parentFrame the frame to center messages on
     * @param stringIn the String to convert
     * @param format the String format to use when parsing (i.e. "MM/dd/yyyy")
     * @return Date output, or null if parsing failed
     */
    public static Date stringToDate(Component parentFrame, String stringIn, String format)
    {
        return stringToDate(parentFrame, stringIn, format, false);
    }
    
    /**
     * Converts the given String to Date, using the specified format.
     * 
     * @param parentFrame the frame to center messages on
     * @param stringIn the String to convert
     * @param format the String format to use when parsing (i.e. "MM/dd/yyyy")
     * @param suppressMessages
     * @return Date output, or null if parsing failed
     */
    public static Date stringToDate(Component parentFrame, String stringIn, String format, boolean suppressMessages)
    {
        Date output = null;
        if (stringIn != null && !stringIn.equals(""))
        {
            try
            {
                DateFormat df = new SimpleDateFormat(format, Locale.ENGLISH);
                output = df.parse(stringIn);
            }
            catch (ParseException ex)
            {
                if (!suppressMessages)
                {
                    errorMsgDefault(parentFrame, ex, "Failed to parse date string.");
                }
            }
        }
        return output;
    }
    
    /**
     * Converts the given String to Date, using the format "M/d/yyyy".
     * 
     * @param parentFrame
     * @param stringIn
     * @return Date output, or null if parsing failed
     */
    public static Date stringToDateMDY(Component parentFrame, String stringIn)
    {
        return stringToDate(parentFrame, stringIn, "M/d/yyyy");
    }
    
    /**
     * Converts the given String to Date, using the format "M/d/yyyy".
     * Option to suppress messages
     * 
     * @param parentFrame
     * @param stringIn
     * @param suppressMessages
     * @return Date output, or null if parsing failed
     */
    public static Date stringToDateMDY(Component parentFrame, String stringIn, boolean suppressMessages)
    {
        return stringToDate(parentFrame, stringIn, "M/d/yyyy", suppressMessages);
    }
    
    /**
     * Converts a formatted date String to Date. (truncates hours/minutes)
     * 
     * @param parentFrame the frame to center messages on
     * @param input string in the format "yyyy-M-d".*
     * @return outputs as date format
     */
    public static Date stringDateTimeToDateMDY(Component parentFrame, String input)
    {
        Date output = null;
        try
        {
            if (input != null)
            {
                DateFormat df = new SimpleDateFormat("yyyy-M-d", Locale.ENGLISH);
                output = df.parse(input.substring(0, 10));
            }
        }
        catch (ParseException ex)
        {
            errorMsgDefault(parentFrame, ex, "Failed to parse date string.");
        }
        return output;
    }
    
    /**
     * Converts the given Date to a java.sql.Date
     * 
     * @param dateIn the date to convert
     * @return the java.sql.Date output
     */
    public static java.sql.Date dateToSqlDate(Date dateIn)
    {
        java.sql.Date output = null;
        if (dateIn != null)
        {
            output = new java.sql.Date(dateIn.getTime());
        }
        return output;
    }
    
    /**
     * Converts the given java.sql.Date to java.util.Date
     * 
     * @param dateIn the date to convert
     * @return the java.sql.Date output
     */
    public static Date sqlDateToDate(java.sql.Date dateIn)
    {
        Date output = null;
        if (dateIn != null)
        {
            output = new Date(dateIn.getTime());
        }
        return output;
    }
    
    /**
     * Converts the given Date to a java.sql.Timestamp
     * 
     * @param dateIn the date to convert
     * @return the java.sql.Timestamp output
     */
    public static java.sql.Timestamp dateToTimestamp(Date dateIn)
    {
        java.sql.Timestamp output = null;
        if (dateIn != null)
        {
            output = new java.sql.Timestamp(dateIn.getTime());
        }
        return output;
    }
    
    /**
     * Converts the given java.sql.Timestamp to a Date
     * 
     * @param timestampIn the date to convert
     * @return the Date output
     */
    public static Date timestampToDate(Date timestampIn)
    {
        Date output = null;
        if (timestampIn != null)
        {
            output = new Date(timestampIn.getTime());
        }
        return output;
    }
    
    /**
     * Converts the given bigDecimal to an integer (truncated).
     * 
     * @param bd the bigDecimal to convert
     * @return the integer value output
     */
    public static int bigDecimalToInt(Object bd)
    {
        return ((BigDecimal)bd).intValue();
    }
    
    /**
     * Checks if the given Object is a valid hour value (Null, "", or a number using .25 increments).
     * 
     * @param amountIn Object value to check
     * @param increments
     * @return true if the input is valid, false otherwise
     */
    public static boolean hoursValid(Object amountIn, boolean increments)
    {
        if (amountIn == null || amountIn.toString().isEmpty())
        {
            return true;
        }
        else if (isNumeric(amountIn.toString()))
        {
            if (!increments)
            {
                return true;
            }
            else
            {
                double hoursIn = Double.parseDouble(amountIn.toString());
                double integerPart = hoursIn - (int) hoursIn;
                return (integerPart == 0 || integerPart == .25 || integerPart == .5 || integerPart == .75);
            }
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Checks if the given Object is a valid minute value (Null, "", or a positive integer).
     * 
     * @param amountIn Object value to check
     * @param increments
     * @return true if the input is valid, false otherwise
     */
    public static boolean minutesValid(Object amountIn, boolean increments)
    {
        if (amountIn == null || amountIn.toString().isEmpty())
        {
            return true;
        }
        else if (isInteger(amountIn.toString()))
        {
            if (!increments)
            {
                return true;
            }
            else
            {
                return (Integer.parseInt(amountIn.toString()) % 15) == 0;
            }
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Checks if the given Object is a valid time format (Null, "", or matches regex format).
     * 
     * @param time Object value to check
     * @return true if the input is valid, false otherwise
     */
    public static boolean timeValid(Object time)
    {
        if (time == null || time.toString().isEmpty())
        {
            return true;
        }
        else
        {
            return time.toString().matches("^(((0{0,1}[1-9]|1[0-2])(:{0,1}((00)|(15)|(30)|(45))){0,1} {0,1}(A|a|P|p)(M|m))|(([01]{0,1}[0-9]|2[0-3])(:{0,1}((00)|(15)|(30)|(45))){0,1}))$");
        }
    }
    
    /**
     * Converts the given string to time format (hh:mm am/pm)
     * 
     * @param timeIn Object value to convert
     * @return true if the input is valid, false otherwise
     */
    public static String formatTime(Object timeIn)
    {
        if (timeIn == null || timeIn.toString().isEmpty())
        {
            return "";
        }
        else
        {
            String time = timeIn.toString().replaceAll(" ", "");
            String hours;
            String minutes;
            String meridiem = "AM";
            if (time.matches("^.*(A|a|P|p)(M|m)$")) //ends with AM/PM
            {
                if (time.matches("^.*(P|p)(M|m)$"))
                {
                    meridiem = "PM";
                }
                time = time.substring(0, time.length() - 2);
            }
            if (time.contains(":"))
            {
                hours = time.split(":")[0];
                minutes = time.split(":")[1];
            }
            else if (time.length() > 2)
            {
                minutes = time.substring(time.length() - 2, time.length());
                hours = time.substring(0, time.length() - 2);
            }
            else
            {
                hours = time;
                minutes = "00";
            }
            if (Integer.parseInt(hours) > 12)
            {
                meridiem = "PM";
                hours = String.valueOf(Integer.parseInt(hours) - 12);
            }
            if (hours.length() < 2)
            {
                hours = "0" + hours;
            }
            if (hours.equals("00"))
            {
                hours = "12";
            }
            if (minutes.length() < 2)
            {
                minutes = "0" + minutes;
            }
            return hours + ":" + minutes + " " + meridiem;
        }
    }
    
    /**
     * Checks if the given Date is a holiday for the specified union.
     * 
     * @param holidayCodes
     * @param dayToCheck the date to check
     * @param union
     * @param shift
     * @return true if the date is a holiday for this union, false otherwise
     */
    public static boolean isHoliday(ArrayList<HolidayRecord> holidayCodes, Date dayToCheck, String union, double shift)
    {
        boolean foundHoliday = false;
        for (int i = 0; (i < holidayCodes.size() && foundHoliday == false); i++)
        {
            if (dayToCheck.compareTo(holidayCodes.get(i).getHoliday()) == 0)
            {
                if (union.contains("TVI") && union.contains("IBEW") && holidayCodes.get(i).getHolidayName().equals("MLK"))
                {
                    foundHoliday = false;
                }
                else if (union.contains("STI") && !union.contains("MGRNE") && holidayCodes.get(i).getHolidayName().equals("PRESIDENTSDAY"))
                {
                    foundHoliday = false;
                }
                else if ("ATI_CWA_4_F".equals(union) && holidayCodes.get(i).getHolidayName().equals("XMASEVE"))
                {
                    foundHoliday = false;
                }
                else if (union.contains("MGRNE") && Arrays.asList("XMASEVE", "MOTHERSDAY").contains(holidayCodes.get(i).getHolidayName()))
                {
                    foundHoliday = false;
                }
                else if (union.contains("STI") && shift == 10 && holidayCodes.get(i).getHolidayName().equals("THANKSGIVING2"))
                {
                    foundHoliday = false;
                }
                else
                {
                    foundHoliday = !holidayCodes.get(i).getHolidayType().equals("OTHER");
                }
            }
        }
        return foundHoliday;
    }
    
    /**
     * Checks to make sure the specified union flag is in the given list of valid unions.
     * 
     * @param feeder
     * @param validUnions comma-separated list of valid unions
     * @param union the union to check
     * @return true if the union is valid, false otherwise
     */
    public static boolean checkUnionFlag(String feeder, String validUnions, String union) // use siteunion if no relevant MU is defined...
    {
        if (validUnions == null || union == null)
        {
            return true;
        }
        String delimiter = "-";
        if (feeder.equals("ATI"))
        {
            delimiter = "_";
        }
        String[] validUnionFlags = validUnions.split(",");
        for (String validUnion: validUnionFlags)
        {
            if (union.equals(feeder + delimiter + validUnion.trim()))
            {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns the matching DwsRecord to the provided String.
     * 
     * @param dwsCodes
     * @param DWSIn
     * @return DwsRecord
     */
    public static DwsRecord getDWSRecord(ArrayList<DwsRecord> dwsCodes, String DWSIn)
    {
        DwsRecord dwsRec = new DwsRecord("NONE","0",false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,"");
        for (DwsRecord dws : dwsCodes)
        {
            if (dws.getDWS().equals(DWSIn))
            {
                dwsRec = dws;
                break;
            }
        }
        return dwsRec;
    }
    
    /**
     * Converts an integer index into it's corresponding diff source String.
     * 
     * @param DiffSource integer index value
     * @return diff source as String
     */
    public static String getDiffSource(int DiffSource)
    {
        switch (DiffSource)
        {
            case 0:
                return "";
            case 1:
                return "Sched";
            case 2:
                return "FtrExp";
            case 3:
                return "3wkRul";
            case 4:
                return "3 Day";
            case 5:
                return "OffDay";
            default:
                return "GTR";
        }
    }
    
    /**
     * Alters the given editing component so that the user can't enter more than the specified number of characters.
     * 
     * @param editorComponent the editing component to change
     * @param limit the maximum number of characters to allow
     * @param toUpper boolean that determines if all input should be forced as UPPERCASE
     */
    public static void setEditorCharLimit(Object editorComponent, int limit, boolean toUpper)
    {
        Document document = ((JTextComponent) editorComponent).getDocument();
        if (document instanceof PlainDocument)
        {
            ((PlainDocument) document).setDocumentFilter(new CharLimitFilter(limit, toUpper));
        }
    }
    
    /**
     * Deletes the specified file.
     * 
     * @param fileName filepath to delete
     * @return true if successful, false otherwise
     */
    public static boolean deleteFile(String fileName)
    {
        File fileToDelete = new File(fileName);
        if (fileToDelete.exists())
        {
            return fileToDelete.delete();
        }
        else
        {
            return true;
        }
    }
    
    /**
     * Creates and runs a visual basic script that gets the motherboard serial number of the current machine (used as a unique device ID).
     * 
     * @param parentFrame the frame to center messages on
     * @return the motherboard serial number String
     */
    public static String getMotherboardSN(Component parentFrame)
    {
        StringBuilder result = new StringBuilder();
        try
        {
            File file = File.createTempFile("getUniqueID",".vbs");
            file.deleteOnExit();
            try (FileWriter fw = new java.io.FileWriter(file))
            {
                String vbs = "Set objWMIService = GetObject(\"winmgmts:\\\\.\\root\\cimv2\")\n"
                        + "Set colItems = objWMIService.ExecQuery _ \n"
                        + "   (\"Select * from Win32_BIOS\") \n"
                        + "For Each objItem in colItems \n"
                        + "    Wscript.Echo objItem.SerialNumber \n"
                        + "    exit for  ' do the first cpu only! \n"
                        + "Next \n";
                
                fw.write(vbs);
            }
            //String[] filePath = {"cscript", "//NoLogo", file.getPath()};
            Process p = Runtime.getRuntime().exec(new String[] {"cscript", "//NoLogo", file.getPath()});
            try (BufferedReader input = new BufferedReader (new InputStreamReader(p.getInputStream())))
            {
                String line;
                while ((line = input.readLine()) != null)
                {
                    result.append(line);
                }
            }
        }
        catch (IOException ex)
        {
            errorMsgDefault(parentFrame, ex, "Error getting unique ID.");
        }
        return result.toString().trim();
    }
    
    /**
     * Checks if the specified date is the given day of the week
     * 
     * @param date
     * @param dayOfWeek Calendar dayOfWeek integer code (SUNDAY = 1, MONDAY = 2, TUESDAY = 3, WEDNESDAY = 4, THURSDAY = 5. FRIDAY = 6, SATURDAY = 7)
     * @return true if matches, false otherwise
     */
    public static boolean dateIsDayOfWeek(Date date, int dayOfWeek)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateNoTime(date));
        return cal.get(Calendar.DAY_OF_WEEK) == dayOfWeek;
    }
    
    /**
     * Gets the next specified day of the week relevant to the provided date.
     * Passing {(Date)(1/1/2015), Calendar.SUNDAY, [inclusive]} would return the first Sunday that follows 1/1/2015, which is 1/4/2015.
     * Passing {(Date)(1/4/2015), Calendar.SUNDAY, true} would return 1/4/2015.
     * Passing {(Date)(1/4/2015), Calendar.SUNDAY, false} would return 1/11/2015.
     * 
     * @param date
     * @param dayOfWeek Calendar dayOfWeek integer code (SUNDAY = 1, MONDAY = 2, TUESDAY = 3, WEDNESDAY = 4, THURSDAY = 5. FRIDAY = 6, SATURDAY = 7)
     * @param inclusive if true, when the date passed IS the given day of the week, it will return itself; if false, the following week will be returned
     * @return the date of the first specified weekday to follow the given date
     */
    public static Date getNextDayOfWeek(Date date, int dayOfWeek, boolean inclusive)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateNoTime(date));
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        int daysToAdd;
        if (dayOfWeek > weekday)
        {
            daysToAdd = dayOfWeek - weekday;
        }
        else if (dayOfWeek < weekday)
        {
            daysToAdd = 7 - (weekday - dayOfWeek);
        }
        else // dayOfWeek == weekday
        {
            if (inclusive)
            {
                daysToAdd = 0;
            }
            else
            {
                daysToAdd = 7;
            }
        }
        cal.add(Calendar.DAY_OF_YEAR, daysToAdd);
        return cal.getTime();
    }
    
    /**
     * Gets the name of the given month
     * 
     * @param parentFrame
     * @param month
     * @return the first day of the given month
     */
    public static String getNameOfMonth(Component parentFrame, int month)
    {
        String name = null;
        switch (month)
        {
            case 0:
                name = "January";
                break;
            case 1:
                name = "February";
                break;
            case 2:
                name = "March";
                break;
            case 3:
                name = "April";
                break;
            case 4:
                name = "May";
                break;
            case 5:
                name = "June";
                break;
            case 6:
                name = "July";
                break;
            case 7:
                name = "August";
                break;
            case 8:
                name = "September";
                break;
            case 9:
                name = "October";
                break;
            case 10:
                name = "November";
                break;
            case 11:
                name = "December";
                break;
            default:
                msgbox(parentFrame, "Unhandled month, email TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
        }
        return name;
    }
    
    /**
     * Gets the first day of the month containing the given date.
     * 
     * @param date
     * @return the first day of the given month
     */
    public static Date getFirstDayOfMonth(Date date)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateNoTime(date));
        cal.set(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }
    
    /**
     * Gets the last day of the month containing the given date.
     * 
     * @param date
     * @return the last day of the given month
     */
    public static Date getLastDayOfMonth(Date date)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dateNoTime(date));
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        return cal.getTime();
    }
    
    /**
     * Checks if the current method is running on the Event Dispatch Thread.
     * Useful for debugging during multithreaded GUI development.
     * 
     * @param identifier name of method being run
     */
    public static void checkOnEDT(String identifier)
    {
        if (!SwingUtilities.isEventDispatchThread())
        {
            System.out.println("Method " + identifier + " called outside of EDT.");
        }
    }
    
    /**
     * Sorts the provided DefaultListModel.
     * 
     * @param data DefaultListModel to sort
     */
    public static void sortListModel(final DefaultListModel<String> data)
    {
        int numOfCodes = data.getSize();
        if (numOfCodes > 0)
        {
            String[] temp = new String[numOfCodes];
            for (int i = 0; i < numOfCodes; i++)
            {
                temp[i] = data.getElementAt(i);
            }
            Arrays.sort(temp);
            data.clear();
            for (int i = 0; i < numOfCodes; i++)
            {
                data.addElement(temp[i]);
            }
        }
    }
    
    /**
     * Adjusts the given date by adding the specified number of hours to it.
     * (Pass a negetive value to subtract)
     * 
     * @param date the date to adjust
     * @param hoursAdjustment the number of hours to add
     * @return the adjusted date
     */
    public static Date dateAdjustHours(Date date, int hoursAdjustment)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.HOUR, hoursAdjustment);
        return cal.getTime();
    }
    
    /**
     * Adds a buttonColumn to the table.
     * 
     * @param table the table to modify
     * @param action the action to perform when the button is pressed
     * @param column the index of the column to modify
     */
    public static void addButtonToTable(JTable table, Action action, int column)
    {
        ButtonColumn buttonColumn = new ButtonColumn(table, action, column);
        
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(column).setCellRenderer(buttonColumn);
        columnModel.getColumn(column).setCellEditor(buttonColumn);
        table.addMouseListener(buttonColumn);
    }
    
    /**
     * Adds a specified number of days to a date.
     * 
     * @param date the date to modify
     * @param days the number of days to add (negative to subtract)
     * @return the adjusted date
     */
    public static Date dateAddDays(Date date, int days)
    {
        return dateAddCustom(date, Calendar.DAY_OF_YEAR, days);
    }
    
    /**
     * Modifies a date by adding a specified amount of a given Calendar type.
     * 
     * @param date the date to modify
     * @param type the Calendar type to modify (Calendar.DAY_OF_YEAR, Calendar.MINUTE, Calendar.MONTH, Calendar.YEAR, etc...)
     * @param amount the amount to add (negative to subtract)
     * @return the adjusted date
     */
    public static Date dateAddCustom(Date date, int type, int amount)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(type, amount);
        return cal.getTime();
    }
    
    /**
     * Checks if the current site is locked; if it is, the appropriate message is also displayed.
     * 
     * @param parentFrame
     * @param siteLock
     * @return true if the site is locked, false otherwise
     */
    public static boolean isSiteLocked(Component parentFrame, String siteLock)
    {
        boolean output = false;
        if (siteLock != null)
        {
            output = true;
            switch (siteLock)
            {
                case "PAY PERIOD":
                    msgbox(parentFrame, "Site is currently locked, you must begin the next Payroll Period.", "Site Locked", 1, 1, 1);
                    break;
                case "COMPUTE 40":
                    msgbox(parentFrame, "Site is temporarily locked by Compute 40 Hr check, call TVI Support if you have any questions.", "Site Locked", 1, 1, 1);
                    break;
                case "COMPUTE FUTURE":
                    msgbox(parentFrame, "Site is temporarily locked by Compute future exceptions, call TVI Support if you have any questions.", "Site Locked", 1, 1, 1);
                    break;
                case "ADDING RECORDS":
                    msgbox(parentFrame, "Site is temporarily locked while employee records are being added, call TVI Support if you have any questions.", "Site Locked", 1, 1, 1);
                    break;
                case "COMPLETING_INT":
                    msgbox(parentFrame, "Site is temporarily locked while while schedules are being completed, call TVI Support if you have any questions.", "Site Locked", 1, 1, 1);
                    break;
                default:
                    msgbox(parentFrame, "Site is currently locked, email TVI Support at " + Constants.EMAIL + " if you have any questions.", "Site Locked", 1, 1, 1);
                    break;
            }
        }
        return output;
    }
    
    /**
     * Gets the inactive effective date from the user.
     * 
     * @param parentFrame the frame to center messages on
     * @param curDate today's date
     * @return the effective date chosen, or null if the user cancels
     */
    public static Date getInactiveEffectiveDate(Component parentFrame, Date curDate)
    {
        Date effectiveDate;
        int selectedIndex = 60;
        
        List<String> dateList = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.setTime(curDate);
        cal.add(Calendar.MONTH, -2);
        for (int i = 0; i < 120; i++)
        {
            if (cal.getTime().compareTo(curDate) == 0)
            {
                selectedIndex = i;
            }
            dateList.add(dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        String[] dateArray = dateList.toArray(new String[dateList.size()]);
        String selectedDate = (String) JOptionPane.showInputDialog(
            null,
            "Select the effective date:",
            "Inactive Date Selection",
            JOptionPane.QUESTION_MESSAGE,
            null,
            dateArray,
            dateArray[selectedIndex]);//selected index = curdate
        if (selectedDate == null) // if the user clicks cancel
        {
            effectiveDate = null;
        }
        else
        {
            effectiveDate = stringToDateMDY(parentFrame, selectedDate);
        }
        return effectiveDate;
    }
    
    /**
     * Formats the given string so it will be center aligned.
     * Needs to be called to fix headers with multiple lines, otherwise the default header renderer won't work as expected
     * 
     * @param input the string text to format
     * @return the html formatted string
     */
    public static String centerHTML(String input)
    {
        return "<html><div align='center' width='100%'>" + input + "</div></html>";
    }
    
    /**
     * Prints the given table with the specified settings.
     * 
     * @param parentFrame the frame to center messages on
     * @param table
     * @param orientation "PORTRAIT" or "LANDSCAPE"
     * @param title
     */
    public static void printTable(Component parentFrame, JTable table, String orientation, String title)
    {
        printTable(parentFrame, null, null, null, table, orientation, title);
    }
    
    /**
     * Prints the given table with the specified settings.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param table
     * @param orientation "PORTRAIT" or "LANDSCAPE"
     * @param title
     */
    public static void printTable(Component parentFrame, String feeder, String site, JTable table, String orientation, String title)
    {
        printTable(parentFrame, feeder, site, null, table, orientation, title);
    }
    
    /**
     * Prints the given table with the specified settings.
     * 
     * @param parentFrame the frame to center messages on
     * @param feeder
     * @param site
     * @param mu
     * @param table
     * @param orientation "PORTRAIT" or "LANDSCAPE"
     * @param title
     */
    public static void printTable(Component parentFrame, String feeder, String site, String mu, JTable table, String orientation, String title)
    {
        try
        {
            String feederText = "";
            String siteText = "";
            String muText = "";
            if (feeder != null)
            {
                feederText = feeder;
            }
            if (site != null)
            {
                siteText = ", Site " + site;
            }
            if (mu != null)
            {
                muText = ", MU " + mu;
            }
            if (feeder != null || site != null || mu != null)
            {
                title = "    " + title;
            }
            String mf = feederText + siteText + muText + title + "    " + dateToStringMDY(Oracle.getCurTimeLocal(parentFrame));
            MessageFormat header = new MessageFormat(mf);
            PrintRequestAttributeSet set = new HashPrintRequestAttributeSet();
            if (orientation.equals("PORTRAIT"))
            {
                set.add(OrientationRequested.PORTRAIT);
            }
            else
            {
                set.add(OrientationRequested.LANDSCAPE);
            }
            table.print(JTable.PrintMode.FIT_WIDTH, header, null, true, set, false);
        }
        catch (PrinterException ex)
        {
            errorMsgDefault(parentFrame, ex, "Failed to print table.");
        }
    }
    
    /**
     * Takes a list of indexes and removes the columns that will be shown.
     * 
     * @param columnsList arraylist of all available columns
     * @param columnsToShow arraylist of only the columns to show
     * @return arraylist containing only the indexes to hide
     */
    public static List<Integer> getHiddenColumns(List<Integer> columnsList, List<Integer> columnsToShow)
    {
        // remove elements in columnsToShow from columnsList
        for (int index : columnsToShow)
        {
            for (int i = 0; i < columnsList.size(); i++)
            {
                if (columnsList.get(i) == index)
                {
                    columnsList.remove(i);
                    break;
                }
            }
        }
        
        return columnsList;
    }
    
    /**
     * Accepts a date string that matches the regex "^\d{1,2}\/\d{1,2}((\/\d{2})|(\/\d{4})){0,1}$".
     * Converts to a date formatted as "mm-dd" or "yyyy-mm-dd" for table filtering compatibility.
     * 
     * @param input
     * @return output
     */
    public static String dateStringToFilterString(String input)
    {
        String output = "";
        String[] parts = input.split("/");
        if (parts.length == 3)
        {
            output += parts[2] + "-";
        }
        if (parts[0].length() == 2)
        {
            output += parts[0];
        }
        else
        {
            output += "0" + parts[0];
        }
        output += "-";
        if (parts[1].length() == 2)
        {
            output += parts[1];
        }
        else
        {
            output += "0" + parts[1];
        }
        return output;
    }
    
    /**
     * Checks if there is a meeting available for the specified user on the given feeder.
     * A meeting is available if the user isn't already signed up and has available slots.
     * 
     * @param parentFrame
     * @param feeder
     * @param sbcid
     * @return true if at least one meeting is available, false otherwise
     */
    public static boolean isMeetingAvailable(Component parentFrame, String feeder, String sbcid)
    {
        boolean meetingAvailable = false;
        ResultSetWrapper results = Oracle.getTrainingClasses(parentFrame, feeder, sbcid);
        ResultSet rs = results.getResultSet();
        
        try
        {
            while (rs.next())
            {
                if (!oracleToBoolean(rs.getInt("SIGNED_UP")) && rs.getInt("SLOTS_FILLED") < rs.getInt("NUMBER_OF_SLOTS"))
                {
                    meetingAvailable = true;
                    break;
                }
            }
        }
        catch (SQLException ex)
        {
            errorMsgDatabase(parentFrame, ex, false, "SQL Error checking meeting list.");
        }
        finally
        {
            results.close();
        }
        return meetingAvailable;
    }
    
    /**
     * Converts the given list of strings to a single string with comma separated values.
     * 
     * @param list
     * @return string of comma separated values
     */
    public static String listToStringCSV(List<String> list)
    {
        StringBuilder output = new StringBuilder();
        if (list != null && list.size() > 0)
        {
            for (int i = 0; i < list.size(); i++)
            {
                output.append(list.get(i));
                if (i + 1 < list.size())
                {
                    output.append(",");
                }
            }
        }
        return output.toString();
    }
    
    /**
     * Converts the given comma separated values to a list of strings.
     * 
     * @param stringCSV
     * @return list of strings
     */
    public static List<String> stringCSVToList(String stringCSV)
    {
        List<String> list = new ArrayList<>();
        if (stringCSV != null)
        {
            list.addAll(Arrays.asList(stringCSV.split(",")));
        }
        return list;
    }
    
    /**
     * Returns the number of days between the two dates given.
     * 
     * @param date1
     * @param date2
     * @return integer number of days
     */
    public static int daysBetween(Date date1, Date date2)
    {
        float diffMs = Math.abs(dateNoTime(date1).getTime() - dateNoTime(date2).getTime());
        int diffDays = Math.round(diffMs/(1000*60*60*24));
        return diffDays;
    }
    
    /**
     * Returns a random integer from min - max (inclusive)
     * 
     * @return integer
     */
    public static int getRandomInteger(int min, int max)
    {
        Random r = new Random();
        return r.nextInt(max - min + 1) + min;
    }
    
    /**
     * Returns a random character from a-z
     * 
     * @return single character String
     */
    public static String getRandomCharacter()
    {
        Random r = new Random();
        return Character.toString((char)(r.nextInt(26) + 'a'));
    }
    
    /**
     * Returns a random character from the given alphabet string.
     * 
     * @param alphabet
     * @return single character String
     */
    public static String getRandomAlphabet(String alphabet)
    {
        Random r = new Random();
        int length = alphabet.length();
        return Character.toString(alphabet.charAt(r.nextInt(length)));
    }
    
    /**
     * Converts the given java.util.Date to a ZonedDateTime variable in the specified timezone.
     * 
     * @param dateToConvert
     * @param oldTimeZone
     * @param newTimeZone
     * @return ZonedDateTime
     */
    public static ZonedDateTime dateToZonedDateTime(Date dateToConvert, ZoneId oldTimeZone, ZoneId newTimeZone)
    {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm");
        LocalDateTime dateTimeZoneless = LocalDateTime.parse(dateToString(dateToConvert, "MM/dd/yyyy HH:mm"), dateFormat);
        ZonedDateTime dateTimeOld = ZonedDateTime.of(dateTimeZoneless, oldTimeZone);
        return dateTimeOld.withZoneSameInstant(newTimeZone);
    }
    
    /**
     * Converts the given LocalDateTime to a ZonedDateTime variable from one timezone to another.
     * 
     * @param date
     * @param oldTimeZone
     * @param newTimeZone
     * @return ZonedDateTime
     */
    public static ZonedDateTime convertDateToTimeZone(LocalDateTime date, ZoneId oldTimeZone, ZoneId newTimeZone)
    {
        ZonedDateTime oldDate = ZonedDateTime.of(date, oldTimeZone);
        return oldDate.withZoneSameInstant(newTimeZone);
    }
    
    /**
     * returns a copy of the given arrayList with duplicates removed.
     * 
     * @param oldList
     * @return ArrayList
     */
    public static <T> ArrayList<T> removeDuplicates(ArrayList<T> oldList)
    {
        ArrayList<T> newList = new ArrayList<>();
        for (T item : oldList)
        {
            if (!newList.contains(item))
            {
                newList.add(item);
            }
        }
        return newList;
    }
    
    /**
     * Gets the current user's network IP
     * 
     * @param oldList
     * @return String
     */
    public static String getNetworkIp()
    {
        String networkIp;
        try (final DatagramSocket socket = new DatagramSocket())
        {
            socket.connect(InetAddress.getByName("8.8.8.8"), 10002);
            networkIp = socket.getLocalAddress().getHostAddress();
        }
        catch (SocketException | UnknownHostException ex)
        {
            networkIp = "";
        }
        return networkIp;
    }
    
    /**
     * Resets the timeout timer to 2 hours. If the timer counts down without being reset, the software shuts down in 30 seconds.
     * 
     */
    public static void resetTimeoutTimer()
    {
        if (timeoutTimer != null)
        {
            timeoutTimer.cancel();
        }
        timeoutTimer = new Timer();
        timeoutTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                timeoutTimer.cancel();
                checkDatabaseTimer.cancel();
                startShutdownTimer(30*1000, "TIMEOUT");
                msgbox(null, "<html><center><font size=\"5\">Your user session has TIMED OUT due to inactivity.<br><b>TVI will shut down in 30 seconds.</b></font>", "TVI Shutting Down", -1, 1, 1);
            }
        }, 2*60*60*1000);
    }
    
    /**
     * Starts or restarts the checkDatabaseTimer
     * @param task 
     */
    public static void startCheckDatabaseTimer(TimerTask task)
    {
        if (checkDatabaseTimer != null)
        {
            checkDatabaseTimer.cancel();
        }
        checkDatabaseTimer = new Timer();
        checkDatabaseTimer.scheduleAtFixedRate(task, 10*60*1000, 10*60*1000);
    }
    
    /**
     * Starts a shutdown timer with the specified duration; when the time runs out, the software is closed.
     * 
     * @param milliseconds
     * @param exitType
     */
    public static void startShutdownTimer(int milliseconds, final String exitType)
    {
        shuttingDown = true;
        shutdownTimer = new Timer();
        shutdownTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                exit(null, exitType);
            }
        }, milliseconds);
    }
    
    /**
     * Checks if the specified user has been flagged to have their current session terminated
     * If so, displays the message and initiates shutdown.
     * 
     * @param sbcid the user's AT&T UUID
     */
    public static void checkForceLogoff(String sbcid)
    {
        if (Oracle.isForceLogoff(null, sbcid))
        {
            String forceLogoffMsg = Oracle.getForceLogoffMsg(null, sbcid);
            String msg = "<html><center>Your current TVI session is being remotely shut down.<br><br>";
            if (forceLogoffMsg != null)
            {
                msg += "<font color = \"blue\">" + forceLogoffMsg + "</font><br><br>";
            }
            msg += "Your session will terminate in 5 minutes.<br>"
                 + "Some unsaved data may be lost at shutdown, please finish any pending work and exit TVI.";
            startShutdownTimer(5*60*1000, "FORCED LOGOFF");
            msgbox(null, msg, "Remote Logoff", -1, 1, 1);
        }
    }
    
    /**
     * Will attempt to convert the given String to "123-4567" or "(123) 456-789" format
     * 
     * @param number
     * @return String
     */
    public static String numberToPhone(String number)
    {
        String output;
        switch (number.length())
        {
            case 10:
                output = "(" + number.substring(0, 3) + ") " + number.substring(3, 6) + "-" + number.substring(6, 10);
                break;
            case 7:
                output = number.substring(0, 3) + "-" + number.substring(3, 7);
                break;
            default:
                output = number;
                break;
        }
        return output;
    }
    
    /**
     * Converts a primitive double to an Object Double
     * 
     * @param value
     */
    public static Double doubleToDouble(double value)
    {
        if (value == 0.0)
        {
            return null;
        }
        else
        {
            return (Double)value;
        }
    }
    
    /**
     * Downloads the specified jar file from the server, updating the provided progressBar and textField with status.
     * It then executes the jar and exits.
     * 
     * @param parentFrame
     * @param filename
     * @param progressBar
     * @param textField
     */
    public static void downloadAndExecuteJar(Component parentFrame, String filename, JProgressBar progressBar, JTextField textField)
    {
        if (!downloadFileLock.tryAcquire())
        {
            Misc.msgbox(parentFrame, "Error: Simultaneous file download : " + filename, "File download interrupted", 0, 1, 1);
            return;
        }
        ResultSetWrapper results = Oracle.getBFILE(parentFrame, filename);
        ResultSet rs = results.getResultSet();
        
        filename = filename.replace("~~~", "jar");
        try
        {
            if (!rs.next())
            {
                errorMsgDatabase(parentFrame, null, true, "Failed to find file in ResultSet.");
            }
            oracle.jdbc.OracleBfile clientFile = ((OracleResultSet)rs).getBFILE(1);
            progressBar.setMaximum((int)clientFile.length());

            File fileOnDisk = new File(filename);
            try (FileOutputStream tviClientStream = new FileOutputStream(fileOnDisk))
            {
                clientFile.openFile();
                try (InputStream in = clientFile.getBinaryStream())
                {
                    byte[] buf = new byte[8192];
                    downloadBytesRead = 0;
                    while ((downloadBytesRead = in.read(buf)) != -1)
                    {
                        tviClientStream.write(buf, 0, downloadBytesRead);
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                progressBar.setValue(progressBar.getValue() + downloadBytesRead);
                            }
                        });
                    }
                }
                clientFile.close();
            }
        }
        catch (SQLException ex)
        {
            Oracle.closeConnection();
            errorMsgDatabase(parentFrame, ex, true, "Failed to obtain " + filename);
        }
        catch (IOException ex)
        {
            Oracle.closeConnection();
            errorMsgCritical(parentFrame, ex, "Failed to access " + filename);
        }
        finally
        {
            downloadFileLock.release();
            results.close();
        }

        textField.setText("DOWNLOADED FINISHED");
        executeJar(parentFrame, filename);
        if (filename.equals("TVIUpgrade.jar"))
        {
            exit(parentFrame, "UPGRADING");
        }
        else
        {
            exit(parentFrame, null);
        }
    }
    
    /**
     * Executes the given jar file.
     * 
     * @param parentFrame
     * @param filename
     */
    public static void executeJar(Component parentFrame, String filename)
    {
        try
        {
            String javaPath = System.getProperty("java.home");
            javaPath = "\"" + javaPath + "\\bin\\javaw" + "\"";
            //String cmdToRun = "cmd  /C  \"" + javaPath + "\"  -jar " + filename;
            Runtime.getRuntime().exec(new String[] {"cmd", "/C", javaPath, "-jar ", filename});
        }
        catch (IOException ex)
        {
            errorMsgCritical(parentFrame, ex, "Failed to open " + filename);
        }
    }
    
    /**
     * Checks if the following import is okay to perform (INFOR deployment transition)
     * DYADD - can remove this once INFOR deployment is completed.
     * 
     * @param parentFrame
     * @param clientName
     * @param feeder
     * @param site
     * @param startDate
     * @param endDate
     * @return true if the importing is allowed, false otherwise
     */
    public static boolean isImportAllowedInforTransition(Component parentFrame, String clientName, String feeder, String site, Date startDate, Date endDate)
    {
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            return true;
        }
        String payCycle = Oracle.getPayCycle(parentFrame, feeder, site);
        Date goLiveDate;
        switch (payCycle)
        {
            case "A1":
                goLiveDate = Misc.stringToDateMDY(parentFrame, "12/17/2023");
                break;
            case "B1":
                goLiveDate = Misc.stringToDateMDY(parentFrame, "12/24/2023");
                break;
            default:
                return true;
        }
        switch (clientName)
        {
            case "ELINK":
                if (endDate.compareTo(goLiveDate) >= 0)
                {
                    String message = "At least one requested date occurs after the INFOR go live date for this MU and cannot be imported.\n" + 
                                     "For pay cycle " + payCycle + ", dates from " + Misc.dateToStringMDY(goLiveDate) + " forward need to be reported via the new INFOR client.\n" + 
                                     "Contact TVI Support if you have any questions.";
                    Misc.msgbox(parentFrame, message, "Importing restriction", 1, 1, 1);
                    return false;
                }
                else
                {
                    return true;
                }
            case "INFOR":
                if (startDate.compareTo(goLiveDate) < 0)
                {
                    String message = "At least one requested date occurs before the INFOR go live date for this MU and cannot be imported.\n" + 
                                     "For pay cycle " + payCycle + ", dates before " + Misc.dateToStringMDY(goLiveDate) + " should already have been reported via the ELINK client.\n" + 
                                     "If you have retro corrections to make, there is a special process for doing so through eLink.\n" +
                                     "Consult the help topics for further info, or contact TVI Support if you have any questions.";
                    Misc.msgbox(parentFrame, message, "Importing restriction", 1, 1, 1);
                    return false;
                }
                else
                {
                    return true;
                }
            default:
                return true;
        }
    }
    
    /**
     * Checks if the given date is for the other client and should be locked. (INFOR deployment transition)
     * DYADD - can remove this once INFOR deployment is completed.
     * 
     * @param parentFrame
     * @param clientName
     * @param feeder
     * @param site
     * @param reportingDate
     * @return true if the importing is allowed, false otherwise
     */
    public static boolean isRecordLockedInforTransition(Component parentFrame, String clientName, String feeder, String site, Date reportingDate)
    {
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            return false;
        }
        String payCycle = Oracle.getPayCycle(parentFrame, feeder, site);
        Date goLiveDate;
        switch (payCycle)
        {
            case "A1":
                goLiveDate = Misc.stringToDateMDY(parentFrame, "12/17/2023");
                break;
            case "B1":
                goLiveDate = Misc.stringToDateMDY(parentFrame, "12/24/2023");
                break;
            default:
                return true;
        }
        switch (clientName)
        {
            case "ELINK":
                return reportingDate.compareTo(goLiveDate) >= 0;
            case "INFOR":
                return reportingDate.compareTo(goLiveDate) < 0;
            default:
                return false;
        }
    }
    
    /**
     * Checks if it's okay to update the payroll period for the given site.
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @param siteLock
     * @param payCycle
     * @param payClose
     * @param hotDay
     * @return true if the payroll period can be updated, false otherwise
     */
    public static boolean isBeginNewPayPeriodOkay(Component parentFrame, String feeder, String site, String siteLock, String payCycle, Date payClose, Date hotDay)
    {
        parentFrame.setCursor(Constants.HOURGLASS);
        if (siteLock != null && !siteLock.equals("PAY PERIOD") && Misc.isSiteLocked(parentFrame, siteLock))
        {
            return false;
        }
        if (Oracle.getCurTimeLocal(parentFrame).compareTo(hotDay) < 0)
        {
            parentFrame.setCursor(Constants.NORMAL);
            Misc.msgbox(parentFrame, "You must wait until Payroll Close to begin new payroll", "Begin New Payroll Period", 1, 1, 1);
            return false;
        }
        Date payStartDate = Oracle.getPayrollStartDate(parentFrame, payCycle, payClose);
        if (feeder.equals("STI") && !Oracle.checkFutureExceptions(parentFrame, feeder, site, payStartDate, payClose))
        {
            parentFrame.setCursor(Constants.NORMAL);
            Misc.msgbox(parentFrame, "FIRST you must... Click on the Compute Night Diff Future Exceptions - button (Southwest Consumer)", "Begin New Payroll Period", 1, 1, 1);
            return false;
        }
        
        /*
        if (!Oracle.checkFutureSchedulesUpdated(parentFrame, feeder, site, payStartDate, payClose))
        {
            parentFrame.setCursor(Constants.NORMAL);
            Misc.msgbox(parentFrame, "There are still future schedule records in this payroll period that need to be updated.\nImport updates for future schedules to remove the future flag first.", "Begin New Payroll Period", 1, 1, 1);
            return false;
        }
        */
        
        return true;
    }
    
    /**
     * Gets the corresponding SAP_CODE for the given Extra Payment description
     * 
     * @param recordList
     * @param codeDescription
     * @return String SAP_CODE
     */
    public static String getExtSapCodeFromDescription(ArrayList<ExtraPaymentCodeRecord> recordList, String codeDescription)
    {
        String output = "NONE";
        for (int i = 0; i < recordList.size(); i++)
        {
            if (Misc.objectEquals(codeDescription, recordList.get(i).getDescriptionErec()))
            {
                output = recordList.get(i).getCodeErec();
                break;
            }
        }
        return output;
    }
    
    /**
     * Gets the corresponding AMOUNT_TYPE for the given Extra Payment description
     * 
     * @param recordList
     * @param codeDescription
     * @return String SAP_CODE
     */
    public static String getExtAmountTypeFromDescription(ArrayList<ExtraPaymentCodeRecord> recordList, String codeDescription)
    {
        String output = "H";
        for (int i = 0; i < recordList.size(); i++)
        {
            if (Misc.objectEquals(codeDescription, recordList.get(i).getDescriptionErec()))
            {
                output = recordList.get(i).getAmountTypeErec();
                break;
            }
        }
        return output;
    }
    
    /**
     * Gets the corresponding SAP_CODE for the given Attendance description
     * 
     * @param recordList
     * @param codeDescription
     * @return String SAP_CODE
     */
    public static String getAttSapCodeFromDescription(ArrayList<AttendanceCodeRecord> recordList, String codeDescription)
    {
        String output = "NONE";
        for (int i = 0; i < recordList.size(); i++)
        {
            if (Misc.objectEquals(codeDescription, recordList.get(i).getDescriptionArec()))
            {
                output = recordList.get(i).getSapCodeArec();
                break;
            }
        }
        return output;
    }
    
    /**
     * Gets the corresponding SAP_CODE for the given Absence description
     * 
     * @param recordList
     * @param codeDescription
     * @return String SAP_CODE
     */
    public static String getAbsSapCodeFromDescription(ArrayList<AbsenceCodeRecord> recordList, String codeDescription)
    {
        String output = "NONE";
        for (int i = 0; i < recordList.size(); i++)
        {
            if (Misc.objectEquals(codeDescription, recordList.get(i).getDescription()))
            {
                output = recordList.get(i).getSapCode();
                break;
            }
        }
        return output;
    }
    
    /**
     * Attempts to validate activity allocations for the previous 2 months for the given site
     * 
     * @param parentFrame
     * @param feeder
     * @param site
     * @return CustomTableModel errorData
     */
    public static CustomTableModel validateAllocations(Component parentFrame, String feeder, String site)
    {
        // Create a Panel and Dialog frame
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(300, 75));

        JLabel messageLabel = new JLabel("This may take a few minutes, please wait.");
        messageLabel.setPreferredSize(new Dimension(300, 30));
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);

        panel.add(messageLabel);
        panel.add(progressBar);

        final JDialog frame = new JDialog((Frame)parentFrame, "Validating Allocations", true);
        frame.setResizable(false);

        // Display the Dialog frame (on the EDT)
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                frame.getContentPane().add(panel);
                frame.pack();

                GraphicsConfiguration gc = parentFrame.getGraphicsConfiguration();
                Rectangle bounds = frame.getGraphicsConfiguration().getBounds();
                int center_x = bounds.x + bounds.width / 2;
                int center_y = bounds.y + bounds.height / 2;
                frame.setLocation(center_x - frame.getWidth() / 2, center_y - frame.getHeight() / 2);
                frame.setVisible(true);
            }
        });

        // Attempt to validate records
        CustomTableModel errorData = CFAS_Validation.validate(parentFrame, feeder, site, UserData.getUUID());
        
        // Close the dialog frame
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                frame.dispose();
            }
        });
        
        // If there are any errors, return them to open ValidationErrors; else notify the user that all records validated and return null
        boolean containsErrors = false;
        if (errorData != null && errorData.getRowCount() > 0)
        {
            containsErrors = true;
        }
        if (containsErrors)
        {
            return errorData;
        }
        else
        {
            Misc.msgbox(parentFrame, "All Validations Completed Successfully", "Validating Allocations", 1, 1, 1);
            return null;
        }
    }
}
