package tvicore.dao;

import java.util.Date;
import tvicore.miscellaneous.Misc;

public class HolidayRecord
{
    private Date holiday;
    private String holidayType;
    private String holidayName;
    
    public HolidayRecord(Date holiday, String holidayType, String holidayName)
    {
        this.holiday = holiday;
        this.holidayType = holidayType;
        this.holidayName = holidayName;
    }
    
    public Date getHoliday()       { return new Date(holiday.getTime()); }
    public String getHolidayType() { return holidayType; }
    public String getHolidayName() { return Misc.objectToString(holidayName); }
    public void setHoliday(Date value)       { holiday = value; }
    public void setHolidayType(String value) { holidayType = value; }
    public void setHolidayName(String value) { holidayName = value; }
}