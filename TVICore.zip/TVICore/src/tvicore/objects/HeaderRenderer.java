package tvicore.objects;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

public class HeaderRenderer implements TableCellRenderer
{
    DefaultTableCellRenderer renderer;
    boolean boldText;
    
    public HeaderRenderer(JTable table, boolean center, boolean bold, Color color)
    {
        boldText = bold;
        if (color != null)
        {
            renderer = new DefaultTableCellRenderer();
            renderer.setBackground(color);
        }
        else
        {
            renderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
        }
        renderer.setVerticalAlignment(JLabel.BOTTOM);
        if (center)
        {
            renderer.setHorizontalAlignment(JLabel.CENTER);//only centers first line, still need to use html for multiline...
        }
        else
        {
            renderer.setHorizontalAlignment(JLabel.LEFT);
        }
    }
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col)
    {
        Component comp = renderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
        if (boldText)
        {
            comp.setFont(comp.getFont().deriveFont(Font.BOLD));
        }
        return comp;
    }
}
