package tvicore.objects;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.TransferHandler;
import tvicore.miscellaneous.Misc;

public class ListTransferHandler extends TransferHandler
{
    JList source = null;
    JList<String> target = null;
    private int[] indices = null;
    
    @Override
    public boolean canImport(TransferHandler.TransferSupport info)
    {
        info.setShowDropLocation(false);
        return info.isDataFlavorSupported(DataFlavor.stringFlavor);
    }
    
    @Override
    protected Transferable createTransferable(JComponent c)
    {
        source = (JList)c;
        indices = source.getSelectedIndices();
        List values = source.getSelectedValuesList();
        
        StringBuilder buff = new StringBuilder();
        for (int i = 0; i < values.size(); i++)
        {
            Object val = values.get(i);
            buff.append(val == null ? "" : val.toString());
            if (i != values.size() - 1)
            {
                buff.append("\n");
            }
        }
        
        return new StringSelection(buff.toString());
    }
    
    @Override
    public int getSourceActions(JComponent c)
    {
        return TransferHandler.MOVE;
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public boolean importData(TransferHandler.TransferSupport info)
    {
        if (!info.isDrop())
        {
            return false;
        }
        
        target = (JList<String>)info.getComponent();
        
        if (source.equals(target)) // no data is being moved
        {
            return false;
        }
        
        // Get the string that is being dropped.
        String data;
        try
        {
            data = (String)info.getTransferable().getTransferData(DataFlavor.stringFlavor);
        }
        catch (UnsupportedFlavorException | IOException e)
        {
            return false;
        }
        
        DefaultListModel<String> listModel = (DefaultListModel<String>)target.getModel();
        
        String[] values = data.split("\n");
        for (String value : values)
        {
            listModel.addElement(value);
        }
        Misc.sortListModel(listModel);
        return true;
    }
    
    @Override
    protected void exportDone(JComponent c, Transferable data, int action)
    {
        if (source.equals(target)) // no data is being moved
        {
            return;
        }
        
        DefaultListModel sourceData = (DefaultListModel)source.getModel();
        
        if (action == TransferHandler.MOVE)
        {
            for (int i = indices.length - 1; i >= 0; i--)
            {
                sourceData.remove(indices[i]);
            }
        }
        indices = null;
    }
}
