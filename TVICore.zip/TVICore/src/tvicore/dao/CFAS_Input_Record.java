package tvicore.dao;

public class CFAS_Input_Record
{
    private final String p_return_after_one_error = "false";
    private final String p_transaction_source = "LABOR-TVI";
    private final String p_transaction_type = "PLANT LBR"; // "ENGRG LBR" for 3XXX employees, "PLANT LBR" for 4XXX employees - we only have 4XXX emps
    private String p_transaction_date = "";
    private String p_accounting_period = "";
    private String p_location_code = "";
    private String p_rco = "";
    private String p_rcc = "";
    private String p_frc = "";
    private String p_function_code = "";
    private String p_ca_activity_code = "";
    private String p_project_number = "";
    private String p_expenditure_item_date = "";
    private final String p_xc = "CYD";
    private String p_hrs_quantity = "";
    private final String p_user_transaction_source = "LABOR-TVI";
    private final String p_sbc_uid;
    private final String p_user_je_category_name = "Labor";
    private final String p_categories = "Labor";
    
    public CFAS_Input_Record(String transaction_date, String accounting_period, String location_code, String rco, String rcc, String frc, String function_code,
                             String ca_activity_code, String project_number, String expenditure_item_date, String hrs_quantity, String sbc_uid)
    {
        this.p_transaction_date = transaction_date;
        this.p_accounting_period = accounting_period;
        this.p_location_code = location_code;
        this.p_rco = rco;
        this.p_rcc = rcc;
        this.p_frc = frc;
        this.p_function_code = function_code;
        this.p_ca_activity_code = ca_activity_code;
        this.p_project_number = project_number;
        this.p_expenditure_item_date = expenditure_item_date;
        this.p_hrs_quantity = hrs_quantity;
        this.p_sbc_uid = sbc_uid;
    }
}
