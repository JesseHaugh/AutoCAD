package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.resources.Resources;

public final class TimeReportingByEmployee extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile TimeReportingByEmployee instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    TableRowSorter<CustomTableModel> sorter;
    
    final static int idx_EMPID    = 0;
    final static int idx_EMPLOYEE = 1;
    final static int idx_LASTDATE = 2;
    final static int idx_MU       = 3;
    
    Date curDate;
    int daysBack = 30;
    
    public synchronized static TimeReportingByEmployee getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new TimeReportingByEmployee(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private TimeReportingByEmployee(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        UIManager.put("TitledBorder.border", new LineBorder(new Color(150, 150, 150), 1));
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        
        Oracle.setupPickEndDate(getFormComponent(), pickDate, RegionData.getPayCycle(), RegionData.getNextPayClose(), 52);
        
        filterTextField.getDocument().addDocumentListener(new DocumentListener()
        {
            @Override public void insertUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void removeUpdate(DocumentEvent e)  { processFilter(); }
            @Override public void changedUpdate(DocumentEvent e) { processFilter(); }
        });
        
        curDate = Misc.dateNoTime(Oracle.getCurTimeLocal(getFormComponent()));
        last30DaysButton.setSelected(true);
        
        filterTextField.requestFocusInWindow();
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    last30DaysButton.setEnabled(false);
                    last365DaysButton.setEnabled(false);
                    retrieveButton.setEnabled(false);
                    employeesScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "AT&T ID",           // idx_EMPID
                "Employee",          // idx_EMPLOYEE
                "Last Report Date",  // idx_LASTDATE
                "MU"                 // idx_MU
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsCurrentEmployees(getFormComponent(), feeder, site, Misc.dateAddDays(curDate, daysBack * -1));
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("EMPID"),       // idx_EMPID
                    rs.getString("EMPLOYEE"),    // idx_EMPLOYEE
                    rs.getDate("LASTDATE"),      // idx_LASTDATE
                    rs.getString("MU")           // idx_MU
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading time reporting by employee data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
                last30DaysButton.setEnabled(true);
                last365DaysButton.setEnabled(true);
                retrieveButton.setEnabled(true);
                employeesScrollPane.setViewportView(table);
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }

                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_LASTDATE:
                            return Date.class;
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_MU:
                        default:
                            return String.class;
                    }
                }
            };
            
            table.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        openDetail();
                    }
                }
            });
        }
        
        private void configureTable()
        {
            Misc.configureTable(table, true, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_EMPID, 80);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 160, Constants.LEFT);
            Misc.setColumnSettings(table, idx_LASTDATE, 110);
            Misc.setColumnSettings(table, idx_MU, 70);
            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);
            processFilter();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        selectEmployeeLabel = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        bodyPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        employeeOptionsPanel = new javax.swing.JPanel();
        last30DaysButton = new javax.swing.JRadioButton();
        last365DaysButton = new javax.swing.JRadioButton();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        filterTextLabel = new javax.swing.JLabel();
        filterTextField = new javax.swing.JTextField();
        retrieveButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        employeesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Time Reporting by Employee");
        setBackground(new java.awt.Color(255, 204, 153));
        setMinimumSize(new java.awt.Dimension(850, 500));
        setPreferredSize(new java.awt.Dimension(900, 600));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(255, 204, 153));
        topPanel.setMinimumSize(new java.awt.Dimension(650, 80));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(255, 204, 153));
        titlePanel.setMinimumSize(new java.awt.Dimension(660, 80));
        titlePanel.setPreferredSize(new java.awt.Dimension(800, 80));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(255, 204, 153));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("TIME REPORTING BY EMPLOYEE");
        titleLabel.setMaximumSize(new java.awt.Dimension(300, 30));
        titleLabel.setMinimumSize(new java.awt.Dimension(300, 30));
        titleLabel.setPreferredSize(new java.awt.Dimension(300, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        selectEmployeeLabel.setText("Select Employee");
        selectEmployeeLabel.setMaximumSize(new java.awt.Dimension(80, 20));
        selectEmployeeLabel.setMinimumSize(new java.awt.Dimension(80, 20));
        selectEmployeeLabel.setPreferredSize(new java.awt.Dimension(80, 20));
        titlePanel.add(selectEmployeeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, -1, -1));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(255, 204, 153));
        centerPanel.setMinimumSize(new java.awt.Dimension(790, 300));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        bodyPanel.setBackground(new java.awt.Color(255, 204, 153));
        bodyPanel.setMinimumSize(new java.awt.Dimension(790, 260));
        bodyPanel.setLayout(new javax.swing.BoxLayout(bodyPanel, javax.swing.BoxLayout.LINE_AXIS));

        leftPanel.setBackground(new java.awt.Color(255, 204, 153));
        leftPanel.setMaximumSize(new java.awt.Dimension(350, 1600));
        leftPanel.setMinimumSize(new java.awt.Dimension(350, 260));
        leftPanel.setPreferredSize(new java.awt.Dimension(380, 500));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        employeeOptionsPanel.setBackground(new java.awt.Color(255, 204, 153));
        employeeOptionsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Options for List of Employees"));
        employeeOptionsPanel.setToolTipText("");
        employeeOptionsPanel.setName(""); // NOI18N
        employeeOptionsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        last30DaysButton.setBackground(new java.awt.Color(255, 204, 153));
        buttonGroup1.add(last30DaysButton);
        last30DaysButton.setText("Last 30 Days");
        last30DaysButton.setFocusable(false);
        last30DaysButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                last30DaysButtonActionPerformed(evt);
            }
        });
        employeeOptionsPanel.add(last30DaysButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        last365DaysButton.setBackground(new java.awt.Color(255, 204, 153));
        buttonGroup1.add(last365DaysButton);
        last365DaysButton.setText("Last Year");
        last365DaysButton.setFocusable(false);
        last365DaysButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                last365DaysButtonActionPerformed(evt);
            }
        });
        employeeOptionsPanel.add(last365DaysButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        leftPanel.add(employeeOptionsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 160, 70));

        pickDateLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pickDateLabel.setText("Payroll Ending Date:");
        pickDateLabel.setMaximumSize(new java.awt.Dimension(130, 20));
        pickDateLabel.setMinimumSize(new java.awt.Dimension(130, 20));
        pickDateLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        leftPanel.add(pickDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        pickDate.setMinimumSize(new java.awt.Dimension(170, 20));
        pickDate.setPreferredSize(new java.awt.Dimension(170, 30));
        leftPanel.add(pickDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, -1, -1));

        filterTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterTextLabel.setText("Filter by text:");
        filterTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        leftPanel.add(filterTextLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        filterTextField.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextField.setMaximumSize(new java.awt.Dimension(150, 30));
        filterTextField.setMinimumSize(new java.awt.Dimension(150, 30));
        filterTextField.setPreferredSize(new java.awt.Dimension(150, 30));
        leftPanel.add(filterTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        retrieveButton.setBackground(new java.awt.Color(255, 204, 153));
        retrieveButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        retrieveButton.setText("Retrieve Data");
        retrieveButton.setMaximumSize(new java.awt.Dimension(130, 30));
        retrieveButton.setMinimumSize(new java.awt.Dimension(130, 30));
        retrieveButton.setPreferredSize(new java.awt.Dimension(130, 30));
        retrieveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retrieveButtonActionPerformed(evt);
            }
        });
        leftPanel.add(retrieveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, -1, -1));

        exitButton.setBackground(new java.awt.Color(255, 204, 153));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setMaximumSize(new java.awt.Dimension(130, 30));
        exitButton.setMinimumSize(new java.awt.Dimension(130, 30));
        exitButton.setPreferredSize(new java.awt.Dimension(130, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        leftPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, -1, -1));

        bodyPanel.add(leftPanel);

        employeesScrollPane.setAlignmentY(0.0F);
        employeesScrollPane.setFocusable(false);
        employeesScrollPane.setMaximumSize(new java.awt.Dimension(440, 500));
        employeesScrollPane.setMinimumSize(new java.awt.Dimension(440, 20));
        employeesScrollPane.setPreferredSize(new java.awt.Dimension(440, 500));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        employeesScrollPane.setViewportView(loadingLabel);

        bodyPanel.add(employeesScrollPane);

        centerPanel.add(bodyPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(255, 204, 153));
        bottomPanel.setPreferredSize(new java.awt.Dimension(900, 40));
        bottomPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void retrieveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retrieveButtonActionPerformed
        openDetail();
    }//GEN-LAST:event_retrieveButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void last30DaysButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_last30DaysButtonActionPerformed
        daysBack = 30;
        refreshData();
    }//GEN-LAST:event_last30DaysButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        filterTextField.requestFocusInWindow();
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void last365DaysButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_last365DaysButtonActionPerformed
        daysBack = 365;
        refreshData();
    }//GEN-LAST:event_last365DaysButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exitButtonActionPerformed
    {//GEN-HEADEREND:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed
    
    private void processFilter()
    {
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> textFilter;
        RowFilter<CustomTableModel, Object> dateFilter = null;
        RowFilter<CustomTableModel, Object> inputFilter;
        
        try
        {
            textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
            
            if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
            {
                dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
            }
            
            inputFilters.add(textFilter);
            if (dateFilter != null)
            {
                inputFilters.add(dateFilter);
            }
            inputFilter = RowFilter.orFilter(inputFilters);
            
            filters.add(inputFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
        }
    }
    
    private void openDetail()
    {
        int selectedRow = table.getSelectedRow();
        Date selectedDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select an employee from the list.", "", 1, 1, 1);
        }
        else if (selectedDate == null)
        {
            Misc.msgbox(getFormComponent(), "You must select a payroll ending date.", "", 1, 1, 1);
        }
        else
        {
            String empid = table.getValueAt(selectedRow, idx_EMPID).toString();
            String mu = table.getValueAt(selectedRow, idx_MU).toString();
            Date endDate = selectedDate;
            Date startDate;
            if (Arrays.asList("CZE", "POL", "SVK").contains(feeder))
            {
                startDate = Oracle.getPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
            }
            else
            {
                startDate = Oracle.getPreviousPayrollStartDate(getFormComponent(), RegionData.getPayCycle(), endDate);
            }
            Date lastDate = (Date) table.getValueAt(selectedRow, idx_LASTDATE);
            String union = Oracle.getUnionFlag(getFormComponent(), feeder, site, mu, empid, lastDate, 28);
            
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, empid, startDate, endDate, union, "BYEMPLOYEE");
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bodyPanel;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JPanel employeeOptionsPanel;
    private javax.swing.JScrollPane employeesScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JTextField filterTextField;
    private javax.swing.JLabel filterTextLabel;
    private javax.swing.JRadioButton last30DaysButton;
    private javax.swing.JRadioButton last365DaysButton;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JButton retrieveButton;
    private javax.swing.JLabel selectEmployeeLabel;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
