package tvicore.objects;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;

public final class CalendarCell extends JPanel
{
    public final String day;
    public final String text;
    public final boolean inCurMonth;
    
    /**
    *  Create a Panel to display a day in the Calendar table.
    *
    *  @param day
    *  @param text
    *  @param inCurMonth
    */
    public CalendarCell(String day, String text, boolean inCurMonth)
    {
        this.day = day;
        this.text = text;
        this.inCurMonth = inCurMonth;
        
        this.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        
        createPanel();
    }
    
    private void createPanel()
    {
        this.setPreferredSize(new Dimension(100, 80));
        
        Color textColor;
        if (inCurMonth)
        {
            textColor = new Color(0, 0, 0);
        }
        else
        {
            textColor = new Color(200, 200, 200);
        }
        
        // Day
        JLabel dayLabel = new JLabel();
        dayLabel.setText(day);
        dayLabel.setPreferredSize(new Dimension(96, 16));
        dayLabel.setFont(new Font("Tahoma", java.awt.Font.PLAIN, 11));
        dayLabel.setForeground(textColor);
        
        // Text
        JTextField textField = new JTextField();
        textField.setText(text);
        textField.setPreferredSize(new Dimension(100, 72));
        textField.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        textField.setFont(new Font("Tahoma", java.awt.Font.BOLD, 36));
        textField.setForeground(textColor);
        
        this.add(dayLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 4, -1, -1));
        this.add(textField, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
    }
}
