package tvi.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportOptions extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = false;
    
    private static volatile ImportOptions instance;
    
    private final String feeder;
    private final String site;
    
    JTable table = new JTable();
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    final static int idx_MU                  = 0;
    final static int idx_AUTO_IMPORT         = 1;
    final static int idx_SKIP_REVIEW_UPDATES = 2;
    
    ArrayList<Integer> musChanged = new ArrayList<>();
    
    Calendar cal = Calendar.getInstance();
    
    Date lastStartDate;
    Date thisStartDate;
    Date nextStartDate;
    Date afterNextStartDate;
    
    Date lastEndDate;
    Date thisEndDate;
    Date nextEndDate;
    Date afterNextEndDate;
    
    public synchronized static ImportOptions getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportOptions(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportOptions(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        musChanged.clear();
    }
    
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    muScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",                                     // idx_MU
                "Auto Import",                            // idx_AUTO_IMPORT
                Misc.centerHTML("Skip<br>Review Updates") // idx_SKIP_REVIEW_UPDATES
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsImportOptions(getFormComponent(), feeder, site);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here.
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU"),                                       // idx_MU
                    Misc.oracleToBoolean(rs.getObject("AUTO_IMPORT")),        // idx_AUTO_IMPORT
                    Misc.oracleToBoolean(rs.getObject("SKIP_REVIEW_UPDATES")) // idx_SKIP_REVIEW_UPDATES
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading import options.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                muScrollPane.setViewportView(table);
                if (table.getRowCount() > 0)
                {
                    table.changeSelection(0, 0, false, false);
                }
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return !UserData.getUserAccessLevel().equals("READONLY") && column != idx_MU;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_AUTO_IMPORT:
                        case idx_SKIP_REVIEW_UPDATES:
                            return Boolean.class;
                        case idx_MU:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            Action muAction = new AbstractAction()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    if (!musChanged.contains(table.getSelectedRow()))
                    {
                        musChanged.add(table.getSelectedRow());
                    }
                }
            };
            table.addPropertyChangeListener(new TableCellListener(table, muAction));
            Misc.configureTable(table, false, false, false);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_MU, 100);
            Misc.setColumnSettings(table, idx_AUTO_IMPORT, 120, false);
            Misc.setColumnSettings(table, idx_SKIP_REVIEW_UPDATES, 120, false);
            table.setRowHeight(20);
            table.setFocusable(false);
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        // Save weekend importing rules
        if (!musChanged.isEmpty())
        {
            loadingLabel.setText("Saving Changes...");
            muScrollPane.setViewportView(loadingLabel);
            validate();
        }
        for (int row : musChanged)
        {
            Oracle.updateImportingOptions
            (
                getFormComponent(),
                feeder,
                site,
                table.getValueAt(row, idx_MU).toString(),
                (Boolean) table.getValueAt(row, idx_AUTO_IMPORT),
                (Boolean) table.getValueAt(row, idx_SKIP_REVIEW_UPDATES)
            );
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        reportSelectionGroup = new javax.swing.ButtonGroup();
        topPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        subtitltePanel = new javax.swing.JPanel();
        autoImportLabel = new javax.swing.JLabel();
        skipReviewUpdatesLabel = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        descriptionLabel1 = new javax.swing.JLabel();
        descriptionLabel2 = new javax.swing.JLabel();
        descriptionLabel3 = new javax.swing.JLabel();
        descriptionLabel4 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        muPanel = new javax.swing.JPanel();
        muScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        exitPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Import Options");
        setMinimumSize(new java.awt.Dimension(700, 580));
        setPreferredSize(new java.awt.Dimension(600, 580));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(120, 200, 200));
        topPanel.setMinimumSize(new java.awt.Dimension(100, 80));
        topPanel.setPreferredSize(new java.awt.Dimension(100, 170));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 20));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Import Options");
        titleLabel.setToolTipText("");
        titleLabel.setPreferredSize(new java.awt.Dimension(400, 30));
        topPanel.add(titleLabel);

        subtitltePanel.setBackground(new java.awt.Color(120, 200, 200));
        subtitltePanel.setMinimumSize(new java.awt.Dimension(1200, 80));
        subtitltePanel.setPreferredSize(new java.awt.Dimension(600, 100));
        subtitltePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        autoImportLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        autoImportLabel.setText("Auto Import");
        autoImportLabel.setPreferredSize(new java.awt.Dimension(150, 15));
        subtitltePanel.add(autoImportLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, -1, -1));

        skipReviewUpdatesLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        skipReviewUpdatesLabel.setText("Skip Review Updates");
        skipReviewUpdatesLabel.setPreferredSize(new java.awt.Dimension(150, 15));
        subtitltePanel.add(skipReviewUpdatesLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        jSeparator1.setBackground(new java.awt.Color(120, 200, 200));
        jSeparator1.setForeground(new java.awt.Color(100, 100, 100));
        subtitltePanel.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 53, 600, 5));

        descriptionLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        descriptionLabel1.setText("Yesterday, Today, and Tomorrow will be imported every morning");
        descriptionLabel1.setPreferredSize(new java.awt.Dimension(450, 15));
        subtitltePanel.add(descriptionLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, -1, -1));

        descriptionLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        descriptionLabel2.setText("These imports will be UPDATES for any schedules that already exist.");
        descriptionLabel2.setPreferredSize(new java.awt.Dimension(450, 15));
        subtitltePanel.add(descriptionLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 35, -1, -1));

        descriptionLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        descriptionLabel3.setText("Imported updates will no longer load with status of 'Updated'");
        descriptionLabel3.setPreferredSize(new java.awt.Dimension(450, 15));
        subtitltePanel.add(descriptionLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        descriptionLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        descriptionLabel4.setText("Updated records will load with a \"Ready\" or \"Not Ready\" status instead.");
        descriptionLabel4.setPreferredSize(new java.awt.Dimension(450, 15));
        subtitltePanel.add(descriptionLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, -1, 20));

        topPanel.add(subtitltePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(120, 200, 200));
        centerPanel.setMinimumSize(new java.awt.Dimension(600, 290));
        centerPanel.setPreferredSize(new java.awt.Dimension(600, 290));
        centerPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 10));

        muPanel.setBackground(new java.awt.Color(120, 200, 200));
        muPanel.setPreferredSize(new java.awt.Dimension(360, 280));
        muPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        muScrollPane.setFocusable(false);
        muScrollPane.setPreferredSize(new java.awt.Dimension(360, 260));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        muScrollPane.setViewportView(loadingLabel);

        muPanel.add(muScrollPane);

        centerPanel.add(muPanel);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        exitPanel.setBackground(new java.awt.Color(120, 200, 200));
        exitPanel.setMinimumSize(new java.awt.Dimension(100, 100));
        exitPanel.setPreferredSize(new java.awt.Dimension(100, 100));
        exitPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 20));

        exitButton.setBackground(new java.awt.Color(120, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        exitButton.setText("Close");
        exitButton.setPreferredSize(new java.awt.Dimension(150, 60));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        exitPanel.add(exitButton);

        getContentPane().add(exitPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel autoImportLabel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JLabel descriptionLabel1;
    private javax.swing.JLabel descriptionLabel2;
    private javax.swing.JLabel descriptionLabel3;
    private javax.swing.JLabel descriptionLabel4;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JPanel muPanel;
    private javax.swing.JScrollPane muScrollPane;
    private javax.swing.ButtonGroup reportSelectionGroup;
    private javax.swing.JLabel skipReviewUpdatesLabel;
    private javax.swing.JPanel subtitltePanel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}