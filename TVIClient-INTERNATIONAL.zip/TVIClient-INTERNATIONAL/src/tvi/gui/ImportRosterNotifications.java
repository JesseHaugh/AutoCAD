/**
 * This form can be opened in several different ways.
 *   These are determined by the string editType, which can be the following values:
 *     NORMAL           - Displays all employees by feeder & site
 *     DETAIL           - Displays a detailed view on a single employee, set by passing a non-null attid value in the constructor
 */

package tvi.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ProgressMonitor;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableCellListener;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class ImportRosterNotifications extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile ImportRosterNotifications instance;
    
    private final String feeder;
    private final String site;
    private final String mu;
    private final Date reportingDate;
    private final String union;
    String attid;
    String editType;
    
    JTable table;
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    boolean formClosing = false;
    boolean changingEmployees = false;
    
    ProgressMonitor progressMonitor;
    boolean proceed = true;
    boolean cancel = false;
    
    boolean employeeUpdated = false;
    int currentRow = -1;
    int employeeCount = 0;
    
    boolean filterEnabled = true;
    int filterColumn = -1;
    String importStatusFilterText = "false";
    boolean filterCoachDiscrepancies = false;
    TableRowSorter<CustomTableModel> sorter;
    
        JComboBox<String> doNotImportCombo = new JComboBox<String>()
    {
        @Override //Override the default actionPerformed to prevent bug where edited values aren't saved when the mouse is clicked in some empty area within the containing JScrollPane
        public void actionPerformed(ActionEvent e)
        {
            Object source = e.getSource();
            if (source instanceof DefaultCellEditor)
            {
                e = new ActionEvent(getEditor(), e.getID(), e.getActionCommand());
            }
            super.actionPerformed(e);
        }
    };
        
    final static int idx_FEEDER                 = 0;
    final static int idx_SITE                   = 1;
    final static int idx_MU                     = 2;
    final static int idx_EMPID                  = 3;
    final static int idx_AGENTID                = 4;
    final static int idx_EMPLOYEE               = 5;
    final static int idx_REPORTING_DATE         = 6;
    final static int idx_DO_NOT_IMPORT          = 7;
    final static int idx_PROGRAM_START          = 8;
    final static int idx_PROGRAM_STOP           = 9;
    final static int idx_LOAD_STATUS            = 10;
    final static int idx_ERROR_TEXT             = 11;
    final static int idx_ERROR_STEPS_TO_CORRECT = 12;
    final static int idx_TVI_USER               = 13;
    
    public synchronized static ImportRosterNotifications getInstance(Component parentFrame, String feeder, String site, String mu, Date reportingDate, String union, String attid, String editType)
    {
        if (instance != null)
        {
            if (Misc.objectEquals(instance.attid, attid))
            {
                instance.toFront();
            }
            else
            {
                instance.closeForm();
            }
        }
        
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ImportRosterNotifications(feeder, site, mu, reportingDate, union, attid, editType);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ImportRosterNotifications(String feeder, String site, String mu, Date reportingDate, String union, String attid, String editType)
    {
        this.feeder = feeder;
        this.site = site;
        this.mu = mu;
        this.reportingDate = reportingDate;
        this.union = union;
        this.attid = attid;
        this.editType = editType;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());

        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        mULabel.setText("MU: " + mu);
        reportingDateLabel.setText("Date: " + reportingDate);
        subtitleLabel2.setText("The employees below WERE NOT IMPORTED. To import these employees, follow the Steps to Correct or contact TVI support at " + Constants.EMAIL);
        
        doNotImportCombo.setModel(new DefaultComboBoxModel<>(new String[] {"false", "true"}));
        doNotImportCombo.addItemListener(new ItemListener()
        {
            Object previousSelection = null;
            
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1)
                {
                    if (e.getStateChange() == ItemEvent.DESELECTED)
                    {
                        previousSelection = e.getItem();
                    }
                }
            }
        });
        
        doNotImportCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "true", "false"}));
    }
    
    public String getATTID()
    {
        return attid;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        mULabel = new javax.swing.JLabel();
        reportingDateLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        subtitleLabel2 = new javax.swing.JLabel();
        centerPanel = new javax.swing.JPanel();
        employeesScrollPane = new javax.swing.JScrollPane();
        loadingLabel = new javax.swing.JLabel();
        bottomPanel = new javax.swing.JPanel();
        bottomControls = new javax.swing.JPanel();
        filterLabelsPanel = new javax.swing.JPanel();
        filterColumnTextLabel = new javax.swing.JLabel();
        filterTextLabel = new javax.swing.JLabel();
        filterEmployeeStatusLabel = new javax.swing.JLabel();
        filterClearLabel = new javax.swing.JLabel();
        filterClearLabel1 = new javax.swing.JLabel();
        filterClearLabel2 = new javax.swing.JLabel();
        filtersPanel = new javax.swing.JPanel();
        filterColumnComboBox = new javax.swing.JComboBox<>();
        filterTextField = new javax.swing.JTextField();
        filterDoNotImportComboBox = new javax.swing.JComboBox<>();
        filterClearButton = new javax.swing.JButton();
        employeeHistoryButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Import Notifications");
        setBackground(new java.awt.Color(255, 255, 128));
        setMinimumSize(new java.awt.Dimension(950, 610));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        topPanel.setBackground(new java.awt.Color(255, 255, 128));
        topPanel.setMinimumSize(new java.awt.Dimension(900, 90));
        topPanel.setPreferredSize(new java.awt.Dimension(900, 90));
        topPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        titlePanel.setBackground(new java.awt.Color(255, 255, 128));
        titlePanel.setMinimumSize(new java.awt.Dimension(950, 90));
        titlePanel.setName(""); // NOI18N
        titlePanel.setPreferredSize(new java.awt.Dimension(950, 90));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(255, 255, 128));
        feederSitePanel.setMinimumSize(new java.awt.Dimension(100, 72));
        feederSitePanel.setPreferredSize(new java.awt.Dimension(100, 72));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 70, -1));

        mULabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        mULabel.setText("  MU: ");
        feederSitePanel.add(mULabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 80, -1));

        reportingDateLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        reportingDateLabel.setText("Date: ");
        feederSitePanel.add(reportingDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 140, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 280, 50));

        exitButton.setBackground(new java.awt.Color(255, 255, 128));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(100, 40));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Import Notifications");
        titleLabel.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 950, -1));

        subtitleLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        subtitleLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subtitleLabel2.setText("The employees below WERE NOT IMPORTED. To import these employees, follow the Steps to Correct or contact TVI support at [EMAIL]");
        subtitleLabel2.setPreferredSize(new java.awt.Dimension(180, 30));
        titlePanel.add(subtitleLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 950, 20));

        topPanel.add(titlePanel);

        getContentPane().add(topPanel, java.awt.BorderLayout.PAGE_START);

        centerPanel.setBackground(new java.awt.Color(255, 255, 128));
        centerPanel.setMaximumSize(new java.awt.Dimension(950, 460));
        centerPanel.setMinimumSize(new java.awt.Dimension(950, 20));
        centerPanel.setPreferredSize(new java.awt.Dimension(950, 200));
        centerPanel.setLayout(new javax.swing.BoxLayout(centerPanel, javax.swing.BoxLayout.Y_AXIS));

        employeesScrollPane.setAlignmentY(0.0F);
        employeesScrollPane.setMaximumSize(new java.awt.Dimension(900, 460));
        employeesScrollPane.setMinimumSize(new java.awt.Dimension(590, 20));
        employeesScrollPane.setPreferredSize(new java.awt.Dimension(590, 200));

        loadingLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loadingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingLabel.setText("LOADING...");
        loadingLabel.setPreferredSize(new java.awt.Dimension(207, 25));
        employeesScrollPane.setViewportView(loadingLabel);

        centerPanel.add(employeesScrollPane);

        getContentPane().add(centerPanel, java.awt.BorderLayout.CENTER);

        bottomPanel.setBackground(new java.awt.Color(255, 255, 128));
        bottomPanel.setMinimumSize(new java.awt.Dimension(950, 200));
        bottomPanel.setPreferredSize(new java.awt.Dimension(950, 200));
        bottomPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        bottomControls.setBackground(new java.awt.Color(255, 255, 128));
        bottomControls.setMinimumSize(new java.awt.Dimension(950, 150));
        bottomControls.setPreferredSize(new java.awt.Dimension(950, 150));

        filterLabelsPanel.setBackground(new java.awt.Color(255, 255, 128));
        filterLabelsPanel.setMinimumSize(new java.awt.Dimension(950, 50));
        filterLabelsPanel.setPreferredSize(new java.awt.Dimension(950, 50));
        filterLabelsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 5));

        filterColumnTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterColumnTextLabel.setText("Column to search:");
        filterColumnTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterColumnTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterColumnTextLabel);

        filterTextLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterTextLabel.setText("Filter by text:");
        filterTextLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterTextLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterTextLabel);

        filterEmployeeStatusLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterEmployeeStatusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterEmployeeStatusLabel.setText("Import Status:");
        filterEmployeeStatusLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        filterEmployeeStatusLabel.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterEmployeeStatusLabel);

        filterClearLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel.setPreferredSize(new java.awt.Dimension(120, 30));
        filterLabelsPanel.add(filterClearLabel);

        filterClearLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel1.setPreferredSize(new java.awt.Dimension(150, 30));
        filterLabelsPanel.add(filterClearLabel1);

        filterClearLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterClearLabel2.setPreferredSize(new java.awt.Dimension(120, 30));
        filterLabelsPanel.add(filterClearLabel2);

        bottomControls.add(filterLabelsPanel);

        filtersPanel.setBackground(new java.awt.Color(255, 255, 128));
        filtersPanel.setMinimumSize(new java.awt.Dimension(950, 50));
        filtersPanel.setPreferredSize(new java.awt.Dimension(950, 50));
        filtersPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 0));

        filterColumnComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterColumnComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "FEEDER", "SITE", "MU", "AGENT ID", "AT&T ID", "EMPLOYEE", "REPORTING DATE", "DO NOT IMPORT", "ERROR", "STEPS TO CORRECT" }));
        filterColumnComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterColumnComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterColumnComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterColumnComboBox);

        filterTextField.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterTextField.setMaximumSize(new java.awt.Dimension(150, 30));
        filterTextField.setMinimumSize(new java.awt.Dimension(150, 30));
        filterTextField.setPreferredSize(new java.awt.Dimension(150, 30));
        filtersPanel.add(filterTextField);

        filterDoNotImportComboBox.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterDoNotImportComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Show All", "Set to Import", "Set not to Import" }));
        filterDoNotImportComboBox.setSelectedIndex(1);
        filterDoNotImportComboBox.setMaximumSize(new java.awt.Dimension(150, 30));
        filterDoNotImportComboBox.setMinimumSize(new java.awt.Dimension(150, 30));
        filterDoNotImportComboBox.setPreferredSize(new java.awt.Dimension(150, 30));
        filterDoNotImportComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterDoNotImportComboBoxActionPerformed(evt);
            }
        });
        filtersPanel.add(filterDoNotImportComboBox);

        filterClearButton.setBackground(new java.awt.Color(255, 255, 128));
        filterClearButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        filterClearButton.setText("Clear Filters");
        filterClearButton.setMaximumSize(new java.awt.Dimension(120, 30));
        filterClearButton.setMinimumSize(new java.awt.Dimension(120, 30));
        filterClearButton.setPreferredSize(new java.awt.Dimension(120, 30));
        filterClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filterClearButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(filterClearButton);

        employeeHistoryButton.setBackground(new java.awt.Color(255, 255, 128));
        employeeHistoryButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        employeeHistoryButton.setText("Employee History");
        employeeHistoryButton.setMaximumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setMinimumSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.setPreferredSize(new java.awt.Dimension(150, 30));
        employeeHistoryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                employeeHistoryButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(employeeHistoryButton);

        printButton.setBackground(new java.awt.Color(255, 255, 128));
        printButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printButton.setText("Print");
        printButton.setMaximumSize(new java.awt.Dimension(120, 30));
        printButton.setMinimumSize(new java.awt.Dimension(120, 30));
        printButton.setPreferredSize(new java.awt.Dimension(120, 30));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        filtersPanel.add(printButton);

        bottomControls.add(filtersPanel);

        bottomPanel.add(bottomControls);

        getContentPane().add(bottomPanel, java.awt.BorderLayout.PAGE_END);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        if (editType.equals("Imported"))
        {
            releaseInstance();
            dispose();
        
            Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, "NORMAL", "TVI");
            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, "NORMAL");
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
        }
        else
        {
            closeForm();
        }
    }//GEN-LAST:event_exitButtonActionPerformed
        
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        if (editType.equals("Imported"))
        {
            releaseInstance();
            dispose();
        
            Oracle.setRecordsUnlocked(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, "NORMAL", "TVI");
            Oracle.updateScheduleStatus(getFormComponent(), feeder, site, mu, reportingDate, reportingDate, "NORMAL");
            TimeReporting.getInstance(getFormComponent(), feeder, site, mu, null, reportingDate, reportingDate, union, "NORMAL");
        }
        else
        {
            closeForm();
        }
    }//GEN-LAST:event_formWindowClosing
    
    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened
    
    private void filterColumnComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterColumnComboBoxActionPerformed
        String selection = filterColumnComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "ALL":
                filterColumn = -1;
                break;
            case "FEEDER":
                filterColumn = idx_FEEDER;
                break;
            case "SITE":
                filterColumn = idx_SITE;
                break;
            case "MU":
                filterColumn = idx_MU;
                break;
            case "AGENT ID":
                filterColumn = idx_AGENTID;
                break;
            case "AT&T ID":
                filterColumn = idx_EMPID;
                break;
            case "EMPLOYEE":
                filterColumn = idx_EMPLOYEE;
                break;
            case "REPORTING DATE":
                filterColumn = idx_REPORTING_DATE;
                break;
            case "DO NOT IMPORT":
                filterColumn = idx_DO_NOT_IMPORT;
                break;
            case "ERROR":
                filterColumn = idx_ERROR_TEXT;
                break;
            case "STEPS TO CORRECT":
                filterColumn = idx_ERROR_STEPS_TO_CORRECT;
                break;
            default:
                Misc.msgbox(getFormComponent(), "Unhandled filter selection, contact TVI Support at " + Constants.EMAIL, "Unhandled Exception", 0, 1, 1);
        }
        processFilter();
    }//GEN-LAST:event_filterColumnComboBoxActionPerformed

    private void filterClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterClearButtonActionPerformed
        clearFilter();
        processFilter();
        filterTextField.requestFocusInWindow();
    }//GEN-LAST:event_filterClearButtonActionPerformed
        
    private void employeeHistoryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_employeeHistoryButtonActionPerformed
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1)
        {
            Misc.msgbox(getFormComponent(), "You must select at least one employee.", "MU Roster Maintenance", 1, 1, 1);
            return;
        }
        else
        {
            String empid = Misc.objectToString(table.getValueAt(selectedRow, idx_EMPID));
            if (empid.equals(""))
            {
                Misc.msgbox(getFormComponent(), "You cannot select an employee with a blank AT&T ID.", "MU Roster Maintenance", 1, 1, 1);
                return; 
            }
            else
            {
                EmployeeHistory.getInstance(getFormComponent(), feeder, site, empid);
            }
        }
    }//GEN-LAST:event_employeeHistoryButtonActionPerformed
                
    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        Misc.printTable(getFormComponent(), feeder, site, table, "PORTRAIT", "Import Notifications");
    }//GEN-LAST:event_printButtonActionPerformed

    private void filterDoNotImportComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filterDoNotImportComboBoxActionPerformed
        String selection = filterDoNotImportComboBox.getSelectedItem().toString();
        switch (selection)
        {
            case "Set to Import":
            importStatusFilterText = "false";
            break;
            case "Set not to Import":
            importStatusFilterText = "true";
            break;
            default:
            importStatusFilterText = "";
            break;
        }
        processFilter();
    }//GEN-LAST:event_filterDoNotImportComboBoxActionPerformed
                        
    private void refreshData()
    {
        new Thread(new RefreshTableThread()).start();
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, contact TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (table != null)
                        {
                            if (table.getSelectedRow() != -1)
                            {
                                changeEmployee(0);
                            }
                        }
                    }
                });
            }
            catch (InterruptedException | InvocationTargetException ex) {}
            
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    employeesScrollPane.setViewportView(loadingLabel);
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "FEEDER",                                    // idx_FEEDER
                "SITE",                                      // idx_SITE
                "MU",                                        // idx_MU
                Misc.centerHTML("AT&T<br>ID"),               // idx_EMPID
                Misc.centerHTML("Agent<br>ID"),              // idx_AGENTID
                "Employee",                                  // idx_EMPLOYEE
                Misc.centerHTML("Reporting<br>Date"),        // idx_START_DATE
                Misc.centerHTML("Do Not<br>Import"),         // idx_DO_NOT_IMPORT
                "",                                          // idx_PROGRAM_START
                "",                                          // idx_PROGRAM_STOP
                "",                                          // idx_LOAD_STATUS
                "Issue",                                     // idx_ERROR_TEXT
                "Steps to Correct",                          // idx_ERROR_STEPS_TO_CORRECT
                ""
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsRosterNotifications(getFormComponent(), feeder, site, mu, reportingDate);
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object []
                {
                    rs.getString("FEEDER"),                                       // idx_FEEDER
                    rs.getString("SITE"),                                         // idx_SITE
                    rs.getString("MU"),                                           // idx_MU
                    rs.getString("EMPID"),                                        // idx_EMPID
                    rs.getString("AGENTID"),                                      // idx_AGENTID
                    rs.getString("EMPLOYEE"),                                     // idx_EMPLOYEE
                    rs.getDate("REPORTING_DATE"),                                 // idx_REPORTING_DATE
                    Misc.oracleToBoolean(rs.getObject("DO_NOT_IMPORT")),          // idx_DO_NOT_IMPORT
                    rs.getDate("PROGRAM_START"),                                  // idx_PROGRAM_START
                    rs.getDate("PROGRAM_STOP"),                                   // idx_PROGRAM_STOP
                    rs.getInt("LOAD_STATUS"),                                     // idx_LOAD_STATUS
                    rs.getString("ERROR_TEXT"),                                   // idx_ERROR_TEXT
                    rs.getString("ERROR_STEPS_TO_CORRECT"),                       // idx_ERROR_STEPS_TO_CORRECT
                    rs.getString("TVI_USER")                                      // idx_TVI_USER
                };
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Import Notifications data.");
                worker.cancel(true);
            }
            employeeCount++;
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
                employeesScrollPane.setViewportView(table);
                filterTextField.requestFocusInWindow();
            }
            refreshTableLock.release();
            if (cancelled)
            {
                closeForm();
            }
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    if (table.convertRowIndexToModel(row) != currentRow ||
                        table.getSelectedRows().length > 1)
                    {
                        return false;
                    }
                    else if (UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        return false;
                    }
                    else if (column == idx_DO_NOT_IMPORT)
                    {
                        if(table.getValueAt(row, idx_LOAD_STATUS).equals(4))
                        {
                            Misc.msgbox(getFormComponent(), "Cannot change Do Not Import status for employees missing in MU Roster in TVI. \nPush the Update MU Roster button on the green schedules screen to add this employee.", "Import Status", 2, 1, 2);
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_DO_NOT_IMPORT:
                            return Boolean.class;
                        case idx_REPORTING_DATE:
                        case idx_PROGRAM_START:
                        case idx_PROGRAM_STOP:
                            return Date.class;
                        case idx_LOAD_STATUS:
                            return Integer.class;
                        case idx_FEEDER:
                        case idx_SITE:
                        case idx_MU:
                        case idx_AGENTID:
                        case idx_EMPID:
                        case idx_EMPLOYEE:
                        case idx_ERROR_TEXT:
                        case idx_ERROR_STEPS_TO_CORRECT:
                        case idx_TVI_USER:
                        default:
                            return String.class;
                    }
                }

                @Override
                public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
                {
                    Component c = super.prepareRenderer(renderer, row, column);
                    if (!isRowSelected(row) && row <= employeeCount - 1)
                    {
                        c.setBackground(Color.WHITE);
                        if (table.getValueAt(row, idx_DO_NOT_IMPORT).equals(false))
                        {
                            c.setBackground(Color.YELLOW);
                        }
                    }
                    return c;
                }
            };
        }

        private void configureTable()
        {
            Action employeeTableAction = new AbstractAction()
            {
               @Override
                public void actionPerformed(ActionEvent e)
                {
                    TableCellListener etcl = (TableCellListener)e.getSource();
                    int selectedRow = table.getSelectedRow();
                    if (etcl.getColumn() == idx_DO_NOT_IMPORT)
                    {
                        updateDoNotImportCombo(Misc.objectToString(table.getValueAt(selectedRow, idx_DO_NOT_IMPORT)));
                    }
                    employeeUpdated = true;
                    currentRow = table.convertRowIndexToModel(selectedRow);
                }
            };
            table.addPropertyChangeListener(new TableCellListener(table, employeeTableAction));

            Misc.configureTable(table, false, true, false);

            sorter = new TableRowSorter<>(dataModel);
            table.setRowSorter(sorter);

            Misc.setTableSorterNumeralComparator(table);
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_FEEDER, 60);
            Misc.setColumnSettings(table, idx_SITE, 40);
            Misc.setColumnSettings(table, idx_MU, 40);
            Misc.setColumnSettings(table, idx_EMPID, 60);
            Misc.setColumnSettings(table, idx_AGENTID, 60);
            Misc.setColumnSettings(table, idx_EMPLOYEE, 120, Constants.LEFT);
            Misc.setColumnSettings(table, idx_REPORTING_DATE, 80);
            Misc.setColumnSettings(table, idx_DO_NOT_IMPORT, 60, false);
            Misc.setColumnSettings(table, idx_PROGRAM_START, 0);
            Misc.setColumnSettings(table, idx_PROGRAM_STOP, 0);
            Misc.setColumnSettings(table, idx_LOAD_STATUS, 0);
            Misc.setColumnSettings(table, idx_ERROR_TEXT, 250, Constants.LEFT);
            Misc.setColumnSettings(table, idx_ERROR_STEPS_TO_CORRECT, 350, Constants.LEFT);
            Misc.setColumnSettings(table, idx_TVI_USER, 0);
       
            table.setRowHeight(20);
            
            if (employeeCount > 0)
            {
                currentRow = 0;
                table.setRowSelectionInterval(0, 0);
                changingEmployees = true;
                changeEmployee(0);
                changingEmployees = false;
            }
            table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                @Override
                public void valueChanged(ListSelectionEvent e)
                {
                    if (!e.getValueIsAdjusting())
                    {
                        int selectedRow = table.getSelectedRow();
                        if (selectedRow != -1 && table.convertRowIndexToModel(selectedRow) != currentRow)
                        {
                            if (!changingEmployees)
                            {
                                changingEmployees = true;
                                changeEmployee(selectedRow);
                                changingEmployees = false;
                            }
                        }
                    }
                }
            });
            processFilter();
        }
    }
    public void changeEmployee(int selectedRow)
    {
        updateRosterNotifications();
        currentRow = table.convertRowIndexToModel(selectedRow);
    }
    private void clearFilter()
    {
        filterEnabled = false;
        filterColumnComboBox.setSelectedIndex(0);
        filterTextField.setText("");
        filterEnabled = true;
    }
    
    private void processFilter()
    {
        if (table == null || !worker.isDone() || !filterEnabled)
        {
            return;
        }
        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        List<RowFilter<CustomTableModel, Object>> filters = new ArrayList<>();
        List<RowFilter<CustomTableModel, Object>> inputFilters = new ArrayList<>();
        RowFilter<CustomTableModel, Object> textFilter;
        RowFilter<CustomTableModel, Object> dateFilter = null;
        RowFilter<CustomTableModel, Object> inputFilter;
        RowFilter<CustomTableModel, Object> importStatusFilter;
        
        try
        {
            if (filterColumn == -1)
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText());
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()));
                }
            }
            else
            {
                textFilter = RowFilter.regexFilter("(?i)" + filterTextField.getText(), filterColumn);
                if (filterTextField.getText().matches("^\\d{1,2}\\/\\d{1,2}((\\/\\d{2})|(\\/\\d{4})){0,1}$"))
                {
                    dateFilter = RowFilter.regexFilter(Misc.dateStringToFilterString(filterTextField.getText()), filterColumn);
                }
            }
            
            importStatusFilter = RowFilter.regexFilter(importStatusFilterText, idx_DO_NOT_IMPORT);
            inputFilters.add(textFilter);
            if (dateFilter != null)
            {
                inputFilters.add(dateFilter);
            }
            inputFilter = RowFilter.orFilter(inputFilters);
            
            filters.add(inputFilter);
            filters.add(importStatusFilter);
        }
        catch (java.util.regex.PatternSyntaxException ex)
        {
            return;
        }
        
        if (sorter != null)
        {
            sorter.setRowFilter(RowFilter.andFilter(filters));
            Misc.scaleScrollPaneToTable(getFormComponent(), employeesScrollPane, table);
        }
    }
    
        private void updateDoNotImportCombo(String doNotImport)
    {
        switch (doNotImport)
        {
            case "true":
                doNotImportCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "false"}));
                break;
            case "false":
                doNotImportCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "true"}));
                break;
            case "":
            default:
                doNotImportCombo.setModel(new DefaultComboBoxModel<>(new String[] {"", "true", "false"}));
                
        }
    }
    private void updateRosterNotifications()
    {
        if (table == null)
        {
            return;
        }

        if (table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }

        int selectedRosterRow = table.getSelectedRow();
        if (employeeUpdated)
        {
            setCursor(Constants.HOURGLASS);
            Oracle.updateRosterNotifications(getFormComponent(),   
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_FEEDER)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_SITE)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_MU)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPID)), 
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_AGENTID)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_EMPLOYEE)),
                (Date)dataModel.getValueAt(currentRow, idx_REPORTING_DATE),
                Misc.booleanToOracle(dataModel.getValueAt(currentRow, idx_DO_NOT_IMPORT)),
                (Date)dataModel.getValueAt(currentRow, idx_PROGRAM_START),
                (Date)dataModel.getValueAt(currentRow, idx_PROGRAM_STOP),
                Misc.objectToInt(dataModel.getValueAt(currentRow, idx_LOAD_STATUS)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_ERROR_TEXT)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_ERROR_STEPS_TO_CORRECT)),
                Misc.objectToString(dataModel.getValueAt(currentRow, idx_TVI_USER))                
            );
            setCursor(Constants.NORMAL);
            employeeUpdated = false;
            currentRow = table.convertRowIndexToModel(selectedRosterRow);
        }
    }
    
    private void closeForm()
    {
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        formClosing = true;
        if (table != null && table.isEditing())
        {
            table.getCellEditor().stopCellEditing();
        }
        
        releaseInstance();
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bottomControls;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JPanel centerPanel;
    private javax.swing.JButton employeeHistoryButton;
    private javax.swing.JScrollPane employeesScrollPane;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JButton filterClearButton;
    private javax.swing.JLabel filterClearLabel;
    private javax.swing.JLabel filterClearLabel1;
    private javax.swing.JLabel filterClearLabel2;
    private javax.swing.JComboBox<String> filterColumnComboBox;
    private javax.swing.JLabel filterColumnTextLabel;
    private javax.swing.JComboBox<String> filterDoNotImportComboBox;
    private javax.swing.JLabel filterEmployeeStatusLabel;
    private javax.swing.JPanel filterLabelsPanel;
    private javax.swing.JTextField filterTextField;
    private javax.swing.JLabel filterTextLabel;
    private javax.swing.JPanel filtersPanel;
    private javax.swing.JLabel loadingLabel;
    private javax.swing.JLabel mULabel;
    private javax.swing.JButton printButton;
    private javax.swing.JLabel reportingDateLabel;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel subtitleLabel2;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel topPanel;
    // End of variables declaration//GEN-END:variables
}
