package tvicore.objects;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.function.Consumer;
import javax.swing.*;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;

public class TrainingMeetingWindow extends JPanel
{
    public final Consumer<Integer> updateClassSelectedMethod;
    public final int meetingID;
    public final String title;
    public final String description;
    public final String feeder;
    public final Date startTime;
    public final int duration;
    public final int slotsAvailable;
    public final int slotsTaken;
    public final boolean signedUp;
    
    MouseAdapter adapter = new MouseAdapter()
    {
        @Override
        public void mouseReleased(MouseEvent e)
        {
            if (getFormComponent().contains(e.getPoint()))
            {
                SwingUtilities.invokeLater(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        selectWindow();
                    }
                });
            }
        }
    };
    
    /**
    * Create a Panel to display the meeting information.
    *
    * @param updateClassSelectedMethod method to update selection on the parent form
    * @param meetingID the unique id for the meeting
    * @param title brief title
    * @param description longer description
    * @param feeder feeder this class is visible for (or ALL)
    * @param startTime date & time the meeting will start
    * @param duration duration of the meeting in minutes
    * @param slotsAvailable maximum participants
    * @param slotsTaken current number of signed up participants
    * @param signedUp boolean flag, true if the user is signed up for the class
    */
    public TrainingMeetingWindow(Consumer<Integer> updateClassSelectedMethod, int meetingID, String title, String description, String feeder, Date startTime, int duration, int slotsAvailable, int slotsTaken, boolean signedUp)
    {
        this.updateClassSelectedMethod = updateClassSelectedMethod;
        this.meetingID = meetingID;
        this.title = title;
        this.description = description;
        this.feeder = feeder;
        this.startTime = startTime;
        this.duration = duration;
        this.slotsAvailable = slotsAvailable;
        this.slotsTaken = slotsTaken;
        this.signedUp = signedUp;
        
        createPanel();
    }
    
    private void createPanel()
    {
        this.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 200, 230), 5)); // hidden border
        if (meetingID != -1)
        {
            this.addMouseListener(adapter);
        }
        
        this.setPreferredSize(new Dimension(320, 420));
        this.setBackground(new Color(100, 200, 230));
        
        // Status Text
        JLabel statusLabel = new JLabel();
        statusLabel.setPreferredSize(new Dimension(320, 30));
        statusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        statusLabel.setFont(new Font("Tahoma", java.awt.Font.BOLD, 16));
        
        if (startTime.compareTo(Oracle.getCurTime(getFormComponent())) < 0)
        {
            statusLabel.setText("COMPLETED");
            statusLabel.setForeground(new Color(0, 0, 0));
        }
        else if (signedUp)
        {
            statusLabel.setText("SIGNED UP");
            statusLabel.setForeground(new Color(0, 150, 0));
        }
        else if (slotsTaken >= slotsAvailable)
        {
            statusLabel.setText("CLASS IS FULL");
            statusLabel.setForeground(new Color(150, 0, 0));
        }
        else
        {
            statusLabel.setText("");
        }
        
        // Title
        JLabel titleLabel = new JLabel();
        titleLabel.setPreferredSize(new Dimension(304, 40));
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setFont(new Font("Tahoma", java.awt.Font.BOLD, 16));
        titleLabel.setText(title);
        
        // Description
        JTextArea descriptionTextArea = new JTextArea();
        descriptionTextArea.setPreferredSize(new Dimension(280, 200));
        descriptionTextArea.setBackground(new Color(140, 215, 240));
        descriptionTextArea.setEditable(false);
        descriptionTextArea.setLineWrap(true);
        descriptionTextArea.setWrapStyleWord(true);
        descriptionTextArea.setHighlighter(null);
        descriptionTextArea.addMouseListener(adapter);
        descriptionTextArea.setText(description);
        
        // Start Time
        JLabel startTimeLabel = new JLabel();
        startTimeLabel.setPreferredSize(new Dimension(320, 30));
        startTimeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        startTimeLabel.setFont(new Font("Tahoma", java.awt.Font.PLAIN, 14));
        startTimeLabel.setText("Start Time: " + Misc.dateToString(startTime, "MMM d, yyyy - h:mm a"));
        
        // Duration
        JLabel durationLabel = new JLabel();
        durationLabel.setPreferredSize(new Dimension(320, 30));
        durationLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        durationLabel.setFont(new Font("Tahoma", java.awt.Font.PLAIN, 14));
        durationLabel.setText("Duration: " + duration + " minutes");
        
        // Slots Taken/Available
        JLabel slotsLabel = new JLabel();
        slotsLabel.setPreferredSize(new Dimension(320, 30));
        slotsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        slotsLabel.setFont(new Font("Tahoma", java.awt.Font.PLAIN, 14));
        int slotsRemaining = slotsAvailable - slotsTaken;
        if (slotsTaken >= slotsAvailable)
        {
            slotsRemaining = 0;
            slotsLabel.setForeground(new Color(200, 0, 0));
        }
        slotsLabel.setText(slotsRemaining + " slots remaining.");
        
        this.add(statusLabel);
        this.add(titleLabel);
        this.add(descriptionTextArea);
        this.add(startTimeLabel);
        this.add(durationLabel);
        this.add(slotsLabel);
    }
    
    public void selectWindow()
    {
        if (updateClassSelectedMethod != null)
        {
            updateClassSelectedMethod.accept(meetingID);
            
            // Visually indicate this class is selected
            this.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        }
    }
    
    public void deselectWindow()
    {
        // Hide the border
        this.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 200, 230), 5));
    }
    
    private Component getFormComponent()
    {
        return this;
    }
}
