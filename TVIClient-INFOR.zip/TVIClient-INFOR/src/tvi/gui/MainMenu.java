package tvi.gui;

import it.sauronsoftware.junique.JUnique;
import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import tvi.client_main.Main;
import tvicore.dao.Oracle;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.resources.Resources;

public final class MainMenu extends javax.swing.JFrame
{
    private final static boolean MAXIMIZE_DEFAULT = true;
    
    private static volatile MainMenu instance;
    
    private String feeder;
    private String site;
    
    private static final Semaphore changeFeederSiteLock = new Semaphore(1, true);
    boolean changeFeederSiteEnabled = false;
    boolean changingFeederOrSite = false;
    
    public static boolean focusInstance()
    {
        if (instance != null)
        {
            instance.toFront();
        }
        return instance != null;
    }
    
    public synchronized static MainMenu getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new MainMenu(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private MainMenu(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        contactInfoTextPane.setText("TVI Support\nEmail: " + Constants.EMAIL);
        StyledDocument doc = contactInfoTextPane.getStyledDocument();
        SimpleAttributeSet center = new SimpleAttributeSet();
        StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
        doc.setParagraphAttributes(0, doc.getLength(), center, false);
        switchDatabaseButton.setVisible(UserData.getUserType().equals("POWER"));
        if (Oracle.getDatabaseName().equals("TVI01T"))
        {
            testDBLabel.setVisible(true);
        }
        else if (UserData.getUserAccessLevel().equals("READONLY"))
        {
            testDBLabel.setText("READ ONLY");
            testDBLabel.setVisible(true);
        }
        else
        {
            testDBLabel.setVisible(false);
        }
        version.setText("Version: " + Main.CLIENTVERSION);
        userInfo.setText("FEEDER: " + feeder + "              SITE: " + site + "              USERID: " + UserData.getUUID());
        for (String s : UserData.getFeederList())
        {
            feeders.addItem(s);
        }
        for (String s : UserData.getSiteList())
        {
            sites.addItem(s);
        }
        String defaultFeeder = UserData.getDefaultFeeder();
        String defaultSite = UserData.getDefaultSite();
        if (defaultFeeder != null && !defaultFeeder.equals(""))
        {
            feeders.setSelectedItem(defaultFeeder);
            if (defaultSite != null && !defaultSite.equals(""))
            {
                sites.setSelectedItem(defaultSite);
            }
        }
        changeFeederSiteEnabled = true;
        
        setupInforFeedTimes();
        
        startCheckDatabaseTimer(getFormComponent());
        Misc.resetTimeoutTimer();
        timeReportingButton.requestFocusInWindow();
    }
    
    private void updateSiteInfo()
    {
        userInfo.setText("FEEDER: " + feeder + "              SITE: " + site + "              USERID: " + UserData.getUUID());
    }
    
    private void setupInforFeedTimes()
    {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("h:mm a");
        
        ZoneId pacificTimeZoneId = ZoneId.of("America/Los_Angeles");
        ZoneId localTimeZoneId = ZoneId.systemDefault();
        
        ZonedDateTime nightlyFeed  = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 19:45", dateFormat), pacificTimeZoneId, localTimeZoneId);
        ZonedDateTime payCloseFeed = Misc.convertDateToTimeZone(LocalDateTime.parse("2000-01-01 07:30", dateFormat), pacificTimeZoneId, localTimeZoneId);
        
        String feedTimes = "INFOR Payroll Feed Times:"
            + "\nEvery night:        " + nightlyFeed.format(timeFormat)
            + "\nPay close mornings: " + payCloseFeed.format(timeFormat)
            + "\n(Shown in your time zone)";
        inforFeedTimesTextArea.setText(feedTimes);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainMenuPanel = new javax.swing.JPanel();
        titlePanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        version = new javax.swing.JLabel();
        switchDatabaseButton = new javax.swing.JButton();
        userInfo = new javax.swing.JTextField();
        gridPanel = new javax.swing.JPanel();
        col1 = new javax.swing.JPanel();
        openLauncherButton = new javax.swing.JButton();
        feederDescriptions = new javax.swing.JScrollPane();
        feederDescriptionsTextArea = new javax.swing.JTextArea();
        inforFeedTimes = new javax.swing.JScrollPane();
        inforFeedTimesTextArea = new javax.swing.JTextArea();
        col2 = new javax.swing.JPanel();
        contactInfoScrollPane = new javax.swing.JScrollPane();
        contactInfoTextPane = new javax.swing.JTextPane();
        timeReportingButton = new javax.swing.JButton();
        helpButton = new javax.swing.JButton();
        configurationButton = new javax.swing.JButton();
        excelReportsMenuButton = new javax.swing.JButton();
        trainingClassesButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        col3 = new javax.swing.JPanel();
        siteSelectionPanel = new javax.swing.JPanel();
        changeFeederLabel = new javax.swing.JLabel();
        feeders = new javax.swing.JComboBox<>();
        changeSiteLabel = new javax.swing.JLabel();
        sites = new javax.swing.JComboBox<>();
        testDBLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Main Menu");
        setBackground(new java.awt.Color(255, 255, 128));
        setMinimumSize(new java.awt.Dimension(690, 660));
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0);
        flowLayout1.setAlignOnBaseline(true);
        getContentPane().setLayout(flowLayout1);

        mainMenuPanel.setBackground(new java.awt.Color(255, 255, 128));
        mainMenuPanel.setMinimumSize(new java.awt.Dimension(670, 680));
        mainMenuPanel.setPreferredSize(new java.awt.Dimension(670, 680));
        mainMenuPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titlePanel.setBackground(new java.awt.Color(255, 255, 128));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        titleLabel.setText("TVI MAIN MENU");
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 300, -1));

        version.setText("Version:");
        titlePanel.add(version, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 100, -1));

        switchDatabaseButton.setBackground(new java.awt.Color(255, 255, 128));
        switchDatabaseButton.setText("Switch DB");
        switchDatabaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                switchDatabaseButtonActionPerformed(evt);
            }
        });
        titlePanel.add(switchDatabaseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, -1, -1));

        userInfo.setEditable(false);
        userInfo.setBackground(new java.awt.Color(51, 255, 102));
        userInfo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        userInfo.setText("FEEDER:                  SITE:                 USERID: ");
        titlePanel.add(userInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 500, -1));

        mainMenuPanel.add(titlePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 10, 500, 100));

        gridPanel.setBackground(new java.awt.Color(255, 255, 128));
        gridPanel.setMinimumSize(new java.awt.Dimension(670, 480));
        gridPanel.setPreferredSize(new java.awt.Dimension(670, 480));
        gridPanel.setLayout(new java.awt.GridLayout(1, 3));

        col1.setBackground(new java.awt.Color(255, 255, 128));
        col1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        openLauncherButton.setBackground(new java.awt.Color(255, 255, 128));
        openLauncherButton.setText("Open TVI Launcher");
        openLauncherButton.setFocusable(false);
        openLauncherButton.setPreferredSize(new java.awt.Dimension(130, 30));
        openLauncherButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openLauncherButtonActionPerformed(evt);
            }
        });
        col1.add(openLauncherButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 0, -1, -1));

        feederDescriptions.setBorder(null);
        feederDescriptions.setPreferredSize(new java.awt.Dimension(200, 130));

        feederDescriptionsTextArea.setEditable(false);
        feederDescriptionsTextArea.setBackground(new java.awt.Color(255, 255, 128));
        feederDescriptionsTextArea.setColumns(20);
        feederDescriptionsTextArea.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        feederDescriptionsTextArea.setLineWrap(true);
        feederDescriptionsTextArea.setRows(6);
        feederDescriptionsTextArea.setText("ATI - Midwest\nBTI - Southeast\nGTI - Internet Services\nSTI - Southwest\nTTI - Classic T\nTVI - West");
        feederDescriptionsTextArea.setBorder(null);
        feederDescriptionsTextArea.setPreferredSize(new java.awt.Dimension(180, 130));
        feederDescriptions.setViewportView(feederDescriptionsTextArea);

        col1.add(feederDescriptions, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 210, -1));

        inforFeedTimes.setBorder(null);
        inforFeedTimes.setPreferredSize(new java.awt.Dimension(200, 130));

        inforFeedTimesTextArea.setEditable(false);
        inforFeedTimesTextArea.setBackground(new java.awt.Color(255, 255, 128));
        inforFeedTimesTextArea.setColumns(20);
        inforFeedTimesTextArea.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        inforFeedTimesTextArea.setLineWrap(true);
        inforFeedTimesTextArea.setRows(6);
        inforFeedTimesTextArea.setText("INFOR Payroll Feed Times:\nEvery night:        8:30 PM\nPay close mornings: 7:30 AM\n(Shown in your time zone)");
        inforFeedTimesTextArea.setBorder(null);
        inforFeedTimesTextArea.setPreferredSize(new java.awt.Dimension(180, 130));
        inforFeedTimes.setViewportView(inforFeedTimesTextArea);

        col1.add(inforFeedTimes, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 210, -1));

        gridPanel.add(col1);

        col2.setBackground(new java.awt.Color(255, 255, 128));
        col2.setLayout(new java.awt.GridLayout(7, 0, 0, 10));

        contactInfoScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        contactInfoScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        contactInfoTextPane.setEditable(false);
        contactInfoTextPane.setBackground(new java.awt.Color(255, 255, 153));
        contactInfoTextPane.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        contactInfoTextPane.setText("TVI SUPPORT CONTACT INFO");
        contactInfoScrollPane.setViewportView(contactInfoTextPane);

        col2.add(contactInfoScrollPane);

        timeReportingButton.setBackground(new java.awt.Color(255, 255, 128));
        timeReportingButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        timeReportingButton.setText("Time Reporting");
        timeReportingButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeReportingButtonActionPerformed(evt);
            }
        });
        col2.add(timeReportingButton);

        helpButton.setBackground(new java.awt.Color(255, 255, 128));
        helpButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        helpButton.setText("TVI Help Documents");
        helpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpButtonActionPerformed(evt);
            }
        });
        col2.add(helpButton);

        configurationButton.setBackground(new java.awt.Color(255, 255, 128));
        configurationButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        configurationButton.setText("Configuration");
        configurationButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                configurationButtonActionPerformed(evt);
            }
        });
        col2.add(configurationButton);

        excelReportsMenuButton.setBackground(new java.awt.Color(255, 255, 128));
        excelReportsMenuButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        excelReportsMenuButton.setText("Excel Reports");
        excelReportsMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                excelReportsMenuButtonActionPerformed(evt);
            }
        });
        col2.add(excelReportsMenuButton);

        trainingClassesButton.setBackground(new java.awt.Color(255, 255, 128));
        trainingClassesButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        trainingClassesButton.setText("Training Classes");
        trainingClassesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trainingClassesButtonActionPerformed(evt);
            }
        });
        col2.add(trainingClassesButton);

        exitButton.setBackground(new java.awt.Color(255, 255, 128));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        exitButton.setText("Exit TVI System");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        col2.add(exitButton);

        gridPanel.add(col2);

        col3.setBackground(new java.awt.Color(255, 255, 128));
        col3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        siteSelectionPanel.setBackground(new java.awt.Color(255, 255, 128));
        siteSelectionPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        changeFeederLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        changeFeederLabel.setText("Change Feeder:");
        siteSelectionPanel.add(changeFeederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 20));

        feeders.setMaximumRowCount(12);
        feeders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feedersActionPerformed(evt);
            }
        });
        siteSelectionPanel.add(feeders, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 51, 20));

        changeSiteLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        changeSiteLabel.setText("Change Site:");
        siteSelectionPanel.add(changeSiteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 80, 20));

        sites.setMaximumRowCount(30);
        sites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sitesActionPerformed(evt);
            }
        });
        siteSelectionPanel.add(sites, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 51, 20));

        col3.add(siteSelectionPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 160, 70));

        testDBLabel.setBackground(new java.awt.Color(255, 51, 51));
        testDBLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        testDBLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        testDBLabel.setText("TEST DATABASE");
        col3.add(testDBLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 223, 58));

        gridPanel.add(col3);

        mainMenuPanel.add(gridPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, -1, -1));

        getContentPane().add(mainMenuPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing

    private void timeReportingButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeReportingButtonActionPerformed
        Schedules.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_timeReportingButtonActionPerformed

    private void helpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpButtonActionPerformed
        HelpDocuments.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_helpButtonActionPerformed

    private void configurationButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_configurationButtonActionPerformed
        Configuration.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_configurationButtonActionPerformed

    private void excelReportsMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_excelReportsMenuButtonActionPerformed
        ExcelReportsMenu.getInstance(getFormComponent(), feeder, site);
    }//GEN-LAST:event_excelReportsMenuButtonActionPerformed

    private void switchDatabaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_switchDatabaseButtonActionPerformed
        if (Misc.getFormList().size() > 1)
        {
            Misc.msgbox(getFormComponent(), "You must close all other forms before switching database.", "LOCKED", 1, 1, 1);
        }
        else
        {
            new Thread(new SwitchDatabaseThread()).start();
        }
    }//GEN-LAST:event_switchDatabaseButtonActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        Misc.updateFormList();
        if (Misc.getFormList().size() <= 1)
        {
            if (!changingFeederOrSite)
            {
                sites.setEnabled(true);
                feeders.setEnabled(true);
            }
        }
    }//GEN-LAST:event_formWindowGainedFocus

    private void feedersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feedersActionPerformed
        if (!changeFeederSiteEnabled)
        {
            return;
        }
        Misc.updateFormList();
        if (Misc.getFormList().size() > 1)
        {
            feeders.setSelectedItem(feeder);
            feeders.setEnabled(false);
            sites.setEnabled(false);
            Misc.msgbox(getFormComponent(), "You must close all other forms before changing feeder or site.", "Feeder & Site LOCKED", 1, 1, 1);
        }
        else
        {
            new Thread(new ChangeFeederThread()).start();
        }
    }//GEN-LAST:event_feedersActionPerformed

    private void sitesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sitesActionPerformed
        if (!changeFeederSiteEnabled)
        {
            return;
        }
        Misc.updateFormList();
        if (Misc.getFormList().size() > 1)
        {
            sites.setSelectedItem(site);
            feeders.setEnabled(false);
            sites.setEnabled(false);
            Misc.msgbox(getFormComponent(), "You must close all other forms before changing feeder or site.", "Feeder & Site LOCKED", 1, 1, 1);
        }
        else
        {
            new Thread(new ChangeSiteThread()).start();
        }
    }//GEN-LAST:event_sitesActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        if (Misc.isMeetingAvailable(getFormComponent(), feeder, UserData.getUUID()))
        {
            setTrainingClassesButtonColor(Color.red);
        }
        else
        {
            setTrainingClassesButtonColor(Constants.YELLOW);
        }
        
        if (!UserData.getUserType().equals("POWER") && !Oracle.isFeederOnline(getFormComponent(), feeder))
        {
            setControlsEnabled(false);
            feeders.setEnabled(true);
            Misc.startShutdownTimer(5*60*1000, "DATABASE OFFLINE");
            Misc.msgbox(getFormComponent(), "Current feeder is OFFLINE. Please select another feeder or exit TVI.", "Feeder Unavailable", -1, 1, 1);
        }
        // set Misc.closeForms to instruct it how to close forms in Misc.exit() if necessary.
        Runnable closeForms = new Runnable()
        {
            @Override
            public void run()
            {
                TimeReporting.closeInstance();
                PayrollPeriodSummary.closeInstance();
            }
        };
        Misc.setCloseFormsRunnable(closeForms);
    }//GEN-LAST:event_formWindowOpened

    private void trainingClassesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trainingClassesButtonActionPerformed
        TrainingScheduler.getInstance(getFormComponent(), feeder);
    }//GEN-LAST:event_trainingClassesButtonActionPerformed

    private void openLauncherButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openLauncherButtonActionPerformed
        String message = "This will close the current session and open the TVI Launcher.\nThere you can change your userid or select another client.\nAre you sure you want to proceed?";
        if (Misc.msgbox(getFormComponent(), message, "TVI Launcher", 1, 2, 1))
        {
            if (TimeReporting.exists())
            {
                String msg = "<html>A schedule is open, you must apply any"
                + "<br>active changes and close it before exiting TVI."
                + "<br><b>The open schedule will now be restored.</b></html>";
                Misc.msgbox(getFormComponent(), msg, "Opening existing schedule window", 1, 1, 1);
                TimeReporting.focusInstance();
            }
            else
            {
                Main.config.setDefaultClient("NONE");
                Main.config.writeToFile();
                JUnique.releaseLock(Main.APPID);
                Misc.executeJar(getFormComponent(), "TVIClient.jar");
                releaseInstance();
                Misc.exit(getFormComponent(), "NORMAL");
            }
        }
    }//GEN-LAST:event_openLauncherButtonActionPerformed
    
    public static void setTrainingClassesButtonColor(Color color)
    {
        instance.trainingClassesButton.setBackground(color);
    }
    
    /**
     * Starts a recurring 10 minute timer that checks database status.
     * Checks broadcast message, feeder online status, user force logoff status, and updates user's last online time.
     * 
     * @param parentFrame
     */
    public static void startCheckDatabaseTimer(Component parentFrame)
    {
        Misc.startCheckDatabaseTimer(new TimerTask()
        {
            @Override
            public void run()
            {
                Oracle.checkBroadcastMessage(RegionData.getFeeder());
                if (!UserData.getUserType().equals("POWER"))
                {
                    String msg = Oracle.checkClientOnline(Main.CLIENTNAME, RegionData.getFeeder());
                    if (msg != null)
                    {
                        Misc.startShutdownTimer(5*60*1000, "DATABASE OFFLINE");
                        Misc.msgbox(null, msg, "CLIENT GOING OFFLINE", -1, 1, 1);
                    }
                }
                Misc.checkForceLogoff(UserData.getUUID());
                Oracle.updateLastOnline(parentFrame, UserData.getUUID());
                if (Misc.isMeetingAvailable(parentFrame, RegionData.getFeeder(), UserData.getUUID()))
                {
                    setTrainingClassesButtonColor(Color.red);
                }
                else
                {
                    setTrainingClassesButtonColor(Constants.YELLOW);
                }
            }
        });
    }
    
    private class SwitchDatabaseThread implements Runnable
    {
        @Override
        public void run()
        {
            setCursor(Constants.HOURGLASS);
            setControlsEnabled(false);
            
            String dbName;
            if (Oracle.getDatabaseName().equals("TVI01P"))
            {
                dbName = "TVI01T";
                testDBLabel.setVisible(true);            
            }
            else
            {
                dbName = "TVI01P";
                testDBLabel.setVisible(false);
            }
            try
            {
                Oracle.closeConnection();
                Oracle.initializeConnection(dbName, Oracle.getDatabasePassword());
                UserData.updateUserFeederPermissions(getFormComponent(), Main.CLIENTNAME, Main.config);
                RegionData.changeFeeder(getFormComponent(), Main.CLIENTNAME, feeder);
                sites.removeAllItems();
                for (String s : UserData.getSiteList())
                {
                    sites.addItem(s);
                }
                sites.setSelectedItem(RegionData.getSite());
                site = (String) sites.getSelectedItem();
                if (Misc.isMeetingAvailable(getFormComponent(), feeder, UserData.getUUID()))
                {
                    setTrainingClassesButtonColor(Color.red);
                }
                else
                {
                    setTrainingClassesButtonColor(Constants.YELLOW);
                }
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, true, "SQL Error switching database.");
            }
            setControlsEnabled(true);
            setCursor(Constants.NORMAL);
        }
    }
    
    private class ChangeFeederThread implements Runnable
    {
        @Override
        public void run()
        {
            if (!UserData.getUserType().equals("POWER"))
            {
                if (!Oracle.isFeederOnline(getFormComponent(), "ALL"))
                {
                    Misc.startShutdownTimer(60*1000, "DATABASE OFFLINE");
                    Misc.msgbox(getFormComponent(), "<html><font size=\"6\"><center>TVI Database is OFFLINE.</font>", "", -1, 1, 1);
                    Misc.exit(getFormComponent(), "DATABASE OFFLINE");
                }
                else if (!Oracle.isFeederOnline(getFormComponent(), (String) feeders.getSelectedItem()))
                {
                    Misc.msgbox(getFormComponent(), "The feeder you have selected is OFFLINE.", "Feeder Unavailable", -1, 1, 1);
                    changeFeederSiteEnabled = false;
                    feeders.setSelectedItem(feeder);
                    changeFeederSiteEnabled = true;
                    return;
                }
                else if (Misc.getShuttingDown())
                {
                    Misc.setShuttingDown(false);
                    if (Misc.shutdownTimer != null)
                    {
                        Misc.shutdownTimer.cancel();
                    }
                }
            }
            if (MainMenu.changeFeederSiteLock.tryAcquire())
            {
                try
                {
                    setCursor(Constants.HOURGLASS);
                    setControlsEnabled(false);
                    feeder = feeders.getSelectedItem().toString();
                    RegionData.changeFeeder(getFormComponent(), Main.CLIENTNAME, feeder);
                    sites.removeAllItems();
                    for (String s : UserData.getSiteList())
                    {
                        sites.addItem(s);
                    }
                    site = (String) sites.getSelectedItem();
                    
                    updateSiteInfo();
                    if (Misc.isMeetingAvailable(getFormComponent(), feeder, UserData.getUUID()))
                    {
                        setTrainingClassesButtonColor(Color.red);
                    }
                    else
                    {
                        setTrainingClassesButtonColor(Constants.YELLOW);
                    }
                    setControlsEnabled(true);
                    setCursor(Constants.NORMAL);
                }
                finally
                {
                    MainMenu.changeFeederSiteLock.release();
                }
            }
        }
    }
    
    private class ChangeSiteThread implements Runnable
    {
        @Override
        public void run()
        {
            if (MainMenu.changeFeederSiteLock.tryAcquire())
            {
                try
                {
                    setCursor(Constants.HOURGLASS);
                    setControlsEnabled(false);
                    site = (String) sites.getSelectedItem();
                    RegionData.changeSite(getFormComponent(), feeder, site);

                    updateSiteInfo();
                    if (Oracle.getDatabaseName().equals("TVI01T"))
                    {
                        testDBLabel.setVisible(true);
                    }
                    else if (UserData.getUserAccessLevel().equals("READONLY"))
                    {
                        testDBLabel.setText("READ ONLY");
                        testDBLabel.setVisible(true);
                    }
                    else
                    {
                        testDBLabel.setVisible(false);
                    }

                    setControlsEnabled(true);
                    setCursor(Constants.NORMAL);
                }
                finally
                {
                    MainMenu.changeFeederSiteLock.release();
                }
            }
        }
    }
    
    private void setControlsEnabled(boolean enabled)
    {
        changingFeederOrSite = !enabled;
        feeders.setEnabled(enabled);
        sites.setEnabled(enabled);
        switchDatabaseButton.setEnabled(enabled);
        timeReportingButton.setEnabled(enabled);
        helpButton.setEnabled(enabled);
        configurationButton.setEnabled(enabled);
        excelReportsMenuButton.setEnabled(enabled);
        trainingClassesButton.setEnabled(enabled);
    }
    
    private void closeForm()
    {
        if (TimeReporting.exists())
        {
            String msg = "<html>A schedule is open, you must apply any"
                       + "<br>active changes and close it before exiting TVI."
                       + "<br><b>The open schedule will now be restored.</b></html>";
            Misc.msgbox(getFormComponent(), msg, "Opening existing schedule window", 1, 1, 1);
            TimeReporting.focusInstance();
        }
        else
        {
            releaseInstance();
            Misc.exit(getFormComponent(), "NORMAL");
        }
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel changeFeederLabel;
    private javax.swing.JLabel changeSiteLabel;
    private javax.swing.JPanel col1;
    private javax.swing.JPanel col2;
    private javax.swing.JPanel col3;
    private javax.swing.JButton configurationButton;
    private javax.swing.JScrollPane contactInfoScrollPane;
    private javax.swing.JTextPane contactInfoTextPane;
    private javax.swing.JButton excelReportsMenuButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JScrollPane feederDescriptions;
    private javax.swing.JTextArea feederDescriptionsTextArea;
    private javax.swing.JComboBox<String> feeders;
    private javax.swing.JPanel gridPanel;
    private javax.swing.JButton helpButton;
    private javax.swing.JScrollPane inforFeedTimes;
    private javax.swing.JTextArea inforFeedTimesTextArea;
    private javax.swing.JPanel mainMenuPanel;
    private javax.swing.JButton openLauncherButton;
    private javax.swing.JPanel siteSelectionPanel;
    private javax.swing.JComboBox<String> sites;
    private javax.swing.JButton switchDatabaseButton;
    private javax.swing.JLabel testDBLabel;
    private javax.swing.JButton timeReportingButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JButton trainingClassesButton;
    private javax.swing.JTextField userInfo;
    private javax.swing.JLabel version;
    // End of variables declaration//GEN-END:variables
    
}
