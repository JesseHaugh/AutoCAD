package tvicore.objects;

import java.util.List;

public class TimeReportingCodesReportSettings
{
    private final String sbcid;
    private final String reportName;
    private final boolean is_public;
    private final String feeder;
    private final boolean absSelected;
    private final boolean attSelected;
    private final boolean extSelected;
    private final List<String> absCodeList;
    private final List<String> attCodeList;
    private final List<String> extCodeList;
    
    public TimeReportingCodesReportSettings(String sbcid, String reportName, boolean is_public, String feeder, boolean absSelected, boolean attSelected, boolean extSelected, List<String> absCodeList, List<String> attCodeList, List<String> extCodeList)
    {
        this.sbcid = sbcid;
        this.reportName = reportName;
        this.is_public = is_public;
        this.feeder = feeder;
        this.absSelected = absSelected;
        this.attSelected = attSelected;
        this.extSelected = extSelected;
        this.absCodeList = absCodeList;
        this.attCodeList = attCodeList;
        this.extCodeList = extCodeList;
    }
    
    public String getSBCID()
    {
        return sbcid;
    }
    
    public String getReportName()
    {
        return reportName;
    }
    
    public boolean isPublic()
    {
        return is_public;
    }
    
    public String getFeeder()
    {
        return feeder;
    }
    
    public boolean getAbsSelected()
    {
        return absSelected;
    }
    
    public boolean getAttSelected()
    {
        return attSelected;
    }
    
    public boolean getExtSelected()
    {
        return extSelected;
    }
    
    public List<String> getAbsCodeList()
    {
        return absCodeList;
    }
    
    public List<String> getAttCodeList()
    {
        return attCodeList;
    }
    
    public List<String> getExtCodeList()
    {
        return extCodeList;
    }
}