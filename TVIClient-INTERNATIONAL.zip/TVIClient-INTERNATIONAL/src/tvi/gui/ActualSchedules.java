package tvi.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.swing.DefaultListModel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.RowSorter.SortKey;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import tvi.client_main.Main;
import tvicore.objects.CustomTableModel;
import tvicore.dao.Oracle;
import tvicore.dao.ResultSetWrapper;
import tvicore.objects.TableSwingWorker;
import tvicore.miscellaneous.Misc;
import tvicore.miscellaneous.Constants;
import tvicore.dao.RegionData;
import tvicore.dao.UserData;
import tvicore.reports.ExcelReports;
import tvicore.resources.Resources;

public final class ActualSchedules extends javax.swing.JFrame
{
    private static volatile ActualSchedules instance;
    
    private final static boolean MAXIMIZE_DEFAULT = false;
    private final String feeder;
    private final String site;
    
    JTable table;
    CustomTableModel dataModel;
    TableSwingWorker worker;
    private static final Semaphore refreshTableLock = new Semaphore(1, true);
    
    Timer workingTimer;
    
    private int workingSelectedRow;
    private int workingRowCount;
    private int workingScrollPosition = 0;
    private String workingSelectedMu;
    private String workingSelectedDate;
    private List<? extends SortKey> workingSortKeys = null;
    
    boolean gotSending = false;
    boolean gotImporting = false;
    
    final static int idx_MU             = 0;
    final static int idx_REPORTING_DATE = 1;
    final static int idx_STATUS         = 2;
    
    public synchronized static ActualSchedules getInstance(Component parentFrame, String feeder, String site)
    {
        if (instance == null)
        {
            parentFrame.setCursor(Constants.HOURGLASS);
            instance = new ActualSchedules(feeder, site);
            parentFrame.setCursor(Constants.NORMAL);
        }
        
        instance.toFront();
        Misc.showOnSameScreen(parentFrame, instance, MAXIMIZE_DEFAULT);
        return instance;
    }
    
    private ActualSchedules(String feeder, String site)
    {
        this.feeder = feeder;
        this.site = site;
        
        setIconImage(Resources.getTVIICON());
        initComponents();
        getContentPane().setBackground(this.getBackground());
        
        /***********************************************************************
        * MU list setup
        ***********************************************************************/
        DefaultListModel<String> modelr = new DefaultListModel<>();
        for (String s : RegionData.getMuList())
        {
            if (!Misc.isAlpha(s.substring(0, 1)))
            {
                modelr.addElement(s);
            }
        }
        importSchedules.setModel(modelr);
        if (importSchedules.getModel().getSize() > 0)
        {
            importSchedules.setSelectedIndex(0);
        }
        
        /***********************************************************************
        * Pick Date Setup
        ***********************************************************************/
        Calendar cal = Calendar.getInstance();
        Date curDate = Misc.dateNoTime(cal.getTime());
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, 20);
        for (int i = 0; i < 60; i++)
        {
            pickDate.addItem(Misc.dateToStringMDY(cal.getTime()));
            cal.add(Calendar.DAY_OF_YEAR, -1);
        }
        cal.setTime(curDate);
        cal.add(Calendar.DAY_OF_YEAR, -1);
        pickDate.setSelectedItem(Misc.dateToStringMDY(cal.getTime()));
        
        /***********************************************************************
        * setup Timers for refreshing data
        ***********************************************************************/
        ActionListener workingRefresh = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent evt)
            {
                new Thread(new RefreshTableThread()).start();
            }
        };
        
        workingTimer = new Timer(60*1000, workingRefresh);
        workingTimer.setRepeats(true);
        workingTimer.setInitialDelay(60*1000);
        workingTimer.start();
        
        feederLabel.setText("Feeder: " + feeder);
        siteLabel.setText("Site: " + site);
        
        importSchedulesPane.setVisible(requestByMUCheckBox.isSelected());
    }
    
    private void refreshData()
    {
        if (worker == null || worker.isDone())
        {
            workingTimer.setInitialDelay(0);
            workingTimer.restart();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titlePanel = new javax.swing.JPanel();
        feederSitePanel = new javax.swing.JPanel();
        feederLabel = new javax.swing.JLabel();
        siteLabel = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        titleLabel = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();
        bodyPanel = new javax.swing.JPanel();
        scheduleColumnsPanel = new javax.swing.JPanel();
        importColumnPane = new javax.swing.JPanel();
        pickDateLabel = new javax.swing.JLabel();
        pickDate = new javax.swing.JComboBox<>();
        requestByMUCheckBox = new javax.swing.JCheckBox();
        importSchedulesPane = new javax.swing.JScrollPane();
        importSchedules = new javax.swing.JList<>();
        importButton = new javax.swing.JButton();
        workingColumnPanel = new javax.swing.JPanel();
        fillerLabel = new javax.swing.JLabel();
        workingSchedulesPane = new javax.swing.JScrollPane();
        loadingWorkingLabel = new javax.swing.JLabel();
        workingScheduleOpenButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Actual Schedules");
        setBackground(new java.awt.Color(250, 200, 200));
        setMinimumSize(new java.awt.Dimension(700, 639));
        setPreferredSize(new java.awt.Dimension(700, 620));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        titlePanel.setBackground(new java.awt.Color(250, 200, 200));
        titlePanel.setMinimumSize(new java.awt.Dimension(700, 100));
        titlePanel.setPreferredSize(new java.awt.Dimension(700, 100));
        titlePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederSitePanel.setBackground(new java.awt.Color(250, 200, 200));
        feederSitePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        feederLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        feederLabel.setText("Feeder:");
        feederSitePanel.add(feederLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 90, -1));

        siteLabel.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        siteLabel.setText("Site: ");
        feederSitePanel.add(siteLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, -1));

        titlePanel.add(feederSitePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, 40));

        exitButton.setBackground(new java.awt.Color(250, 200, 200));
        exitButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setPreferredSize(new java.awt.Dimension(140, 30));
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        titlePanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 10, -1, -1));

        titleLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Actual vs Schedule");
        titlePanel.add(titleLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 700, -1));

        refreshButton.setBackground(new java.awt.Color(250, 200, 200));
        refreshButton.setText("Refresh Screen");
        refreshButton.setPreferredSize(new java.awt.Dimension(110, 30));
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        titlePanel.add(refreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 60, -1, -1));

        getContentPane().add(titlePanel, java.awt.BorderLayout.PAGE_START);

        bodyPanel.setBackground(new java.awt.Color(0, 204, 153));
        bodyPanel.setPreferredSize(new java.awt.Dimension(700, 500));
        bodyPanel.setLayout(new javax.swing.BoxLayout(bodyPanel, javax.swing.BoxLayout.Y_AXIS));

        scheduleColumnsPanel.setBackground(new java.awt.Color(250, 200, 200));
        scheduleColumnsPanel.setMinimumSize(new java.awt.Dimension(835, 433));
        scheduleColumnsPanel.setPreferredSize(new java.awt.Dimension(835, 460));
        scheduleColumnsPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 0));

        importColumnPane.setBackground(new java.awt.Color(250, 200, 200));
        importColumnPane.setMinimumSize(new java.awt.Dimension(100, 500));
        importColumnPane.setPreferredSize(new java.awt.Dimension(100, 500));

        pickDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pickDateLabel.setText("Pick Date: ");
        pickDateLabel.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDateLabel.setPreferredSize(new java.awt.Dimension(100, 20));
        importColumnPane.add(pickDateLabel);

        pickDate.setEditable(true);
        pickDate.setMaximumRowCount(14);
        pickDate.setMaximumSize(new java.awt.Dimension(100, 20));
        pickDate.setMinimumSize(new java.awt.Dimension(100, 20));
        pickDate.setName(""); // NOI18N
        pickDate.setPreferredSize(new java.awt.Dimension(100, 20));
        importColumnPane.add(pickDate);

        requestByMUCheckBox.setBackground(new java.awt.Color(250, 200, 200));
        requestByMUCheckBox.setText("Request by MU");
        requestByMUCheckBox.setPreferredSize(new java.awt.Dimension(100, 24));
        requestByMUCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                requestByMUCheckBoxActionPerformed(evt);
            }
        });
        importColumnPane.add(requestByMUCheckBox);

        importSchedulesPane.setPreferredSize(new java.awt.Dimension(100, 350));

        importSchedulesPane.setViewportView(importSchedules);

        importColumnPane.add(importSchedulesPane);

        importButton.setBackground(new java.awt.Color(250, 200, 200));
        importButton.setText("Request Report");
        importButton.setMargin(new java.awt.Insets(2, 8, 2, 8));
        importButton.setPreferredSize(new java.awt.Dimension(100, 30));
        importButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importButtonActionPerformed(evt);
            }
        });
        importColumnPane.add(importButton);

        scheduleColumnsPanel.add(importColumnPane);

        workingColumnPanel.setBackground(new java.awt.Color(250, 200, 200));
        workingColumnPanel.setMinimumSize(new java.awt.Dimension(365, 500));
        workingColumnPanel.setPreferredSize(new java.awt.Dimension(265, 500));

        fillerLabel.setMaximumSize(null);
        fillerLabel.setMinimumSize(null);
        fillerLabel.setName(""); // NOI18N
        fillerLabel.setPreferredSize(new java.awt.Dimension(260, 75));
        workingColumnPanel.add(fillerLabel);

        workingSchedulesPane.setPreferredSize(new java.awt.Dimension(265, 350));

        loadingWorkingLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loadingWorkingLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadingWorkingLabel.setText("LOADING...");
        workingSchedulesPane.setViewportView(loadingWorkingLabel);

        workingColumnPanel.add(workingSchedulesPane);

        workingScheduleOpenButton.setBackground(new java.awt.Color(250, 200, 200));
        workingScheduleOpenButton.setText("Open Selected");
        workingScheduleOpenButton.setMaximumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setMinimumSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.setPreferredSize(new java.awt.Dimension(110, 30));
        workingScheduleOpenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                workingScheduleOpenButtonActionPerformed(evt);
            }
        });
        workingColumnPanel.add(workingScheduleOpenButton);

        scheduleColumnsPanel.add(workingColumnPanel);

        bodyPanel.add(scheduleColumnsPanel);

        getContentPane().add(bodyPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        closeForm();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        refreshData();
    }//GEN-LAST:event_formWindowOpened

    private void importButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importButtonActionPerformed
        setCursor(Constants.HOURGLASS);
        
        Date importDate = Misc.stringToDateMDY(getFormComponent(), pickDate.getSelectedItem().toString());
        if (importDate == null)
        {
            setCursor(Constants.NORMAL);
            return;
        }
        if (importSchedules.getSelectedValue() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must select an MU from the list!", "Import Schedules", 1, 1, 1);
            return;
        }
        if (pickDate.getSelectedItem() == null)
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must Pick or Enter a Date!", "Import Schedules", 1, 1, 1);
            return;
        }
        else if (!Misc.isDate(pickDate.getSelectedItem().toString()))
        {
            setCursor(Constants.NORMAL);
            Misc.msgbox(getFormComponent(), "You must first Pick or Enter a valid Date", "Importing Schedules", 1, 1, 1);
            return;
        }
        boolean okToImport = Oracle.isImportingOkay(getFormComponent(), Main.CLIENTNAME, feeder, site);
        if (okToImport)
        {
            RegionData.updateSiteInfo(getFormComponent(), feeder, site);
            okToImport = !Misc.isSiteLocked(getFormComponent(), RegionData.getSiteLock());
        }
        if (!okToImport)
        {
            setCursor(Constants.NORMAL);
            return;
        }

        if (requestByMUCheckBox.isSelected())
        {
            List selectedMUs = importSchedules.getSelectedValuesList();

            for (Object mu : selectedMUs)
            {
                if (Oracle.actualScheduleIsRequesting(getFormComponent(), feeder, site, mu.toString(), "ALL", importDate))
                {
                    setCursor(Constants.NORMAL);
                    Misc.msgbox(getFormComponent(), "At least one schedule is already requesting", "Importing Schedules", 1, 1, 1);
                    return;
                }
            }
            
            setCursor(Constants.HOURGLASS);
            for (Object mu : selectedMUs)
            {
                if (Oracle.actualScheduleExists(getFormComponent(), feeder, site, mu.toString(), "ALL", importDate))
                {
                    Oracle.updateActualScheduleStatus(getFormComponent(), feeder, site, mu.toString(), "ALL", importDate, "Done");
                    Oracle.clearActualSchedule(getFormComponent(), feeder, site, mu.toString(), importDate);
                }
                Oracle.requestActualSchedule(getFormComponent(), feeder, site, mu.toString(), importDate, UserData.getUUID());
            }
        }
        else // ALLMU
        {
            if (Oracle.actualScheduleIsRequesting(getFormComponent(), feeder, site, "ALL", "ALLMU", importDate))
            {
                setCursor(Constants.NORMAL);
                Misc.msgbox(getFormComponent(), "At least one schedule is already requesting", "Importing Schedules", 1, 1, 1);
                return;
            }
            
            setCursor(Constants.HOURGLASS);
            if (Oracle.actualScheduleExists(getFormComponent(), feeder, site, "ALL", "ALLMU", importDate))
            {
                Oracle.updateActualScheduleStatus(getFormComponent(), feeder, site, "ALL", "ALLMU", importDate, "Done");
                Oracle.clearActualSchedule(getFormComponent(), feeder, site, "ALL", importDate);
            }
            Oracle.requestActualScheduleALL(getFormComponent(), feeder, site, importDate, UserData.getUUID());
        }
        
        setCursor(Constants.NORMAL);
        refreshData();
    }//GEN-LAST:event_importButtonActionPerformed
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        closeForm();
    }//GEN-LAST:event_formWindowClosing
    
    private void workingScheduleOpenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_workingScheduleOpenButtonActionPerformed
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1)
        {
            String mu = Misc.objectToString(table.getValueAt(selectedRow, idx_MU));
            Date reportingDate = (Date) table.getValueAt(selectedRow, idx_REPORTING_DATE);
            new Thread(new GenerateActualScheduleReportThread(mu, reportingDate)).start();
        }
    }//GEN-LAST:event_workingScheduleOpenButtonActionPerformed
    
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        refreshData();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void requestByMUCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_requestByMUCheckBoxActionPerformed
        importSchedulesPane.setVisible(requestByMUCheckBox.isSelected());
        validate();
    }//GEN-LAST:event_requestByMUCheckBoxActionPerformed
    
    private class GenerateActualScheduleReportThread implements Runnable
    {
        String mu;
        Date reportingDate;
        public GenerateActualScheduleReportThread(String mu, Date reportingDate)
        {
            this.mu = mu;
            this.reportingDate = reportingDate;
        }
        
        @Override
        public void run()
        {
            if (ExcelReports.openingXLSReportLock.tryAcquire())
            {
                try
                {
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                setCursor(Constants.HOURGLASS);
                                workingScheduleOpenButton.setEnabled(false);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                    
                    if (Oracle.isActualScheduleAvailable(getFormComponent(), feeder, site, mu, reportingDate, "ALL"))
                    {
                        ExcelReports.fillActualScheduleReport(getFormComponent(), feeder, site, mu, reportingDate);
                        refreshData();
                    }
                    else
                    {
                        Misc.msgbox(getFormComponent(), "Schedule must have a status of 'Available'.", "Generating actual schedule report", 1, 1, 1);
                    }
                }
                finally
                {
                    ExcelReports.openingXLSReportLock.release();
                    try
                    {
                        SwingUtilities.invokeAndWait(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                workingScheduleOpenButton.setEnabled(true);
                                setCursor(Constants.NORMAL);
                            }
                        });
                    }
                    catch (InterruptedException | InvocationTargetException ex) {}
                }
            }
        }
    }
    
    private class RefreshTableThread implements Runnable
    {
        @Override
        public void run()
        {
            if (refreshTableLock.tryAcquire())
            {
                try
                {
                    worker = null;
                    
                    // builds the column names and create the data model - buildColumnNames is defined below inside this thread
                    dataModel = new CustomTableModel(buildColumnNames());
                    
                    // create reference methods (defined below inside this thread) to pass to the swing worker - this::methodName is a lambda expression that creates the method reference
                    Supplier<ResultSetWrapper> getResultsMethod = this::getResults;
                    Function<ResultSet, Object[]> processResultsFunc = this::processResults;
                    Consumer<Boolean> finalizeRefreshMethod = this::finalizeRefresh;
                    
                    // initialize the custom swing worker
                    worker = new TableSwingWorker(getFormComponent(), dataModel, getResultsMethod, processResultsFunc, finalizeRefreshMethod);
                    
                    // initial code to run before starting the worker - initializeRefresh is defined below inside this thread
                    initializeRefresh();
                    
                    // start the worker.  it will get results from the database and add row to the table in background threads, then call finalizeRefresh() on the EDT.  see tvi.dao.TableSwingWorker
                    worker.execute();
                }
                finally
                {
                    if (worker == null) // The thread encountered an error before the worker could be initialized - release the lock.
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                loadingWorkingLabel.setText("ERROR");
                            }
                        });
                        refreshTableLock.release();
                        Misc.msgbox(getFormComponent(), "Error loading table, email TVI Support at " + Constants.EMAIL, "Loading Failed", 2, 1, 2);
                    }
                }
            }
        }
        
        /**
        * initializeRefresh
        * 
        * Work that needs to be done before building the table.
        * GUI work that needs to be run on the Event Dispatch Thread needs to be explicitly invoked.
        * The TableSwingWorker should already be initialized before running this so that it can be referenced to cancel.
        * Cancelling the TableSwingWorker OFF the EDT will enqueue finalizeRefresh on the EDT - initializeRefresh will finish first.
        * Cancelling the TableSwingWorker ON the EDT will immediately call finalizeRefresh() in-line.  If you want it to instead be enqueud to the EDT, put it in an invokeLater block.
        */
        private void initializeRefresh()
        {
            SwingUtilities.invokeLater(new Runnable()
            {
                @Override
                public void run()
                {
                    // Variables for maintaining table selection and position
                    if (table != null)
                    {
                        workingRowCount = table.getRowCount();
                        workingScrollPosition = workingSchedulesPane.getVerticalScrollBar().getValue();
                        workingSortKeys = table.getRowSorter().getSortKeys();
                        workingSelectedRow = table.getSelectedRow();
                        if (workingSelectedRow >= 0)
                        {
                            workingSelectedMu = table.getValueAt(workingSelectedRow, idx_MU).toString();
                            workingSelectedDate = table.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString();
                        }
                    }
                    
                    workingSchedulesPane.setViewportView(loadingWorkingLabel);
                    gotSending = false;
                    gotImporting = false;
                }
            });
        }
        
        /**
        * buildColumnNames()
        * 
        * Builds the column names to use for the table, in index order.
        * Hidden columns still need to be listed, but can be empty Strings.
        * 
        * @return String[] column headers
        */
        private String[] buildColumnNames()
        {
            return new String[]
            {
                "MU",        // idx_MU
                "Date",      // idx_REPORTING_DATE
                "Status"     // idx_STATUS
            };
        }
        
        /**
        * getResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Supplier.
        * This Supplier queries the database for results.
        * The wrapped ResultSet and CallableStatement cursors are closed by the TableSwingWorker.
        * If there is a progressbar, the additional query to determine the maximum number of rows should also be here.
        * 
        * @return ResultSetWrapper
        */
        private ResultSetWrapper getResults()
        {
            return Oracle.getResultsActualSchedules(getFormComponent(), feeder, site, 365, "ALL");
        }
        
        /**
        * processResults
        * 
        * A reference to this method is passed to the TableSwingWorker as a Function.
        * This Function gets values for the current row of the table from the resultset.
        * If there is a progress bar the progress will be updated here in an invokeLater().
        * 
        * @param rs
        * @return Object[] single row of table
        */
        private Object[] processResults(ResultSet rs)
        {
            Object[] data = null;
            try
            {
                data = new Object[]
                {
                    rs.getString("MU"),              // idx_MU
                    rs.getDate("REPORTING_DATE"),    // idx_REPORTING_DATE
                    rs.getString("STATUS")           // idx_STATUS    
                };
                if (rs.getString("STATUS").equals("Requesting"))
                {
                    gotImporting = true;
                }
            }
            catch (SQLException ex)
            {
                Misc.errorMsgDatabase(getFormComponent(), ex, false, "SQL Error loading Actual Schedules data.");
                worker.cancel(true);
            }
            return data;
        }
        
        /**
        * finalizeRefresh
        * 
        * A reference to this method is passed to the TableSwingWorker as a Consumer - it's always called, whether the worker finishes or cancels.
        * This Consumer does work that needs to be done after building the table - primarily creating and configuring the JTable.
        * All code here will be run on the Event Dispatch Thread.
        * If the TableSwingWorker is cancelled ON the EDT, this code will be run immediately in-line.
        * If the TableSwingWorker is cancelled OFF the EDT, this code is enqueued on the EDT.
        * Once this code is executed, the table is finished and displayed, ready for the user.
        * 
        * @param cancelled true if the TableSwingWorker was cancelled
        */
        private void finalizeRefresh(Boolean cancelled)
        {
            if (!cancelled)
            {
                createTable(); //defined below inside this thread
                configureTable(); //defined below inside this thread
                
                // attempt to restore table selection and position
                table.setPreferredScrollableViewportSize(table.getPreferredSize());
                if (workingSelectedRow >= 0 && workingSelectedMu != null && workingSelectedDate != null && workingSelectedRow <= table.getRowCount() - 1)
                {
                    if (table.getValueAt(workingSelectedRow, idx_MU).equals(workingSelectedMu) &&
                        table.getValueAt(workingSelectedRow, idx_REPORTING_DATE).toString().equals(workingSelectedDate))
                    {
                        table.changeSelection(workingSelectedRow, 0, false, false);
                    }
                }
                workingSchedulesPane.setViewportView(table);
                revalidate();
                int position = workingScrollPosition + (table.getRowCount() - workingRowCount) * 16;
                if (workingScrollPosition != 0 && position > 0)
                {
                    workingSchedulesPane.getVerticalScrollBar().setValue(position);
                }
                
                if (gotSending || gotImporting)
                {
                    if (workingTimer.getDelay() != 30 * 1000)
                    {
                        workingTimer.setDelay(30 * 1000);
                        workingTimer.setInitialDelay(10 * 1000);
                        workingTimer.restart();
                    }
                }
                else if (workingTimer.getDelay() != 60 * 1000)
                {
                    workingTimer.setDelay(60 * 1000);
                    workingTimer.setInitialDelay(60 * 1000);
                    workingTimer.restart();
                }
            }
            refreshTableLock.release();
        }
        
        private void createTable()
        {
            table = new JTable(dataModel)
            {
                @Override
                public boolean isCellEditable(int row, int column)
                {
                    return false;
                }
                
                @Override
                public Class getColumnClass(int column)
                {
                    switch (column)
                    {
                        case idx_REPORTING_DATE:
                            return Date.class;
                        case idx_MU:
                        case idx_STATUS:
                        default:
                            return String.class;
                    }
                }
            };
        }
        
        private void configureTable()
        {
            table.addMouseListener(new MouseAdapter()
            {
                @Override
                public void mouseClicked(MouseEvent e)
                {
                    if (e.getClickCount() == 2)
                    {
                        SwingUtilities.invokeLater(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                int selectedRow = table.getSelectedRow();
                                if (selectedRow != -1)
                                {
                                    String mu = Misc.objectToString(table.getValueAt(selectedRow, idx_MU));
                                    Date reportingDate = (Date) table.getValueAt(selectedRow, idx_REPORTING_DATE);
                                    new Thread(new GenerateActualScheduleReportThread(mu, reportingDate)).start();
                                }
                            }
                        });
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    createSchedulePopup(e);
                }
            });
            
            Misc.configureTable(table, true, false, false);
            if (workingSortKeys != null)
            {
                table.getRowSorter().setSortKeys(workingSortKeys);
            }
            Misc.setHeaderRenderer(table, true, true, null);
            Misc.setColumnSettings(table, idx_MU, 50);
            Misc.setColumnSettings(table, idx_REPORTING_DATE, 75);
            Misc.setColumnSettings(table, idx_STATUS, 120);
        }
    }
    
    private void createSchedulePopup(MouseEvent e)
    {
        final JTable parentTable = (JTable) e.getComponent();
        final int row = parentTable.rowAtPoint(e.getPoint());
        if (row >= 0 && row < parentTable.getRowCount())
        {
            parentTable.setRowSelectionInterval(row, row);
        }
        else
        {
            parentTable.clearSelection();
        }
        
        int rowindex = parentTable.getSelectedRow();
        if (rowindex < 0)
        {
            return;
        }
        if (e.isPopupTrigger() && e.getComponent() instanceof JTable)
        {
            JPopupMenu popup = new JPopupMenu();
            JMenuItem openReportOption = new JMenuItem("Open Report");
            openReportOption.addActionListener(new java.awt.event.ActionListener()
            {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt)
                {
                    int selectedRow = parentTable.getSelectedRow();
                    if (selectedRow != -1)
                    {
                        String mu = Misc.objectToString(parentTable.getValueAt(selectedRow, idx_MU));
                        Date reportingDate = (Date) parentTable.getValueAt(selectedRow, idx_REPORTING_DATE);
                        new Thread(new GenerateActualScheduleReportThread(mu, reportingDate)).start();
                    }
                }
            });
            popup.add(openReportOption);
            popup.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    
    private void closeForm()
    {
        // stop the refresh timers if they haven't been already
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                if (workingTimer.isRunning())
                {
                    workingTimer.stop();
                }
            }
        });
        
        if (worker != null)
        {
            worker.cancel(true);
        }
        
        // close the form
        releaseInstance();
        refreshButton.setEnabled(true);
        dispose();
    }
    
    private static void releaseInstance()
    {
        instance = null;
    }
    
    private Component getFormComponent()
    {
        return this;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bodyPanel;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel feederLabel;
    private javax.swing.JPanel feederSitePanel;
    private javax.swing.JLabel fillerLabel;
    private javax.swing.JButton importButton;
    private javax.swing.JPanel importColumnPane;
    private javax.swing.JList<String> importSchedules;
    private javax.swing.JScrollPane importSchedulesPane;
    private javax.swing.JLabel loadingWorkingLabel;
    private javax.swing.JComboBox<String> pickDate;
    private javax.swing.JLabel pickDateLabel;
    private javax.swing.JButton refreshButton;
    private javax.swing.JCheckBox requestByMUCheckBox;
    private javax.swing.JPanel scheduleColumnsPanel;
    private javax.swing.JLabel siteLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JPanel titlePanel;
    private javax.swing.JPanel workingColumnPanel;
    private javax.swing.JButton workingScheduleOpenButton;
    private javax.swing.JScrollPane workingSchedulesPane;
    // End of variables declaration//GEN-END:variables
}
