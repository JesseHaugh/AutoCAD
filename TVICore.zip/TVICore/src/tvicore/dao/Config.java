package tvicore.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Properties;
import tvicore.miscellaneous.Encryption;
import tvicore.miscellaneous.Misc;

public class Config
{
    private String dbName;
    private String password1;
    private String password2;
    private Date effectiveDate1;
    private Date effectiveDate2;
    private String launcher_version;
    private String elink_version;
    private String infor_version;
    private String international_version;
    private String admin_version;
    private String userid;
    private String defaultClient;
    
    public Config()
    {
        // set the default values
        dbName = "TVI01P";
        launcher_version = "0";
        elink_version = "0";
        infor_version = "0";
        international_version = "0";
        admin_version = "0";
        userid = "DEFAULT";
        defaultClient = "NONE";
    }
    
    public void readFromFile()
    {
        try (InputStream input = new FileInputStream("TVIClient.cfg"))
        {
            Properties prop = new Properties();
            
            prop.load(input);
            
            dbName = Encryption.decryptDBName(prop.getProperty("db_name"));
            password1 = Encryption.decrypt256(prop.getProperty("db_login1"));
            password2 = Encryption.decrypt256(prop.getProperty("db_login2"));
            effectiveDate1 = Misc.stringToDateMDY(null, prop.getProperty("effective_date1"));
            effectiveDate2 = Misc.stringToDateMDY(null, prop.getProperty("effective_date2"));
            userid = prop.getProperty("userid");
            defaultClient = prop.getProperty("default_client");
            launcher_version = prop.getProperty("launcher_version");
            elink_version = prop.getProperty("elink_version");
            infor_version = prop.getProperty("infor_version");
            international_version = prop.getProperty("international_version");
            admin_version = prop.getProperty("admin_version");
            if (admin_version == null){
                admin_version = "5.7";
            }
        }
        catch (IOException | NullPointerException ex)
        {
            readFromFileOld();
        }
    }
    
    public void readFromFileOld()
    {
        try (BufferedReader file = new BufferedReader(new FileReader("TVIClient.cfg")))
        {
            effectiveDate1 = Misc.stringToDateMDY(null, file.readLine());
            password1 = Encryption.decrypt256(file.readLine());
            effectiveDate2 = Misc.stringToDateMDY(null, file.readLine());
            password2 = Encryption.decrypt256(file.readLine());
            String dbNameEncrypted = file.readLine();
            if (dbNameEncrypted != null)
            {
                if (dbNameEncrypted.length() > 2)
                {
                    dbName = Encryption.decryptDBName(dbNameEncrypted);
                }
            }
        }
        catch (IOException | NullPointerException ex)
        {
            Misc.errorMsgCritical(null, ex, "Failed to read values from config file, contact TVI support.");
        }
    }
    
    public void updateValues()
    {
        ResultSetWrapper results = Oracle.getClientConfig(null, null); // defaults to "ALL" client
        ResultSet rs = results.getResultSet();
        
        try
        {
            while (rs.next())
            {
                dbName = Encryption.decryptDBName(Misc.objectToString(rs.getObject("DBNAME")));
                password1 = Encryption.decrypt256(Misc.objectToString(rs.getObject("PASSWORD1")));
                effectiveDate1 = rs.getDate("EFFECTIVE_DATE1");
                password2 = Encryption.decrypt256(Misc.objectToString(rs.getObject("PASSWORD2")));
                effectiveDate2 = (rs.getDate("EFFECTIVE_DATE2"));
            }
        }
        catch (SQLException ex)
        {
            Misc.errorMsgDatabase(null, ex, true, "SQL Error retrieving client config data.");
        }
        finally
        {
            results.close();
        }
    }
    
    public void writeToFile()
    {
        try (OutputStream output = new FileOutputStream("TVIClient.cfg"))
        {
            Properties prop = new Properties();
            
            prop.setProperty("db_name", Encryption.encryptDBName(dbName));
            prop.setProperty("db_login1", Encryption.encrypt256(password1));
            prop.setProperty("db_login2", Encryption.encrypt256(password2));
            prop.setProperty("effective_date1", Misc.dateToStringMDY(effectiveDate1));
            prop.setProperty("effective_date2", Misc.dateToStringMDY(effectiveDate2));
            prop.setProperty("userid", userid);
            prop.setProperty("default_client", defaultClient);
            prop.setProperty("launcher_version", launcher_version);
            prop.setProperty("elink_version", elink_version);
            prop.setProperty("infor_version", infor_version);
            prop.setProperty("international_version", international_version);
            prop.setProperty("admin_version", admin_version);
            
            prop.store(output, null);
        }
        catch (IOException ex)
        {
            Misc.errorMsgDefault(null, ex, "Error writing config file, contact TVI Support.");
        }
    }
    
    public String getDbName()               { return dbName; }
    public String getPassword1()            { return password1; }
    public String getPassword2()            { return password2; }
    public Date getEffectiveDate1()         { return effectiveDate1; }
    public Date getEffectiveDate2()         { return effectiveDate2; }
    public String getUserid()               { return userid; }
    public String getDefaultClient()        { return defaultClient; }
    
    public void setUserid(String value)        { userid = value; }
    public void setDefaultClient(String value) { defaultClient = value; }
    
    public String getClientVersion(String clientName)
    {
        switch (clientName)
        {
            case "ALL":
                return launcher_version;
            case "ELINK":
                return elink_version;
            case "INFOR":
                return infor_version;
            case "INTERNATIONAL":
                return international_version;
            case "ADMIN":
		return admin_version;    
            default:
                return null;
        }
    }
    
    public void setClientVersion(String clientName, String value)
    {
        switch (clientName)
        {
            case "ALL":
                launcher_version = value;
                break;
            case "ELINK":
                elink_version = value;
                break;
            case "INFOR":
                infor_version = value;
                break;
            case "INTERNATIONAL":
                international_version = value;
                break;
            case "ADMIN":
                admin_version = value;
                break;
            default:
        }
    }
}
