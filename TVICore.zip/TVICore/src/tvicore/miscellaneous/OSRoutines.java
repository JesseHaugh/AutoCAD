package tvicore.miscellaneous;

import java.awt.Component;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

//Cross platform solution to view a PDF file
public class OSRoutines
{
    public static void openFileWithJava(Component parentFrame, String fileToOpenIn)
    {
        try
        {
            File fileToOpen = new File(fileToOpenIn);
            if (fileToOpen.exists())
            {
                if (Desktop.isDesktopSupported())
                {
                    Desktop.getDesktop().open(fileToOpen);
                }
                else
                {
                    Misc.msgbox(parentFrame, "Error opening file.", "File Cannot Be Opened", 1, 1, 1);
                }
            }
            else
            {
                Misc.msgbox(parentFrame, "File does not exist!", "File Cannot Be Opened", 1, 1, 1);
            }
        }
        catch (IOException ex)
        {
            Misc.msgbox(parentFrame, "IOException opening file.", "File Cannot Be Opened", 1, 1, 1);
        }
    }
    
    public static void openFileWithWindows(Component parentFrame, String fileToOpenIn)
    {
        try
        {
            File fileToOpen = new File(fileToOpenIn);
            if ((fileToOpen).exists())
            {
                Process p = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler" +  fileToOpen);
            }
            else
            {
                Misc.msgbox(parentFrame, "File does not exist!", "File Cannot Be Opened", 1, 1, 1);
            }
        }
        catch (IOException ex)
        {
            Misc.msgbox(parentFrame, "IOException opening file.", "File Cannot Be Opened", 1, 1, 1);
        }
    }
}