package tvicore.dao;

public class ShiftRecord
{
    private String hoursPerDay;
    private String unionFlags;
    
    public ShiftRecord(String hoursPerDay, String unionFlags)
    {
        this.hoursPerDay = hoursPerDay;
        this.unionFlags = unionFlags;
    }
    
    public String getHoursPerDay()
    {
        return hoursPerDay;
    }
    
    public void setHoursPerDay(String hoursPerDay)
    {
        this.hoursPerDay = hoursPerDay;
    }
    
    @Override
    public String toString()
    {
        return hoursPerDay;
    }
    
    public String getUnionFlags()
    {
        return unionFlags;
    }
    
    public void setUnionFlags(String unionFlags)
    {
        this.unionFlags = unionFlags;
    }
}