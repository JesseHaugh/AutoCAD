package tvicore.miscellaneous;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class Encryption
{
    private static final String SECRET_KEY = "sj65f65fn4iwf";
    private static final String SALT = "6g5l4d6g5j46";
    
    public static String encrypt256(String strToEncrypt)
    {
	try
	{
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
	}
	catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException ex)
	{
            Misc.errorMsgDefault(null, ex, "Error encrypting");
	}
	return null;
    }

    public static String decrypt256(String strToDecrypt)
    {
	try
	{
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKeySpec secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	}
	catch (InvalidAlgorithmParameterException | InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException ex)
	{
            Misc.errorMsgDefault(null, ex, "Error decrypting");
	}
	return null;
    }
    
    public static String decryptDBName(String nameIn)
    {
        boolean oddCounter = true;
        StringBuilder nameOut = new StringBuilder();
        for (int i = nameIn.length() - 1; i >= 0; i--)
        {
            if (oddCounter)
            {
                oddCounter = false;
                nameOut.append(nameIn.charAt(i));
            }
            else
            {
                oddCounter = true;
            }
        }
        return nameOut.toString();
    }
    
    public static String encryptDBName(String nameIn)
    {
        String fillerCharacters = "735XYA";
        StringBuilder nameOut = new StringBuilder();
        for (int i = nameIn.length() - 1; i >= 0; i--)
        {
            nameOut.append(fillerCharacters.charAt(i));
            nameOut.append(nameIn.charAt(i));
        }
        return nameOut.toString();
    }
}